<?php
// Cosmic Corner Book - API for JSON data handling
// Place this in the same directory as index.html and data.json

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$jsonFile = 'data.json';

// Read data
function readData() {
    global $jsonFile;
    if (!file_exists($jsonFile)) {
        return [
            'inventory' => [],
            'transactions' => [],
            'investments' => [],
            'maintenance' => [],
            'settings' => ['lastBackup' => null, 'currency' => 'USD']
        ];
    }
    return json_decode(file_get_contents($jsonFile), true);
}

// Write data
function writeData($data) {
    global $jsonFile;
    return file_put_contents($jsonFile, json_encode($data, JSON_PRETTY_PRINT));
}

// Handle requests
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $data = readData();
    
    switch ($action) {
        case 'read':
            echo json_encode(['success' => true, 'data' => $data]);
            break;
            
        case 'write':
            if ($method === 'POST') {
                $input = json_decode(file_get_contents('php://input'), true);
                if (writeData($input)) {
                    echo json_encode(['success' => true, 'message' => 'Data saved']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to write']);
                }
            }
            break;
            
        case 'backup':
            $backupFile = 'backups/backup_' . date('Y-m-d_His') . '.json';
            if (!is_dir('backups')) {
                mkdir('backups', 0755, true);
            }
            if (copy($jsonFile, $backupFile)) {
                echo json_encode(['success' => true, 'message' => 'Backup created']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Backup failed']);
            }
            break;
            
        case 'restore':
            if ($method === 'POST' && isset($_FILES['file'])) {
                $content = file_get_contents($_FILES['file']['tmp_name']);
                if (writeData(json_decode($content, true))) {
                    echo json_encode(['success' => true, 'message' => 'Data restored']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Restore failed']);
                }
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>