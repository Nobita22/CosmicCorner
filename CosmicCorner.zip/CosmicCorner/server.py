import http.server
import socketserver
import json
import os
from datetime import datetime
import uuid

PORT = 8000

class CosmicHandler(http.server.SimpleHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_POST(self):
        if self.path == '/save':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            with open('data.json', 'w', encoding='utf-8') as f:
                f.write(post_data.decode('utf-8'))
            self._send_json({"status": "success"})
            
        elif self.path == '/upload':
            ctype = self.headers['Content-Type']
            if 'multipart/form-data' in ctype:
                import cgi
                form = cgi.FieldStorage(
                    fp=self.rfile,
                    headers=self.headers,
                    environ={'REQUEST_METHOD': 'POST'}
                )
                if "file" in form:
                    fileitem = form["file"]
                    if fileitem.filename:
                        if not os.path.exists('Media'): os.makedirs('Media')
                        ext = os.path.splitext(fileitem.filename)[1]
                        filename = f"{uuid.uuid4().hex}{ext}"
                        with open(f"Media/{filename}", 'wb') as f:
                            f.write(fileitem.file.read())
                        self._send_json({"status": "success", "path": f"Media/{filename}"})
                        return
            self._send_json({"error": "Upload failed"}, 400)

    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def do_GET(self):
        if self.path == '/data.json':
            if not os.path.exists('data.json'):
                self._send_json({"inventory":[], "transactions":[], "investments":[], "maintenance":[], "settings":{"currency":"INR"}})
                return
        return http.server.SimpleHTTPRequestHandler.do_GET(self)

if __name__ == "__main__":
    if not os.path.exists('Media'): os.makedirs('Media')
    with socketserver.TCPServer(("", PORT), CosmicHandler) as httpd:
        print(f"Server at http://localhost:{PORT}")
        httpd.serve_forever()