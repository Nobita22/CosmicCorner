import http.server
import socketserver
import json
import os
import base64
from datetime import datetime

PORT = 8000

class CosmicHandler(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/save':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            
            try:
                # Save data to data.json
                with open('data.json', 'w') as f:
                    f.write(post_data.decode('utf-8'))
                
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "success"}).encode())
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode())
        
        elif self.path == '/upload-image':
            content_length = int(self.headers['Content-Length'])
            data = json.loads(self.rfile.read(content_length))
            
            image_data = data['image'] # base64 string
            filename = data['filename']
            
            if not os.path.exists('Media'):
                os.makedirs('Media')
            
            header, encoded = image_data.split(",", 1)
            with open(f"Media/{filename}", "wb") as f:
                f.write(base64.b64decode(encoded))
            
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps({"url": f"Media/{filename}"}).encode())

    def do_GET(self):
        return http.server.SimpleHTTPRequestHandler.do_GET(self)

if __name__ == "__main__":
    if not os.path.exists('Media'):
        os.makedirs('Media')
    
    with socketserver.TCPServer(("", PORT), CosmicHandler) as httpd:
        print(f"Cosmic Corner Book serving at port {PORT}")
        httpd.serve_forever()