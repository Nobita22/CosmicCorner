# Cosmic Corner Book
A modern 3D Printing Business Management Suite

## Features

- 🏠 **Dashboard** - Overview of revenue, profit, inventory value, and investments
- 📒 **Sales Ledger** - Track daily transactions with monthly/yearly filtering
- 📦 **Inventory Management** - Manage products with variants (e.g., colors, sizes)
- 📊 **Analytics** - Visual charts for profit, sales trends, and stock distribution
- 🏦 **Investments** - Track machinery, bulk orders, and one-time expenses
- 🧮 **Cost Calculator** - Calculate 3D print production costs
- 🔧 **Maintenance Log** - Track printer repairs and maintenance
- 📤 **Backup & Restore** - Export/import data as JSON

## File Structure

```
your-server/
├── index.html          # Main application
├── data.json           # Database file (auto-created)
├── api.php             # Optional server API for multi-device sync
├── backups/            # Auto-generated backups (if using api.php)
└── Media/              # Folder for storing images (optional)
```

## Setup Instructions

### Option 1: Local Storage (Simplest)
1. Upload `index.html` to your server
2. Open in browser - data is stored in your browser's local storage
3. Use Export button to backup your data regularly

### Option 2: Server-Based Storage (Recommended for multiple devices)
1. Upload all files (`index.html`, `data.json`, `api.php`) to your server
2. Ensure PHP is enabled on your server
3. Set proper file permissions:
   - `data.json` - writable (chmod 666)
   - `backups/` folder - writable (chmod 777)

## Quick Start

1. **Add Products** - Go to Inventory → Add Product
   - Enter product name, code, and category
   - Upload product image (camera supported on mobile)
   - Add variants with quantities

2. **Track Sales** - Go to Ledger → Add Sale
   - Select product and variant
   - Enter quantity, actual cost, and selling price
   - Stock is automatically deducted

3. **View Analytics** - Go to Analytics
   - Overview: Investment vs Returns
   - Sales: Top products, category breakdown
   - Inventory: Stock distribution, low stock alerts
   - Profit: Monthly trends, profit by product

4. **Calculate Costs** - Go to Cost Calculator
   - Enter electricity cost, printer power
   - Add material cost and weight
   - Get estimated production cost

## Theme

The application uses a modern black/white/gray gradient theme with:
- Animated twinkling stars background
- Glass-morphism effects
- Smooth animations and transitions
- Fully responsive (mobile & desktop)

## Data Backup

**Manual Backup:**
1. Click the database icon (top right) → Export Data
2. Save the JSON file to your computer

**Restore Data:**
1. Click the database icon → Import Data
2. Select your backup JSON file

## Browser Compatibility

- Chrome/Edge (recommended)
- Firefox
- Safari
- Works on mobile browsers

## Tips

- Use global search (top right) to quickly find products
- Low stock alerts appear in Analytics → Inventory tab
- Images are stored as base64 (embedded in data) for portability
- Digital clock shows IST (Indian Standard Time)

## Support

For issues or questions, check the console for error messages.