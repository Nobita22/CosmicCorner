# Cosmic Corner Book (Self-hosted SPA)

This repo is a **single-page** ERP/CRM for a small 3D printing business.

## Folder Structure

- `index.html` – the full SPA (UI + Tailwind + JS logic)
- `data.json` – flat-file database
- `server.py` – Python (stdlib) backend server (recommended)
- `api.php` – PHP backend (LAMP)
- `.htaccess` – optional Apache rewrites for `/save` and `/upload`
- `Media/` – uploaded files
  - `Products/`
  - `Receipts/`
  - `QR_Codes/`
- `Reports/` – generated exports (reserved)

## Data schema (inventory)

Inventory uses **product + variants**. Product has no price/cost/qty; those are stored per-variant.

```json
{
  "inventory": [
    {
      "id": 1767727628717,
      "name": "Spiral Fidget",
      "code": "000",
      "category": "Toy",
      "image": "Media/...jpg",
      "variants": [
        {
          "ext": "1",
          "name": "Spiral Fidget",
          "qty": 6,
          "actual": 1,
          "selling": 400,
          "image": "Media/...jpg"
        }
      ],
      "createdAt": "2026-01-06T19:27:08.717Z"
    }
  ]
}
```

## Run with Python (recommended)

### Windows (localhost)

```powershell
python server.py
```

Open:
- `http://localhost:8000`

Change port:

```powershell
$env:PORT="9000"; python server.py
```

### Android (Termux) (localhost)

```bash
pkg update
pkg install python
python server.py
```

Change port:

```bash
PORT=9000 python server.py
```

> Camera / QR scanning works on `http://localhost`.

## Run with PHP

### PHP built-in server

```bash
php -S 127.0.0.1:8000
```

Open:
- `http://localhost:8000`

> Note: rewrites won't work on PHP built-in server, but the frontend automatically falls back to `api.php?action=write` and `api.php?action=upload`.

## Notes

- Uploads are stored in `Media/Products/`.
- The system is designed for local use. CORS is enabled.