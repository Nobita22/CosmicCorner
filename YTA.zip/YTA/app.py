from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import sqlite3
import yt_dlp
import subprocess
import shutil
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
import random
import threading
import json
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SCHEDULED_FOLDER'] = 'scheduled'
app.config['THUMBNAILS_FOLDER'] = 'thumbnails'
app.config['DOWNLOADS_FOLDER'] = 'downloads'

# Create directories
for folder in [app.config['UPLOAD_FOLDER'], app.config['SCHEDULED_FOLDER'], 
               app.config['THUMBNAILS_FOLDER'], app.config['DOWNLOADS_FOLDER']]:
    os.makedirs(folder, exist_ok=True)

# Database setup
def init_db():
    conn = sqlite3.connect('videos.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS videos 
                 (id INTEGER PRIMARY KEY, name TEXT, description TEXT, 
                  file_path TEXT, thumbnail TEXT, status TEXT, created_at TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS schedules 
                 (id INTEGER PRIMARY KEY, video_id INTEGER, scheduled_time TEXT, 
                  status TEXT, youtube_id TEXT, thumbnail TEXT)''')
    conn.commit()
    conn.close()

init_db()

# YouTube API credentials (add your own)
YOUTUBE_API_KEY = "905709704870-0217jalfi2tu5l9okccges9bg0ocq3vj.apps.googleusercontent.com"
YOUTUBE_CLIENT_SECRETS = "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.json"

def send_notification(message):
    """Send Telegram/WhatsApp notification"""
    print(f"🚨 NOTIFICATION: {message}")  # Replace with actual notification service

def download_video(url, filename):
    """Download YouTube/Instagram short using yt-dlp"""
    ydl_opts = {
        'format': 'best[height<=1080]',
        'outtmpl': f'downloads/{filename}.%(ext)s',
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        return f"downloads/{filename}.mp4"
    except:
        return None

def create_thumbnail(video_path, output_path):
    """Extract thumbnail using FFmpeg"""
    cmd = f'ffmpeg -i {video_path} -ss 00:00:01 -vframes 1 -q:v 2 {output_path}'
    subprocess.run(cmd, shell=True, capture_output=True)

def midnight_scheduler():
    """Daily midnight: select 5 random videos and schedule"""
    conn = sqlite3.connect('videos.db')
    c = conn.cursor()
    
    # Get available videos
    c.execute("SELECT * FROM videos WHERE status='available'")
    videos = c.fetchall()
    
    if len(videos) < 5:
        send_notification(f"⚠️ Only {len(videos)} videos available. Need 5!")
        return
    
    selected = random.sample(videos, 5)
    schedules = []
    
    for video in selected:
        # Random time today between 9AM-10PM
        hour = random.randint(9, 22)
        minute = random.choice([0, 15, 30, 45])
        scheduled_time = datetime.now().replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        c.execute("INSERT INTO schedules (video_id, scheduled_time, status) VALUES (?, ?, 'scheduled')",
                 (video[0], scheduled_time.isoformat()))
        conn.commit()
        schedules.append({
            'video': video[1],
            'time': scheduled_time.strftime('%H:%M'),
            'id': video[0]
        })
    
    message = "📅 Today's Schedule:\n" + "\n".join([f"{s['video'][:30]}... at {s['time']}" for s in schedules])
    send_notification(message)
    conn.close()

# Start scheduler
scheduler = BackgroundScheduler()
scheduler.add_job(midnight_scheduler, 'cron', hour=0, minute=0)
scheduler.start()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_video():
    if 'file' in request.files:
        file = request.files['file']
        name = request.form['name']
        desc = request.form['description']
        if file.filename:
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            # Create thumbnail
            thumb_path = f"{app.config['THUMBNAILS_FOLDER']}/{name}.jpg"
            create_thumbnail(file_path, thumb_path)
            
            conn = sqlite3.connect('videos.db')
            c = conn.cursor()
            c.execute("INSERT INTO videos (name, description, file_path, thumbnail, status, created_at) VALUES (?, ?, ?, ?, 'available', ?)",
                     (name, desc, file_path, thumb_path, datetime.now().isoformat()))
            conn.commit()
            conn.close()
            return jsonify({'success': True})
    
    # Handle YouTube link
    url = request.form['url']
    if url:
        name = request.form['name']
        desc = request.form['description']
        filename = name.replace(' ', '_')
        file_path = download_video(url, filename)
        
        if file_path:
            thumb_path = f"{app.config['THUMBNAILS_FOLDER']}/{name}.jpg"
            create_thumbnail(file_path, thumb_path)
            
            conn = sqlite3.connect('videos.db')
            c = conn.cursor()
            c.execute("INSERT INTO videos (name, description, file_path, thumbnail, status, created_at) VALUES (?, ?, ?, ?, 'available', ?)",
                     (name, desc, file_path, thumb_path, datetime.now().isoformat()))
            conn.commit()
            conn.close()
            return jsonify({'success': True})
    
    return jsonify({'success': False})

@app.route('/schedules')
def schedules():
    conn = sqlite3.connect('videos.db')
    c = conn.cursor()
    c.execute('''SELECT s.*, v.name, v.description, v.thumbnail 
                 FROM schedules s JOIN videos v ON s.video_id = v.id 
                 ORDER BY s.scheduled_time''')
    data = c.fetchall()
    conn.close()
    return render_template('schedules.html', schedules=data)

@app.route('/api/schedules')
def api_schedules():
    conn = sqlite3.connect('videos.db')
    c = conn.cursor()
    c.execute('''SELECT s.*, v.name, v.description, v.file_path, v.thumbnail 
                 FROM schedules s JOIN videos v ON s.video_id = v.id 
                 ORDER BY s.scheduled_time''')
    schedules = []
    for row in c.fetchall():
        schedules.append({
            'id': row[0], 'video_id': row[1], 'scheduled_time': row[2],
            'status': row[3], 'youtube_id': row[4], 'name': row[6],
            'description': row[7], 'file_path': row[9], 'thumbnail': row[10]
        })
    conn.close()
    return jsonify(schedules)

@app.route('/update_schedule/<int:schedule_id>', methods=['POST'])
def update_schedule(schedule_id):
    data = request.json
    conn = sqlite3.connect('videos.db')
    c = conn.cursor()
    c.execute("UPDATE schedules SET scheduled_time=?, name=?, description=?, thumbnail=? WHERE id=?",
             (data['scheduled_time'], data['name'], data['description'], data['thumbnail'], schedule_id))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
