#!/bin/bash
echo "🚀 Starting YouTube Shorts Agent..."

# Create storage symlink
termux-setup-storage

# Install system deps if missing
pkg install -y ffmpeg termux-api

# Start server
cd "$(dirname "$0")"
nohup python3 app.py > server.log 2>&1 &
echo $! > server.pid

# Notifications
termux-toast "✅ Agent Started!" -g top
echo "📱 Access: http://localhost:5000"
echo "📊 Logs: tail -f server.log"
echo "🛑 Stop: pkill -f app.py"

# Auto-restart monitor
nohup bash -c '
while true; do
    sleep 300
    if ! pgrep -f "app.py" > /dev/null; then
        echo "$(date): Server crashed! Restarting..."
        cd '"$(pwd)"' && nohup python3 app.py > server.log 2>&1 &
        termux-toast "🔄 Auto-restarted!"
    fi
done' &
