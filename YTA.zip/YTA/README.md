# 🚀 YouTube Shorts Automation Agent

## 📱 One-Click Setup (Termux)

```bash
# 1. Unzip project
unzip youtube-shorts-agent.zip
cd youtube-shorts-agent

# 2. Install everything
pip install -r requirements.txt

# 3. One-click start
chmod +x start.sh
./start.sh

# 4. Open browser
# http://localhost:5000
