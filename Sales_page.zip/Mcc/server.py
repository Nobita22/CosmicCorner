#!/usr/bin/env python3
"""
Simple Python Server for Product Form
Works on both Windows and Termux (Android)

Run: python server.py
Then open: http://localhost:8000
"""

import json
import os
from http.server import HTTPServer, SimpleHTTPRequestHandler

DATA_FILE = 'data.json'

class FormHandler(SimpleHTTPRequestHandler):
    
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        request_data = json.loads(post_data.decode('utf-8'))
        
        if self.path == '/save':
            # Load existing data
            data = self.load_data()
            
            # Append new item
            data.append(request_data)
            
            # Save to JSON file
            self.save_data(data)
            
            # Send success response
            self.send_json_response({'status': 'success'})
            print(f"✅ Saved: {request_data['productName']} - Qty: {request_data['qty']} - ${request_data['amount']}")
        
        elif self.path == '/edit':
            # Load existing data
            data = self.load_data()
            index = request_data['index']
            
            if 0 <= index < len(data):
                # Update the item
                data[index]['productName'] = request_data['productName']
                data[index]['qty'] = request_data['qty']
                data[index]['amount'] = request_data['amount']
                
                self.save_data(data)
                self.send_json_response({'status': 'success'})
                print(f"✏️ Edited entry {index}")
            else:
                self.send_json_response({'status': 'error', 'message': 'Invalid index'}, 400)
        
        elif self.path == '/delete':
            # Load existing data
            data = self.load_data()
            index = request_data['index']
            
            if 0 <= index < len(data):
                deleted = data.pop(index)
                self.save_data(data)
                self.send_json_response({'status': 'success'})
                print(f"🗑️ Deleted: {deleted['productName']}")
            else:
                self.send_json_response({'status': 'error', 'message': 'Invalid index'}, 400)
        
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_GET(self):
        if self.path == '/data':
            data = self.load_data()
            self.send_json_response(data)
        else:
            super().do_GET()
    
    def load_data(self):
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                return []
        return []
    
    def save_data(self, data):
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def send_json_response(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

def run_server(port=8000):
    server_address = ('', port)
    httpd = HTTPServer(server_address, FormHandler)
    
    print("=" * 40)
    print("  Product Form Server")
    print("=" * 40)
    print(f"  http://localhost:{port}")
    print(f"  Data file: {DATA_FILE}")
    print("=" * 40)
    print("  Press Ctrl+C to stop")
    print("=" * 40)
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
        httpd.shutdown()

if __name__ == '__main__':
    run_server()