# NOBITA - Quick Reference Cheat Sheet

## Command Line

```bash
# Start NOBITA
python MainServer.py

# Kill MainServer (press in terminal)
Ctrl+C

# Kill specific port (Windows)
netstat -ano | findstr :9001
taskkill /PID 12345 /F

# Kill specific port (Mac/Linux)
lsof -i :9001
kill -9 12345

# Check Python installation
python --version
```

## Dashboard URLs

```
Main Dashboard:    http://localhost:9000
SampleApp:         http://localhost:9001
First Custom App:  http://localhost:9002
```

## config.json Structure

```json
{
  "folders": {
    "SampleApp": 9001,
    "MyApp": 9002
  },
  "last_port": 9002,
  "metadata": {
    "SampleApp": {
      "description": "Sample application"
    }
  }
}
```

## Minimal server.py

```python
#!/usr/bin/env python3
import json
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

def get_port():
    config = Path(__file__).parent.parent / "config.json"
    with open(config) as f:
        folder = Path(__file__).parent.name
        return json.load(f)["folders"].get(folder, 9999)

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)

if __name__ == "__main__":
    HTTPServer(('0.0.0.0', get_port()), Handler).serve_forever()
```

## Server.py with API

```python
def do_GET(self):
    if self.path == '/api/hello':
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"message": "Hello World"}')
    else:
        super().do_GET()

def do_POST(self):
    if self.path == '/api/submit':
        content_length = int(self.headers['Content-Length'])
        body = self.rfile.read(content_length)
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"success": true}')
```

## Testing APIs with curl

```bash
# GET request
curl http://localhost:9001/api/hello

# POST request
curl -X POST http://localhost:9001/api/submit \
  -H "Content-Type: application/json" \
  -d '{"name": "Alice"}'

# GET with query
curl "http://localhost:9001/api/data?id=123"
```

## Testing APIs with JavaScript

```javascript
// GET request
fetch('http://localhost:9001/api/hello')
  .then(r => r.json())
  .then(d => console.log(d))

// POST request
fetch('http://localhost:9001/api/submit', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({name: 'Alice'})
})
  .then(r => r.json())
  .then(d => console.log(d))
```

## File Structure Template

```
MyApp/
├── server.py              (Required)
├── index.html             (Required)
├── data.json              (Optional)
├── icon.png               (Optional, 256x256+)
├── media/
│   ├── style.css
│   ├── script.js
│   ├── logo.png
│   └── ...
└── [optional: database.db, logs/, etc.]
```

## Valid Folder Names

```
✓ MyApp
✓ my_app
✓ my-app
✓ MyApp123
✓ test_app_v1

✗ My App         (space)
✗ my-app!        (special character)
✗ 123app         (starts with number)
✗ .hidden        (starts with dot)
✗ __pycache__    (starts with __)
```

## Main API Endpoints

```
GET  /api/servers              List all servers
POST /api/servers              Create server
GET  /api/servers/{name}       Get server info
PUT  /api/servers/{name}       Update server
DELETE /api/servers/{name}     Delete server
POST /api/servers/{name}/start Start server
POST /api/servers/{name}/stop  Stop server
```

## HTTP Status Codes

```
200 - OK (success)
201 - Created
400 - Bad Request (invalid input)
404 - Not Found (endpoint doesn't exist)
500 - Server Error (crash in code)
```

## Keyboard Shortcuts (Dashboard)

```
Ctrl+N    New server
Ctrl+R    Refresh
Esc       Close modal
```

## JSON Response Format

```javascript
// Success
{
  "success": true,
  "message": "Operation completed",
  "data": {...}
}

// Error
{
  "success": false,
  "error": "Description of error"
}

// List
{
  "servers": [
    {"name": "App1", "port": 9001, "status": "running"},
    {"name": "App2", "port": 9002, "status": "stopped"}
  ]
}
```

## Dashboard Features

| Button | Action |
|--------|--------|
| ➕ New Server | Create server |
| 🔄 Refresh | Update server list |
| ▶️ Play | Start server |
| ⏹️ Stop | Stop server |
| ✏️ Edit | Rename/change port |
| 🗑️ Trash | Delete server |
| ℹ️ Info | Show details |

## Common Errors & Fixes

```
Error: Address already in use
Fix: Kill process on that port

Error: No module named 'flask'
Fix: Don't import third-party libraries (use built-in only)

Error: FileNotFoundError: server.py
Fix: Ensure server.py exists in folder

Error: JSON decode error
Fix: Validate JSON format at jsonlint.com

Error: Connection refused
Fix: Check if MainServer is running
```

## Environment Info

```bash
# Check Python version
python --version
# Should be 3.6+

# Check current directory
pwd (Mac/Linux) or cd (Windows)
# Should be NOBITA folder

# List files in current directory
ls (Mac/Linux) or dir (Windows)
# Should see: MainServer.py, config.json, SampleApp, etc.
```

## Troubleshooting Flow

```
Issue: Can't access dashboard
  ↓
Check: Is MainServer running?
  ↓ No
Start: python MainServer.py
  ↓
Check: Port 9000 available?
  ↓ No
Kill: Process on port 9000
  ↓
Try: Open http://localhost:9000
  ↓
Success ✓ or Still broken ✗
  ↓ Broken
Read: TROUBLESHOOTING_FAQ.md
```

## Performance Tips

```
Speed up:
  - Stop unused servers
  - Close background apps
  - Use local network (not internet)
  - Optimize server code
  - Use caching

Optimize memory:
  - Don't store large data in memory
  - Use database instead
  - Clear logs regularly

Optimize disk:
  - Compress old files
  - Move data to database
  - Delete unused servers
```

## Backup & Restore

```bash
# Backup NOBITA folder
# Windows
xcopy NOBITA NOBITA_backup /I /S /E

# Mac/Linux
cp -r NOBITA NOBITA_backup

# Restore (if something breaks)
rm -rf NOBITA
cp -r NOBITA_backup NOBITA
python MainServer.py
```

## Best Practices

```
DO:
  ✓ Read port from config.json
  ✓ Use folder name in logs
  ✓ Handle shutdown gracefully
  ✓ Include index.html
  ✓ Add icon.png
  ✓ Create data.json
  ✓ Use try-except blocks
  ✓ Test APIs with curl first

DON'T:
  ✗ Hardcode port numbers
  ✗ Use non-standard modules
  ✗ Ignore error messages
  ✗ Skip index.html
  ✗ Store secrets in config.json
  ✗ Use relative paths
  ✗ Forget to handle Ctrl+C
```

## Documentation Quick Links

| File | Purpose | Read Time |
|------|---------|-----------|
| QUICK_START.md | Getting started | 5-10 min |
| DETAILED_GUIDE.md | Technical details | 20 min |
| ARCHITECTURE.md | System design | 15 min |
| CUSTOM_SERVER_TEMPLATE.py | Code examples | 10 min |
| TROUBLESHOOTING_FAQ.md | Problem solving | As needed |
| README_COMPREHENSIVE.md | Navigation | 5 min |

## One-Liners

```bash
# Start and open dashboard
python MainServer.py && open http://localhost:9000

# Check if port is free
lsof -i :9000 || echo "Port 9000 is free"

# Count running servers
ps aux | grep "python" | wc -l

# List all folders
ls -d */

# Create new app folder structure
mkdir MyApp && touch MyApp/server.py MyApp/index.html MyApp/data.json
```

## Port Assignments Example

```
MainServer:       9000
SampleApp:        9001
MyApp:            9002
TestApp:          9003
ProductionApp:    9004
...
Next free port:   9005 (auto-assigned)
```

## Decision Tree

```
Want to get started?
  → python MainServer.py
  
Need help?
  → Read QUICK_START.md
  
Want to understand how it works?
  → Read DETAILED_GUIDE.md
  
Want to see diagrams?
  → Read ARCHITECTURE.md
  
Want code examples?
  → Review CUSTOM_SERVER_TEMPLATE.py
  
Something broken?
  → Check TROUBLESHOOTING_FAQ.md
  
Lost in documentation?
  → Read README_COMPREHENSIVE.md
```

## Pro Tips

1. Use `curl` to test APIs before building UI
2. Add logging to server.py for debugging
3. Create folder structure before creating server
4. Always include icon.png for professional look
5. Use descriptive folder names
6. Document your APIs with comments
7. Test with multiple browser tabs
8. Keep config.json backed up
9. Monitor console output for errors
10. Restart MainServer if unsure

---

**Print this sheet! Keep it handy! 📋**
