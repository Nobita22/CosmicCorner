# NOBITA - Detailed Technical Guide

## Table of Contents
1. [MainServer.py Architecture](#mainserverpy-architecture)
2. [How to Create Server.py for New Folders](#how-to-create-serverpy-for-new-folders)
3. [Configuration Management](#configuration-management)
4. [API Endpoints Reference](#api-endpoints-reference)
5. [Troubleshooting](#troubleshooting)

---

## MainServer.py Architecture

### Overview
MainServer.py is the central orchestrator that manages multiple sub-servers running on different ports. It:
- Hosts the web dashboard on port 9000
- Scans for subfolders and launches their servers
- Manages folder creation, deletion, and updates
- Handles all API requests from the dashboard
- Maintains configuration in config.json

### Key Components

#### 1. **Global Configuration**
```python
MAIN_PORT = 9000                    # Dashboard port
START_PORT = 9001                   # First sub-server port
CONFIG_FILE = "config.json"         # Configuration storage
BASE_DIR = Path(__file__).parent    # NOBITA root directory
```

**What it does:**
- `MAIN_PORT (9000)`: Where the dashboard is hosted
- `START_PORT (9001)`: First port for sub-servers (increments for each new server)
- Ports range from 9001 onwards (9002, 9003, 9004...)

#### 2. **Configuration File (config.json)**
```json
{
  "folders": {
    "SampleApp": 9001,
    "MyApp": 9002,
    "TestApp": 9003
  },
  "last_port": 9003,
  "metadata": {
    "SampleApp": {
      "description": "A sample application"
    }
  }
}
```

**How it works:**
- `folders`: Maps folder names to their assigned ports
- `last_port`: Tracks the highest port assigned (for auto-increment)
- `metadata`: Stores descriptions and other info about folders

#### 3. **Loading Configuration**
```python
def load_config():
    """Load configuration from config.json"""
    config_path = BASE_DIR / CONFIG_FILE
    if config_path.exists():
        with open(config_path, 'r') as f:
            return json.load(f)
    return {"folders": {}, "last_port": START_PORT - 1, "metadata": {}}
```

**Flow:**
1. Check if config.json exists
2. If yes: Parse and return the JSON data
3. If no: Return default empty configuration
4. This ensures MainServer always has a valid config to work with

#### 4. **Port Assignment Logic**
```python
def get_next_port(config):
    """Get the next available port number"""
    used_ports = set(config["folders"].values())
    port = config.get("last_port", START_PORT - 1) + 1
    while port in used_ports:
        port += 1
    return port
```

**Step-by-step:**
1. Get all currently used ports from config
2. Start from `last_port + 1` (e.g., if last was 9003, start at 9004)
3. Loop until we find a port not in `used_ports`
4. Return the first available port

**Example:**
```
If last_port = 9003:
  - used_ports = {9001, 9002, 9003}
  - Next port = 9004 (not in used_ports, so return it)

If last_port = 9003 and port 9004 is somehow taken:
  - Loop increments to 9005
  - 9005 not in used_ports, so return 9005
```

#### 5. **Folder Scanning**
```python
def scan_folders():
    """Scan for subdirectories that could be server folders"""
    folders = []
    for item in BASE_DIR.iterdir():
        if item.is_dir() and not item.name.startswith('.') and not item.name.startswith('__'):
            folders.append(item.name)
    return folders
```

**What it does:**
1. Iterate through all items in NOBITA directory
2. Include only directories (folders)
3. Exclude hidden folders (starting with `.`) and Python packages (starting with `__`)
4. Return list of valid folder names

**Example:**
```
NOBITA/
├── SampleApp/       ✓ Included
├── MyApp/           ✓ Included
├── .git/            ✗ Excluded (starts with .)
├── __pycache__/     ✗ Excluded (starts with __)
└── MainServer.py    ✗ Not a folder
```

#### 6. **Creating Folder Structure**
```python
def create_folder_structure(folder_name, port, description=""):
    """Create a new server folder with default files"""
```

**Creates these files:**
- `server.py` - The individual server (explained below)
- `index.html` - Default frontend
- `data.json` - Server metadata
- `media/` - Assets folder

**Generated server.py includes:**
- Port configuration auto-read from config.json
- HTTP request handling
- Logging for debugging

#### 7. **Starting Servers**
```python
def start_server(folder_name, port):
    """Start a server process for a folder"""
    folder_path = BASE_DIR / folder_name
    server_script = folder_path / "server.py"
    
    process = subprocess.Popen(
        [sys.executable, str(server_script)],
        cwd=str(folder_path),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        start_new_session=True
    )
```

**How it works:**
1. Find the folder's `server.py`
2. Use `subprocess.Popen()` to launch it as a separate process
3. `start_new_session=True` allows independent process management
4. Store process info in `server_processes` dictionary

**Key points:**
- Each server runs independently
- Each server listens on its own port
- Servers can be stopped without affecting others
- Uses process groups for clean shutdown

#### 8. **Stopping Servers**
```python
def stop_server(folder_name):
    """Stop a server process"""
    if folder_name in server_processes:
        proc_info = server_processes[folder_name]
        process = proc_info["process"]
        try:
            os.killpg(os.getpgid(process.pid), signal.SIGTERM)
            process.wait(timeout=5)
        except:
            process.kill()
        del server_processes[folder_name]
```

**Process:**
1. Get the process from storage
2. Send SIGTERM signal to gracefully shut down
3. Wait up to 5 seconds for graceful shutdown
4. If timeout, force kill the process
5. Remove from tracking dictionary

#### 9. **Synchronizing Folders**
```python
def sync_folders():
    """Synchronize folders with config"""
    config = load_config()
    current_folders = scan_folders()
    
    # Add new folders to config
    for folder in current_folders:
        if folder not in config["folders"]:
            port = get_next_port(config)
            config["folders"][folder] = port
            config["last_port"] = port
    
    # Remove deleted folders from config
    folders_to_remove = [f for f in config["folders"] if f not in current_folders]
    for folder in folders_to_remove:
        del config["folders"][folder]
    
    save_config(config)
    return config
```

**Handles three scenarios:**

**Scenario 1: New Folder Added**
```
Disk has: [SampleApp, MyApp, NewFolder]
Config has: {SampleApp: 9001, MyApp: 9002}

Result:
- NewFolder gets port 9003
- Config updated to: {SampleApp: 9001, MyApp: 9002, NewFolder: 9003}
```

**Scenario 2: Folder Deleted**
```
Disk has: [SampleApp]
Config has: {SampleApp: 9001, DeletedApp: 9002}

Result:
- DeletedApp removed from config
- Config becomes: {SampleApp: 9001}
```

**Scenario 3: No Changes**
```
Disk and Config match - Config unchanged
```

#### 10. **HTTP Request Handler (DashboardHandler)**
```python
class DashboardHandler(SimpleHTTPRequestHandler):
```

This class handles all HTTP requests. Key methods:

**do_GET() - Handle GET requests:**
- `/api/servers` → Return list of all servers with status
- `/api/config` → Return configuration file
- `/api/servers/{name}` → Return specific server info
- Static files → Serve index.html and other assets

**do_POST() - Handle POST requests:**
- `/api/servers` → Create new server
- `/api/servers/{name}/start` → Start server
- `/api/servers/{name}/stop` → Stop server
- `/api/refresh` → Rescan folders

**do_PUT() - Handle PUT requests:**
- `/api/servers/{name}` → Update server (rename, change port)

**do_DELETE() - Handle DELETE requests:**
- `/api/servers/{name}` → Delete server folder

#### 11. **Initialization Sequence**
```python
def initialize_servers():
    """Initialize all servers on startup"""
    config = sync_folders()
    
    for folder_name, port in config["folders"].items():
        folder_path = BASE_DIR / folder_name
        if (folder_path / "server.py").exists():
            start_server(folder_name, port)
```

**On startup:**
1. Sync folders with config
2. For each folder in config:
   - Check if server.py exists
   - If yes: Start the server process
   - If no: Log warning and skip

#### 12. **Cleanup on Shutdown**
```python
def cleanup():
    """Stop all servers on shutdown"""
    print("\n[SHUTDOWN] Stopping all servers...")
    for folder_name in list(server_processes.keys()):
        stop_server(folder_name)
```

**On Ctrl+C or system shutdown:**
1. Gracefully stop all server processes
2. Update config
3. Exit cleanly

---

## How to Create Server.py for New Folders

### Method 1: Automatic Creation (Recommended)

When you create a server via the dashboard:
1. Dashboard sends POST request to `/api/servers`
2. MainServer.py automatically creates:
   - Folder
   - server.py (auto-generated)
   - index.html (template)
   - data.json (metadata)
   - media/ (assets folder)

**No manual work needed!**

### Method 2: Manual Creation

If you want to create a folder manually and write server.py yourself:

#### Step 1: Create Folder Structure
```bash
mkdir MyCustomApp
cd MyCustomApp
```

#### Step 2: Create server.py

**Minimal server.py:**
```python
#!/usr/bin/env python3
"""
Server for MyCustomApp
"""

import json
import sys
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

# Get port from MainServer's config
def get_port():
    config_path = Path(__file__).parent.parent / "config.json"
    if config_path.exists():
        with open(config_path, 'r') as f:
            config = json.load(f)
            return config.get("folders", {}).get("MyCustomApp", 9999)
    return 9999

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # Serve files from current folder
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)
    
    def log_message(self, format, *args):
        # Custom logging
        print(f"[MyCustomApp] {args[0]}")

if __name__ == "__main__":
    port = get_port()
    server = HTTPServer(('0.0.0.0', port), Handler)
    print(f"[MyCustomApp] Server running on http://localhost:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print(f"\n[MyCustomApp] Server stopped")
        server.shutdown()
```

**Key points:**
1. `get_port()` reads from config.json to know its assigned port
2. `Handler` extends `SimpleHTTPRequestHandler` to serve static files
3. `directory=str(Path(__file__).parent)` serves files from the folder
4. Custom logging with `[FolderName]` prefix for easy debugging

#### Step 3: Create index.html

**Simple example:**
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyCustomApp</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-gray-900 text-white flex items-center justify-center min-h-screen">
    <div class="text-center">
        <h1 class="text-4xl font-bold mb-4">MyCustomApp</h1>
        <p class="text-gray-400 mb-6">Running successfully!</p>
        <a href="http://localhost:9000" class="px-6 py-2 bg-indigo-600 rounded-lg hover:bg-indigo-700">
            Back to Dashboard
        </a>
    </div>
</body>
</html>
```

#### Step 4: Create data.json
```json
{
  "name": "MyCustomApp",
  "created": "2024-01-15 10:30:00",
  "description": "My custom application",
  "port": 9009,
  "version": "1.0.0"
}
```

#### Step 5: Update config.json Manually
```json
{
  "folders": {
    "SampleApp": 9001,
    "MyCustomApp": 9009
  },
  "last_port": 9009,
  "metadata": {
    "SampleApp": {
      "description": "Sample app"
    },
    "MyCustomApp": {
      "description": "My custom application"
    }
  }
}
```

#### Step 6: Restart MainServer.py
```bash
python MainServer.py
```

MainServer will:
1. Scan and find MyCustomApp folder
2. Load port from config.json
3. Launch its server.py on that port
4. Display on dashboard

### Method 3: Advanced Custom API

If you want to add custom API endpoints:

```python
def do_GET(self):
    if self.path == '/api/custom-data':
        # Return custom JSON data
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        
        data = {
            "name": "MyCustomApp",
            "status": "healthy",
            "uptime": "2 hours"
        }
        self.wfile.write(json.dumps(data).encode())
    
    elif self.path == '/api/users':
        # Return list of users
        users = [
            {"id": 1, "name": "Alice"},
            {"id": 2, "name": "Bob"}
        ]
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(users).encode())
    
    else:
        # Default: serve static files
        super().do_GET()

def do_POST(self):
    if self.path == '/api/submit':
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)
        data = json.loads(body)
        
        # Process the data
        print(f"Received: {data}")
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        
        response = {"success": True, "message": "Data received"}
        self.wfile.write(json.dumps(response).encode())
    else:
        super().do_POST()
```

### Method 4: Using Icon

Add an icon to your folder for the dashboard:

1. **Save image as icon.png** in your folder
   ```
   MyCustomApp/
   ├── icon.png          ← Add this (256x256 or larger)
   ├── server.py
   ├── index.html
   ├── data.json
   └── media/
   ```

2. **MainServer detects it automatically:**
   - Checks for `icon.png`, `icon.jpg`, `icon.jpeg`, `icon.gif`, `icon.svg`
   - Serves it from `/{FolderName}/icon.png`
   - Dashboard displays it on the card

---

## Configuration Management

### Adding Server Manually to config.json

```json
{
  "folders": {
    "ExistingApp": 9001,
    "NewApp": 9010
  },
  "last_port": 9010,
  "metadata": {
    "ExistingApp": {
      "description": "Existing application"
    },
    "NewApp": {
      "description": "New application"
    }
  }
}
```

### Modifying Ports

**Before:**
```json
"folders": {
  "MyApp": 9001
}
```

**After:**
```json
"folders": {
  "MyApp": 9050
}
```

**Then:** Restart MainServer.py

---

## API Endpoints Reference

### GET Endpoints

**Get all servers:**
```
GET /api/servers
Response:
{
  "servers": [
    {
      "name": "SampleApp",
      "port": 9001,
      "status": "running",
      "icon": "/SampleApp/icon.png",
      "description": "Sample app"
    }
  ],
  "main_port": 9000
}
```

**Get server info:**
```
GET /api/servers/SampleApp
Response:
{
  "name": "SampleApp",
  "port": 9001,
  "status": "running",
  "description": "Sample app"
}
```

### POST Endpoints

**Create server:**
```
POST /api/servers
Body: {
  "name": "NewApp",
  "port": null,           // null for auto-assign
  "description": "My app"
}
Response: {"success": true, "name": "NewApp", "port": 9002}
```

**Start server:**
```
POST /api/servers/SampleApp/start
Response: {"success": true}
```

**Stop server:**
```
POST /api/servers/SampleApp/stop
Response: {"success": true}
```

### PUT Endpoints

**Update server:**
```
PUT /api/servers/OldName
Body: {
  "name": "NewName",
  "port": 9050
}
Response: {"success": true, "name": "NewName", "port": 9050}
```

### DELETE Endpoints

**Delete server:**
```
DELETE /api/servers/SampleApp
Response: {"success": true}
```

---

## Troubleshooting

### Issue: "Address already in use"
```
Error: Address already in use (port 9000 or 9001)
```

**Solution:**
1. Find process: `lsof -i :9000` (Mac/Linux) or `netstat -ano | findstr :9000` (Windows)
2. Kill process: `kill -9 <PID>` or use Task Manager
3. Restart MainServer.py

### Issue: Server won't start
```
[ERROR] Failed to start SampleApp: FileNotFoundError
```

**Solution:**
- Check if `server.py` exists in folder
- Check if file has execution permissions: `chmod +x server.py`
- Check Python is in PATH: `python --version`

### Issue: Port shows as "Stopped"
```
Dashboard shows status as "stopped" even though it should run
```

**Solution:**
1. Check if server.py has errors: Run manually `python SampleApp/server.py`
2. Check console logs for errors
3. Ensure port is not blocked by firewall

### Issue: New folder not detected
```
Created folder but it doesn't appear on dashboard
```

**Solution:**
1. Folder must be direct child of NOBITA (not nested)
2. Folder name can't start with `.` or `__`
3. Click "Refresh" button or restart MainServer.py

### Issue: Port conflicts
```
Trying to use port 9001 but already in use by another server
```

**Solution:**
1. Leave port blank in creation form (auto-assign)
2. Or manually specify an unused port (9050, 9100, etc.)
3. Check current config.json for used ports

---

## Summary

**MainServer.py Flow:**
1. Load config.json
2. Scan for folders
3. Sync new/deleted folders
4. Assign ports to new folders
5. Start each folder's server.py on its port
6. Host dashboard on 9000
7. Handle API requests
8. Gracefully shutdown on Ctrl+C

**Creating Server.py:**
1. Read port from config.json
2. Create HTTP server on that port
3. Serve static files or custom APIs
4. Handle requests with custom logic
5. Support graceful shutdown

**Best Practices:**
- Always read port dynamically from config.json
- Use try-except for graceful error handling
- Add logging with `[FolderName]` prefix
- Create icon.png for dashboard display
- Include data.json with metadata
