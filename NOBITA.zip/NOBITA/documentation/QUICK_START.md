# NOBITA - Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Step 1: Start MainServer
```bash
python MainServer.py
```

You should see:
```
==================================================
NOBITA - Multi-Server Hosting System
==================================================

[STARTED] SampleApp on port 9001 (PID: 12345)

--------------------------------------------------
Dashboard: http://localhost:9000
--------------------------------------------------
```

### Step 2: Open Dashboard
Open your browser: **http://localhost:9000**

You'll see the SampleApp server card with:
- ✅ Status: Running
- 🔌 Port: 9001
- 📋 Description: A sample application

### Step 3: Create Your First Server

**Option A: Using Dashboard (Easiest)**

1. Click **"+ New Server"** button
2. Enter folder name: `MyApp`
3. Leave port blank (auto-assign)
4. Click **"Create Server"**

MainServer will automatically:
- ✅ Create MyApp/ folder
- ✅ Generate server.py
- ✅ Generate index.html
- ✅ Assign port 9002
- ✅ Start the server
- ✅ Display on dashboard

**Option B: Manual Creation**

1. Create folder: `mkdir MyApp`
2. Create `MyApp/server.py` (see template below)
3. Restart MainServer: `python MainServer.py`
4. Done! Server appears on dashboard

---

## 📝 Creating Custom Server.py

### Simplest Possible server.py

Copy this minimal template:

```python
#!/usr/bin/env python3
import json
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

def get_port():
    config = Path(__file__).parent.parent / "config.json"
    with open(config) as f:
        folder = Path(__file__).parent.name
        return json.load(f)["folders"].get(folder, 9999)

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)
    
    def log_message(self, format, *args):
        print(f"[{Path(__file__).parent.name}] {args[0]}")

if __name__ == "__main__":
    port = get_port()
    HTTPServer(('0.0.0.0', port), Handler).serve_forever()
```

**Key points:**
- `get_port()`: Reads port from MainServer's config.json
- `Handler`: Serves files from the MyApp folder
- `log_message()`: Adds folder name to logs for easy debugging

### Adding Custom API Endpoints

Add this to your server.py's `do_GET()` method:

```python
def do_GET(self):
    if self.path == '/api/hello':
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"message": "Hello World"}')
    else:
        super().do_GET()
```

Test it:
```bash
curl http://localhost:9002/api/hello
# Output: {"message": "Hello World"}
```

### Adding POST Handler

```python
def do_POST(self):
    if self.path == '/api/submit':
        content_length = int(self.headers['Content-Length'])
        body = self.rfile.read(content_length)
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"success": true}')
    else:
        super().do_POST()
```

Test it:
```bash
curl -X POST http://localhost:9002/api/submit \
  -H "Content-Type: application/json" \
  -d '{"name": "Alice"}'
# Output: {"success": true}
```

---

## 📁 Recommended Folder Structure

```
NOBITA/
├── MainServer.py
├── index.html
├── config.json
│
├── SampleApp/
│   ├── server.py
│   ├── index.html
│   ├── data.json
│   ├── icon.png
│   └── media/
│
└── MyApp/
    ├── server.py              ← Your custom server
    ├── index.html             ← Your frontend
    ├── data.json              ← Your metadata
    ├── icon.png               ← Dashboard icon
    ├── media/
    │   ├── logo.png
    │   ├── style.css
    │   └── script.js
    └── database/              ← Optional
        └── data.db
```

---

## 🎯 Common Tasks

### Task 1: Change Server Port

1. **Via Dashboard:**
   - Click Edit (pencil icon) on server card
   - Change port number
   - Click "Save Changes"

2. **Manually:**
   - Edit config.json
   - Change port number
   - Restart MainServer.py

### Task 2: Rename Folder

1. **Via Dashboard:**
   - Click Edit on server card
   - Change folder name
   - Click "Save Changes"
   - Dashboard renames folder automatically

### Task 3: Delete Server

1. **Via Dashboard:**
   - Click Delete (trash icon) on server card
   - Confirm deletion
   - Folder and all files removed

### Task 4: Add Server Icon

1. **Create icon:** Save as PNG, JPG, or SVG
2. **Place it:** Save to `MyApp/icon.png`
3. **Restart:** Restart MainServer.py
4. **Done:** Icon appears on dashboard card

### Task 5: Add Custom Data

**Create data.json:**
```json
{
  "name": "MyApp",
  "description": "My awesome application",
  "version": "1.0.0",
  "author": "John Doe",
  "features": [
    "Real-time updates",
    "User authentication",
    "Data analytics"
  ]
}
```

**Fetch in JavaScript:**
```javascript
fetch('http://localhost:9002/api/data')
  .then(r => r.json())
  .then(d => console.log(d))
```

---

## 🔍 Understanding config.json

### Initial State
```json
{
  "folders": {
    "SampleApp": 9001
  },
  "last_port": 9001,
  "metadata": {
    "SampleApp": {
      "description": "Sample app"
    }
  }
}
```

### After Adding MyApp
```json
{
  "folders": {
    "SampleApp": 9001,
    "MyApp": 9002
  },
  "last_port": 9002,
  "metadata": {
    "SampleApp": {
      "description": "Sample app"
    },
    "MyApp": {
      "description": "My custom app"
    }
  }
}
```

### Key Fields

| Field | Purpose | Example |
|-------|---------|---------|
| `folders` | Maps folder names to ports | `{"MyApp": 9002}` |
| `last_port` | Highest port assigned | `9002` |
| `metadata` | Folder descriptions | `{"MyApp": {"description": "..."}}` |

**Auto-increment logic:**
```
If last_port = 9002
Next new folder gets port = 9003
Then last_port = 9003
```

---

## 🐛 Debugging

### Check if Server is Running

```bash
# On Mac/Linux
lsof -i :9002

# On Windows
netstat -ano | findstr :9002
```

### View Server Logs

When you start MainServer.py, look for:
```
[MyApp] GET /index.html 200
[MyApp] GET /api/data 200
[MyApp] POST /api/submit 200
```

### Common Errors

**Error: Address already in use**
```
Error: Address already in use (port 9002)
Solution: Kill process on that port or use different port
```

**Error: No server.py found**
```
[SKIP] MyApp - No server.py found
Solution: Create server.py in MyApp folder
```

**Error: Module not found**
```
ModuleNotFoundError: No module named 'flask'
Solution: Use only built-in modules (http.server)
```

---

## 💡 Pro Tips

### Tip 1: Dynamic Port Reading
Always read port from config.json, never hardcode:

```python
# ✅ Good
port = get_port()  # Reads from config.json

# ❌ Bad
port = 9002  # Hardcoded!
```

### Tip 2: Add Logging
Use folder name in logs for easy debugging:

```python
def log_message(self, format, *args):
    folder = Path(__file__).parent.name
    print(f"[{folder}] {args[0]}")
```

Output: `[MyApp] GET /index.html 200`

### Tip 3: Use CORS Headers
Allow requests from other ports:

```python
self.send_header('Access-Control-Allow-Origin', '*')
```

### Tip 4: Test with curl
```bash
# GET request
curl http://localhost:9002/api/hello

# POST request
curl -X POST http://localhost:9002/api/submit \
  -H "Content-Type: application/json" \
  -d '{"key": "value"}'
```

### Tip 5: Auto-reload Development
Use watchdog for development:

```bash
pip install watchdog
watchmedo shell-command \
  --patterns="*.py" \
  --recursive \
  --command='python MainServer.py' \
  .
```

---

## 📚 Learning Path

1. **Start here:** Run MainServer.py, explore dashboard
2. **Create server:** Use dashboard to create first server
3. **Add files:** Create index.html with basic content
4. **Add APIs:** Implement custom /api/ endpoints
5. **Add icon:** Add icon.png to folder
6. **Scale up:** Create multiple servers
7. **Advanced:** Add databases, authentication, WebSockets

---

## 🎓 Example: Complete MyApp

### File: MyApp/server.py
```python
#!/usr/bin/env python3
import json
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import time

def get_port():
    config = Path(__file__).parent.parent / "config.json"
    with open(config) as f:
        folder = Path(__file__).parent.name
        return json.load(f)["folders"].get(folder, 9999)

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)
    
    def log_message(self, format, *args):
        folder = Path(__file__).parent.name
        print(f"[{folder}] {args[0]}")
    
    def do_GET(self):
        if self.path == '/api/status':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            status = {
                "status": "healthy",
                "uptime": "2 hours",
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.wfile.write(json.dumps(status).encode())
        else:
            super().do_GET()

if __name__ == "__main__":
    port = get_port()
    folder = Path(__file__).parent.name
    print(f"[{folder}] Running on http://localhost:{port}")
    HTTPServer(('0.0.0.0', port), Handler).serve_forever()
```

### File: MyApp/index.html
```html
<!DOCTYPE html>
<html>
<head>
    <title>MyApp</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-gray-900 text-white">
    <div class="flex items-center justify-center min-h-screen">
        <div class="text-center">
            <h1 class="text-4xl font-bold mb-4">MyApp</h1>
            <button onclick="checkStatus()" class="px-6 py-2 bg-blue-600 rounded">
                Check Status
            </button>
            <div id="status" class="mt-4"></div>
        </div>
    </div>
    <script>
        async function checkStatus() {
            const res = await fetch('/api/status');
            const data = await res.json();
            document.getElementById('status').textContent = JSON.stringify(data, null, 2);
        }
    </script>
</body>
</html>
```

### File: MyApp/data.json
```json
{
  "name": "MyApp",
  "version": "1.0.0",
  "description": "My custom application"
}
```

That's it! You now have a fully functional server running on the NOBITA platform.

---

## 🔗 Next Steps

1. Read **DETAILED_GUIDE.md** for deep technical knowledge
2. Check **CUSTOM_SERVER_TEMPLATE.py** for advanced features
3. Explore the MainServer.py source code
4. Build amazing applications!

---

## 📞 Support

If you encounter issues:
1. Check the console output for error messages
2. Review DETAILED_GUIDE.md troubleshooting section
3. Test your server manually: `python MyApp/server.py`
4. Verify ports aren't blocked by firewall
5. Restart MainServer.py

---

**Happy coding! 🚀**
