const CACHE_NAME = 'nobita-v1';
let CACHE_ENABLED = true;

const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json'
];

// Listen for messages from page
self.addEventListener('message', event => {
  if (event.data === 'CLEAR_AND_DISABLE_CACHE') {
    CACHE_ENABLED = false;
    caches.keys().then(names =>
      Promise.all(names.map(n => caches.delete(n)))
    );
    console.log('[SW] Cache cleared and disabled');
  }

  if (event.data === 'ENABLE_CACHE') {
    CACHE_ENABLED = true;
    console.log('[SW] Cache enabled');
  }
});

// Install
self.addEventListener('install', event => {
  self.skipWaiting();

  if (!CACHE_ENABLED) return;

  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache))
  );
});

// Activate
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(names =>
      Promise.all(
        names.map(name => {
          if (name !== CACHE_NAME) {
            return caches.delete(name);
          }
        })
      )
    ).then(() => self.clients.claim())
  );
});

// Fetch
self.addEventListener('fetch', event => {
  if (!CACHE_ENABLED) {
    // NETWORK ONLY (no cache)
    event.respondWith(fetch(event.request));
    return;
  }

  event.respondWith(
    caches.match(event.request).then(response => {
      if (response) return response;

      return fetch(event.request).then(networkResponse => {
        if (networkResponse && networkResponse.status === 200) {
          const clone = networkResponse.clone();
          caches.open(CACHE_NAME).then(cache =>
            cache.put(event.request, clone)
          );
        }
        return networkResponse;
      });
    })
  );
});
