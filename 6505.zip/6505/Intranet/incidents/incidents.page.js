/* incidents.page.js */
const Incidents = (() => {
    return {
        openIncidentView
    };
})();
