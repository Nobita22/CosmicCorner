function collectFormAData() {

            // =========================
            // Section 6 – Data Items
            // =========================
                const dataItems = Array.from(document.querySelectorAll('input[name="dataItems"]')).map(cb => cb.value);
                // console.log(dataItems)
                const formDataA = {

                    // =========================
                    // Header Information
                    // =========================
                    reportedDate:
                        document.getElementById('reportedDate')?.textContent ||
                        new Date().toLocaleDateString('en-GB'),

                    csirtEmail: 'infosec@toshiba-ttdi.com',

                    // =========================
                    // CSIRT Leader
                    // =========================
                    csirtName: 'Marumoto Shuichiro',
                    csirtJobTitle: 'CSIRT Leader',
                    csirtDivision: 'IT Security Division',

                    // =========================
                    // Department Information
                    // =========================
                    companyName: 'TOSHIBA-TTDI',
                    department:
                        document.querySelector('#formatAContent input[placeholder*="department"]')?.value ||
                        'N/A',

                    // =========================
                    // Person Making Report
                    // =========================
                    reporterName: document.getElementById('currentUserName')?.textContent || 'N/A',
                    reporterJobTitle: document.getElementById('currenttitle')?.textContent || 'N/A',
                    reporterPhone: document.getElementById('currentphone')?.textContent || 'N/A',

                    // =========================
                    // Person Involved
                    // =========================
                    personInvolvedName: document.getElementById('empName')?.textContent || 'N/A',
                    personInvolvedJobTitle: document.getElementById('empJobTitle')?.textContent || 'N/A',
                    personInvolvedId: document.getElementById('empId')?.textContent || 'N/A',
                    personInvolvedDept: document.getElementById('empDept')?.textContent || 'N/A',
                    personInvolvedDivision: document.getElementById('empDiv')?.textContent || 'N/A',
                    personInvolvedPhone: document.getElementById('empPhone')?.textContent || 'N/A',
                    personInvolvedEmail: document.getElementById('empEmail')?.textContent || 'N/A',

                    jobCategory:
                        document.querySelector('input[name="jobCategory"]:checked')?.value || 'N/A',
                    outsourcee:
                        document.querySelector('input[name="outsourcee"]')?.value || 'N/A',

                    // =========================
                    // Incident Type
                    // =========================
                    incidentType:
                        document.querySelector('input[name="incidentType"]:checked')?.value || 'N/A',

                    // =========================
                    // Theft / Loss
                    // =========================
                    theftItems: getSelectedCheckboxValues('input[name="theftItem"]:checked'),
                    theftItemOther:
                        document.querySelector('input[name="theftItem"][value="Other"]')?.checked
                            ? document
                                .querySelector('input[name="theftItem"][value="Other"]')
                                ?.parentElement.querySelector('input[type="text"]')?.value
                            : '',

                    // =========================
                    // Wrong Destination
                    // =========================
                    wrongDestMethods: getSelectedCheckboxValues(
                        'input[name="wrongDestMethod"]:checked'
                    ),
                    wrongDestMethodOther:
                        document.querySelector('input[name="wrongDestMethod"][value="Other"]')?.checked
                            ? document
                                .querySelector('input[name="wrongDestMethod"][value="Other"]')
                                ?.parentElement.querySelector('input[type="text"]')?.value
                            : '',

                    // =========================
                    // Section 1 – Report Status
                    // =========================
                    // reportStatus:
                    //     document.querySelector('input[name="reportStatus"]:checked')?.value ||
                    //     'First',

                    // =========================
                    // Section 2 & 3 – Date / Time
                    // =========================
                    incidentDateTime:
                        document.querySelectorAll('#formatAContent input[type="datetime-local"]')[0]
                            ?.value || 'N/A',

                    discoveredDateTime:
                        document.querySelectorAll('#formatAContent input[type="datetime-local"]')[1]
                            ?.value || 'N/A',

                    // =========================
                    // Section 4 – Detection
                    // =========================
                    whatMadeNotice:
                        document.querySelector('textarea[placeholder*="what made you notice"]')?.value ||
                        '',

                    locationOccurred:
                        document.querySelector('#section4Card input[placeholder*="Office"]')?.value ||
                        'N/A',

                    alcoholIntake:
                        document.querySelector('input[name="alcoholIntake"]:checked')?.value || 'N/A',

                    // =========================
                    // Section 5 – Incident Overview
                    // =========================
                    incidentOverview:
                        document.querySelector(
                            '#formatAContent textarea[placeholder*="comprehensive overview"]'
                        )?.value || 'N/A',

                    // =========================
                    // ✅ Section 6 – Information Leaked
                    // =========================
                    infoLeaked:
                        document.querySelector(
                            '#formatAContent textarea[placeholder*="information at risk"]'
                        )?.value || 'N/A',

                    dataItems: dataItems, // ✅ FIXED

                    recordsCount: document.querySelectorAll('input[type="number"]')[0]?.value || '0',
                    customersInfo: document.querySelectorAll('input[type="number"]')[1]?.value || '0',
                    employeesInfo: document.querySelectorAll('input[type="number"]')[2]?.value || '0',
                    otherContacts: document.querySelectorAll('input[type="number"]')[3]?.value || '0',

                    secondaryDamage:
                        document.querySelector('input[name="secondaryDamage"]:checked')?.value ||
                        'N/A',

                    secondaryDamageDesc:
                        document.querySelector('textarea[placeholder*="If possible"]')?.value || '',

                    // =========================
                    // Section 7 – Theft/Loss Security Measures
                    // =========================
                    managerPermission:
                        document.querySelector('input[name="managerPermission"]:checked')?.value ||
                        'N/A',

                    passwordTypes: getSelectedCheckboxValues(
                        'input[name="passwordType"]:checked'
                    ),

                    passwordOther:
                        document.querySelector('input[name="passwordType"][value="other"]')?.checked
                            ? document
                                .querySelector('input[name="passwordType"][value="other"]')
                                ?.parentElement.querySelector('input[type="text"]')?.value
                            : '',

                    windowsEncryption:
                        document.querySelector('input[name="windowsEncryption"]:checked')?.value ||
                        'N/A',

                    encryptionTools: getSelectedCheckboxValues(
                        'input[name="encryptionTool"]:checked'
                    ),

                    encryptionToolOther:
                        document.querySelector('input[name="encryptionTool"][value="other"]')?.checked
                            ? document
                                .querySelector('input[name="encryptionTool"][value="other"]')
                                ?.parentElement.querySelector('input[type="text"]')?.value
                            : '',

                    storageEncryption:
                        document.querySelector('input[name="storageEncryption"]:checked')?.value ||
                        'N/A',

                    lossPreventionStrap:
                        document.querySelector('input[name="lossPreventionStrap"]:checked')?.value ||
                        'N/A',

                    securityMeasuresOther:
                        document.querySelector(
                            '#section7TheftLossContent textarea[placeholder*="other security"]'
                        )?.value || '',

                    // =========================
                    // Section 8 – Post-Incident (Theft/Loss)
                    // =========================
                    searchedPlace:
                        document.querySelector(
                            'input[name="searchActions"][value="searchedPlace"]'
                        )?.checked || false,

                    searchedPlaceDesc:
                        document.querySelector(
                            'input[name="searchActions"][value="searchedPlace"]'
                        )?.checked
                            ? document
                                .querySelector(
                                    'input[name="searchActions"][value="searchedPlace"]'
                                )
                                ?.parentElement.querySelector('input[type="text"]')?.value
                            : '',

                    gpsSearch:
                        document.querySelector(
                            'input[name="searchActions"][value="gpsSearch"]'
                        )?.checked || false,

                    gpsResult:
                        document.querySelector('input[name="gpsResult"]:checked')?.value || 'N/A',

                    notSubjectGPS:
                        document.querySelector(
                            'input[name="searchActions"][value="notSubjectGPS"]'
                        )?.checked || false,

                    reportedTransport:
                        document.querySelector(
                            'input[name="searchActions"][value="reportedTransport"]'
                        )?.checked || false,

                    reportedTransportDateTime:
                        document.querySelectorAll('input[type="datetime-local"]')[2]?.value || '',

                    reportedTransportPlace:
                        document.querySelector(
                            'input[placeholder*="Station name"]'
                        )?.value || '',

                    reportedPolice:
                        document.querySelector(
                            'input[name="searchActions"][value="reportedPolice"]'
                        )?.checked || false,

                    reportedPoliceDateTime:
                        document.querySelectorAll('input[type="datetime-local"]')[3]?.value || '',

                    reportedPolicePlace:
                        document.querySelector(
                            'input[placeholder*="Police station"]'
                        )?.value || '',

                    disableIntranet:
                        document.querySelector(
                            'input[name="damageMinimization"][value="disableIntranet"]'
                        )?.checked || false,

                    disableIntranetNA:
                        document.querySelector('input[name="disableIntranetNA"]')?.checked || false,

                    remoteWipe:
                        document.querySelector(
                            'input[name="damageMinimization"][value="remoteWipe"]'
                        )?.checked || false,

                    remoteWipeResult:
                        document.querySelector('input[name="remoteWipeResult"]:checked')?.value ||
                        'N/A',

                    remoteWipeNA:
                        document.querySelector('input[name="remoteWipeNA"]')?.checked || false,

                    closeLine:
                        document.querySelector(
                            'input[name="damageMinimization"][value="closeLine"]'
                        )?.checked || false,

                    phoneNumber:
                        document.querySelector('input[type="tel"]')?.value || '',

                    closeLineNA:
                        document.querySelector('input[name="closeLineNA"]')?.checked || false,

                    otherActionsTheft:
                        document.querySelector(
                            '#section8TheftLossContent textarea[placeholder*="other actions"]'
                        )?.value || '',

                    // =========================
                    // Section 8 – Wrong Destination
                    // =========================
                    deleteRequest:
                        document.querySelector('input[name="deleteRequest"]:checked')?.value ||
                        'N/A',

                    deleteRequestReason:
                        document.querySelector(
                            '#section8WrongDestContent textarea[placeholder*="why deletion"]'
                        )?.value || '',

                    otherActionsWrongDest:
                        document.querySelector(
                            '#section8WrongDestContent textarea[placeholder*="email recall"]'
                        )?.value || '',

                    // =========================
                    // Section 9 – Timeline
                    // =========================
                    timeline: getTimelineDataA(),

                    // =========================
                    // Section 10 – Causes
                    // =========================
                    assumedCauses:
                        document.querySelector(
                            'textarea[placeholder*="assumed root causes"]'
                        )?.value || '',

                    // =========================
                    // Section 11 – Preventive Measures
                    // =========================
                    preventiveMeasures:
                        document.querySelector(
                            'textarea[placeholder*="preventive measures"]'
                        )?.value || '',

                    responsiblePerson: 'Kaza Saritha, Head of IT Department',

                    completionDate:
                        document.querySelector('#formatAContent input[type="date"]')?.value || '',

                    // =========================
                    // Section 12 – Remarks
                    // =========================
                    remarks:
                        document.querySelector(
                            'textarea[placeholder*="Additional remarks"]'
                        )?.value || ''
                };

            return formDataA;
        }