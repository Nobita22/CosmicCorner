 function generateFormAReport() {
            
            // const formData = new FormData(this);

            // // Loop through all fields
            // formData.forEach((value, name) => {
            //     console.log(name + ":", value);
            // });

            const data = collectFormAData();
            currentFormDataA = data;

            const reportHTMLA = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Information Security Incident Report - Form A</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; font-size: 12px; }
                    .report-container { max-width: 1200px; margin: 0 auto; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    table, th, td { border: 1px solid #000; }
                    th, td { padding: 8px; text-align: left; vertical-align: top; }
                    th { background: #f0f0f0; font-weight: 600; width: 40%; }
                    .header-section { background: #1d4ed8; color: white; padding: 15px; margin-bottom: 20px; }
                    .section-title { background: #e8f4f8; font-weight: bold; padding: 10px; margin-top: 15px; }
                    .review-btn { 
                        background: #3b82f6; 
                        color: white; 
                        padding: 12px 30px; 
                        border: none; 
                        border-radius: 5px; 
                        cursor: pointer; 
                        font-size: 14px;
                        margin: 20px 0;
                    }
                    .review-btn:hover { background: #2563eb; }
                    .editable { background: #fffbeb; }
                    textarea { width: 100%; min-height: 60px; padding: 5px; }
                    input[type="text"], input[type="date"], input[type="datetime-local"] { 
                        width: 100%; padding: 5px; 
                    }
                    
                    input[type="checkbox"]:disabled {
                        opacity: 0.8;
                        cursor: default;
                    }
                </style>
            </head>
            <body>
                <div class="report-container">
                    <div class="header-section">
                        <h2>Information Security Incident Report (Format A)</h2>
                        <p>Use this format when "Theft/loss Information Devices/Medium," or "Sending Emails, etc. to wrong destination" occur.</p>
                    </div>

                    <!-- Top Section -->
                    <table>
                        <tr>
                            <th>Reported on:</th>
                            <td>${data.reportedDate}</td>
                        </tr>
                        <tr>
                            <th>To:</th>
                            <td>Manager of Cyber Security Center of Corporate Technology Planning Div.<br>
                            (email address: HDQ-CSEC-head@ml.toshiba.co.jp)</td>
                        </tr>
                        <tr>
                            <th>Scope of disclosure:</th>
                            <td>Cyber Security Center of Corporate Technology Planning Div., Legal Affairs Div., reporting division/department, and those permitted by the managers thereof</td>
                        </tr>
                    </table>

                    <!-- CSIRT Leader Section -->
                    <table>
                        <tr>
                            <th colspan="2" class="section-title">CSIRT Leader of Toshiba or Key group company (Division in Charge)</th>
                        </tr>
                        <tr>
                            <th>Name</th>
                            <td>Marumoto Shuichiro</td>
                        </tr>
                        <tr>
                            <th>Designation and Division</th>
                            <td>Director, CO</td>
                        </tr>
                    </table>

                    <!-- Department Information -->
                    <table>
                        <tr>
                            <th colspan="2" class="section-title">Case Details</th>
                        </tr>
                        <tr>
                            <th>Company name & department</th>
                            <td>${data.companyName}, ${data.personInvolvedDept}</td>
                        </tr>
                        <tr>
                            <th>Name, job title and phone of person making report</th>
                            <td>${data.reporterName}, ${data.reporterJobTitle} (Phone: ${data.reporterPhone})</td>
                        </tr>
                        <tr>
                            <th>Job category, job title and name of the person involved in incident</th>
                            <td id="edit-personInvolved">
                                Name & Job Title: ${data.personInvolvedName}, ${data.personInvolvedJobTitle}<br>
                                Job category: ${data.personInvolvedDivision}<br>
                            </td>
                        </tr>
                    </table>

                    <!-- Incident Type -->
                    <table>
                        <tr>
                            <th colspan="2" class="section-title">Incident Type and Device Involved</th>
                        </tr>
                        ${data.incidentType === 'theftLoss' ? `
                        <tr>
                            <th style="width: 40%;">
                                <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                                Theft/loss
                            </th>
                            <td>${data.theftItems.join(', ')}</td>
                        </tr>
                        ` : ''}
                        ${data.incidentType === 'wrongDestination' ? `
                        <tr>
                            <th style="width: 40%;">
                                <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                                Sending to wrong destination (to a person outside Toshiba Group)
                            </th>
                            <td>${data.wrongDestMethods.join(', ')}</td>
                        </tr>
                        ` : ''}
                    </table>


                    <!-- Main Content Sections 1-12 -->
                    <table>
                        <tr>
                            <th>1. Report status</th>
                            <td class="editable" id="edit-reportStatus">${data.reportStatus}</td>
                        </tr>
                        <tr>
                            <th>2. Date and time of incident</th>
                            <td>${data.incidentDateTime}</td>
                        </tr>
                        <tr>
                            <th>3. Date and time of incident discovered</th>
                            <td>${data.discoveredDateTime}</td>
                        </tr>
                        <tr>
                            <th>4. What Made You Notice Incident</th>
                            <td></td>
                        </tr>
                        <tr>
                            <th>5. Incident overview<br><small>* General overview of incident, including causes</small></th>
                            <td><div class="incident-overview-section">
                                ${data.incidentOverview}<br><br>
                                <small>＜Fill in the following section if the incident is Theft/loss＞</small><br>
                                Location of theft/loss: ${data.locationOccurred}<br>
                                Alcohol intake: ${data.alcoholIntake}
                            </div></td>
                        </tr>
                        <tr>
                            <th>6. Information that was, or can possibly be, leaked<br><small>* If a loss includes customers' information, write their company names.</small></th>
                            <td id="edit-infoLeaked">
                                <label class="editable">${data.infoLeaked}</label><br><br>
                                <small>＜Fill in the following section if the incident includes loss of personal information＞</small><br>
                                <strong>Data items:</strong>
                                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-top: 8px;">
                                    <label><input class="editable" disabled type="checkbox"  ${data.dataItems.name ? 'checked' : ''} > Name</label>
                                    <label><input class="editable" disabled type="checkbox"  ${data.dataItems.birthDate ? 'checked' : ''}> Birth date</label>
                                    <label><input class="editable" disabled type="checkbox"  ${data.dataItems.gender ? 'checked' : ''}> Gender</label>
                                    <label><input class="editable" type="checkbox" disabled ${data.dataItems.address ? 'checked' : ''}> Address</label>
                                    <label><input class="editable" type="checkbox" disabled ${data.dataItems.phone ? 'checked' : ''}> Phone number</label>
                                    <label><input class="editable" type="checkbox" disabled ${data.dataItems.email ? 'checked' : ''}> Email address</label>
                                    <label><input class="editable" type="checkbox" disabled ${data.dataItems.other ? 'checked' : ''}> Other</label>
                                </div><br>
                                Records on: <label class="editable"> ${data.recordsCount}</label> people<br> 
                                (Breakdown: Customers' info. <label class="editable">${data.customersInfo}</label>,<br> 
                                Employees' info. <label class="editable">${data.employeesInfo}</label>,<br> 
                                Other contacts <label class="editable">${data.otherContacts})</label><br>
                                Secondary damage in event of misuse: <label class="editable">${data.secondaryDamage}</label> <br>
                                Description- <label class="editable">${data.secondaryDamageDesc}</label>
                            </td>
                        </tr>
                    </table>

                    <!-- Section 7: Information Security Measures (if Theft/Loss) -->
                    ${data.incidentType === 'theftLoss' ? `
                    <table>
                        <tr>
                            <th colspan="2" class="section-title">7. Information security measures that were taken</th>
                        </tr>
                        <tr>
                            <th rowspan="1">Permission from manager to take out a device</th>
                            <td id="edit-managerPermission"><input class="editable" type="checkbox">Obtained permission (incl. blanket permission covering predefined period)<br>
                            <input class="editable" type="checkbox">Not obtained permission</td>
                        </tr>
                        <tr>
                            <th>Password (incl. fingerprint authentication)</th>
                            <td id="edit-password">
                                <input class="editable" type="checkbox">At boot time 
                                <input class="editable" type="checkbox">On OS startup 
                                <input class="editable" type="checkbox">When unlocking screen<br>
                                <input class="editable" type="checkbox">When exiting Sleep mode <input class="editable" type="checkbox">Other<input class="editable" type="text" placeholder=" "><br>
                                <input class="editable" type="checkbox">Not subject to this requirement
                            </td>
                        </tr>
                        <tr>
                            <th>Encryption</th>
                            <td colspan="2" id="edit-encryption">
                                <strong>&lt;For Windows PCs and storage media.&gt;</strong><br>
                                Windows PC: <input class="editable" type="radio"> Encrypted <br>
                                (Encryption tool: <input class="editable" type="checkbox">BitLocker <input class="editable" type="checkbox">Other<input class="editable" placeholder=" " type="text" style="max-width: 40%;"> <br>
                                <input class="editable" type="radio">Not encrypted<br>
                                Storage medium: <input class="editable" type="checkbox">All company information has been encrypted. <br>
                                <input class="editable" type="checkbox"> There is unencrypted company information.
                            </td>
                        </tr>
                        <tr>
                            <th>Loss prevention measures</th>
                            <td colspan="2" id="edit-lossPrevention">
                                <strong>&lt;Required for cell phones and smartphones&gt;</strong><br>
                                <input class="editable" type="checkbox">Device did not have strap.<br>
                                <input class="editable" type="checkbox">Device had strap, but person concerned neglected to clip it to cloths or bag.<br>
                                <input class="editable" type="checkbox">Device had strap, and person concerned had it clipped to clothes or bag.
                            </td>
                        </tr>
                        <tr>
                            <th>Local wipe</th>
                            <td colspan="2" id="edit-localWipe">
                                <strong>&lt;For iOS and Android devices&gt;</strong><br>
                                ☑ Registered 
                            </td>
                        </tr>
                        <tr>
                            <th>MDM registration</th>
                            <td colspan="2" id="edit-mdm">
                                <strong>&lt;For iOS and Android devices&gt;</strong><br>
                                ☑ Registered 
                            </td>
                        </tr>
                        <tr>
                            <th>Others</th>
                            <td colspan="2" class="editable" id="edit-securityOther"></td>
                        </tr>
                    </table>

                    <!-- Section 8: Post-incident responses -->
                    <<table>
                        <tr>
                            <th colspan="3" class="section-title">8. Post-incident responses<br><small>* Actions taken to minimize potential damage</small></th>
                        </tr>
                        <tr>
                            <th rowspan="4">Searching & reporting</th>
                            <td id="edit-searchedPlace"><input class="editable" type="checkbox"></input> Searched likely place ( )</td>
                        </tr>
                        <tr>
                            <td id="edit-gps"><input class="editable" type="checkbox">Performed GPS search. (Result: <input class="editable" type="radio">Succeeded <input class="editable" type="radio">Failed)<br>
                            <input class="editable" type="checkbox"></input>Not subject to GPS search</td>
                        </tr>
                        <tr>
                            <td id="edit-transportReport"><input class="editable" type="checkbox"> Reported loss to transport (Date and time: ${data.reportedTransportDateTime || ''}, Reported place: ${data.reportedTransportPlace || ''})</td>
                        </tr>
                        <tr>
                            <td id="edit-policeReport"><input class="editable" type="checkbox"> Reported loss to the police (Date and time: ${data.reportedPoliceDateTime || ''}, Reported place: ${data.reportedPolicePlace || ''})</td>
                        </tr>
                        <tr>
                            <th>Measures taken to minimize damage</th>
                            <td id="edit-damageMinimization">
                                <input class="editable" type="checkbox"></input>Requested overseeing department to disable lost device to connect to Intranet (e.g., certificate revocation)<br>
                                <input class="editable" type="checkbox"></input>Requested overseeing department to execute remote wipe. (Result: ${data.remoteWipeResult})<br>
                                <input class="editable" type="checkbox"></input>Requested carrier to close communication line. (Telephone number: ${data.phoneNumber})
                            </td>
                        </tr>
                        <tr>
                            <th>Others</th>
                            <td colspan="2" id="edit-postIncidentOther"><input class="editable" type="text">${data.otherActionsTheft || ''}</input></td>
                        </tr>
                    </table>
                    ` : ''}

                    <!-- Section 8: For Wrong Destination -->
                    ${data.incidentType === 'wrongDestination' ? `
                    <table>
                        <tr>
                            <th colspan="2" class="section-title">7. Information security measures that were taken</th>
                        </tr>
                        <tr>
                            <th></th>
                            <td></td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <th colspan="2" class="section-title">8. Post-incident responses<br><small>* Actions taken to minimize potential damage</small></th>
                        </tr>
                        <tr>
                            <th>Request a recipient to delete the wrongly sent email</th>
                            <td class="editable" id="edit-deleteRequest">${data.deleteRequest}<br>Reason: ${data.deleteRequestReason || ''}</td>
                        </tr>
                        <tr>
                            <th>Others</th>
                            <td class="editable" id="edit-wrongDestOther">${data.otherActionsWrongDest || ''}</td>
                        </tr>
                    </table>
                    ` : ''}

                    <!-- Section 9: Timeline -->
                    <div>
                        <table id="timeline-table">
                            <tr>
                                    <th colspan="2" class="section-title">9. Timeline<br><small>* Describe chronologically: Initial response, Stopgap measure, Instructions given by CSIRT Leader</small></th>
                            </tr>
                            <tr>
                                    <th style="width: 30%;">Date/time</th>
                                    <th>Situation, response, etc.</th>
                            </tr>
                            ${data.timeline.map(item => `
                            <tr class="timeline-row">
                                    <td><input class="editable" type="datetime-local" value="${item.dateTime}" style="width: 100%; box-sizing: border-box;" disabled /></td>
                                    <td><textarea class="editable" style="width: 100%; box-sizing: border-box;" disabled>${item.situation}</textarea></td>
                            </tr>
                            `).join('')}
                            ${data.timeline.length === 0 ? '<tr class="timeline-row"><td colspan="2">No timeline entries</td></tr>' : ''}
                        </table>
                        <button class="review-btn" id="report-actions" style="display: none; style="background: #09bb53; padding: 8px 10px; margin: 0px 0 20px 0;" onclick="addTimelineRow()">
                                Add Timeline Row
                        </button>
                    </div>

                    <!-- Sections 10-11 -->
                    <table>
                        <tr>
                            <th>10. Assumed causes<br><small>* Provide root causes. For example, if person concerned neglected to follow rules, describe why he/she did.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                            <td id="edit-assumedCauses"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.assumedCauses || ''}</textarea></td>
                        </tr>
                        <tr>
                            <th>11. Preventive measures<br><small>* Describe specifically. Attach evidence records, if any, such as a notice of issue and documents provided.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                            <td id="edit-preventiveMeasures">
                                <textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.preventiveMeasures || ''}</textarea><br>
                                Name and job title of person responsible for implementation: <label class="editable"> ${data.responsiblePerson}</label><br>
                                Date of (scheduled) completion: <label class="editable">${data.completionDate || ''}</label>
                            </td>
                        </tr>
                        <tr>
                            <th>12. Remarks</th>
                            <td id="edit-remarks"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.remarks || ''}</textarea></td>
                        </tr>
                    </table>

                    <div style="margin-top: 20px;">
                        <p style="font-size: 11px;"><strong>*1 Local wipe:</strong> A function to delete data of devices when failed a specified number of login attempts for unlocking the entry of a password.</p>
                        <p style="font-size: 11px;"><strong>*2 Mobile Device Management Tool:</strong> A tool for the centralized registration and administration of mobile devices such as tablets and smartphones, including their information and configuration settings</p>
                    </div>

                    <!-- Review/Edit Button -->
                    <div style="text-align: center; margin: 30px 0;">
                        <button class="review-btn" onclick="enableEditing()">Review & Edit Report</button>
                        <button class="review-btn" style="background: #10b981; display: none;" id="saveBtn" onclick="saveChanges()">Save Changes</button>
                        <button class="review-btn" onclick="window.print()">Print Report</button>                   
                    </div>
                </div>

                <script>
                    function enableEditing() {
                        const editables = document.querySelectorAll('.editable');
                        editables.forEach(el => {
                            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                                el.disabled = false;
                            } else {
                                el.contentEditable = true;
                            }
                            el.style.border = '2px solid #3b82f6';
                        });
                       
                        // Show the Add Timeline button
                        document.getElementById('report-actions').style.display = 'block';
                        document.getElementById('saveBtn').style.display = 'inline-block';
                       
                        alert('Editing enabled for Section 1 and Sections 6-12. Click inside cells to edit.');
                    }
 
 
                    function addTimelineRow() {
 
                        const table = document.getElementById('timeline-table');
                        const rows = table.querySelectorAll('.timeline-row');
                        if (rows.length === 1) {
                            const firstCell = rows[0].cells[0];
                            if (firstCell && firstCell.colSpan === 2 && firstCell.textContent.includes('No timeline entries')) {
                                rows[0].remove();
                            }
                        }
                       
                        const newRow = table.insertRow(-1); // Insert at the end
                        newRow.className = 'timeline-row';
                       
                        // Create date/time cell
                        const cell1 = newRow.insertCell(0);
                        const dateInput = document.createElement('input');
                        dateInput.type = 'datetime-local';
                        dateInput.className = 'editable';
                        dateInput.style.width = '100%';
                        dateInput.style.boxSizing = 'border-box';
                        dateInput.style.border = '2px solid #3b82f6';
                        cell1.appendChild(dateInput);
                       
                        // Create situation cell
                        const cell2 = newRow.insertCell(1);
                        const textarea = document.createElement('textarea');
                        textarea.className = 'editable';
                        textarea.style.width = '100%';
                        textarea.style.boxSizing = 'border-box';
                        textarea.style.border = '2px solid #3b82f6';
                        textarea.style.minHeight = '60px';
                        cell2.appendChild(textarea);
                    }
 
 
                    function saveChanges() {
                        // Remove empty timeline rows before saving
                        const timelineRows = document.querySelectorAll('#timeline-table .timeline-row');
                        timelineRows.forEach(row => {
                                const dateInput = row.querySelector('input[type="datetime-local"]');
                                const textarea = row.querySelector('textarea');
                               
                                // Check if both date and situation are empty
                                if (dateInput && textarea) {
                                        const dateValue = dateInput.value.trim();
                                        const textValue = textarea.value.trim();
                                       
                                        // Remove row if either field is empty
                                        if (!dateValue || !textValue) {
                                                row.remove();
                                        }
                                }
                        });
       
                        // Check if no timeline rows remain, add back "No timeline entries" row
                        const remainingRows = document.querySelectorAll('#timeline-table .timeline-row');
                        if (remainingRows.length === 0) {
                                const table = document.getElementById('timeline-table');
                                const newRow = table.insertRow(-1);
                                newRow.className = 'timeline-row';
                                const cell = newRow.insertCell(0);
                                cell.colSpan = 2;
                                cell.textContent = 'No timeline entries';
                        }
                       
                        // Disable editing for all editable fields
                        const editables = document.querySelectorAll('.editable');
                        editables.forEach(el => {
                                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                                        el.disabled = true;
                                } else {
                                        el.contentEditable = false;
                                }
                                el.style.border = '';
                        });
                   
                            // Hide the Add Timeline button
                            document.getElementById('report-actions').style.display = 'none';
                            document.getElementById('saveBtn').style.display = 'none';
                           
                            alert('Changes saved! Empty timeline rows have been removed. You can now print or close this report.');
                    }
 
 
                </script>
            </body>
            </html>
            `;

            // Open popout window
            // const reportWindow = window.open('', 'ITSecurityReportFormA', 'width=1200,height=900,resizable=yes,scrollbars=yes');
            window.reportWindow = window.open('', 'ITSecurityReportFormA', 'width=1200,height=900,resizable=yes,scrollbars=yes');
            reportWindow.document.write(reportHTMLA);
            reportWindow.document.close();
        }
