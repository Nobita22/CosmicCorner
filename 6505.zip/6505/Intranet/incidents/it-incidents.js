function initITIncidentsPage() {
    // Default tab
    document.querySelectorAll('.it-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-content').forEach(tc => tc.style.display = 'none');
            document.getElementById(`tab-${btn.dataset.tab}`).style.display = 'block';
        });
    });

    // Show New Incident by default
    const defaultTab = document.querySelector('[data-tab="newIT"]');
    if (defaultTab) defaultTab.click();

    // Any existing logic you already have:
    // setReportedDates();
    // populateCurrentUser();
}
