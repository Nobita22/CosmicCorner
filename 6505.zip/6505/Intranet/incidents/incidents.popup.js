const IncidentPopupScripts = `
function openModal(contentHtml) {
    document.getElementById('modalContent').innerHTML = contentHtml;
    document.getElementById('modalOverlay').style.display = 'flex';
}

function closeModal() {
    document.getElementById('modalOverlay').style.display = 'none';
}

document.querySelectorAll('.btn-primary').forEach(btn => {
    btn.onclick = function() {
        const type = this.innerText;
        if (type === 'Root Cause') {
            openModal('<h3>Root Cause Analysis</h3><textarea></textarea>');
        }
        if (type === 'Counter Measures') {
            openModal('<h3>Counter Measures</h3>');
        }
        if (type === 'OHC') {
            openModal('<h3>OHC</h3>');
        }
    };
});
`;
