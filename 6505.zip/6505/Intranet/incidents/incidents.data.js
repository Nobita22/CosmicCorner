/* incidents.data.js */

const IncidentData = (() => {
    const incidents = {
        'FY25-DTR-CRG235': {
            reportedBy: 'TTDI000123 - D',
            reportedOn: '2026-01-08 14:30',
            incidentType: 'Non-reportable',
            division: 'DTR',
            unit: 'Unit 10 - IT Dept',
            section: 'IT Support',
            workCenter: 'Server Room',
            location: 'Rudraram',
            area: 'Core assembly',
            victim: 'TTDI001234',
            victimAge: '32',
            doj: '2023-03-15',
            incidentDate: '2026-01-08',
            incidentTime: '14:30',
            subject: 'Server room ventilation failure',
            responsiblePerson: 'TTDI000456 - Manager IT',
            description: 'Ventilation system failed during peak load...',
            rootCause: 'Filter blockage due to dust accumulation...',
            correctiveAction: 'Immediate filter replacement...',
            riskLevel: 'Low',
            riskCategory: 'Near-miss'
        }
    };

    return {
        getIncident(id) {
            return incidents[id] || incidents['FY25-DTR-CRG235'];
        }
    };
})();

/* incidents.data.js */

// ================= EMPLOYEE DATABASE =================
const IncidentEmployeeDB = (() => {

    const employeeDatabase = {
        '1234': {
            ename: 'John Doe',
            empid: '1234',
            jobTitle: 'Sr. Engineer',
            company: 'TTDI',
            dept: 'Corporate',
            divi: 'Information Technology',
            phone: '+91-40-1234-5678',
            email: 'john.doe@toshiba-ttdi.com'
        },
        '2345': {
            ename: 'Jane Smith',
            empid: '2345',
            jobTitle: 'Sr. Engineer',
            company: 'TTDI',
            dept: 'DTR',
            divi: 'Stores',
            phone: '+91-40-2345-6789',
            email: 'jane.smith@toshiba-ttdi.com'
        },
        '3456': {
            ename: 'Raj Kumar',
            empid: '3456',
            jobTitle: 'Jr. Engineer',
            company: 'TTDI',
            dept: 'Corporate',
            divi: 'Finance & Accounts',
            phone: '+91-40-3456-7890',
            email: 'raj.kumar@toshiba-ttdi.com'
        },
        '4567': {
            ename: 'Sarah Johnson',
            empid: '4567',
            jobTitle: 'Jr. Engineer',
            company: 'TTDI',
            dept: 'Corporate',
            divi: 'Human Resources',
            phone: '+91-40-4567-8901',
            email: 'sarah.johnson@toshiba-ttdi.com'
        }
    };

    function searchEmployee(btn) {
        const form = btn.closest('form');
        if (!form) return;

        const input = form.querySelector('#empIdInput');
        const detailsDiv = form.querySelector('#employeeDetails');
        const errorDiv = form.querySelector('#errorMessage');

        detailsDiv.style.display = 'none';
        errorDiv.style.display = 'none';

        const empId = input.value.trim().toUpperCase();
        if (!empId) {
            errorDiv.textContent = 'Please enter a Employee ID.';
            errorDiv.style.display = 'block';
            return;
        }

        const employee = employeeDatabase[empId];
        if (!employee) {
            errorDiv.textContent = 'Employee not found. Please check the employee ID.';
            errorDiv.style.display = 'block';
            return;
        }

        form.querySelector('#empName').textContent = employee.ename;
        form.querySelector('#empJobTitle').textContent = employee.jobTitle;
        form.querySelector('#empId').textContent = employee.empid;
        form.querySelector('#empComp').textContent = employee.company;
        form.querySelector('#empDept').textContent = employee.dept;
        form.querySelector('#empDiv').textContent = employee.divi;
        form.querySelector('#empPhone').textContent = employee.phone;
        form.querySelector('#empEmail').textContent = employee.email;

        detailsDiv.style.display = 'block';
    }

    return { searchEmployee };
})();

// keep backward compatibility
window.searchEmployee = IncidentEmployeeDB.searchEmployee;
