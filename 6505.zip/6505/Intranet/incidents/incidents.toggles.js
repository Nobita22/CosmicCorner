function toggleIncidentSections(type) {
            const theftLoss = document.getElementById('theftLossSection');
            const wrongDest = document.getElementById('wrongDestinationSection');
            const email=document.querySelector('input[name="wrongDestMethod"][value="Email"]');
            const fax=document.querySelector('input[name="wrongDestMethod"][value="Fax"]');
            const mail=document.querySelector('input[name="wrongDestMethod"][value="Mail"]');
            const cloud=document.querySelector('input[name="wrongDestMethod"][value="Cloud"]');
            const other=document.querySelector('input[name="wrongDestMethod"][value="Other"]');
            const pclaptop=document.querySelector('input[name="theftItem"][value="PC/Laptop"]');
            const usb=document.querySelector('input[name="theftItem"][value="USB Drive"]');
            const mobilephone=document.querySelector('input[name="theftItem"][value="Mobile Phone"]');
            const tablet=document.querySelector('input[name="theftItem"][value="Tablet"]');
            const documents=document.querySelector('input[name="theftItem"][value="Documents"]');
            const other2=document.querySelector('input[name="theftItem"][value="Other"]');


            // Section 4 - Location and Circumstances
            const section4Card = document.getElementById('section4Card');
            
            // Section 7 content
            const section7TheftLossContent = document.getElementById('section7TheftLossContent');
            const section7WrongDestContent = document.getElementById('section7WrongDestContent');
            
            // Section 8 content
            const section8TheftLossContent = document.getElementById('section8TheftLossContent');
            const section8WrongDestContent = document.getElementById('section8WrongDestContent');
            
            if (type === 'theftLoss') {
                // Show Theft/Loss incident type section
                theftLoss.style.display = 'block';
                wrongDest.style.display = 'none';
                
                // Show Section 4
                if (section4Card) {
                    section4Card.style.display = 'block';
                }
                
                // Section 7: Show Theft/Loss content, Hide Wrong Destination content
                if (section7TheftLossContent) {
                    section7TheftLossContent.style.display = 'block';
                }
                if (section7WrongDestContent) {
                    section7WrongDestContent.style.display = 'none';
                }
                
                // Section 8: Show Theft/Loss content, Hide Wrong Destination content
                if (section8TheftLossContent) {
                    section8TheftLossContent.style.display = 'block';
                }
                if (section8WrongDestContent) {
                    section8WrongDestContent.style.display = 'none';
                }
                
                pclaptop.disabled=false;
                usb.disabled=false;
                mobilephone.disabled=false;
                tablet.disabled=false;
                documents.disabled=false;
                other2.disabled=false;

                email.disabled=true;
                email.checked=false;
                fax.disabled=true;
                fax.checked=false;
                mail.disabled=true;
                mail.checked=false;
                cloud.disabled=true;
                cloud.checked=false;
                other.disabled=true;
                other.checked=false;

            } else if (type === 'wrongDestination') {

                // Show Wrong Destination incident type section
                theftLoss.style.display = 'none';
                wrongDest.style.display = 'block';
                
                // Hide Section 4
                if (section4Card) {
                    section4Card.style.display = 'none';
                }
                
                // Section 7: Hide Theft/Loss content, Show Wrong Destination content
                if (section7TheftLossContent) {
                    section7TheftLossContent.style.display = 'none';
                }
                if (section7WrongDestContent) {
                    section7WrongDestContent.style.display = 'block';
                }
                
                // Section 8: Hide Theft/Loss content, Show Wrong Destination content
                if (section8TheftLossContent) {
                    section8TheftLossContent.style.display = 'none';
                }
                if (section8WrongDestContent) {
                    section8WrongDestContent.style.display = 'block';
                }

                email.disabled=false;
                fax.disabled=false;
                mail.disabled=false;
                cloud.disabled=false;
                other.disabled=false;

                pclaptop.disabled=true;
                pclaptop.checked=false;
                usb.disabled=true;
                usb.checked=false;
                mobilephone.disabled=true;
                mobilephone.checked=false;
                tablet.disabled=true;
                tablet.checked=false;
                documents.disabled=true;
                documents.checked=false;
                other2.disabled=true;
                other2.checked=false;
            }
        }

        /* incidents.toggles.js */

// ================= INCIDENT TYPE TOGGLE =================

function toggleIncidentSections(type) {
    const theftLoss = document.getElementById('theftLossSection');
    const wrongDest = document.getElementById('wrongDestinationSection');
    const section4Card = document.getElementById('section4Card');

    const section7Theft = document.getElementById('section7TheftLossContent');
    const section7Wrong = document.getElementById('section7WrongDestContent');

    const section8Theft = document.getElementById('section8TheftLossContent');
    const section8Wrong = document.getElementById('section8WrongDestContent');

    if (type === 'theftLoss') {
        theftLoss.style.display = 'block';
        wrongDest.style.display = 'none';
        if (section4Card) section4Card.style.display = 'block';

        section7Theft.style.display = 'block';
        section7Wrong.style.display = 'none';

        section8Theft.style.display = 'block';
        section8Wrong.style.display = 'none';

    } else if (type === 'wrongDestination') {
        theftLoss.style.display = 'none';
        wrongDest.style.display = 'block';
        if (section4Card) section4Card.style.display = 'none';

        section7Theft.style.display = 'none';
        section7Wrong.style.display = 'block';

        section8Theft.style.display = 'none';
        section8Wrong.style.display = 'block';
    }
}

// ================= SECTION 7 CONTROL =================

function toggleSection7Content(type) {
    const publicWebsite = document.getElementById('publicwebsitecontent7');
    const virus = document.getElementById('virusinfectioncontent7');
    const other = document.getElementById('othercontent7');

    if (!publicWebsite || !virus || !other) return;

    if (type === 'publicWebsite') {
        publicWebsite.style.display = 'block';
        virus.style.display = 'none';
        other.style.display = 'block';
    } else if (type === 'virusInfection') {
        publicWebsite.style.display = 'none';
        virus.style.display = 'block';
        other.style.display = 'block';
    } else if (type === 'other') {
        publicWebsite.style.display = 'none';
        virus.style.display = 'none';
        other.style.display = 'block';
    } else {
        publicWebsite.style.display = 'none';
        virus.style.display = 'none';
        other.style.display = 'none';
    }
}

// ================= SECTION 8 CONTROL =================

function toggleSection8Content(type) {
    const interim = document.getElementById('interimMeasuresSection');
    const damage = document.getElementById('investigationDamageSection');
    const causes = document.getElementById('investigationCausesSection');
    const othersGrid = document.getElementById('othersRecoveryGrid');
    const others = document.getElementById('othersAdditionalMeasures');
    const reopening = document.getElementById('reopeningWebsiteSection');
    const recovery = document.getElementById('recoveryMethodSection');

    if (!interim || !damage || !causes || !othersGrid) return;

    if (type === 'publicWebsite') {
        interim.style.display = 'block';
        damage.style.display = 'block';
        causes.style.display = 'block';
        othersGrid.style.display = 'grid';
        if (others) others.style.display = 'block';
        if (reopening) reopening.style.display = 'block';
        if (recovery) recovery.style.display = 'none';

    } else if (type === 'virusInfection') {
        interim.style.display = 'block';
        damage.style.display = 'block';
        causes.style.display = 'block';
        othersGrid.style.display = 'block';
        if (others) others.style.display = 'block';
        if (reopening) reopening.style.display = 'none';
        if (recovery) recovery.style.display = 'block';

    } else if (type === 'other') {
        interim.style.display = 'none';
        damage.style.display = 'none';
        causes.style.display = 'none';
        othersGrid.style.display = 'block';
        if (others) others.style.display = 'block';
        if (reopening) reopening.style.display = 'none';
        if (recovery) recovery.style.display = 'none';

    } else {
        interim.style.display = 'none';
        damage.style.display = 'none';
        causes.style.display = 'none';
        othersGrid.style.display = 'none';
        if (recovery) recovery.style.display = 'none';
    }
}

// expose
window.toggleIncidentSections = toggleIncidentSections;
window.toggleSection7Content = toggleSection7Content;
window.toggleSection8Content = toggleSection8Content;
