/* incidents.view.js */

function openIncidentView(incidentId) {
    const data = IncidentData.getIncident(incidentId);

    const popup = window.open(
        '',
        'incidentView',
        'width=800,height=800,resizable=yes,scrollbars=yes'
    );

    popup.document.write(buildIncidentHTML(incidentId, data));
    popup.document.close();
}

function buildIncidentHTML(incidentId, data) {
    return `
<!DOCTYPE html>
<html>
<head>
<title>Incident View - ${incidentId}</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
${IncidentStyles.popup}
</style>
</head>
<body>
${IncidentTemplates.view(incidentId, data)}
<script>
${IncidentPopupScripts}
<\/script>
</body>
</html>
`;
}
