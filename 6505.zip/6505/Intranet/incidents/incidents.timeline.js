/* incidents.timeline.js */

// ================= TIMELINE HELPERS =================

function getTimelineDataA() {
    const timeline = [];
    document.querySelectorAll('#timelineRowsA tr').forEach(row => {
        const dateTime = row.querySelector('input[type="datetime-local"]')?.value || '';
        const situation = row.querySelector('textarea')?.value || '';
        if (dateTime || situation) {
            timeline.push({ dateTime, situation });
        }
    });
    return timeline;
}

function getTimelineDataB() {
    const timeline = [];
    document.querySelectorAll('#timelineRowsB tr').forEach(row => {
        const dateTime = row.querySelector('input[type="datetime-local"]')?.value || '';
        const situation = row.querySelector('textarea')?.value || '';
        if (dateTime || situation) {
            timeline.push({ dateTime, situation });
        }
    });
    return timeline;
}

function addTimelineRowA() {
    const tbody = document.getElementById('timelineRowsA');
    if (!tbody || !tbody.rows[0]) return;

    const newRow = tbody.rows[0].cloneNode(true);
    newRow.querySelectorAll('input, textarea').forEach(el => el.value = '');
    tbody.appendChild(newRow);
}

function addTimelineRowB() {
    const tbody = document.getElementById('timelineRowsB');
    if (!tbody || !tbody.rows[0]) return;

    const newRow = tbody.rows[0].cloneNode(true);
    newRow.querySelectorAll('input, textarea').forEach(el => el.value = '');
    tbody.appendChild(newRow);
}

// generic timeline (report view)
function addTimelineRow() {
    const tbody = document.getElementById('timelineRows');
    if (!tbody) return;

    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td>
            <input type="datetime-local" style="width:100%;">
        </td>
        <td>
            <textarea style="width:100%;"></textarea>
        </td>
    `;
    tbody.appendChild(tr);
}

// backward compatibility
window.getTimelineDataA = getTimelineDataA;
window.getTimelineDataB = getTimelineDataB;
window.addTimelineRowA = addTimelineRowA;
window.addTimelineRowB = addTimelineRowB;
window.addTimelineRow = addTimelineRow;
