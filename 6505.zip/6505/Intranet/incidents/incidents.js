// incidents.js

let incidentsLoaded = false;

function loadIncidentsPage() {
    if (incidentsLoaded) {
        console.warn('Incidents page already loaded, skipping re-load');
        return;
    }

    incidentsLoaded = true;

    fetch('incidents/incidents.html')
        .then(res => res.text())
        .then(html => {
            const content = document.getElementById('contentArea');
            content.innerHTML = html;

            initIncidentTabs();
            initIncidentDefaults();
        })
        .catch(err => console.error('Failed to load incidents page', err));
}

window.loadIncidentsPage = loadIncidentsPage;

// function initIncidentTabs() {
//     const buttons = document.querySelectorAll('.it-tab-btn');
//     if (!buttons.length) return;

//     buttons.forEach(btn => {
//         btn.addEventListener('click', () => {
//             const tab = btn.getAttribute('data-tab');
//             const container = btn.closest('.helpdesk-container');

//             // reset buttons
//             container.querySelectorAll('.it-tab-btn').forEach(b => {
//                 b.classList.remove('active');
//                 b.style.background = '#f9fafb';
//                 b.style.color = '#666';
//                 b.style.fontWeight = 'normal';
//             });

//             // reset content
//             container.querySelectorAll('.tab-content').forEach(c => {
//                 c.style.display = 'none';
//             });

//             // activate
//             btn.classList.add('active');
//             btn.style.background = '#dbeafe';
//             btn.style.color = '#1d4ed8';
//             btn.style.fontWeight = '600';

//             const target = container.querySelector(`#tab-${tab}`);
//             if (target) target.style.display = 'block';
//         });
//     });
// }

function initIncidentTabs() {
    const buttons = document.querySelectorAll('.it-tab-btn');
    if (!buttons.length) return;

    buttons.forEach(btn => {
        btn.replaceWith(btn.cloneNode(true));
    });

    document.querySelectorAll('.it-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.tab;
            const container = btn.closest('.helpdesk-container');

            container.querySelectorAll('.it-tab-btn')
                .forEach(b => b.classList.remove('active'));

            container.querySelectorAll('.tab-content')
                .forEach(c => c.style.display = 'none');

            btn.classList.add('active');
            container.querySelector(`#tab-${tab}`).style.display = 'block';
        });
    });
}


function initIncidentDefaults() {
    // Form A/B default hidden sections
    if (typeof toggleSection7Content === 'function') {
        toggleSection7Content('none');
    }
    if (typeof toggleSection8Content === 'function') {
        toggleSection8Content('none');
    }

    // Theft / Wrong destination sections
    const theft = document.getElementById('theftLossSection');
    const wrong = document.getElementById('wrongDestinationSection');
    if (theft) theft.style.display = 'none';
    if (wrong) wrong.style.display = 'none';
}

function showFormatA() {
    // Hide the selection page and show Form A content
    const selectionPage = document.getElementById('itIncidentSelection');
    const formA = document.getElementById('formAContent');
    
    if (selectionPage) selectionPage.style.display = 'none';
    if (formA) formA.style.display = 'block';
    
    // Initialize Form A specific functionality
    if (typeof initFormA === 'function') {
        initFormA();
    }
}

function showFormatB() {
    // Hide the selection page and show Form B content
    const selectionPage = document.getElementById('itIncidentSelection');
    const formB = document.getElementById('formBContent');
    
    if (selectionPage) selectionPage.style.display = 'none';
    if (formB) formB.style.display = 'block';
    
    // Initialize Form B specific functionality
    if (typeof initFormB === 'function') {
        initFormB();
    }
}

function initFormA() {
    // Initialize Form A specific functionality
    console.log('Initializing Form A');
    
    // Set default values for Form A fields
    const incidentType = document.getElementById('incidentType');
    if (incidentType) {
        incidentType.value = 'Non-reportable';
    }
    
    // Initialize any Form A specific event listeners
    // Add your Form A initialization code here
}

function initFormB() {
    // Initialize Form B specific functionality
    console.log('Initializing Form B');
    
    // Set default values for Form B fields
    const incidentType = document.getElementById('incidentType');
    if (incidentType) {
        incidentType.value = 'Non-reportable';
    }
    
    // Initialize any Form B specific event listeners
    // Add your Form B initialization code here
}

// Make functions globally available
window.showFormatA = showFormatA;
window.showFormatB = showFormatB;
window.initFormA = initFormA;
window.initFormB = initFormB;
