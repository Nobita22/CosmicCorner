import os
import urllib.parse

class Config:
    """Flask application configuration"""
    
    # Password encoding for special characters
    _raw_password = "P@ssword"
    _password = urllib.parse.quote_plus(_raw_password)
    
    # SQL Server Database URI for incident/request tables
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "INCIDENT_DB_URI",
        (
            f"mssql+pyodbc://sa:{_password}@ttdirdwebdev\\sqlexpress/dbhdm"
            "?driver=ODBC+Driver+17+for+SQL+Server"
        )
    )
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = True  # Set to False in production
    
    # Secret key for Flask sessions
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-change-in-production')
    
    # CORS settings
    CORS_HEADERS = 'Content-Type'
    
    # SQL Server connection string for employee/asset table (using raw pyodbc)
    ASSET_DB_CONN_STR = os.getenv(
        "ASSET_DB_CONN_STR",
        (
            "Driver={ODBC Driver 17 for SQL Server};"
            "Server=ttdirdwebdev\\sqlexpress;"
            "Database=dbhdm;"
            "UID=sa;"
            "PWD=P@ssword;"
        )
    )
