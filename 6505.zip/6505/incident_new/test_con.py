﻿from app import app, db
from models import EmployeeAsset, FacilityRequest, ServiceRequest
import traceback

def test_database_connection():
    """Test connection to SQL Server database"""
    with app.app_context():
        print("=" * 60)
        print("TESTING DATABASE CONNECTION")
        print("=" * 60)
        
        try:
            # Test 1: Employee/Asset table
            print("\n1. Testing Employee/Asset table...")
            emp_count = EmployeeAsset.query.count()
            print(f"   ✓ Found {emp_count} employees in database")
            
            if emp_count > 0:
                first_emp = EmployeeAsset.query.first()
                print(f"   ✓ Sample employee: {first_emp.ename} ({first_emp.empId})")
                print(f"   ✓ Department: {first_emp.dept}")
                print(f"   ✓ Asset: {first_emp.assetname} ({first_emp.assetId})")
            
            # Test 2: Facility Requests table
            print("\n2. Testing Facility Requests table...")
            facility_count = FacilityRequest.query.count()
            print(f"   ✓ Found {facility_count} facility requests")
            
            # Test 3: Service Requests table
            print("\n3. Testing Service Requests table...")
            service_count = ServiceRequest.query.count()
            print(f"   ✓ Found {service_count} service requests")
            
            print("\n" + "=" * 60)
            print("✓ ALL DATABASE CONNECTIONS SUCCESSFUL!")
            print("=" * 60)
            
            return True
            
        except Exception as e:
            print("\n" + "=" * 60)
            print("✗ DATABASE CONNECTION FAILED!")
            print("=" * 60)
            print(f"\nError: {str(e)}")
            print("\nFull traceback:")
            print(traceback.format_exc())
            return False

if __name__ == '__main__':
    test_database_connection()
