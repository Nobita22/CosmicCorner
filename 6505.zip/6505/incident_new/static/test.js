// ============================================================================
// DATABASE INTEGRATION - ADD AT THE TOP OF YOUR EXISTING test.js
// ============================================================================

// API Configuration
const API_BASE_URL = 'http://localhost:5000/api';

/**
 * Generic fetch function with error handling
 */
async function fetchAPI(endpoint, options = {}) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        });

        // Check if response is ok before parsing
        if (!response.ok) {
            let errorMessage = 'API request failed: '.concat(response.status, ' ', response.statusText);
            try {
                const errorData = await response.json();
                errorMessage = errorData.error || errorMessage;
            } catch (e) {
                // If JSON parsing fails, use default error message
            }
            throw new Error(errorMessage);
        }

        // Parse JSON only if response is ok
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Fetch dashboard counts from database
 */
async function fetchDashboardCounts() {
    try {
        const result = await fetchAPI('/dashboard/counts');
        return result.data;
    } catch (error) {
        console.error('Error fetching dashboard counts:', error);
        return {
            facility_requests: 0,
            service_requests: 0,
            leave_requests: 0,
            ot_requests: 0
        };
    }
}

/**
 * Fetch facility requests from database
 */
async function fetchFacilityRequests() {
    try {
        const result = await fetchAPI('/facility-requests');
        return result.data || [];
    } catch (error) {
        console.error('Error fetching facility requests:', error);
        return [];
    }
}

// Load IT security incidents for the Logged IT tab
async function fetchItIncidents() {
    const tbody = document.getElementById('itIncidentsBody');
    if (!tbody) return;

    // Show loading row
    tbody.innerHTML = `
    <tr>
      <td colspan="8" style="padding: 0.75rem; text-align: center; font-size: 0.85rem; color: #6b7280;">
        Loading incidents...
      </td>
    </tr>
  `;

    try {
        // Expect backend: GET /api/it-incidents -> { data: [ ... ] }
        const result = await fetchAPI('/it-incidents');
        const incidents = result.data || [];

        if (!incidents.length) {
            tbody.innerHTML = `
        <tr>
          <td colspan="8" style="padding: 0.75rem; text-align: center; font-size: 0.85rem; color: #6b7280;">
            No IT security incidents found.
          </td>
        </tr>
      `;
            return;
        }

        // Build rows
        tbody.innerHTML = incidents.map(inc => {
            const incidentId = inc.incident_id || '';
            const reportedDate = inc.reported_on || inc.reported_at || '';
            const incidentType = inc.incident_type || inc.form_type || '';
            const department = inc.department || inc.person_involved_dept || '';
            const severity = inc.severity || 'Medium';
            const status = inc.status || 'Open';
            const reportStatus = inc.report_status || 'First';

            // Pick a badge color based on severity
            let severityClass = 'background: #dcfce7; color: #166534;';   // Low
            if (severity === 'High') severityClass = 'background: #fee2e2; color: #991b1b;';
            if (severity === 'Medium') severityClass = 'background: #fef3c7; color: #92400e;';

            return `
        <tr style="border-bottom: 1px solid #e5e7eb;">
          <td style="padding: 0.75rem 0.5rem;">
            <span style="font-weight: 600; color: #1d4ed8;">${incidentId}</span>
          </td>
          <td style="padding: 0.75rem 0.5rem;">${reportedDate}</td>
          <td style="padding: 0.75rem 0.5rem;">
            <span style="font-size: 0.85rem;">${incidentType}</span>
          </td>
          <td style="padding: 0.75rem 0.5rem;">${department}</td>
          <td style="padding: 0.75rem 0.5rem;">
            <span style="${severityClass} padding: 0.25rem 0.5rem; border-radius: 0.3rem; font-size: 0.85rem; font-weight: 600;">
              ${severity}
            </span>
          </td>
          <td style="padding: 0.75rem 0.5rem;">
            <span style="font-size: 0.85rem;">${status}</span>
          </td>
          <td style="padding: 0.75rem 0.5rem;">${reportStatus} Report</td>
          <td style="padding: 0.75rem 0.5rem;">
            <button
              style="padding: 0.4rem 0.8rem; background: #3b82f6; color: white; border: none; border-radius: 0.3rem; cursor: pointer; font-size: 0.85rem;"
              onclick="openItIncidentView('${incidentId}')"
            >
              View
            </button>
          </td>
        </tr>
      `;
        }).join('');
    } catch (err) {
        console.error('Error loading IT incidents:', err);
        tbody.innerHTML = `
      <tr>
        <td colspan="8" style="padding: 0.75rem; text-align: center; font-size: 0.85rem; color: #b91c1c;">
          Error loading IT incidents: ${err.message}
        </td>
      </tr>
    `;
    }
}


/**
 * Fetch service requests from database
 */
async function fetchServiceRequests() {
    try {
        const result = await fetchAPI('/service-requests');
        return result.data || [];
    } catch (error) {
        console.error('Error fetching service requests:', error);
        return [];
    }
}

/**
 * Fetch leave requests from database
 */
async function fetchLeaveRequests() {
    try {
        const result = await fetchAPI('/leave-requests');
        return result.data || [];
    } catch (error) {
        console.error('Error fetching leave requests:', error);
        return [];
    }
}

/**
 * Fetch OT requests from database
 */
async function fetchOTRequests() {
    try {
        const result = await fetchAPI('/ot-requests');
        return result.data || [];
    } catch (error) {
        console.error('Error fetching OT requests:', error);
        return [];
    }
}

/**
 * Fetch employee data by employee ID from database
 */
async function fetchEmployeeFromDB(empId) {
    try {
        const result = await fetchAPI(`/employees/${empId}`);
        return result.data;
    } catch (error) {
        console.error('Error fetching employee:', error);
        return null;
    }
}

/**
 * Update facility request in database
 */
async function updateFacilityRequest(caseId, status, comment) {
    try {
        const result = await fetchAPI(`/facility-requests/${caseId}`, {
            method: 'PUT',
            body: JSON.stringify({ status, comment })
        });
        return result;
    } catch (error) {
        console.error('Error updating facility request:', error);
        throw error;
    }
}

/**
 * Update service request in database
 */
async function updateServiceRequest(caseId, status, comment) {
    try {
        const result = await fetchAPI(`/service-requests/${caseId}`, {
            method: 'PUT',
            body: JSON.stringify({ status, comment })
        });
        return result;
    } catch (error) {
        console.error('Error updating service request:', error);
        throw error;
    }
}

/**
 * Handle action buttons (Grant, Reject, Add Level) with database update
 */
async function handleActionFromDB(action, requestId, type) {
    const commentInput = document.getElementById(`comment-${requestId}`);
    const comment = commentInput ? commentInput.value.trim() : '';

    if (!comment && (action === 'grant' || action === 'reject')) {
        alert('Please enter a comment before proceeding');
        if (commentInput) commentInput.focus();
        return;
    }

    try {
        let status;
        switch (action) {
            case 'grant':
                status = 'approved';
                break;
            case 'reject':
                status = 'rejected';
                break;
            case 'addLevel':
                status = 'escalated';
                break;
            default:
                status = 'pending';
        }

        // Update in database
        if (type === 'facility') {
            await updateFacilityRequest(requestId, status, comment);
        } else if (type === 'service') {
            await updateServiceRequest(requestId, status, comment);
        }

        alert(`Request ${requestId} has been ${status}`);

        // Reload the content to show updated data
        const currentKey = type === 'facility' ? 'facilityRequests' : 'serviceRequests';
        await loadContent(currentKey);

    } catch (error) {
        alert('Error updating request: ' + error.message);
    }
}

// ============================================================================
// END OF DATABASE INTEGRATION - YOUR EXISTING CODE CONTINUES BELOW
// ============================================================================




const contentData = {
    // Home and quick modules
    'home': `
            <div class="slider">
                <img src="https://tse4.mm.bing.net/th/id/OIP.3t0T3Pb1NCKosvPDeVnNJgHaCX?rs=1&pid=ImgDetMain&o=7&rm=3" alt="Slide 1" class="slide active">
                <img src="https://toshiba-india.com/images/pr/tddi_factory.jpg" alt="Slide 2" class="slide">
                <img src="https://www.constructionworld.in/assets/uploads/6bf8955e98bb9fe1df79681b442b3c44.jpg" alt="Slide 3" class="slide">
            </div>
            <div class="navigation">
                <span class="dot active" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
                <span class="dot" onclick="currentSlide(3)"></span>
            </div>


            <div class="welcome-row">
              <article class="welcome-card">
                <!-- welcome card content (shortened here for brevity) -->
                <h1 class="welcome-title">Welcome back, D</h1>
                <p class="welcome-subtitle">Access HR services, company tools, and mandatory actions from a single, clean white dashboard.</p>
                <div class="welcome-meta">
                  <div class="pill">
                    <span class="pill-label">Employee ID</span>
                    <span class="pill-value">TTDI‑000123</span>
                  </div>
                  <div class="pill">
                    <span class="pill-label">Division</span>
                    <span class="pill-value">Corporate Operations</span>
                  </div>
                  <div class="pill">
                    <span class="pill-label">Role</span>
                    <span class="pill-value">Engineer</span>
                  </div>

                <!-- NEW: HR Services Section -->
                
                <!-- Pending Approvals Section -->
                <div class="hr-services-section">
                    <h3 class="services-heading">Pending Approvals</h3>
                    <div class="hr-services-grid">
                        <div class="service-item">
                            <div class="service-icon">🏢</div>
                            <div class="service-info">
                                <span class="service-label">Facility Requests</span>
                                <span class="service-count">3</span>
                            </div>
                        </div>

                        <div class="service-item">
                            <div class="service-icon">🛠️</div>
                            <div class="service-info">
                                <span class="service-label">Service Requests</span>
                                <span class="service-count">5</span>
                            </div>
                        </div>

                        <div class="service-item">
                            <div class="service-icon">🏖️</div>
                            <div class="service-info">
                                <span class="service-label">Leave</span>
                                <span class="service-count">12</span>
                            </div>
                        </div>

                        <div class="service-item">
                            <div class="service-icon">⏰</div>
                            <div class="service-info">
                                <span class="service-label">OT</span>
                                <span class="service-count">8</span>
                            </div>
                        </div>
                    </div>
                </div>

               <!-- <div class="policy-groups" id="policyGroups" role="list">
                <section class="policy-group open" role="listitem">
                <button class="policy-group-header" type="button" aria-expanded="true" aria-controls="policies-message" aria-label="Toggle Message from Toshiba policies">
                  <span>Announcements</span>
                  <span class="policy-toggle-icon" aria-hidden="true">▶</span>
                </button>
                <ul class="policy-list" id="policies-message" role="list">
                  <li><span class="policy-link" tabindex="0" role="button">CEO Message – November</span></li>
                  <li><span class="policy-link" tabindex="0" role="button">CEO Message – Start of FY25A</span></li>
                  <li><span class="policy-link" tabindex="0" role="button">CEO Message – Start of FY24B</span></li>
                  <li><span class="policy-link" tabindex="0" role="button">New Medium‑Term Business Plan</span></li>
                </ul>
              </section>-->

                </div>
              </article>
              <article class="kpi-card" aria-label="Key personal stats">
                <header class="kpi-header">
                  <div>
                    <div class="kpi-title">Personal snapshot</div>
                    <div class="kpi-caption">Your current balances and mandatory items</div>
                  </div>
                  <div class="kpi-badge">
                    <span class="kpi-dot"></span>
                    <span>All systems normal</span>
                  </div>
                </header>
                <div class="kpi-pill">
                  <div class="kpi-pill-label">Leave balance (EL / CL / SL)</div>
                  <div class="kpi-pill-value">23 / 1 / 4.5 days</div>
                </div>
                <div class="kpi-pill">
                  <div class="kpi-pill-label">Pending e‑Learning schedules</div>
                  <div class="kpi-pill-value">0 courses</div>
                </div>
                <div class="kpi-pill">
                  <div class="kpi-pill-label">Disclosure submissions (FY)</div>
                  <div class="kpi-pill-value">Up to date</div>
                </div>
                <div class="kpi-pill">
                  <div class="kpi-pill-label">Open incident / IT tickets</div>
                  <div class="kpi-pill-value">0 tickets</div>
                </div>
              </article>
              </div>`,

    'facilityRequests': `<div class="approval-wrapper">
            <div class="approval-header">
                <h2>Facility Requests</h2>
                <div class="approval-meta">
                    <span class="approval-count">Total: <strong>3</strong> Pending</span>
                </div>
            </div>

            <div class="approval-table-wrapper">
                <table class="approval-table">
                    <thead>
                        <tr>
                            <th colspan="4" class="section-header">Content</th>
                            <th colspan="3" class="section-header">Actions</th>
                        </tr>
                        <tr>
                            <th>Case ID</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Comment</th>
                            <th colspan="3">Action Buttons</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><span class="request-id">FR-2026-001</span></td>
                            <td><span class="badge badge-info">Conference Room</span></td>
                            <td>Request for projector setup in Conference Room A</td>
                            <td>
                                <input type="text" class="comment-input" id="comment-FR-2026-001" placeholder="Enter comment...">
                            </td>
                            <td>
                                <button class="action-btn btn-grant" onclick="handleAction('grant', 'FR-2026-001')">
                                    ✓ Grant
                                </button>
                            </td>
                            <td>
                                <button class="action-btn btn-reject" onclick="handleAction('reject', 'FR-2026-001')">
                                    ✗ Reject
                                </button>
                            </td>
                            <td>
                                <button class="action-btn btn-level" onclick="handleAction('addLevel', 'FR-2026-001')">
                                    ↑ Add Level
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td><span class="request-id">FR-2026-002</span></td>
                            <td><span class="badge badge-warning">Parking</span></td>
                            <td>Additional parking space request for visitor</td>
                            <td>
                                <input type="text" class="comment-input" id="comment-FR-2026-002" placeholder="Enter comment...">
                            </td>
                            <td>
                                <button class="action-btn btn-grant" onclick="handleAction('grant', 'FR-2026-002')">
                                    ✓ Grant
                                </button>
                            </td>
                            <td>
                                <button class="action-btn btn-reject" onclick="handleAction('reject', 'FR-2026-002')">
                                    ✗ Reject
                                </button>
                            </td>
                            <td>
                                <button class="action-btn btn-level" onclick="handleAction('addLevel', 'FR-2026-002')">
                                    ↑ Add Level
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td><span class="request-id">FR-2026-003</span></td>
                            <td><span class="badge badge-success">Maintenance</span></td>
                            <td>AC repair request for Floor 3, Wing B</td>
                            <td>
                                <input type="text" class="comment-input" id="comment-FR-2026-003" placeholder="Enter comment...">
                            </td>
                            <td>
                                <button class="action-btn btn-grant" onclick="handleAction('grant', 'FR-2026-003')">
                                    ✓ Grant
                                </button>
                            </td>
                            <td>
                                <button class="action-btn btn-reject" onclick="handleAction('reject', 'FR-2026-003')">
                                    ✗ Reject
                                </button>
                            </td>
                            <td>
                                <button class="action-btn btn-level" onclick="handleAction('addLevel', 'FR-2026-003')">
                                    ↑ Add Level
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>`,

    'serviceRequests': `<div class="approval-wrapper">
            <div class="approval-header">
                <h2>Service Requests</h2>
                <div class="approval-meta">
                    <span class="approval-count">Total: <strong>5</strong> Pending</span>
                </div>
            </div>
            <div class="approval-table-wrapper">
                <table class="approval-table">
                    <thead>
                        <tr>
                            <th colspan="4" class="section-header">Content</th>
                            <th colspan="3" class="section-header">Actions</th>
                        </tr>
                        <tr>
                            <th>Case ID</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Comment</th>
                            <th colspan="3">Action Buttons</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><span class="request-id">SR-2026-001</span></td>
                            <td><span class="badge badge-info">IT Support</span></td>
                            <td>Laptop replacement request</td>
                            <td>
                                <input type="text" class="comment-input" id="comment-SR-2026-001" placeholder="Enter comment...">
                            </td>
                            <td><button class="action-btn btn-grant" onclick="handleAction('grant', 'SR-2026-001')">✓ Grant</button></td>
                            <td><button class="action-btn btn-reject" onclick="handleAction('reject', 'SR-2026-001')">✗ Reject</button></td>
                            <td><button class="action-btn btn-level" onclick="handleAction('addLevel', 'SR-2026-001')">↑ Add Level</button></td>
                        </tr>
                        <tr>
                            <td><span class="request-id">SR-2026-002</span></td>
                            <td><span class="badge badge-warning">Stationery</span></td>
                            <td>Office supplies for new joiners</td>
                            <td>
                                <input type="text" class="comment-input" id="comment-SR-2026-002" placeholder="Enter comment...">
                            </td>
                            <td><button class="action-btn btn-grant" onclick="handleAction('grant', 'SR-2026-002')">✓ Grant</button></td>
                            <td><button class="action-btn btn-reject" onclick="handleAction('reject', 'SR-2026-002')">✗ Reject</button></td>
                            <td><button class="action-btn btn-level" onclick="handleAction('addLevel', 'SR-2026-002')">↑ Add Level</button></td>
                        </tr>
                        <tr>
                            <td><span class="request-id">SR-2026-003</span></td>
                            <td><span class="badge badge-success">Transport</span></td>
                            <td>Company vehicle for site visit</td>
                            <td>
                                <input type="text" class="comment-input" id="comment-SR-2026-003" placeholder="Enter comment...">
                            </td>
                            <td><button class="action-btn btn-grant" onclick="handleAction('grant', 'SR-2026-003')">✓ Grant</button></td>
                            <td><button class="action-btn btn-reject" onclick="handleAction('reject', 'SR-2026-003')">✗ Reject</button></td>
                            <td><button class="action-btn btn-level" onclick="handleAction('addLevel', 'SR-2026-003')">↑ Add Level</button></td>
                        </tr>
                        <tr>
                            <td><span class="request-id">SR-2026-004</span></td>
                            <td><span class="badge badge-danger">Security</span></td>
                            <td>Access card for contractor</td>
                            <td>
                                <input type="text" class="comment-input" id="comment-SR-2026-004" placeholder="Enter comment...">
                            </td>
                            <td><button class="action-btn btn-grant" onclick="handleAction('grant', 'SR-2026-004')">✓ Grant</button></td>
                            <td><button class="action-btn btn-reject" onclick="handleAction('reject', 'SR-2026-004')">✗ Reject</button></td>
                            <td><button class="action-btn btn-level" onclick="handleAction('addLevel', 'SR-2026-004')">↑ Add Level</button></td>
                        </tr>
                        <tr>
                            <td><span class="request-id">SR-2026-005</span></td>
                            <td><span class="badge badge-info">Training</span></td>
                            <td>External training approval</td>
                            <td>
                                <input type="text" class="comment-input" id="comment-SR-2026-005" placeholder="Enter comment...">
                            </td>
                            <td><button class="action-btn btn-grant" onclick="handleAction('grant', 'SR-2026-005')">✓ Grant</button></td>
                            <td><button class="action-btn btn-reject" onclick="handleAction('reject', 'SR-2026-005')">✗ Reject</button></td>
                            <td><button class="action-btn btn-level" onclick="handleAction('addLevel', 'SR-2026-005')">↑ Add Level</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>`,

    'leaveRequests': `<div class="approval-wrapper">
            <div class="approval-header">
                <h2>Leave Requests</h2>
                <div class="approval-meta">
                    <span class="approval-count">Total: <strong>12</strong> Pending</span>
                </div>
            </div>
            <p style="text-align: center; margin-top: 2rem; color: #6b7280;">Leave approval content - 12 requests pending...</p>
        </div>`,

    'otRequests': `<div class="approval-wrapper">
            <div class="approval-header">
                <h2>Overtime (OT) Requests</h2>
                <div class="approval-meta">
                    <span class="approval-count">Total: <strong>8</strong> Pending</span>
                </div>
            </div>
            <p style="text-align: center; margin-top: 2rem; color: #6b7280;">OT approval content - 8 requests pending...</p>
        </div>`,

    // Policy group contents: These contain the list of clickable policy items for each group
    'msgGroup': `
            <h2>Message from Toshiba</h2>
            <ul>
              <li><button class="policy-item" data-content="msgFY25A">CEO Message – Start of FY25A</button></li>
              <li><button class="policy-item" data-content="msgFY24B">CEO Message – Start of FY24B</button></li>
              <li><button class="policy-item" data-content="msgFY24A1">Message from Koji Ikeya,Corporate Senior Executive Vice President – Start of FY24A</button></li>
              <li><button class="policy-item" data-content="msgFY24A">CEO Message-Taro Shimada - Start of FY24A</button></li>
              <li><button class="policy-item" data-content="msgnewyear"> CEO Message – 2024 New Year</button></li>
              <li><button class="policy-item" data-content="msgnewyear-Japanese"> CEO Message – 2024 New Year-Japanese</button></li>
              <li><button class="policy-item" data-content="msgmediumTermPlan">CEO Message – New Medium‑Term Business Plan</button></li>
              <li><button class="policy-item" data-content="mediumTermPlan">New Medium‑Term Business Plan</button></li>
              <li><button class="policy-item" data-content="CISO"> Message – CISO Cybersecurity</button></li>
              <li><button class="policy-item" data-content="CISO-Japanese"> Message – CISO_Cybersecurity-Japanese</button></li>

            </ul>
          `,
    'legalGroup': `
            <h2>Legal Policies</h2>
            <ul>
              <li><button class="policy-item" data-content="codeConduct">Code of Conduct</button></li>
              <li><button class="policy-item" data-content="antiBribery">Anti-Bribery / Anti-Corruption</button></li>
              <li><button class="policy-item" data-content="whistleBlower">Whistle Blower Policy</button></li>
              <li><button class="policy-item" data-content="conflictInterest">Conflict of Interest</button></li>
              <li><button class="policy-item" data-content="exportControl">Export Control Program</button></li>
              <li><button class="policy-item" data-content="csrPolicy">CSR Policy</button></li>
            </ul>
          `,
    'itGroup': `
            <h2>Information Technology</h2>
            <ul>
              <li><button class="policy-item" data-content="infoSecurity">Information Security Standard</button></li>
              <li><button class="policy-item" data-content="cyberSecurity">Cyber Security Regulations</button></li>
              <li><button class="policy-item" data-content="infoSystems">Use of Information Systems</button></li>
              <li><button class="policy-item" data-content="socialMedia">Social Media Guidelines</button></li>
            </ul>
          `,
    'hrGroup': `
            <h2>Human Resource</h2>
            <ul>
              <li><button class="policy-item" data-content="leavePolicy">Leave Policy</button></li>
              <li><button class="policy-item" data-content="travelAttendance">Travel & Attendance</button></li>
              <li><button class="policy-item" data-content="performanceManagement">Performance Management</button></li>
            </ul>
          `,
    'purchaseGroup': `
            <h2>Procurement</h2>
            <ul>
              <li><button class="policy-item" data-content="procurementManagementRules">Procurement Management Rules</button></li>
              <li><button class="policy-item" data-content="procurementPolicy">Procurement Policy</button></li>
              <li><button class="policy-item" data-content="internalConstructionManagementRules">Internal Construction Management Rules</button></li>
            </ul>
          `,
    'qualityGroup': `
            <h2>Quality</h2>
            <ul>
              <li><button class="policy-item" data-content="qualityPolicy">Quality Policy</button></li>
              <li><button class="policy-item" data-content="environmentalPolicy">Environmental Policy</button></li>
              <li><button class="policy-item" data-content="occupationalHealthSafetyPolicy">Occupational Health & Safety Policy</button></li>
              <li><button class="policy-item" data-content="basicRegulationsEnvironmentalManagement">Basic Regulations on Environmental Management</button></li>
              <li><button class="policy-item" data-content="comprehensiveQualityAssuranceRegulations">Comprehensive Quality Assurance Regulations</button></li>
              <li><button class="policy-item" data-content="nablAccreditedTestingLabs">NABL Accredited Testing Laboratories (Certificate No. TC-7827)</button></li>
            </ul>
          `,
    'F&AGroup': `
            <h2>Finance & Accounts</h2>
            <ul>
              <li><button class="policy-item" data-content="regulationBadDoubtfulDebts">Regulation on Provision for Bad and Doubtful Debts</button></li>
              <li><button class="policy-item" data-content="regulationPhysicalStockTaking">Regulation for Physical Stock Taking</button></li>
              <li><button class="policy-item" data-content="regulationValuationInventories">Regulation on Valuation of Inventories</button></li>
              <li><button class="policy-item" data-content="revenueRecognitionEPC">Revenue Recognition - EPC Contracts</button></li>
              <li><button class="policy-item" data-content="revenueRecognitionGoodsServices">Revenue Recognition for Supply of Goods and Services</button></li>
              <li><button class="policy-item" data-content="accountingPolicyManual">Accounting Policy Manual</button></li>
              <li><button class="policy-item" data-content="regulationBudgetManagement">Regulation for Budget Management</button></li>
              <li><button class="policy-item" data-content="regulationPPEIntangibles">Regulation on Property, Plant and Equipment (PPE) & Intangibles</button></li>
              <li><button class="policy-item" data-content="regulationDeferredTaxCalculation">Regulation on Deferred Tax Calculation</button></li>
              <li><button class="policy-item" data-content="regulationValuationBusinessImpairment">Regulation on Valuation of Business for the purpose of Impairment Test of Assets</button></li>
              <li><button class="policy-item" data-content="businessRiskManagementStandardRules">Business Risk Management Standard Rules</button></li>
              <li><button class="policy-item" data-content="ttdiTimelyDisclosureProcedure">TTDI Regulations for Timely Disclosure Procedure Policy</button></li>
            </ul>
          `,
    'EnggGroup': `
            <h2>Engineering</h2>
            <ul>
              <li><button class="policy-item" data-content="basicRegulationsTechnologyManagement">Basic Regulations for Technology Management</button></li>
              <li><button class="policy-item" data-content="policyTechnicalInformationIPR">Policy for Technical Information and Intellectual Property Rights Administration</button></li>
              <li><button class="policy-item" data-content="universalDesignPromotionRegulations">Universal Design (UD) Promotion Regulations</button></li>
            </ul>
          `,
    'planGroup': `
            <h2>Planning</h2>
            <ul>
              <li><button class="policy-item" data-content="guidelinesPlanningProcess">Guidelines for Planning Process</button></li>
            </ul>
          `,
    'marketGroup': `
            <h2>Marketing</h2>
            <ul>
              <li><button class="policy-item" data-content="marketingPolicyFraudRisk">Marketing Policy Against Fraud Risk</button></li>
            </ul>
          `,

    // Individual policy content details
    'msgmediumTermPlan': `<h3>CEO Message – New Medium‑Term Business Plan</h3><p>Latest CEO updates for November.</p>
            <iframe 
                src=""
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,

    'msgFY25A': `<h3>CEO Message – Start of FY25A</h3><p>Start of FY25A updates and plans.</p>
            <iframe 
                src="https://ttdi.toshiba-ttdi.com/IT%20Training/CEO/CEO%20message%20FY25A/"
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,

    'msgFY24B': `<h3>CEO Message – Start of FY24B</h3><p>Overview of FY24B goals.</p>
            <iframe 
                src="https://ttdi.toshiba-ttdi.com/IT%20Training/CEO/CEO%20Message_start%20of%20FY24B//"
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,

    'mediumTermPlan': `<h3>New Medium‑Term Business Plan</h3><p>Details of the new business roadmap.</p>
            <iframe 
                src="https://ttdi.toshiba-ttdi.com/IT%20Training/CEO/CEO%20Message_New%20Medium-Term%20Business%20Plan/"
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,

    'msgFY24A1': `<h3>Message from Koji Ikeya,Corporate Senior Executive Vice President – Start of FY24A</h3><p>Message from Koji Ikeya, Corporate Senior Executive Vice President, at the start of FY24A</p>
            <iframe 
                src="https://ttdi.toshiba-ttdi.com/IT%20Training/CEO/Message%20from%20Corporate%20Senior%20Executive%20Vice%20President%20_FY24A/"
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,

    'msgFY24A': `<h3>CEO Message-Taro Shimada - Start of FY24A</h3><p>Message from Taro Shimada, CEO of Toshiba, at the start of FY24A</p>
            <iframe 
                src="https://ttdi.toshiba-ttdi.com/IT%20Training/CEO/Message%20from%20CEO_FY24A/"
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,

    'CISO': `<h3>CISO Cybersecurity</h3><p>Message from the CISO Cybersecurity Month</p>
            <iframe 
                src="https://ttdi.toshiba-ttdi.com/IT%20Training/CEO/Message%20from%20the%20CISO_Cybersecurity%20Month/"
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,

    'CISO-Japanese': `<h3>CISO Cybersecurity-Japanese</h3><p>Message from the CISO Cybersecurity Month-Japanese</p>
            <iframe 
                src="https://ttdi.toshiba-ttdi.com/IT%20Training/CEO/Message%20from%20the%20CISO_Cybersecurity%20Month%20-%20Japanese/"
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,

    'msgnewyear': `<h3>CEO Message – 2024 New Year</h3><p>2024 New Year Message from the CEO</p>
            <iframe 
                src="https://ttdi.toshiba-ttdi.com/IT%20Training/CEO/2024%20New%20Year%20Message%20from%20the%20CEO/"
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,

    'msgnewyear-Japanese': `<h3>CEO Message – 2024 New Year-Japanese</h3><p>2024 New Year Message from the CEO - Japanese</p>
            <iframe 
                src="https://ttdi.toshiba-ttdi.com/IT%20Training/CEO/2024%20New%20Year%20Message%20from%20the%20CEO_JPN/"
                width="100%" 
                height="600px"
                style="border: none;">
            </iframe>`,


    //Legal Policies
    'codeConduct': `<h3>Code of Conduct</h3><p>Rules and guidelines for workplace conduct.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/SOC/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'antiBribery': `<h3>Anti-Bribery / Anti-Corruption</h3><p>Policies against bribery and corruption.</p>
                            <iframe 
                                src=""
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'whistleBlower': `<h3>Whistle Blower Policy</h3><p>How to report misconduct confidentially.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/whistle-blower/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'conflictInterest': `<h3>Conflict of Interest</h3><p>Declare potential conflicts at work.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Legal/Conflict%20of%20Interest%20Policy%20and%20Procedure/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'exportControl': `<h3>Export Control Program</h3><p>Compliance for export controls.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Export%20Control%20Program/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'csrPolicy': `<h3>CSR Policy</h3><p>Corporate social responsibility commitment.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Legal/Corporate%20Social%20Responsibility%20Policy/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,


    // Information Technology
    'infoSecurity': `<h3>Information Security Standard</h3><p>Security policies for company information.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/IT/ITsit/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'cyberSecurity': `<h3>Cyber Security Regulations</h3><p>Cybersecurity rules and procedures.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/IT/Basic%20Regulation%20for%20Cyber%20Security/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'infoSystems': `<h3>Rules on Use of Information Systems</h3><p>Guidelines on IT assets and usage.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/IT/Rules%20on%20Use%20of%20Information%20Systems/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'socialMedia': `<h3>Social Media Guidelines</h3><p>Proper use of social media by employees.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/IT/PSocialMediaGuideE/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,


    //Human Resources
    'leavePolicy': `<h3>Leave Policy</h3><p>Details on company leave entitlements and process.</p>
                            <iframe 
                                src=""
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'travelAttendance': `<h3>Travel & Attendance</h3><p>Policies on travel and attendance tracking.</p>
                            <iframe 
                                src=""
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'performanceManagement': `<h3>Performance Management</h3><p>Details of appraisal and performance processes.</p>
                            <iframe 
                                src=""
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,


    //Procurement
    'procurementManagementRules': `<h3>Procurement Management Rules</h3><p>Details for Procurement Management Rules.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Procurement/ProcurementRule/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'procurementPolicy': `<h3>Procurement Policy</h3><p>Details for Procurement Policy.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Procurement/Procurementpolicy/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'internalConstructionManagementRules': `<h3>Internal Construction Management Rules</h3><p>Details for Internal Construction Management Rules.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Procurement/Internal%20Construction%20Management%20Rules/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,


    //Qualtiy
    'qualityPolicy': `<h3>Quality Policy</h3><p>Details on the Quality Policy.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Quality/Quality%20Policy/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'environmentalPolicy': `<h3>Environmental Policy</h3><p>Details on the Environmental Policy.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Quality/Environmental%20policy/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'occupationalHealthSafetyPolicy': `<h3>Occupational Health & Safety Policy</h3><p>Details on the Occupational Health & Safety Policy.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Quality/OH%20and%20S/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'basicRegulationsEnvironmentalManagement': `<h3>Basic Regulations on Environmental Management</h3><p>Details on Environmental Management regulations.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Quality/Basic%20Regulations%20on%20Environmental%20Management/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'comprehensiveQualityAssuranceRegulations': `<h3>Comprehensive Quality Assurance Regulations</h3><p>Details on Quality Assurance Regulations.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Quality/Comprehensive%20Quality%20Assurance%20Regulations/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'nablAccreditedTestingLabs': `<h3>NABL Accredited Testing Laboratories</h3><p>Certificate number TC-7827 details.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Quality/NABL/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,



    //Finance and Accounts
    'regulationBadDoubtfulDebts': `<h3>Regulation on Provision for Bad and Doubtful Debts</h3><p>Details of provision regulations.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Provision%20for%20Bad%20and%20Doubtful%20Debts/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'regulationPhysicalStockTaking': `<h3>Regulation for Physical Stock Taking</h3><p>Details about stock taking regulations.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Regulation%20for%20Physical%20Stock%20Taking/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'regulationValuationInventories': `<h3>Regulation on Valuation of Inventories</h3><p>Inventory valuation procedures.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Regulation%20on%20Valuation%20of%20Inventories/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'revenueRecognitionEPC': `<h3>Revenue Recognition - EPC Contracts</h3><p>Revenue recognition guidelines for EPC contracts.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Quality/Revenue%20Recognition%20-%20EPC%20Contracts/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'revenueRecognitionGoodsServices': `<h3>Revenue Recognition for Supply of Goods and Services</h3><p>Revenue recognition for goods and services.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Revenue%20Recognition%20-%20Manufactured%20Goods/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'accountingPolicyManual': `<h3>Accounting Policy Manual</h3><p>Comprehensive accounting policies.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Accounitng%20Policy%20Manual/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'regulationBudgetManagement': `<h3>Regulation for Budget Management</h3><p>Guidelines for managing budgets.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Regulation%20%20for%20%20Budget%20Management/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'regulationPPEIntangibles': `<h3>Regulation on Property, Plant and Equipment (PPE) & Intangibles</h3><p>Policies on PPE and intangible assets.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Regulation%20on%20Fixed%20Assets/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'regulationDeferredTaxCalculation': `<h3>Regulation on Deferred Tax Calculation</h3><p>Standards for deferred tax calculation.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Regulation%20on%20Deferred%20Tax%20Calculation/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'regulationValuationBusinessImpairment': `<h3>Regulation on Valuation of Business for the purpose of Impairment Test of Assets</h3><p>Procedures for business valuation and asset impairment tests.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Regulation%20on%20Valuation%20of%20Business%20for%20the%20purpose%20of%20Impairment%20Test%20of%20Assets/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'businessRiskManagementStandardRules': `<h3>Business Risk Management Standard Rules</h3><p>Rules for risk management standards.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/Training/Business_Risk_Management"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'ttdiTimelyDisclosureProcedure': `<h3>TTDI Regulations for Timely Disclosure Procedure Policy</h3><p>Guidelines on timely disclosure procedures.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/FandA/Timely%20Disclosure/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,



    //Engineering
    'basicRegulationsTechnologyManagement': `<h3>Basic Regulations for Technology Management</h3><p>Details on technology management regulations.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/ENGINEERING/Basic%20Regulations%20for%20Technology%20Management/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'policyTechnicalInformationIPR': `<h3>Policy for Technical Information and Intellectual Property Rights Administration</h3><p>Details on handling technical information and intellectual property rights.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/ENGINEERING/Policy%20for%20Technical%20Information%20and%20IPR%20Admn/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'universalDesignPromotionRegulations': `<h3>Universal Design (UD) Promotion Regulations</h3><p>Information on UD promotion regulations.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/ENGINEERING/Universal%20Design(UD)%20Promotion%20Regulations/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,


    //Planning
    'guidelinesPlanningProcess': `<h3>Guidelines for Planning Process</h3><p>Details on the planning process guidelines.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/planning/Guidelines/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,


    //Marketing
    'marketingPolicyFraudRisk': `<h3>Marketing Policy Against Fraud Risk</h3><p>Details on marketing policies to mitigate fraud risk.</p>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/IT%20Training/Marketing/Marketing%20Policy%20against%20Fraud%20Risk/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,


    // Quick modules and others as needed...
    'general': `<section class="quick-links" aria-label="Quick access modules">
              <!-- Quick cards simplified for brevity -->
              <article class="quick-card">
                <header class="quick-card-header">
                  <div class="quick-badge">G</div>
                  <div>
                    <div class="quick-title">General Company Info</div>
                    <div class="quick-caption">Company Calender,Directory &amp; more</div>
                  </div>
                </header>
                <div class="quick-actions">
                  <button class="btn-chip btn-chip-primary" type="button" data-content="generalCalendar">Company Calender</button>
                  <button class="btn-chip" type="button" data-content="generalDirectory">Web Directory</button>
                  <button class="btn-chip" type="button" data-content="others">Others</button>

                </div>
              </article>
              <!-- other quick cards can be added similarly -->
            </section>`,

    'Helpdesk': `<h2 style="text-align: center;">Help Desk</h2>
            <section class="helpdesk-widgets" aria-label="Help desk modules">
                <!-- IT Help Desk Widget (Clickable) -->
                <article class="quick-text" style="cursor: pointer;" onclick="loadContent('itHelpdesk')">
                <header class="quick-card-header">
                    <div class="quick-badge">I</div>
                    <div>
                    <div class="quick-title">IT Help Desk</div>
                    <div class="quick-caption">Submit IT requests & track tickets</div>
                    </div>
                </header>
                </article>

                <!-- Engineering Help Desk Widget -->
                <article class="quick-text">
                <header class="quick-card-header">
                    <div class="quick-badge">E</div>
                    <div>
                    <div class="quick-title">Engg Help Desk</div>
                    <div class="quick-caption">Technical support & engineering queries</div>
                    </div>
                </header>
                </article>
            </section>
            `,

    'itHelpdesk': `<!-- Helpdesk Content Section - Add this inside main content area -->

                <div id="itHelpdesk" class="content others" >
                    <div class="helpdesk-container">
                        <h2 class="page-heading">Helpdesk</h2>

                        <!-- Tab Navigation -->
                        <div class="tab-bar">
                            <button class="tab-btn active" data-tab="new">New Case</button>
                            <button class="tab-btn" data-tab="logged">Logged Cases</button>
                            <button class="tab-btn" data-tab="pending">Pending Approvals</button>
                            <button class="tab-btn" data-tab="reports">Reports</button>
                        </div>

                        <!-- NEW CASE TAB -->
                        <div id="tab-new" class="tab-content active">
                            <div class="new-request-wrapper">
                                <!-- Request Type Toggle -->
                                <div class="request-toggle">
                                    <button class="toggle-btn active" data-request="facility">Facility Request</button>
                                    <button class="toggle-btn" data-request="service">Service Request</button>
                                </div>

                                <!-- FACILITY REQUEST FORM -->
                                <div id="request-facility" class="request-form full-width">
                                    <h3 class="section-title">Requisition Form for IT Facilities</h3>

                                    <!-- Form Header -->
                                    <div class="form-header">
                                        <div><span class="label">Domain ID</span> cit06389</div>
                                        <div><span class="label">Name</span> Harsha Vardhan</div>
                                        <div><span class="label">Date</span> <span id="facility-date"></span></div>
                                    </div>

                                    <!-- Employee Details -->
                                    <div class="form-section">
                                        <h4 class="form-section-title">Employee Details</h4>
                                        <div class="form-grid">
                                            <div class="form-row">
                                                <label>Employee Code</label>
                                                <input type="text" placeholder="EMP ID" id="emp-code">
                                            </div>
                                            <div class="form-row">
                                                <label>Company</label>
                                                <select id="company">
                                                    <option>Select Company</option>
                                                    <option>Toshiba-TTDI</option>
                                                    <option>Toshiba HQ</option>
                                                </select>
                                            </div>
                                            <div>
                                                <button class="view-btn small">View Employee</button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Employee Info Display -->
                                    <div class="form-section subtle">
                                        <div class="info-grid compact">
                                            <div><strong>Name:</strong> Ravi Kumar</div>
                                            <div><strong>Department:</strong> Engineering</div>
                                            <div><strong>Location:</strong> Hyderabad</div>
                                        </div>
                                    </div>

                                    <!-- Request Details -->
                                    <div class="form-section">
                                        <h4 class="form-section-title">Request Details</h4>
                                        <div class="form-grid">
                                            <div class="form-row">
                                                <label>Contact Number</label>
                                                <input type="number" id="contact-number">
                                            </div>
                                            <div class="form-row">
                                                <label>Department</label>
                                                <select id="request-dept">
                                                    <option value="">Select</option>
                                                    <option value="IT">IT</option>
                                                    <option value="ADMIN">ADMIN</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- IT Requirements (shown when IT selected) -->
                                    <div id="it-section" class="form-section highlight">
                                        <h4 class="form-section-title">IT Requirement</h4>
                                        <div class="form-row">
                                            <label>Request Type</label>
                                            <select id="it-request-type">
                                                <option value="">Select</option>
                                                <option value="Facility">Facility</option>
                                                <option value="Hardware">Hardware</option>
                                                <option value="BYOD">BYOD</option>
                                            </select>
                                        </div>

                                        <!-- Facility Type Options -->
                                        <div id="facility-type-section" style="display: none;">
                                            <div class="form-row">
                                                <label>Facility Type</label>
                                                <select id="facility-type">
                                                    <option value="">Select</option>
                                                    <option>Domain ID</option>
                                                    <option>ERP</option>
                                                    <option>Internet</option>
                                                    <option>Email</option>
                                                    <option>CD/DVD/Pen Drive</option>
                                                    <option>Software</option>
                                                    <option>DMS</option>
                                                    <option>Access</option>
                                                </select>
                                            </div>

                                            <!-- Domain ID Fields -->
                                            <div id="domain-id-fields" class="facility-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>Domain ID</label>
                                                    <input type="text">
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>

                                            <!-- ERP Fields -->
                                            <div id="erp-fields" class="facility-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>ERP User ID</label>
                                                    <input type="text">
                                                </div>
                                                <div class="form-row">
                                                    <label>Required Business Roles</label>
                                                    <textarea></textarea>
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>

                                            <!-- Internet Fields -->
                                            <div id="internet-fields" class="facility-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>Required Hours</label>
                                                    <select>
                                                        <option>9-11</option>
                                                        <option>2-4</option>
                                                        <option>Office Hours</option>
                                                        <option>24 Hours</option>
                                                    </select>
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>

                                            <!-- Email Fields -->
                                            <div id="email-fields" class="facility-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>Sending Option</label>
                                                    <select>
                                                        <option>External Sending</option>
                                                    </select>
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>

                                            <!-- CD/DVD/Pen Drive Fields -->
                                            <div id="cd-fields" class="facility-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>Data Copying Option</label>
                                                    <select>
                                                        <option>CD</option>
                                                        <option>DVD</option>
                                                        <option>Pen Drive</option>
                                                    </select>
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>

                                            <!-- Software Fields -->
                                            <div id="software-fields" class="facility-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>Specification</label>
                                                    <textarea placeholder="Software name, version, license details"></textarea>
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>

                                            <!-- DMS Fields -->
                                            <div id="dms-fields" class="facility-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>Specification</label>
                                                    <textarea placeholder="Folder access, workflow, role details"></textarea>
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>

                                            <!-- Access Fields -->
                                            <div id="access-fields" class="facility-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>Required Access</label>
                                                    <select>
                                                        <option>USB</option>
                                                        <option>CCTV</option>
                                                        <option>Cloud Link</option>
                                                        <option>NAS</option>
                                                    </select>
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Hardware Type Options -->
                                        <div id="hardware-type-section" style="display: none;">
                                            <div class="form-row">
                                                <label>Hardware Type</label>
                                                <select id="hardware-type">
                                                    <option value="">Select</option>
                                                    <option>Computer</option>
                                                    <option>Laptop</option>
                                                    <option>Printer</option>
                                                    <option>System Upgradation</option>
                                                    <option>Scanner</option>
                                                    <option>MFD</option>
                                                    <option>UPS</option>
                                                    <option>Network</option>
                                                    <option>Temporary Laptop/Mobile</option>
                                                </select>
                                            </div>

                                            <div id="regular-hardware-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>Specification</label>
                                                    <textarea></textarea>
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>

                                            <div id="temp-device-fields" style="display: none;">
                                                <div class="form-row">
                                                    <label>Device Type</label>
                                                    <select>
                                                        <option value="">Select</option>
                                                        <option>Laptop</option>
                                                        <option>Mobile</option>
                                                    </select>
                                                </div>
                                                <div class="form-row">
                                                    <label>From Date</label>
                                                    <input type="date">
                                                </div>
                                                <div class="form-row">
                                                    <label>To Date</label>
                                                    <input type="date">
                                                </div>
                                                <div class="form-row">
                                                    <label>Purpose</label>
                                                    <textarea></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- ADMIN Requirements (shown when ADMIN selected) -->
                                    <div id="admin-section" class="form-section highlight" style="display: none;">
                                        <h4 class="form-section-title">Admin Requirement</h4>
                                        <div class="form-row">
                                            <label>Request Type</label>
                                            <select id="admin-request-type">
                                                <option value="">Select</option>
                                                <option value="Communication">Communication</option>
                                                <option value="Guest House">Guest House</option>
                                                <option value="Vehicle">Vehicle Requisition</option>
                                            </select>
                                        </div>

                                        <!-- Communication Fields -->
                                        <div id="communication-fields" style="display: none;">
                                            <div class="form-row">
                                                <label>Communication Type</label>
                                                <select>
                                                    <option>Mobile</option>
                                                    <option>Landline</option>
                                                    <option>Datacard</option>
                                                </select>
                                            </div>
                                            <div class="form-row">
                                                <label>Purpose</label>
                                                <textarea></textarea>
                                            </div>
                                        </div>

                                        <!-- Guest House Fields -->
                                        <div id="guesthouse-fields" style="display: none;">
                                            <div class="form-row">
                                                <label>From Date & Time</label>
                                                <input type="datetime-local">
                                            </div>
                                            <div class="form-row">
                                                <label>To Date & Time</label>
                                                <input type="datetime-local">
                                            </div>
                                            <div class="form-row">
                                                <label>Remarks</label>
                                                <textarea></textarea>
                                            </div>

                                            <!-- Guest Details -->
                                            <div class="sub-form">
                                                <h5 class="sub-title">Additional Guest Details (Max 4)</h5>
                                                <div class="guest-grid">
                                                    <div class="guest-card">
                                                        <div class="guest-header">Guest 1</div>
                                                        <div class="form-row">
                                                            <label>Guest Type</label>
                                                            <select class="guest-type">
                                                                <option value="">Select</option>
                                                                <option value="Internal">Internal</option>
                                                                <option value="External">External</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-row guest-empid-row">
                                                            <label>Employee ID</label>
                                                            <input type="number" class="guest-empid">
                                                        </div>
                                                        <div class="form-row">
                                                            <label>Guest Name</label>
                                                            <input type="text" class="guest-name">
                                                        </div>
                                                    </div>

                                                    <div class="guest-card">
                                                        <div class="guest-header">Guest 2</div>
                                                        <div class="form-row">
                                                            <label>Guest Type</label>
                                                            <select class="guest-type">
                                                                <option value="">Select</option>
                                                                <option value="Internal">Internal</option>
                                                                <option value="External">External</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-row guest-empid-row">
                                                            <label>Employee ID</label>
                                                            <input type="number" class="guest-empid">
                                                        </div>
                                                        <div class="form-row">
                                                            <label>Guest Name</label>
                                                            <input type="text" class="guest-name">
                                                        </div>
                                                    </div>

                                                    <div class="guest-card">
                                                        <div class="guest-header">Guest 3</div>
                                                        <div class="form-row">
                                                            <label>Guest Type</label>
                                                            <select class="guest-type">
                                                                <option value="">Select</option>
                                                                <option value="Internal">Internal</option>
                                                                <option value="External">External</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-row guest-empid-row">
                                                            <label>Employee ID</label>
                                                            <input type="number" class="guest-empid">
                                                        </div>
                                                        <div class="form-row">
                                                            <label>Guest Name</label>
                                                            <input type="text" class="guest-name">
                                                        </div>
                                                    </div>

                                                    <div class="guest-card">
                                                        <div class="guest-header">Guest 4</div>
                                                        <div class="form-row">
                                                            <label>Guest Type</label>
                                                            <select class="guest-type">
                                                                <option value="">Select</option>
                                                                <option value="Internal">Internal</option>
                                                                <option value="External">External</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-row guest-empid-row">
                                                            <label>Employee ID</label>
                                                            <input type="number" class="guest-empid">
                                                        </div>
                                                        <div class="form-row">
                                                            <label>Guest Name</label>
                                                            <input type="text" class="guest-name">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Vehicle Requisition Fields -->
                                        <div id="vehicle-fields" style="display: none;">
                                            <div class="form-row">
                                                <label>Pickup Location</label>
                                                <input type="text">
                                            </div>
                                            <div class="form-row">
                                                <label>Purpose</label>
                                                <select>
                                                    <option>Factory Visit</option>
                                                    <option>Inspection</option>
                                                    <option>Meeting</option>
                                                    <option>Airport/Railway Pickup or Drop</option>
                                                    <option>Outstation</option>
                                                    <option>Others</option>
                                                </select>
                                            </div>
                                            <div class="form-row">
                                                <label>Car Required From</label>
                                                <input type="datetime-local">
                                            </div>
                                            <div class="form-row">
                                                <label>To</label>
                                                <input type="datetime-local">
                                            </div>
                                            <div class="form-row">
                                                <label>Guest Mobile Number</label>
                                                <input type="number">
                                            </div>

                                            <!-- Guest Details for Vehicle -->
                                            <div class="sub-form">
                                                <h5 class="sub-title">Additional Guest Details (Max 4)</h5>
                                                <div class="guest-grid">
                                                    <!-- Same 4 guest cards structure as above -->
                                                    <div class="guest-card">
                                                        <div class="guest-header">Guest 1</div>
                                                        <div class="form-row">
                                                            <label>Guest Type</label>
                                                            <select class="guest-type-vehicle">
                                                                <option value="">Select</option>
                                                                <option value="Internal">Internal</option>
                                                                <option value="External">External</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-row guest-empid-row-vehicle">
                                                            <label>Employee ID</label>
                                                            <input type="number" class="guest-empid-vehicle">
                                                        </div>
                                                        <div class="form-row">
                                                            <label>Guest Name</label>
                                                            <input type="text" class="guest-name-vehicle">
                                                        </div>
                                                    </div>
                                                    <!-- Repeat for Guest 2, 3, 4 -->
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="form-actions">
                                        <button class="submit-btn">Submit Request</button>
                                    </div>
                                </div>

                                <!-- SERVICE REQUEST FORM -->
                                <div id="request-service" class="request-form full-width" style="display: none;">
                                    <h3 class="section-title">Service Request</h3>

                                    <!-- Form Header -->
                                    <div class="form-header">
                                        <div><span class="label">Domain ID</span> cit06389</div>
                                        <div><span class="label">Name</span> Harsha Vardhan</div>
                                        <div><span class="label">Date</span> <span id="service-date"></span></div>
                                    </div>

                                    <!-- Basic Details -->
                                    <div class="form-section">
                                        <h4 class="form-section-title">Basic Details</h4>
                                        <div class="form-grid">
                                            <div class="form-row">
                                                <label>Call Logged For</label>
                                                <input type="number">
                                            </div>
                                            <div class="form-row">
                                                <label>Company</label>
                                                <select>
                                                    <option>Toshiba-TTDI</option>
                                                </select>
                                            </div>
                                            <div class="form-row">
                                                <label>Contact Number</label>
                                                <input type="number">
                                            </div>
                                            <div class="form-row">
                                                <label>Email ID</label>
                                                <input type="email">
                                            </div>
                                            <div class="form-row">
                                                <label>Department</label>
                                                <select id="service-dept">
                                                    <option value="">Select</option>
                                                    <option value="IT">Information Technology</option>
                                                    <option value="Maintenance">Maintenance</option>
                                                    <option value="HR">Human Resource</option>
                                                    <option value="Internal">Internal Projects</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- IT Details (shown when IT selected) -->
                                    <div id="service-it-section" class="form-section highlight" style="display: none;">
                                        <h4 class="form-section-title">IT Details</h4>
                                        <div class="form-row">
                                            <label>Category</label>
                                            <select id="service-it-category">
                                                <option value="">Select</option>
                                                <option value="Computer">Computer</option>
                                                <option value="ERP">ERP</option>
                                            </select>
                                        </div>

                                        <!-- Computer Sub-category -->
                                        <div id="computer-sub" style="display: none;">
                                            <div class="form-row">
                                                <label>Sub Category</label>
                                                <select>
                                                    <option>Hardware</option>
                                                    <option>Network</option>
                                                    <option>Software</option>
                                                </select>
                                            </div>
                                            <div class="form-row">
                                                <label>Asset ID</label>
                                                <input type="text">
                                            </div>
                                        </div>

                                        <!-- ERP Sub-category -->
                                        <div id="erp-sub" style="display: none;">
                                            <div class="form-row">
                                                <label>Sub Category</label>
                                                <select>
                                                    <option>Functional</option>
                                                    <option>ION</option>
                                                    <option>Tools</option>
                                                </select>
                                            </div>
                                            <div class="form-row">
                                                <label>Session ID</label>
                                                <input type="text">
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <label>
                                                <input type="checkbox" id="rework-check">
                                                Rework
                                            </label>
                                        </div>
                                    </div>

                                    <!-- Maintenance Details -->
                                    <div id="service-maintenance-section" class="form-section highlight" style="display: none;">
                                        <h4 class="form-section-title">Maintenance Details</h4>
                                        <div class="form-row">
                                            <label>Category</label>
                                            <select>
                                                <option>Unit - 2</option>
                                                <option>Unit - 3</option>
                                                <option>Unit - 4</option>
                                                <option>Unit - 7</option>
                                                <option>Unit - 9</option>
                                                <option>Unit - 10</option>
                                                <option>Unit - 11</option>
                                                <option>Unit - 16</option>
                                                <option>Unit - 18</option>
                                            </select>
                                        </div>
                                        <div class="form-row">
                                            <label>Sub Category</label>
                                            <select>
                                                <option>Electrical</option>
                                                <option>Mechanical</option>
                                                <option>Utility</option>
                                            </select>
                                        </div>
                                        <div class="form-row">
                                            <label>Description</label>
                                            <select>
                                                <option>Machine Breakdown</option>
                                                <option>Machine Abnormality</option>
                                                <option>Machine Preventive</option>
                                                <option>Machine General</option>
                                                <option>General Electrical</option>
                                                <option>Others</option>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- HR Details -->
                                    <div id="service-hr-section" class="form-section highlight" style="display: none;">
                                        <h4 class="form-section-title">HR Details</h4>
                                        <div class="form-row">
                                            <label>Category</label>
                                            <select>
                                                <option>Communication</option>
                                                <option>Office Setup</option>
                                            </select>
                                        </div>
                                        <div class="form-row">
                                            <label>Sub Category</label>
                                            <select>
                                                <option>Landline</option>
                                                <option>Mobile</option>
                                                <option>Furniture</option>
                                                <option>House Keeping</option>
                                                <option>Plumbing</option>
                                                <option>Refreshment</option>
                                                <option>Xerox</option>
                                            </select>
                                        </div>
                                        <div class="form-row">
                                            <label>Description</label>
                                            <textarea></textarea>
                                        </div>
                                    </div>

                                    <!-- Internal Projects Details -->
                                    <div id="service-internal-section" class="form-section highlight" style="display: none;">
                                        <h4 class="form-section-title">Internal Projects</h4>
                                        <div class="form-row">
                                            <label>Category</label>
                                            <select>
                                                <option>Common Area</option>
                                                <option>Office Improvement or Development</option>
                                                <option>Shop Floor</option>
                                            </select>
                                        </div>
                                        <div class="form-row">
                                            <label>Sub Category</label>
                                            <select>
                                                <option>Doors and Windows</option>
                                                <option>Flooring</option>
                                                <option>Walls</option>
                                                <option>Roof</option>
                                                <option>Drains</option>
                                                <option>Road</option>
                                            </select>
                                        </div>
                                        <div class="form-row">
                                            <label>Description</label>
                                            <textarea></textarea>
                                        </div>
                                    </div>

                                    <!-- Common Fields -->
                                    <div class="form-section">
                                        <div class="form-row">
                                            <label>Subject</label>
                                            <input type="text">
                                        </div>
                                        <div class="form-row">
                                            <label>Problem Description</label>
                                            <textarea></textarea>
                                        </div>
                                        <div class="form-row">
                                            <label>Attachment</label>
                                            <input type="file">
                                        </div>
                                    </div>

                                    <div class="form-actions">
                                        <button class="submit-btn">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- LOGGED CASES TAB -->
                        <div id="tab-logged" class="tab-content">
                            <div class="table-header">
                                <h3 class="section-title">User Logged Cases</h3>
                                <div class="search-bar">
                                    <select id="search-by">
                                        <option value="caseId">Search by Case ID</option>
                                        <option value="problem">Search by Problem</option>
                                    </select>
                                    <input type="text" id="search-text" placeholder="Search...">
                                </div>
                            </div>

                            <table class="cases-table">
                                <thead>
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Case Number</th>
                                        <th>To Department</th>
                                        <th>Problem</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Change Request Status</th>
                                    </tr>
                                </thead>
                                <tbody id="logged-cases-tbody">
                                    <tr>
                                        <td>1</td>
                                        <td><button class="link-btn" onclick="showPopup('Case Details', 'Case Number: ULC-2024-001')">ULC-2024-001</button></td>
                                        <td>IT</td>
                                        <td>Email not syncing</td>
                                        <td>2024-12-02</td>
                                        <td><span class="status open">Open</span></td>
                                        <td><button class="link-btn" onclick="showPopup('Change Request', 'Status: Pending')">Pending</button></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td><button class="link-btn" onclick="showPopup('Case Details', 'Case Number: ULC-2024-002')">ULC-2024-002</button></td>
                                        <td>HR</td>
                                        <td>Leave balance mismatch</td>
                                        <td>2024-12-04</td>
                                        <td><span class="status closed">Closed</span></td>
                                        <td><button class="link-btn" onclick="showPopup('Change Request', 'Status: Approved')">Approved</button></td>
                                    </tr>
                                </tbody>
                            </table>

                            <h3 class="section-title">User Facility Requests</h3>
                            <table class="cases-table">
                                <thead>
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Case Number</th>
                                        <th>Request Type</th>
                                        <th>Request Date</th>
                                        <th>Remark</th>
                                        <th>Change Request Status</th>
                                    </tr>
                                </thead>
                                <tbody id="facility-requests-tbody">
                                    <tr>
                                        <td>1</td>
                                        <td><button class="link-btn" onclick="showPopup('Facility Case', 'Case Number: HD-2024-001')">HD-2024-001</button></td>
                                        <td>IT Support</td>
                                        <td>2024-12-01</td>
                                        <td>System not booting</td>
                                        <td><button class="link-btn" onclick="showPopup('Facility Status', 'Current Status: Open')">Open</button></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td><button class="link-btn" onclick="showPopup('Facility Case', 'Case Number: HD-2024-002')">HD-2024-002</button></td>
                                        <td>Access Request</td>
                                        <td>2024-12-03</td>
                                        <td>VPN access required</td>
                                        <td><button class="link-btn" onclick="showPopup('Facility Status', 'Current Status: In Progress')">In Progress</button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- PENDING APPROVALS TAB -->
                        <div id="tab-pending" class="tab-content">
                            <p>Pending Approvals form will be implemented here.</p>
                        </div>

                        <!-- REPORTS TAB -->
                        <div id="tab-reports" class="tab-content">
                            <div class="request-form full-width">
                                <h3 class="section-title">Reports</h3>

                                <!-- Form Header -->
                                <div class="form-header">
                                    <div><span class="label">Domain ID</span> cit06389</div>
                                    <div><span class="label">Name</span> Harsha Vardhan</div>
                                    <div><span class="label">Date</span> <span id="report-date"></span></div>
                                </div>

                                <!-- Report Filters -->
                                <div class="form-section">
                                    <h4 class="form-section-title">Report Filters</h4>
                                    <div class="form-grid two-col">
                                        <div class="form-row">
                                            <label>Employee ID</label>
                                            <input type="text" id="report-emp-id">
                                        </div>
                                        <div class="form-row">
                                            <label>Company</label>
                                            <select>
                                                <option>Toshiba-TTDI</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-grid two-col">
                                        <div class="form-row">
                                            <label>From Date</label>
                                            <input type="date" id="report-from-date">
                                        </div>
                                        <div class="form-row">
                                            <label>To Date</label>
                                            <input type="date" id="report-to-date">
                                        </div>
                                    </div>

                                    <div class="form-grid two-col">
                                        <div class="form-row">
                                            <label>Required Area</label>
                                            <select id="report-category">
                                                <option value="">Select</option>
                                                <option>Computer</option>
                                                <option>ERP</option>
                                                <option>Communication</option>
                                                <option>Office Setup</option>
                                                <option>Common Area</option>
                                                <option>Office Improvement or Development</option>
                                                <option>Shop Floor</option>
                                                <option>Unit - 2</option>
                                                <option>Unit - 3</option>
                                                <option>Unit - 4</option>
                                                <option>Unit - 7</option>
                                                <option>Unit - 9</option>
                                                <option>Unit - 10</option>
                                                <option>Unit - 11</option>
                                                <option>Unit - 16</option>
                                                <option>Unit - 18</option>
                                                <option>General</option>
                                            </select>
                                        </div>
                                        <div class="form-row">
                                            <label>Category</label>
                                            <select id="report-subcategory">
                                                <option value="">Select</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-grid two-col">
                                        <div class="form-row">
                                            <label>Status</label>
                                            <select>
                                                <option value="">Select</option>
                                                <option>New Request</option>
                                                <option>Assigned</option>
                                                <option>In Progress</option>
                                                <option>Resolved</option>
                                                <option>Closed</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-actions">
                                    <button class="submit-btn">Generate Reports</button>
                                    <button class="submit-btn" style="margin-left: 12px;">Export to Excel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Popup Modal -->
                <div id="popup-overlay" class="popup-overlay" style="display: none;" onclick="closePopup()">
                    <div class="popup-box" onclick="event.stopPropagation()">
                        <h4 id="popup-title">Title</h4>
                        <p id="popup-message">Message</p>
                        <div class="popup-actions">
                            <button class="submit-btn" onclick="closePopup()">Close</button>
                        </div>
                    </div>
                </div>`,


    'hr': `<h2>HR Services</h2>
                    <section class="quick-links" aria-label="Quick access modules">
                  <article class="quick-card">
                        <header class="quick-card-header">
                          <div class="quick-badge">HR</div>
                          <div>
                            <div class="quick-title">Human Resources</div>
                            <div class="quick-caption">Leave Requests,payroll &amp; more</div>
                          </div>
                        </header>
                        <div class="quick-actions">
                          <button class="btn-chip btn-chip-primary" type="button" data-content="hrLeave">Leave Dashboard</button>
                          <button class="btn-chip" type="button" data-content="hrPaySlip">Pay Slips</button>
                          <button class="btn-chip" type="button" data-content="hrLetters">Letters & Revisions</button>
                          <button class="btn-chip" type="button" data-content="hrTax">Income Tax Declaration</button>
                          <button class="btn-chip" type="button" data-content="hrBus">Bus Routes</button>
                        </div>
                      </article>
                      </section>`,
    'learning': `<h2>E-Learning</h2><p>online courses.</p>`,
    'it': `<h2>IT & Security</h2>
                      <section class="quick-links" aria-label="Quick access modules">
                       <article class="quick-card">
                          <header class="quick-card-header">
                            <div class="quick-badge">IT</div>
                            <div>
                            <div class="quick-title">IT assest and software</div>
                            </div>
                          </header>
                          <div class="quick-actions">
                            <button class="btn-chip btn-chip-primary" type="button">Assets</button>
                            <button class="btn-chip" type="button">Software Licenses</button>
                          </div>
                       </article>
                    </section>`,
    'hrLeave': `<h3>Leave Dashboard</h3><p>Your leave balances and request management.</p>`,
    'hrPaySlip': `<h3>Pay Slip</h3><p>View and download your pay slips.</p>`,
    'hrLetters': `<h3>Letters & Revisions</h3><p>Access employment letters and revisions.</p>`,
    'hrTax': `<h3>Income Tax Declaration</h3><p>Manage tax declarations for the fiscal year.</p>`,
    'hrBus': `<h3>Bus Routes</h3><p>Information about company transport and bus routes.</p>`,
    'generalCalendar': `<h3>Company Calendar</h3>
                                <div style="text-align: center; margin-top: 20px;">
                                    <img src="./calender.png" 
                                        alt="Company Calendar" 
                                        style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                                </div>`,
    'generalDirectory': `<h3>Web Directory</h3>
                              <div class="sidebar-header">
                                <div class="sidebar-title">Company-wide directory of contacts and resources.</div>
                              </div>
                              <div class="sidebar-search">
                                <input type="search" id="policySearch" placeholder="Search employees..." />
                              </div>`,

    'Safety': `<h2 style="text-align: center;">Incidents</h2>
                        <section class="helpdesk-widgets" aria-label="Safety modules">
                            <!-- Safety Incidents Widget (Clickable) -->
                            <article class="quick-text" style="cursor: pointer;" onclick="loadContent('safetyIncidents')">
                                <header class="quick-card-header">
                                    <div class="quick-badge">S</div>
                                    <div>
                                        <div class="quick-title">Safety Incidents</div>
                                        <div class="quick-caption">Report & track safety incidents</div>
                                    </div>
                                </header>
                            </article>

                            <!-- IT Incidents Widget -->
                            <article class="quick-text" style="cursor: pointer;" onclick="loadContent('itIncidents')">
                                <header class="quick-card-header">
                                    <div class="quick-badge">I</div>
                                    <div>
                                        <div class="quick-title">IT Incidents</div>
                                        <div class="quick-caption">Report & track IT incidents</div>
                                    </div>
                                </header>
                            </article>
                        </section>`,

    'safetyIncidents': `
                <div style="display: flex ; justify-content: center; gap: 10px;">
                <button id="newIncidentBtn" style="width: 20%; border-radius: 0.7rem; border: 1px solid #ccc; background: #f9fafb; padding: 0.5rem 0.7rem; font-size: 0.78rem; color: #666; user-select: none; transition: all 0.2s ease;" data-content="newIncident">New Incident</button>
                <button id="incidentsBtn" style="width: 20%; border-radius: 0.7rem; border: 1px solid #ccc; background: #dbeafe; padding: 0.5rem 0.7rem; font-size: 0.78rem; color: #1d4ed8; font-weight: 600; user-select: none; transition: all 0.2s ease;">Incidents</button>
                </div>
                <div id="incidentsContent" style="display: none; margin: 1rem;">
                <h2 style="margin-bottom: 1rem; color: #111827;">Incidents</h2>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 0.8rem; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                    <thead>
                        <tr style="background: #1d4ed8; color: white; border-bottom: 3px solid #1e40af;">
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Incident ID</th>
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Division</th>
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Location</th>
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Section</th>
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Area</th>
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Occurred Date</th>
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Risk Category</th>
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Risk Level</th>
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Incident Type</th>
                            <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><a href="#" onclick="openIncidentView('FY25-DTR-CRG235'); return false;" style="color: #1d4ed8; text-decoration: none; font-weight: 600;">FY25-DTR-CRG235</a></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">DTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Rudraram</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 10 - IT Dept</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Core assembly</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2026-01-08 14:30</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Near-miss</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #dcfce7; color: #166534;">Low</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Non-reportable</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">New</span></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FY25-PTR-FIR456</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">PTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Baroda</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 3 Main Stores</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Central kitchen</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2026-01-07 09:15</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Fire</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #fecaca; color: #991b1b;">High</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FIR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">In Progress</span></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FY25-DTR-UA789</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">DTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Rudraram</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 5 - Assembly</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">OHC</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2026-01-06 16:45</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unsafe Act</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #fef3c7; color: #92400e;">Medium</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">First-Aid</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">Closed</span></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FY25-PTR-INC123</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">PTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Hyderabad</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 8 - Testing</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Test Lab</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2026-01-05 11:20</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Incident</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #dcfce7; color: #166534;">Low</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Non-reportable</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">New</span></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FY25-DTR-NM567</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">DTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Rudraram</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 2 - Welding</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Welding Bay</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2026-01-04 13:10</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Near-miss</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #fef3c7; color: #92400e;">Medium</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Non-reportable</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">In Progress</span></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FY25-PTR-UA890</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">PTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Baroda</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 7 - Paint Shop</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Paint Booth</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2026-01-03 08:30</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unsafe Act</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #fecaca; color: #991b1b;">High</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">First-Aid</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">Closed</span></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FY25-DTR-FIR234</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">DTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Rudraram</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 1 - Fabrication</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Main Shop Floor</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2026-01-02 17:20</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Fire</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #fecaca; color: #991b1b;">High</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FIR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">New</span></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FY25-PTR-NM678</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">PTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Hyderabad</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 9 - Quality</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">QC Lab</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2025-12-31 10:45</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Near-miss</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #dcfce7; color: #166534;">Low</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Non-reportable</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">Closed</span></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FY25-DTR-INC901</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">DTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Rudraram</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 4 - Maintenance</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Maintenance Bay</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2025-12-30 15:15</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Incident</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #fef3c7; color: #92400e;">Medium</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">First-Aid</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">In Progress</span></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e5e7eb;">
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">FY25-PTR-UA345</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">PTR</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Baroda</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unit 6 - Packing</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Packing Area</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">2025-12-29 12:00</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Unsafe Act</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600; background: #dcfce7; color: #166534;">Low</span></td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;">Non-reportable</td>
                            <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem;"><span style="padding: 0.25rem 0.6rem; border-radius: 999px; font-size: 0.75rem; font-weight: 600;">New</span></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                </div>
                `,

    'newIncident': `

                <div style="display: flex; gap: 10px; justify-content: center;">
                <button id="newIncidentBtn" style="width: 20%; border-radius: 0.7rem; border: 1px solid #ccc; background: #dbeafe; padding: 0.5rem 0.7rem; font-size: 0.78rem; color: #1d4ed8; font-weight: 600; user-select: none; transition: all 0.2s ease;" >New Incident</button>
                <button id="incidentsBtn" style="width: 20%; border-radius: 0.7rem; border: 1px solid #ccc; background: #f9fafb; padding: 0.5rem 0.7rem; font-size: 0.78rem; color: #666; user-select: none; transition: all 0.2s ease; data-content="SafetyIncidents">Incidents</button>
                </div>
                <div style=" margin: 1rem;">
                <h2 style="margin-bottom: 1.5rem; color: #111827; font-weight: 700;">New Incident Report</h2>
                
                <!-- 3 Column Grid -->
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem; margin-bottom: 2rem;">
                    
                    <!-- First Column -->
                    <div>
                    <h3 style="font-size: 0.95rem; font-weight: 600; color: #374151; margin-bottom: 1rem;">Report Details</h3>
                    <div style="background: #f8fafc; padding: 1.25rem; border-radius: 0.8rem; border: 1px solid #e5e7eb;">
                        <div style="margin-bottom: 1rem;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Reported By</label>
                        <input type="text" id="reportedBy" value="TTDI000123 - D" readonly style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: #f9fafb;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Reported On</label>
                        <input type="text" id="reportedOn" value="2026-01-08 17:07" readonly style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: #f9fafb;">
                        </div>
                        <div>
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Incident Type</label>
                        <select id="incidentType" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: white;">
                            <option>FIR</option>
                            <option>First-Aid</option>
                            <option>Non-reportable</option>
                        </select>
                        </div>
                        <div style="margin-bottom: 1rem;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Location</label>
                        <select id="location" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: white;">
                            <option value="">Select Location</option>
                            <option value="Rudraram">Rudraram</option>
                            <option value="Baroda">Baroda</option>
                        </select>
                        </div>
                    </div>
                    </div>

                    <!-- Second Column -->
                    <div>
                    <h3 style="font-size: 0.95rem; font-weight: 600; color: #374151; margin-bottom: 1rem;">Location Details</h3>
                    <div style="background: #f8fafc; padding: 1.25rem; border-radius: 0.8rem; border: 1px solid #e5e7eb;">
                        <div style="margin-bottom: 1rem;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Division</label>
                        <select id="division" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: white;" onchange="updateUnits()">
                            <option value="">Select Division</option>
                            <option value="DTR">DTR</option>
                            <option value="PTR">PTR</option>
                            <option value="CO">CO</option>
                            <option value="SA">SA</option>
                            <option value="SWG">SWG</option>
                        </select>
                        </div>
                        <div style="margin-bottom: 1rem;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Unit</label>
                        <select id="unit" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: white;" disabled>
                            <option value="">Select Unit</option>
                        </select>
                        </div>
                        <div style="margin-bottom: 1rem;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Section</label>
                        <select id="section" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: white;" disabled>
                            <option value="">Select Section</option>
                        </select>
                        </div>
                        <div>
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Work Center</label>
                        <select id="workCenter" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: white;" disabled>
                            <option value="">Select Work Center</option>
                        </select>
                        </div>
                    </div>
                    </div>

                    <!-- Third Column -->
                    <div>
                    <h3 style="font-size: 0.95rem; font-weight: 600; color: #374151; margin-bottom: 1rem;">Victim Details</h3>
                    <div style="background: #f8fafc; padding: 1.25rem; border-radius: 0.8rem; border: 1px solid #e5e7eb;">
                        
                        <div style="margin-bottom: 1rem;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Area</label>
                        <input type="text" id="area" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Victim</label>
                        <input type="text" id="victim" placeholder="Enter employee id only for internal employees" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem;">
                        </div>
                        <div style="margin-bottom: 1rem;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Victim Age</label>
                        <input type="number" id="victimAge" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem;">
                        </div>
                        <div>
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Date of Joining</label>
                        <input type="text" id="doj" value="2022-05-15" readonly style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: #f9fafb;">
                        </div>
                    </div>
                    </div>
                </div>

                <!-- Additional Details -->
                <div style="background: #f8fafc; padding: 2rem; border-radius: 0.8rem; border: 1px solid #e5e7eb; margin-bottom: 1.5rem;">
                    <div style="display: grid; grid-template-columns: 1fr 3fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                        <div>
                            <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Incident Date & Time</label>
                            <div style="display: flex; gap: 0.5rem;">
                                <input type="date" id="incidentDate" style="flex: 1; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem;">
                                
                                <input type="time" id="incidentTime" style="flex: 1; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: white; font-family: inherit;">
                            </div>
                        </div>
                    <div>
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Subject</label>
                        <input type="text" id="subject" placeholder="Brief description of incident" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem;">
                    </div>
                    <div>
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Responsible Person</label>
                        <div style="display: flex; gap: 0.5rem;">
                        <input type="text" id="responsiblePerson" placeholder="Enter name or ID" style="flex: 1; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem;">
                        <button type="button" onclick="searchPerson()" style="padding: 0.6rem 1rem; background: #1d4ed8; color: white; border: none; border-radius: 0.6rem; font-size: 0.85rem; cursor: pointer;">Search</button>
                        </div>
                    </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                    <div>
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Description</label>
                        <textarea id="description" rows="4" placeholder="Detailed description of what happened..." style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; font-family: inherit; resize: vertical;"></textarea>
                    </div>
                    <div>
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Preliminary Root Cause</label>
                        <textarea id="rootCause" rows="4" placeholder="What caused the incident..." style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; font-family: inherit; resize: vertical;"></textarea>
                    </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                    <div>
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Preliminary Corrective Action</label>
                        <textarea id="correctiveAction" rows="4" placeholder="Immediate actions taken..." style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; font-family: inherit; resize: vertical;"></textarea>
                    </div>
                    <div style="display: flex; gap: 1rem;">
                        <div style="flex: 1;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Risk Level</label>
                        <select id="riskLevel" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: white;">
                            <option value="">Select Risk Level</option>
                            <option value="High">High</option>
                            <option value="Medium">Medium</option>
                            <option value="Low">Low</option>
                        </select>
                        </div>
                        <div style="flex: 1;">
                        <label style="display: block; font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 0.4rem;">Risk Category</label>
                        <select id="riskCategory" style="width: 100%; padding: 0.6rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.6rem; font-size: 0.85rem; background: white;">
                            <option value="">Select Category</option>
                            <option value="Incident">Incident</option>
                            <option value="Near-miss">Near miss</option>
                            <option value="Unsafe Act">Unsafe act</option>
                            <option value="Unsafe Condition">Unsafe condition</option>
                            <option value="Fire">Fire</option>
                            <option value="Environmental">Environmental</option>
                        </select>
                        </div>
                    </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <div style="text-align: center;">
                    <button id="submitIncident" disabled style="padding: 0.8rem 2.5rem; background: #9ca3af; color: white; border: none; border-radius: 0.8rem; font-size: 0.9rem; font-weight: 600; cursor: not-allowed; transition: all 0.2s ease;">Submit Incident</button>
                </div>
                </div>

                <style>
                input:invalid, select:invalid, textarea:invalid { border-color: #d1d5db; }
                input:valid, select:valid, textarea:valid { border-color: #10b981; }
                </style>
                `,

    'itIncidents': `
                        <!-- IT Helpdesk Content Section -->
                        <div id="itHelpdesk" class="content others">
                            <div class="helpdesk-container">

                                <!-- Tab Navigation -->

                                <div style="display: flex; justify-content: center; gap: 10px; margin-bottom: 1.5rem;">
                                    <button class="it-tab-btn" data-tab="newIT" style="width: 20%; border-radius: 0.7rem; border: 1px solid #ccc; background: #dbeafe; padding: 0.5rem 0.7rem; font-size: 0.78rem; color: #1d4ed8; font-weight: 600; user-select: none; transition: all 0.2s ease; cursor: pointer;">New Incident</button>
                                    <button class="it-tab-btn" data-tab="loggedIT" style="width: 20%; border-radius: 0.7rem; border: 1px solid #ccc; background: #f9fafb; padding: 0.5rem 0.7rem; font-size: 0.78rem; color: #666; user-select: none; transition: all 0.2s ease; cursor: pointer;">Incidents</button>
                                </div>
                                <!-- LOGGED IT INCIDENTS TAB -->
                                <div id="tab-loggedIT" class="tab-content"  style="display: none;" >
                                    <div class="incidents-table-wrapper">
                                        <h3 style="margin-bottom: 1rem; color: #1d4ed8;">Logged IT Security Incidents</h3>
                                        <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 0.8rem; box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow: hidden;">
                                            <thead>
                                                <tr style="background: #1d4ed8; color: white; border-bottom: 3px solid #1e40af;">
                                                    <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Incident ID</th>
                                                    <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Report Date</th>
                                                    <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Incident Type</th>
                                                    <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Department</th>
                                                    <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Severity</th>
                                                    <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Status</th>
                                                    <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Report Status</th>
                                                    <th style="padding: 0.75rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.85rem;">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody id="itIncidentsBody">
                                              <!-- Rows will be injected by JavaScript -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!-- NEW IT INCIDENT TAB -->
                                <div id="tab-newIT" class="tab-content" >
                                     <div id="itIncidentSelection" class="it-selection-page">
                                        <h3 style="text-align: center; color: #1d4ed8; margin-bottom: 2rem;">Select Incident Report Type</h3>
                                        
                                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 2rem; max-width: 1000px; margin: 0 auto;">
                                            <!-- Option 1: Form A -->
                                            <div class="it-selection-card" onclick="showFormatA()" style="cursor: pointer;">
                                                <div style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%); padding: 1.5rem; border-radius: 1rem 1rem 0 0;">
                                                    <h4 style="color: white; margin: 0; font-size: 1.1rem; text-align: center;">Form A</h4>
                                                </div>
                                                <div style="padding: 2rem; background: white; border: 2px solid #1d4ed8; border-radius: 0 0 1rem 1rem; min-height: 200px; display: flex; flex-direction: column; justify-content: center;">
                                                    <p style="text-align: center; font-size: 0.95rem; color: #374151; line-height: 1.6;">
                                                        <strong>Theft/Loss of Information Devices/Medium</strong><br>
                                                        or<br>
                                                        <strong>Sending Emails etc. to Wrong Destination</strong>
                                                    </p>
                                                </div>
                                            </div>

                                            <!-- Option 2: Form B -->
                                            <div class="it-selection-card" onclick="showFormatB()" style="cursor: pointer;">
                                                <div style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%); padding: 1.5rem; border-radius: 1rem 1rem 0 0;">
                                                    <h4 style="color: white; margin: 0; font-size: 1.1rem; text-align: center;">Form B</h4>
                                                </div>
                                                <div style="padding: 2rem; background: white; border: 2px solid #1d4ed8; border-radius: 0 0 1rem 1rem; min-height: 200px; display: flex; flex-direction: column; justify-content: center;">
                                                    <p style="text-align: center; font-size: 0.95rem; color: #374151; line-height: 1.6;">
                                                        <strong>Tampering or Unauthorized Access of Public Websites</strong><br>
                                                        or<br>
                                                        <strong>Virus Infection and Other Incidents</strong>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div id="formatAContent" style="display: none;">
                                        <button onclick="backToSelection()" style="margin-bottom: 1rem; padding: 0.6rem 1.2rem; background: #6b7280; color: white; border: none; border-radius: 0.5rem; cursor: pointer; font-size: 0.9rem;">
                                            ← Back to Selection
                                        </button>

                                        <div class="container">
                                        <div class="form-header-section">
                                            <h3>Information Security Incident Report (Form A)</h3>
                                            <p>Use this format when "Theft/Loss of information devices/Medium" or "Sending emails etc. to wrong destination" occurs.</p>
                                            
                                            <!-- 1. Report Status -->
                                                <div class="section-card full-width" style="margin-bottom: 30px;">
                                                    <div class="section-header">
                                                        <div class="section-num">1</div>
                                                        <h4>Report Status</h4>
                                                    </div>
                                                    <div class="section-content">
                                                        <div class="status-options">
                                                            <label class="checkbox-item">
                                                                <input type="radio" name="reportStatus" value="First" checked> First report
                                                            </label>
                                                            <label class="checkbox-item">
                                                                <input type="radio" name="reportStatus" value="Interim" disabled> Interim report
                                                            </label>
                                                            <label class="checkbox-item">
                                                                <input type="radio" name="reportStatus" value="Final" disabled> Final report
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            <!-- Fixed Header Information -->
                                            <div class="header-box">
                                                <div class="header-item">
                                                    <h4>Reported On:</h4>
                                                    <span id="reportedDate" class="value-text"></span>
                                                </div>

                                                <div class="header-item">
                                                    <h4>To: Cyber Security Incident Response Team</h4>
                                                    <span class="value-text">HDQ-CSEC-head@ml.toshiba.co.jp</span>
                                                </div>
                                            </div>

                                            <!-- CSIRT Leader Information -->
                                            <div class="info-card">
                                                <h4>CSIRT Leader</h4>
                                                <div class="info-row">
                                                    <span class="info-label">Name:</span>
                                                    <span class="info-value">Marumoto Shuichiro</span>
                                                </div>
                                                <div class="info-row">
                                                    <span class="info-label">Designation:</span>
                                                    <span class="info-value">Director</span>
                                                </div>
                                            </div>

                                            <!-- Incident Logged By -->
                                            <div class="info-card">
                                                <h4>Incident Logged By</h4>
                                                <div class="info-row">
                                                    <span class="info-label">Name:</span>
                                                    <span class="info-value" id="currentUserName">-</span>
                                                </div>
                                                <div class="info-row">
                                                    <span class="info-label">ID:</span>
                                                    <span class="info-value" id="currentUserId">-</span>
                                                </div>
                                                <div class="info-row">
                                                    <span class="info-label">Job Title:</span>
                                                    <span class="info-value" id="currenttitle">-</span>
                                                </div>
                                                <div class="info-row">
                                                    <span class="info-label">phone:</span>
                                                    <span class="info-value" id="currentphone">-</span>
                                                </div>
                                            </div>
                                        </div>

                                        <form id="incidentForm" onsubmit="handleSubmit(event)">
                                            <!-- Employee Search Section -->
                                            <div class="card">
                                                <h4 class="card-title">Incident Logged For</h4>
                                                <div style="margin-bottom: 1rem;">
                                                    <div class="search-area">
                                                     <label style="display: block; text-align: center; font-weight: 600; margin-bottom: 0.5rem; font-size: 0.9rem;">Employee ID</label>
                                                        <input type="text" id="empIdInput" placeholder="Enter ID" style="flex: 1; max-width: 300px;">
                                                        <button type="button" class="btn" data-show-assets="true" onclick="searchEmployee(this)">Search</button>
                                                    </div>
                                                </div>

                                                <div id="errorMessage" class="error-msg"></div>

                                                <div id="employeeDetails" class="employee-details">
                                                    <h5 style="color: #065f46; margin-bottom: 0.75rem; font-size: 0.95rem; font-weight: 600;">Employee Details</h5>
                                                    <div class="details-grid">
                                                        <div class="info-row"><span class="info-label">Name:</span><span id="empName">-</span></div>
                                                        <div class="info-row"><span class="info-label">Job Title:</span><span id="empJobTitle">-</span></div>
                                                        <div class="info-row"><span class="info-label">ID:</span><span id="empId">-</span></div>
                                                        <div class="info-row"><span class="info-label">Company:</span><span id="empComp">-</span></div>
                                                        <div class="info-row"><span class="info-label">Department:</span><span id="empDept">-</span></div>
                                                        <div class="info-row"><span class="info-label">Division:</span><span id="empDiv">-</span></div>
                                                        <div class="info-row"><span class="info-label">Phone:</span><span id="empPhone">-</span></div>
                                                        <div class="info-row" style="grid-column: 1 / -1;"><span class="info-label">Email ID:</span><span id="empEmail">-</span></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Incident Type -->
                                    <!-- Incident Type -->
                                    <div class="card">
                                        <h4 class="card-title">Incident Type and Items Involved</h4>

                                        <!-- Theft/Loss -->
                                        <div>
                                            <label class="radio-label">
                                                <input type="radio" name="incidentType" value="theftLoss" checked onclick="toggleIncidentSections('theftLoss')">
                                                <span>Theft/Loss of information devices/medium</span>
                                            </label>
                                            <div id="theftLossSection" class="incident-sub-section">
                                                <label style="display: block; font-weight: 600; margin-bottom: 0.5rem; font-size: 0.9rem;">Select items involved:</label>

                                                <div id="dynamicAssetContainer" class="checkbox-grid" style="margin-bottom: 1rem;">
                                                    <p style="color: #666; font-style: italic; font-size: 0.85rem;">Please search for an employee to see available assets.</p>
                                                </div>

                                                <div class="checkbox-item" style="margin-top: 10px; display: flex; align-items: center; gap: 0.5rem;">
                                                    <input type="checkbox" id=otherCheckbox2 name="theftItem" value="Other"onchange="syncToggle('otherCheckbox2', 'otherTextbox1')">
                                                    <span>Other:</span>
                                                    <input type="text" id="otherTextbox1" placeholder="Specify item" disabled style="padding: 0.3rem 0.5rem; flex: 1; max-width: 300px;">
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Wrong Destination -->
                                        <div style="margin-top: 1rem;">
                                            <label class="radio-label">
                                                <input type="radio" name="incidentType" value="wrongDestination" onclick="toggleIncidentSections('wrongDestination')">
                                                <span>Sending emails, etc. to wrong destination</span>
                                            </label>
                                            <div id="wrongDestinationSection" class="incident-sub-section">
                                                <label style="display: block; font-weight: 600; margin-bottom: 0.5rem; font-size: 0.9rem;">Method of transmission:</label>
                                                <div class="checkbox-grid">
                                                    <label class="checkbox-item"><input type="checkbox" name="wrongDestMethod" value="Email"> Email</label>
                                                    <label class="checkbox-item"><input type="checkbox" name="wrongDestMethod" value="Fax"> Fax</label>
                                                    <label class="checkbox-item"><input type="checkbox" name="wrongDestMethod" value="Mail"> Physical mail</label>
                                                    <label class="checkbox-item"><input type="checkbox" name="wrongDestMethod" value="Cloud"> Cloud sharing/File transfer</label>
                                                    <div class="checkbox-item" style="grid-column: 1 / -1; gap: 0.5rem;">
                                                    <label><input type="checkbox" id="otherCheckbox1" name="wrongDestMethod" value="Other" onchange="syncToggle('otherCheckbox1', 'otherTextbox')">
                                                        Other:</label>
                                                        <input type="text" id="otherTextbox" name="wrongDestMethodOther" placeholder="Specify method" disabled >
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                            <!-- Main Sections Grid -->
                                            <div class="section-grid">
                                                <!-- 2. Date and Time of Incident -->
                                                <div class="section-card">
                                                    <div class="section-header">
                                                        <div class="section-num">2</div>
                                                        <h4>Date and Time of Incident</h4>
                                                    </div>
                                                    <div class="section-content">
                                                        <p style="margin-bottom: 0.5rem;">Be specific to the best of your knowledge.</p>
                                                        <input type="datetime-local" style="width: 100%;">
                                                    </div>
                                                </div>

                                                <!-- 3. Date and Time Discovered -->
                                                <div class="section-card">
                                                    <div class="section-header">
                                                        <div class="section-num">3</div>
                                                        <h4>Date and Time Incident Discovered</h4>
                                                    </div>
                                                    <div class="section-content">
                                                        <p style="margin-bottom: 0.5rem;">Be specific to the best of your knowledge.</p>
                                                        <input type="datetime-local" style="width: 100%;">
                                                    </div>
                                                </div>

                                                <!-- 4. Location and Circumstances -->
                                                    <div class="section-card" id="section4Card">
                                                    <div class="section-header">
                                                        <div class="section-num">4</div>
                                                        <h4>Location and Circumstances of Incident</h4>
                                                    </div>
                                                    <div class="section-content">
                                                        <div style="margin-bottom: 1rem;">
                                                            <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.9rem;">Location where incident occurred</label>
                                                            <input type="text" placeholder="e.g., Office, Home, Train, etc." style="width: 100%;">
                                                        </div>
                                                        <div>
                                                            <label style="display: block; font-weight: 600; margin-bottom: 0.5rem; font-size: 0.9rem;">Alcohol intake</label>
                                                            <div style="display: flex; gap: 2rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="alcoholIntake" value="yes"> Yes
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="alcoholIntake" value="no"> No
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </div>


                                                <!-- 5. Incident Overview -->
                                                <div class="section-card">
                                                    <div class="section-header">
                                                        <div class="section-num">5</div>
                                                        <h4>Incident Overview</h4>
                                                    </div>
                                                    <div class="section-content">
                                                        <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.9rem;">General overview of incident, including causes</label>
                                                        <small>＜Fill in the following section if the incident is Theft/loss＞</small>
                                                        <textarea rows="3" placeholder="Provide a comprehensive overview" style="width: 100%;"></textarea> <br>
                                                        <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.9rem;">What Made you Notice the Incident</label>
                                                        <textarea rows="3" placeholder="Describe how the incident was discovered"
                                                        style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                                                    </div>
                                                </div>
                                                
                                                <!-- Section 6: Information Leaked -->
                                                <div class="section-card" style="grid-column: span 2;">
                                                    <div class="section-header">
                                                        <span class="section-num">6</span>
                                                        <h4>Information That Was, or Can Possibly Be, Leaked</h4>
                                                    </div>
                                                    <div class="section-content">
                                                        <label style="display: block; font-size: 0.85rem; color: #374151; margin-bottom: 0.5rem;">If a loss includes customers' information, write their company names.</label>
                                                        <label style="display: block; font-size: 0.85rem; color: #374151; margin-bottom: 0.5rem;"><br>＜Fill in the following section if the incident includes loss of personal information＞</label>
                                                        <textarea rows="3" placeholder="Describe information at risk" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem; margin-bottom: 1rem;"></textarea>
                                                        
                                                        <div style="padding: 1rem; border-radius: 0.5rem; margin-top: 1rem;">
                                                            <p style="font-weight: 600; margin-bottom: 0.5rem;">If incident includes loss of personal information:</p>
                                                            <label style="display: block; margin-bottom: 0.5rem; font-size: 0.9rem;">Data items:</label>
                                                            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.5rem; margin-bottom: 1rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox" name="dataItems" value="Name"> Name</label>
                                                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox" name="dataItems" value="Birth date"> Birth date</label>
                                                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox" name="dataItems" value="Gender"> Gender</label>
                                                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox" name="dataItems" value="Address"> Address</label>
                                                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox" name="dataItems" value="Phone number"> Phone number</label>
                                                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox" name="dataItems" value="Email address"> Email address</label>
                                                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox" id=otherCheckbox3 name="dataItems" value="Other"
                                                                onchange="syncToggle('otherCheckbox3', 'otherTextbox2')"> Other</label>
                                                                <input type="text" id="otherTextbox2" placeholder="Specify item" disabled style="padding: 0.3rem 0.5rem; flex: 1; max-width: 300px;">
                                                            </div>    
                                                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                                                            <div>
                                                                <label style="display: block; margin-bottom: 0.3rem; font-size: 0.9rem;">Records on:</label>
                                                                <input type="number" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                            </div>
                                                            <div>
                                                                <label style="display: block; margin-bottom: 0.3rem; font-size: 0.9rem;">Customers' info:</label>
                                                                <input type="number" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                            </div>
                                                            <div>
                                                                <label style="display: block; margin-bottom: 0.3rem; font-size: 0.9rem;">Employees' info:</label>
                                                                <input type="number" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                            </div>
                                                            <div>
                                                                <label style="display: block; margin-bottom: 0.3rem; font-size: 0.9rem;">Other personal contacts:</label>
                                                                <input type="number" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                            </div>
                                                        </div>
                                                        <div style="margin-top: 1rem;">
                                                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Secondary damage in event of misuse:</label>
                                                            <div style="display: flex; gap: 2rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="secondaryDamage" value="possible" id="secondaryPossible" onchange="toggleSecondaryDamage()"> Possible
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="secondaryDamage" value="none" id="secondaryNone" onchange="toggleSecondaryDamage()"> None
                                                                </label>
                                                            </div>
                                                            
                                                            <textarea id="secondaryTextbox" rows="2" placeholder="If possible, describe" disabled style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem; margin-top: 0.5rem;"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>  
                                            
                                            <!-- Section 7: Information Security Measures -->
                                            <div class="section-card" style="grid-column: span 2;">
                                                <div class="section-header" style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);">
                                                    <span class="section-num" style="color: #1d4ed8;">7</span>
                                                    <h4>Information Security Measures That Were Taken</h4>
                                                </div>
                                                <div class="section-content">
                                                <!-- Content for Theft/Loss only -->
                                                    <div id="section7TheftLossContent">    
                                                        <!-- Permission from manager -->
                                                        <div style="padding: 1rem; border-radius: 0.5rem;">
                                                            <h5 style="font-weight: 600; margin-bottom: 0.75rem;">Permission from manager to take out a device</h5>
                                                            <div style="display: flex; gap: 2rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="managerPermission" value="obtained" id="permissionObtained"> Obtained permission (incl. blanket permission covering predefined period)

                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="managerPermission" value="notObtained" id="permissionNotObtained"> Not obtained permission
                                                                </label>
                                                            </div>
                                                        </div>

                                                        <!-- Password -->
                                                        <div style="padding: 1rem; border-radius: 0.5rem;">
                                                            <h5 style="font-weight: 600; margin-bottom: 0.75rem;">Password (incl. fingerprint authentication)</h5>
                                                            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="checkbox" name="passwordType" value="bootTime"> At boot time
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="checkbox" name="passwordType" value="osStartup"> On OS startup
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="checkbox" name="passwordType" value="unlockScreen" id="passwordUnlockScreen"> When unlocking screen
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="checkbox" name="passwordType" value="sleepMode"> When exiting Sleep mode
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="checkbox" id="otherCheckbox4" name="passwordType" value="other" 
                                                                        onchange="syncToggle('otherCheckbox4', 'otherTextbox3')"> 
                                                                    Other
                                                                    <input type="text" id="otherTextbox3" placeholder="Specify" disabled 
                                                                        style="width: 250px; padding: 0.4rem; border: 1px solid #d1d5db; border-radius: 0.3rem; margin-left: 0.5rem; opacity: 0.5; transition: opacity 0.2s;">
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="checkbox" name="passwordType" value="notSubject"> Not subject to this requirement
                                                                </label>
                                                            </div>
                                                        </div>

                                                        <!-- Encryption -->
                                                        <div style="padding: 1rem; border-radius: 0.5rem;">
                                                            <h5 style="font-weight: 600;">Encryption</h5>
                                                            
                                                            <!-- Windows PC Encryption -->
                                                            <div id="windowsPCEncryption" style="padding: 0.75rem; background: white; border-radius: 0.5rem;">
                                                                <label style="display: block; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">Windows PC:</label>
                                                                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                                                    <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                        <input type="radio" name="windowsEncryption" value="encrypted"> Encrypted
                                                                    </label>
                                                                    <div style="margin-left: 2rem; display: flex; flex-wrap: wrap; gap: 1rem; align-items: center;">
                                                                        <span style="font-size: 0.9rem;">Encryption tool:</span>
                                                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                                            <input type="checkbox" name="encryptionTool" value="BitLocker"> BitLocker
                                                                        </label>
                                                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                                            <input type="checkbox" id="otherCheckbox5" name="encryptionTool" value="other" 
                                                                                onchange="syncToggle('otherCheckbox5', 'otherTextbox4')"> 
                                                                            Other
                                                                            <input type="text" id="otherTextbox4" placeholder="Specify tool" disabled 
                                                                                style="width: 150px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem; margin-left: 0.3rem; opacity: 0.5; transition: opacity 0.2s;">
                                                                        </label>
                                                                    </div>
                                                                    <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                        <input type="radio" name="windowsEncryption" value="notEncrypted"> Not encrypted
                                                                    </label>
                                                                </div>
                                                            </div>

                                                            <!-- Storage Medium Encryption -->
                                                            <div id="storageMediumEncryption" style="padding: 0.75rem; background: white; border-radius: 0.5rem;">
                                                                <label style="display: block; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">Storage medium:</label>
                                                                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                                                    <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                        <input type="radio" name="storageEncryption" value="allEncrypted"> All company information has been encrypted
                                                                    </label>
                                                                    <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                        <input type="radio" name="storageEncryption" value="unencrypted"> There is unencrypted company information
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Loss Prevention Measures -->
                                                        <div style="padding: 1rem; border-radius: 0.5rem;">
                                                            <h5 style="font-weight: 600; margin-bottom: 0.5rem;">Loss prevention measures</h5>
                                                            <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 0.75rem;">Describe practice(s) that were taken for prevention of loss.</p>
                                                            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="lossPreventionStrap" value="noStrap"> Device did not have strap
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="lossPreventionStrap" value="strapNotUsed"> Device had strap, but person concerned neglected to clip it to clothes or bag
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="lossPreventionStrap" value="strapUsed"> Device had strap, and person concerned had it clipped to clothes or bag
                                                                </label>
                                                            </div>
                                                        </div>

                                                        <!-- Others -->
                                                        <div style="margin-top: 1rem;">
                                                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Others</label>
                                                            <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 0.5rem;">Fill in the blank if there are other measures taken rather than the above.</p>
                                                            <textarea rows="3" placeholder="Describe any other security measures that were in place" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                                                        </div>
                                                    </div>

                                                    <!-- Footnotes - For Wrong Destination only -->
                                                    <div class="section-content" id="section7WrongDestContent">
                                                        <label style="display: block; font-size: 0.85rem; color: #374151; margin-bottom: 0.5rem;">If the incident is "Sending to Wrong Destination"</label>
                                                        <textarea rows="4" placeholder="Please Provide details of measures taken" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Section 8: Post-Incident Actions -->
                                            <div class="section-card" style="grid-column: span 2;">
                                                <div class="section-header" style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);">
                                                    <span class="section-num" style="color: #1d4ed8;">8</span>
                                                    <h4>Post-Incident Responses</h4>
                                                </div>
                                                <div class="section-content">
                                                    <p style="font-size: 0.85rem; color: #6b7280;">Actions taken to minimize potential damage</p>
                                                <!-- Content for Theft/Loss only -->
                                                <div id="section8TheftLossContent">
                                                    <!-- Searching & Reporting -->
                                                    <div style="padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                                                        <h5 style="font-weight: 600; margin-bottom: 0.75rem;">Searching & reporting</h5>
                                                        
                                                        <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                                                            <!-- Searched likely place -->
                                                            <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                <input type="checkbox" name="searchActions" value="searchedPlace"> Searched likely place
                                                                <input type="text" placeholder="Specify location(s) searched" style="flex: 1; padding: 0.4rem; border: 1px solid #d1d5db; border-radius: 0.3rem; margin-left: 0.5rem;">
                                                            </label>

                                                            <!-- GPS Search -->
                                                            <div style="background: white; padding: 0.75rem; border-radius: 0.5rem; display: flex; flex-direction: column; gap: 0.75rem;">
                                                                <div>
                                                                    <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                                                        <input type="radio" name="gpsGroup" value="gpsSearch" onchange="toggleGPSFields()"> Performed GPS search
                                                                    </label>
                                                                    <div id="gpsResultContainer" style="margin-left: 2rem; display: flex; gap: 1.5rem; align-items: center; opacity: 0.5;">
                                                                        <span style="font-size: 0.9rem;">Result:</span>
                                                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                                            <input type="radio" name="gpsResult" value="succeeded" disabled> Succeeded
                                                                        </label>
                                                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                                            <input type="radio" name="gpsResult" value="failed" disabled> Failed
                                                                        </label>
                                                                    </div>
                                                                </div>

                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="gpsGroup" value="notSubjectGPS" onchange="toggleGPSFields()"> Not subject to GPS search
                                                                </label>
                                                            </div>

                                                            <div style="background: white; padding: 0.75rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                                                    <input type="checkbox" id="checkTransport" name="searchActions" value="reportedTransport" onchange="toggleInputs('checkTransport', 'transportInputs')"> 
                                                                    Reported loss to transport
                                                                </label>
                                                                <div id="transportInputs" style="margin-left: 2rem; display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; opacity: 0.5;">
                                                                    <div>
                                                                        <label style="display: block; font-size: 0.85rem; margin-bottom: 0.3rem;">Date and time:</label>
                                                                        <input type="datetime-local" disabled style="width: 100%; padding: 0.4rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                                    </div>
                                                                    <div>
                                                                        <label style="display: block; font-size: 0.85rem; margin-bottom: 0.3rem;">Reported place:</label>
                                                                        <input type="text" disabled placeholder="e.g., Station name, Bus company" style="width: 100%; padding: 0.4rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- Reported loss to police -->
                                                            <div style="background: white; padding: 0.75rem; border-radius: 0.5rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                                                    <input type="checkbox" id="checkPolice" name="searchActions" value="reportedPolice" onchange="toggleInputs('checkPolice', 'policeInputs')"> 
                                                                    Reported loss to the police
                                                                </label>
                                                                <div id="policeInputs" style="margin-left: 2rem; display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; opacity: 0.5;">
                                                                    <div>
                                                                        <label style="display: block; font-size: 0.85rem; margin-bottom: 0.3rem;">Date and time:</label>
                                                                        <input type="datetime-local" disabled style="width: 100%; padding: 0.4rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                                    </div>
                                                                    <div>
                                                                        <label style="display: block; font-size: 0.85rem; margin-bottom: 0.3rem;">Reported place:</label>
                                                                        <input type="text" disabled placeholder="Police station name" style="width: 100%; padding: 0.4rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!-- Measures Taken to Minimize Damage -->
                                                    <div style="border-radius: 0.5rem; margin-bottom: 1rem;">
                                                        <h5 style="font-weight: 600; margin-bottom: 0.75rem;">Measures taken to minimize damage</h5>

                                                        <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                                                            
                                                            <div style="background: white; padding: 0.75rem; border-radius: 0.5rem; display: flex; flex-direction: column; gap: 0.5rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="intranetGroup" value="disableIntranet"> 
                                                                    Requested overseeing department to disable lost device to connect to Intranet (e.g., certificate revocation)
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="intranetGroup" value="notSubject"> 
                                                                    Not subject to this requirement
                                                                </label>
                                                            </div>

                                                            <!-- Remote Wipe -->
                                                            <div style="background: white; padding: 0.75rem; border-radius: 0.5rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                                                    <input type="radio" name="wipeGroup" value="remoteWipe" onchange="toggleDamageFields()"> 
                                                                    Requested overseeing department to execute remote wipe
                                                                </label>
                                                                
                                                                <div id="wipeResults" style="margin-left: 2rem; display: flex; gap: 1.5rem; align-items: center; margin-bottom: 0.5rem; opacity: 0.5;">
                                                                    <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                                        <input type="radio" name="remoteWipeResult" value="succeeded" disabled> Succeeded
                                                                    </label>
                                                                    <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                                        <input type="radio" name="remoteWipeResult" value="waiting" disabled> Yet to succeed
                                                                    </label>
                                                                    <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                                        <input type="radio" name="remoteWipeResult" value="failed" disabled> Failed
                                                                    </label>
                                                                </div>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="wipeGroup" value="notSubject" onchange="toggleDamageFields()"> 
                                                                    Not subject to this requirement
                                                                </label>
                                                            </div>

                                                            <!-- Close Communication Line -->
                                                            <div style="background: white; padding: 0.75rem; border-radius: 0.5rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                                                    <input type="radio" name="lineGroup" value="closeLine" onchange="toggleDamageFields()"> 
                                                                    Requested carrier to close communication line
                                                                    <span style="font-size: 0.8rem; color: #6b7280; margin-left: 0.5rem;">(Close communication line after GPS search and remote wipe)</span>
                                                                </label>
                                                                
                                                                <div id="phoneInputContainer" style="margin-left: 2rem; margin-bottom: 0.5rem; opacity: 0.5;">
                                                                    <label style="display: block; font-size: 0.85rem; margin-bottom: 0.3rem;">Telephone number:</label>
                                                                    <input type="tel" id="telNumber" placeholder="Enter phone number" disabled style="width: 250px; padding: 0.4rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                                </div>

                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="lineGroup" value="notSubject" onchange="toggleDamageFields()"> 
                                                                    Not subject to this requirement
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!-- Additional Actions -->
                                                    <div style="margin-top: 1rem;">
                                                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Other actions taken:</label>
                                                        <textarea rows="4" placeholder="Describe any other actions taken to minimize damage or recover the device/information" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                                                    </div>
                                                </div>
                                                        <!-- Request recipient to delete - For Wrong Destination only -->
                                                    <div id="section8WrongDestContent" style="padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">

                                                        <h5 style="font-weight: 600; margin-bottom: 0.75rem;">Request a recipient to delete the wrongly sent email</h5>
                                                        
                                                        <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                                                            <div style="display: flex; gap: 2rem;">
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="deleteRequest" value="requested"> Requested
                                                                </label>
                                                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                                                    <input type="radio" name="deleteRequest" value="notRequested"> Not requested
                                                                </label>
                                                            </div>

                                                            <div style="background: white; padding: 0.75rem; border-radius: 0.5rem;">
                                                                <label style="display: block; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">
                                                                    If "Not requested", fill in the reason below:
                                                                </label>
                                                                <textarea rows="3" placeholder="Explain why deletion was not requested from the recipient" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;"></textarea>
                                                            </div>
                                                        </div>

                                                        <!-- Others -->
                                                        <div style="margin-top: 1rem;">
                                                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Others</label>
                                                            <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 0.5rem;">Fill in the blank if there are other measures taken rather than the above.</p>
                                                            <textarea rows="4" placeholder="Describe any other actions taken (e.g., email recall attempted, contacted IT department, notified management, etc.)" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>


                                            <!-- Section 9: Timeline -->
                                            <div class="section-card" style="grid-column: span 2;">
                                                <div class="section-header" style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);">
                                                    <span class="section-num" style="color: #1d4ed8;">9</span>
                                                    <h4>Timeline</h4>
                                                </div>
                                                <div class="section-content">
                                                    <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 1rem;">Describe chronologically - initial response, stopgap measure, instructions given by CSIRT Leader</p>
                                                    <table style="width: 100%; border-collapse: collapse;">
                                                        <thead>
                                                            <tr style="background: #1d4ed8; color: white;">
                                                                <th style="padding: 0.75rem; text-align: left; border: 1px solid #ddd;">Date/Time</th>
                                                                <th style="padding: 0.75rem; text-align: left; border: 1px solid #ddd;">Situation, Response, etc.</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="timelineRowsA">
                                                            <tr>
                                                                <td style="padding: 0.5rem; border: 1px solid #ddd;">
                                                                    <input type="datetime-local" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                                                </td>
                                                                <td style="padding: 0.5rem; border: 1px solid #ddd;">
                                                                    <textarea rows="2" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;"></textarea>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <button type="button" onclick="addTimelineRowA()" style="margin-top: 0.5rem; padding: 0.5rem 1rem; background: #3b82f6; color: white; border: none; border-radius: 0.5rem; cursor: pointer;">+ Add Row</button>
                                                </div>
                                            </div>

                                            <!-- Section 10: Assumed Causes -->
                                            <div class="section-card">
                                                <div class="section-header" style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);">
                                                    <span class="section-num" style="color: #1d4ed8;">10</span>
                                                    <h4>Assumed Causes</h4>
                                                </div>
                                                <div class="section-content">
                                                    <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 0.5rem;">Provide root causes. For example, if person concerned neglected to follow rules, describe why he/she did.</p>
                                                    <p style="font-size: 0.8rem; color: #ef4444; margin-bottom: 0.5rem;">(Can be omitted for first report)</p>
                                                    <textarea rows="5" placeholder="Describe assumed root causes" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                                                </div>
                                            </div>

                                            <!-- Section 11: Preventive Measures -->
                                            <div class="section-card">
                                                <div class="section-header" style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);">
                                                    <span class="section-num" style="color: #1d4ed8;">11</span>
                                                    <h4>Preventive Measures</h4>
                                                </div>
                                                <div class="section-content">
                                                    <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 0.5rem;">Describe specifically. Attach evidence records, if any, such as a notice of issue and documents provided.</p>
                                                    <p style="font-size: 0.8rem; color: #ef4444; margin-bottom: 0.5rem;">(Can be omitted for first report)</p>
                                                    <textarea rows="4" placeholder="Describe preventive measures" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem; margin-bottom: 1rem;"></textarea>
                                                    
                                                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                                                        <div>
                                                            <label style="display: block; margin-bottom: 0.3rem; font-weight: 600;">Name and title of person responsible</label>
                                                            <div style="padding: 0.6rem; background: #f0f9ff; border: 0.5px solid #bfdbfe; border-radius: 0.5rem;">
                                                                <span style="font-weight: 500; color: #374151;">Kaza Saritha, Head of IT Department</span>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <label style="display: block; margin-bottom: 0.3rem; font-weight: 600;">Date of scheduled completion</label>
                                                            <input type="date" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;">
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                                <!-- 12. Remarks -->
                                                <div class="section-card full-width">
                                                    <div class="section-header">
                                                        <div class="section-num">12</div>
                                                        <h4>Remarks</h4>
                                                    </div>
                                                    <div class="section-content">
                                                        <textarea rows="4" placeholder="Additional remarks or notes" style="width: 100%;"></textarea>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Submit Button -->
                                            <div style="text-align: center; margin-top: 2rem;">
                                                <button type="button" class="submit-btn" onclick="generateFormAReport()">Submit IT Security Incident Report Form A</button>
                                            </div>

                                            <!-- Success Message -->
                                            <div id="successMessage" class="success-msg">
                                                IT Security Incident Report (Form A) submitted successfully!
                                            </div>
                                        </form>
                                    </div>
                                    </div>

                                    
                                    <!-- Form B Content -->
                                     <div id="formatBContent" style="display: none;">
                                        <button onclick="backToSelection()" style="margin-bottom: 1rem; padding: 0.6rem 1.2rem; background: #6b7280; color: white; border: none; border-radius: 0.5rem; cursor: pointer; font-size: 0.9rem;">
                                            ← Back to Selection
                                        </button>
                                    <div class="it-incident-form-wrapper">
                                        <div class="form-header-section">
                                            <h3 style="color: #1d4ed8; margin-bottom: 0.5rem;">Information Security Incident Report (Form B)</h3>
                                            <p style="color: #6b7280; font-size: 0.9rem; margin-bottom: 1rem;">
                                                Use this format when "Tampering or unauthorized access of public websites", or "Virus infection" and other incidents occur.
                                            </p>
                                            <!-- Fixed Header Information -->

                                            <!-- 1. Report Status -->
                                                <div class="section-card full-width" style="margin-bottom: 30px;">
                                                    <div class="section-header">
                                                        <div class="section-num">1</div>
                                                        <h4>Report Status</h4>
                                                    </div>
                                                    <div class="section-content">
                                                        <div class="status-options">
                                                            <label class="checkbox-item">
                                                                <input type="radio" name="reportStatus" value="First" checked> First report
                                                            </label>
                                                            <label class="checkbox-item">
                                                                <input type="radio" name="reportStatus" value="Interim" disabled> Interim report
                                                            </label>
                                                            <label class="checkbox-item">
                                                                <input type="radio" name="reportStatus" value="Final" disabled> Final report
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                        <div class="header-box">
                                            <div class="header-item">
                                                <h4>Reported On:</h4>
                                                <span id="reportedDateB" class="value-text"></span>
                                            </div>

                                            <div class="header-item">
                                                <h4>To: Cyber Security Incident Response Team</h4>
                                                <span class="value-text">HDQ-CSEC-head@ml.toshiba.co.jp</span>
                                            </div>
                                        </div>

          <!-- CSIRT Leader Information -->
          <div class="info-card">
              <h4>CSIRT Leader</h4>
              <div class="info-row">
                  <span class="info-label">Name:</span>
                  <span class="info-value">Marumoto Shuichiro</span>
              </div>
              <div class="info-row">
                  <span class="info-label">Designation:</span>
                  <span class="info-value">Director</span>
              </div>
          </div>

          <!-- Incident Logged By -->
          <div class="info-card">
              <h4>Incident Logged By</h4>
              <div class="info-row">
                  <span class="info-label">Name:</span>
                  <span class="info-value" id="currentUserNameB">-</span>
              </div>
              <div class="info-row">
                  <span class="info-label">ID:</span>
                  <span class="info-value" id="currentUserIdB">-</span>
              </div>
              <div class="info-row">
                <span class="info-label">Job Title:</span>
                <span class="info-value" id="currenttitleB">-</span>
            </div>
            <div class="info-row">
                <span class="info-label">phone:</span>
                <span class="info-value" id="currentphoneB">-</span>
            </div>
          </div>
      </div>

      <form id="incidentForm" onsubmit="handleSubmit(event)">
          <!-- Employee Search Section -->
          <div class="card">
              <h4 class="card-title">Incident Logged For</h4>
              <div style="margin-bottom: 1rem;">
                  <div class="search-area">
                  <label style="display: block; text-align: center; font-weight: 600; margin-bottom: 0.5rem; font-size: 0.9rem;">Employee ID</label>
                      <input type="text" id="empIdInput" placeholder="Enter ID" style="flex: 1; max-width: 300px;">
                      <button type="button" class="btn" onclick="searchEmployee(this)">Search</button>
                  </div>
              </div>

              <div id="errorMessage" class="error-msg"></div>

              <div id="employeeDetails" class="employee-details">
                  <h5 style="color: #065f46; margin-bottom: 0.75rem; font-size: 0.95rem; font-weight: 600;">Employee Details</h5>
                  <div class="details-grid">
                      <div class="info-row"><span class="info-label">Name:</span><span id="empName">-</span></div>
                      <div class="info-row"><span class="info-label">Job Title:</span><span id="empJobTitle">-</span></div>
                      <div class="info-row"><span class="info-label">ID:</span><span id="empId">-</span></div>
                      <div class="info-row"><span class="info-label">Company:</span><span id="empComp">-</span></div>
                      <div class="info-row"><span class="info-label">Department:</span><span id="empDept">-</span></div>
                      <div class="info-row"><span class="info-label">Division:</span><span id="empDiv">-</span></div>
                      <div class="info-row"><span class="info-label">Phone:</span><span id="empPhone">-</span></div>
                      <div class="info-row" style="grid-column: 1 / -1;"><span class="info-label">Email ID:</span><span id="empEmail">-</span></div>
                  </div>
              </div>
          </div>     

                <!-- Incident Type and Device Involved -->
                <div class="card">
                    <h4 class="card-title">Incident Type and Device Involved</h4>
                    <div class="form-row">
                        <label style="display: flex; align-items: flex-start; gap: 0.5rem; font-weight: 600;">
                            <input type="radio" name="incidentType" value="publicWebsite"
                                style="margin-top: 0.3rem;">
                            <span>Public website (unauthorized access or tampering)</span>
                        </label>
                        <div style="margin-left: 2rem; margin-top: 0.5rem;">
                            

                            <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <input type="radio" name="websiteType" value="registered" id=otherradio
                                    onchange="syncToggle1('otherradio', 'otherbox')"> Website registered with [SEC]
                                -
                                <span>Content number:</span>
                                <input type="text" name="box" value="" id=otherbox disabled style="width: 300px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                            </label>

                            <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <input type="radio" name="websiteType" value="unregistered" id=otherradio1
                                    onchange="syncToggle1('otherradio1', 'otherbox1')"> Unregistered website
                                    <span>URL:</span>
                                    <input type="text" name="box1" value="" id=otherbox1 disabled style="width: 300px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                            </label>
                        </div>
                    </div>
                    <div class="form-row" style="margin-top: 1rem;">
                        <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: 600;">
                            <input type="radio" name="incidentType" value="virusInfection" checked
                                style="margin-top: 0.3rem;">
                            <span>Virus infection (when information was, or probably was, leaked)</span>
                        </label>
                        <div
                            style="margin-left: 2rem; margin-top: 0.5rem; display: flex; gap: 1rem; flex-wrap: wrap; align-items: center;">
                            <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: normal;">
                                <input type="checkbox" name="deviceType" value="intranet"> Devices connected to Intranet
                            </label>
                            <div style="display: flex; gap: 1rem; align-items: center;">
                                <label style="display: flex; align-items: center; gap: 0.3rem; font-weight: normal;">
                                    <input type="checkbox" name="intranetDevice" value="servers"> Server(s)
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.3rem; font-weight: normal;">
                                    <input type="checkbox" name="intranetDevice" value="clients"> Client(s)
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.3rem; font-weight: normal;">
                                    <input type="checkbox" name="intranetDevice" value="intranetOther" id=otherradio2
                                    onchange="syncToggle('otherradio2', 'otherbox2')"> Other
                                    <input type="text" name="box2" value="" id=otherbox2
                                        style="width: 100px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                            </div>
                            <span>Number of devices:</span>
                            <input type="number" name="count" value=""
                                style="width: 80px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                        </div>
                        <div
                            style="margin-left: 2rem; margin-top: 0.5rem; display: flex; gap: 1rem; flex-wrap: wrap; align-items: center;">
                            <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: normal;">
                                <input type="checkbox" name="deviceType" value="mobile"> Mobile device(s)
                            </label>
                            <div style="display: flex; gap: 1rem;">
                                <label style="display: flex; align-items: center; gap: 0.3rem; font-weight: normal;">
                                    <input type="checkbox" name="mobileDevice" value="pcTablet"> PC(s)/tablet(s)
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.3rem; font-weight: normal;">
                                    <input type="checkbox" name="mobileDevice" value="smartphone"> Smartphone(s)
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.3rem; font-weight: normal;">
                                    <input type="checkbox" name="mobileDevice" value="mobileOther" id=otherradio3
                                    onchange="syncToggle('otherradio3', 'otherbox3')"> Other
                                    <input type="text" name="box3" value="" id=otherbox3
                                        style="width: 100px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                            </div>
                            <span>Number of devices:</span>
                            <input type="number" name="count2" value=""
                                style="width: 80px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                        </div>
                    </div>
                    <div class="form-row" style="margin-top: 1rem;">
                        <label style="display: flex; align-items: center; gap: 0.5rem; font-weight: normal;">
                            <input type="radio" name="incidentType" value="other" id="typeOther" onchange="toggleDescription()"> Other
                        </label>
                        <label style="display: block; margin-bottom: 0.5rem; margin-left: 1rem; font-weight: 600;">Brief Description of Incident</label>
                        <textarea id="incidentDesc" rows="3" placeholder="Describe the incident briefly" disabled 
                        style="width: 100%; padding: 0.6rem; margin-left: 1rem; border: 1px solid #d1d5db; border-radius: 0.5rem; opacity: 0.5; transition: opacity 0.2s;"></textarea>
                    </div>

                </div>

             <!-- Main Sections Grid -->
          <div class="section-grid">


              <!-- 2. Date and Time of Incident -->
              <div class="section-card">
                  <div class="section-header">
                      <div class="section-num">2</div>
                      <h4>Date and Time of Incident</h4>
                  </div>
                  <div class="section-content">
                      <p style="margin-bottom: 0.5rem;">Be specific to the best of your knowledge.</p>
                      <input type="datetime-local" style="width: 100%;">
                  </div>
              </div>

              <!-- 3. Date and Time Discovered -->
              <div class="section-card">
                  <div class="section-header">
                      <div class="section-num">3</div>
                      <h4>Date and Time Incident Discovered</h4>
                  </div>
                  <div class="section-content">
                      <p style="margin-bottom: 0.5rem;">Be specific to the best of your knowledge.</p>
                      <input type="datetime-local" style="width: 100%;">
                  </div>
              </div>
            
                <!-- Section 4: What Made You Notice Incident -->
                <div class="section-card">
                    <div class="section-header">
                        <span class="section-num">4</span>
                        <h4>What Made You Notice Incident</h4>
                    </div>
                    <div class="section-content">
                        <textarea rows="4" placeholder="Describe how the incident was discovered"
                            style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                    </div>
                </div>

                <!-- Section 5: Incident Overview -->
                <div class="section-card">
                    <div class="section-header">
                        <span class="section-num">5</span>
                        <h4>Incident Overview</h4>
                    </div>
                    <div class="section-content">
                        <label
                            style="display: block; font-size: 0.85rem; color: #374151; margin-bottom: 0.5rem;">General
                            overview of incident, including causes</label>
                        <textarea rows="5" placeholder="Provide a comprehensive overview"
                            style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                    </div>
                </div>

                <!-- Section 6: Information Leaked -->
                <div class="section-card" style="grid-column: span 2;">
                    <div class="section-header">
                        <span class="section-num">6</span>
                        <h4>Information That Was, or Can Possibly Be, Leaked</h4>
                    </div>
                    <div class="section-content">
                        <label style="display: block; font-size: 0.85rem; color: #374151; margin-bottom: 0.5rem;">If a
                            loss includes customers' information, write their company names.</label>
                        <label style="display: block; font-size: 0.85rem; color: #374151; margin-bottom: 0.5rem;">Fill
                            the incident's details, degree of seriousness including an impact on business operation and
                            clients.</label>
                        <textarea rows="3" placeholder="Describe information at risk"
                            style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem; margin-bottom: 1rem;"></textarea>

                        <div style="padding: 1rem; border-radius: 0.5rem; margin-top: 1rem;">
                            <p style="font-weight: 600; margin-bottom: 0.5rem;">If incident includes loss of personal
                                information:</p>
                            <label style="display: block; margin-bottom: 0.5rem; font-size: 0.9rem;">Data items:</label>
                            <div
                                style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.5rem; margin-bottom: 1rem;">
                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox">
                                    Name</label>
                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox">
                                    Birth date</label>
                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox">
                                    Gender</label>
                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox">
                                    Address</label>
                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox">
                                    Phone number</label>
                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox">
                                    Email address</label>
                                <label style="display: flex; align-items: center; gap: 0.3rem;"><input type="checkbox" id=otherradio4 name="dataItems" value="Other"
                                onchange="syncToggle('otherradio4', 'otherbox4')"> Other</label>
                                <input type="text" id="otherbox4" placeholder="Specify item" disabled style="padding: 0.3rem 0.5rem; flex: 1; max-width: 300px;">
                            </div>    
                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                                <div>
                                    <label style="display: block; margin-bottom: 0.3rem; font-size: 0.9rem;">Records
                                        on:</label>
                                    <input type="number"
                                        style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 0.3rem; font-size: 0.9rem;">Customers'
                                        info:</label>
                                    <input type="number"
                                        style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 0.3rem; font-size: 0.9rem;">Employees'
                                        info:</label>
                                    <input type="number"
                                        style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 0.3rem; font-size: 0.9rem;">Other
                                        personal contacts:</label>
                                    <input type="number"
                                        style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </div>
                            </div>
                            <div style="margin-top: 1rem;">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Secondary damage in event of misuse:</label>
                                <div style="display: flex; gap: 2rem;">
                                    <label style="display: flex; align-items: center; gap: 0.5rem;">
                                        <input type="radio" name="secondaryDamage" value="possible" id="secondaryPossible1" onchange="toggleSecondaryDamage()"> Possible
                                    </label>
                                    <label style="display: flex; align-items: center; gap: 0.5rem;">
                                        <input type="radio" name="secondaryDamage" value="none" id="secondaryNone1" onchange="toggleSecondaryDamage()"> None
                                    </label>
                                </div>
                                
                                <textarea id="secondaryTextbox1" rows="2" placeholder="If possible, describe" disabled style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem; margin-top: 0.5rem;"></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 7: Information Security Measures -->
                <div class="section-card" style="grid-column: span 2;">
                    <div class="section-header">
                        <span class="section-num">7</span>
                        <h4>Information Security Measures That Were Taken</h4>
                    </div>
                    <div class="section-content">
                        <div id="publicwebsitecontent7" style="padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                            <p style="font-weight: 600; margin-bottom: 1rem;">For "Public Website" Incidents:</p>

                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">IPS
                                        (Intrusion Prevention System):</label>
                                    <div style="display: flex; gap: 1rem;">
                                        <label style="display: flex; align-items: center; gap: 0.3rem;"><input
                                                type="radio" name="ips" value="inUse"> In use</label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;"><input
                                                type="radio" name="ips" value="notUsed"> Not used yet</label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            <input type="radio" name="ips" value="other" id=otherradio5 
                                            onchange="syncToggle1('otherradio5', 'otherbox5')"> Other
                                            <input type="text" id=otherbox5 disabled
                                                style="width: 100px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                        </label>
                                    </div>
                                </div>

                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">WAF (Web
                                        Application Firewall):</label>
                                    <div style="display: flex; gap: 1rem;">
                                        <label style="display: flex; align-items: center; gap: 0.3rem;"><input
                                                type="radio" name="waf" value="inUse"> In use</label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;"><input
                                                type="radio" name="waf" value="notUsed"> Not used yet</label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            <input type="radio" name="waf" value="other" id=otherradio6
                                            onchange="syncToggle1('otherradio6', 'otherbox6')"> Other
                                            <input type="text" id=otherbox6 disabled
                                                style="width: 100px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                        </label>
                                    </div>
                                </div>

                                <div style="grid-column: span 2;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Security
                                        diagnosis in the past half a year:</label>
                                    <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            <input type="radio" name="securityDiagnosis" value="performed" id=otherradioz
                                            onchange="syncToggle1('otherradioz', 'otherboxz')"> TSIS
                                            security diagnosis was performed, and passed
                                        </label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            Date: <input type="date" id=otherboxz disabled
                                                style="padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                        </label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;"><input
                                                type="radio" name="securityDiagnosis" value="notPerformed"> Not
                                            performed</label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            <input type="radio" name="securityDiagnosis" value="other" id=otherradio7
                                            onchange="syncToggle1('otherradio7', 'otherbox7')"> Other
                                            <input type="text" id=otherbox7 disabled
                                                style="width: 150px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                        </label>
                                    </div>
                                </div>

                                <div style="grid-column: span 2;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Device
                                        limitation for contents update:</label>
                                    <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            <input type="checkbox" name="deviceLimit" value="disableInternet"> Disable
                                            update via the Internet
                                        </label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            <input type="checkbox" name="deviceLimit" value="limitIP"> Limit IP address
                                            of update devices
                                        </label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            <input type="checkbox" name="deviceLimit" value="other" id=otherradio8
                                            onchange="syncToggle('otherradio8', 'otherbox8')"> Other
                                            <input type="text" id=otherbox8 disabled
                                                style="width: 150px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="virusinfectioncontent7" style="padding: 1rem; border-radius: 0.5rem;">
                            <p style="font-weight: 600; margin-bottom: 1rem;">For "Virus Infection" Incidents:</p>

                            <div style="display: grid; gap: 1rem;">
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Installation of antivirus software:</label>
                                    <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            <input type="radio" name="antivirus" value="installed" id=otherradio9
                                            onchange="syncToggle1('otherradio9', 'otherbox9')"> Installed
                                        </label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            Product name: <input type="text" id=otherbox9 disabled
                                                style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                        </label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;"><input
                                                type="radio" name="antivirus" value="notInstalled"> Not
                                            installed</label>
                                        <label style="display: flex; align-items: center; gap: 0.3rem;">
                                            <input type="radio" name="antivirus" value="other" id=otherradioa
                                            onchange="syncToggle1('otherradioa', 'otherboxa')"> Other
                                            <input type="text" id=otherboxa disabled
                                                style="width: 150px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                        </label>
                                    </div>
                                </div>

                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Regular
                                        online security patching:</label>
                                    <div>
                                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Regular online security patching:</label>
                                        <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                                            <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                <input type="radio" name="securityPatching" value="inUse" onchange="togglePatchingOptions(true)"> In use
                                            </label>

                                            <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                <input type="checkbox" name="patchingType" value="toshibaWSUS" class="patch-option" disabled> Toshiba WSUS
                                            </label>
                                            
                                            <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                <input type="checkbox" name="patchingType" value="wsus" class="patch-option" disabled> WSUS
                                            </label>

                                            <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                <input type="checkbox" name="patchingType" value="other" id="otherradiob" class="patch-option" disabled 
                                                    onchange="syncToggle1('otherradiob', 'otherboxb')"> Other
                                                <input type="text" id="otherboxb" disabled 
                                                    style="width: 150px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                            </label>

                                            <label style="display: flex; align-items: center; gap: 0.3rem;">
                                                <input type="radio" name="securityPatching" value="notUsed" onchange="togglePatchingOptions(false)"> Not used yet
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="othercontent7" style="margin-top: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Others (additional
                                measures):</label>
                            <textarea rows="2" placeholder="Fill in if there are other measures taken"
                                style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                        </div>
                    </div>
                </div>

                <!-- Section 8: Post-Incident Responses -->
                <div class="section-card" style="grid-column: span 2;">
                    <div class="section-header">
                        <span class="section-num">8</span>
                        <h4>Post-Incident Responses</h4>
                    </div>
                    <div class="section-content">
                        <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 1rem;">Actions taken to minimize
                            potential damage, investigate causes and make a recovery</p>

                        <!-- Interim Measures -->
                        <div id="interimMeasuresSection" style="padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                            <h5 style="font-weight: 600; margin-bottom: 0.75rem;">Interim Measures</h5>
                            <p style="font-size: 0.85rem; margin-bottom: 0.5rem;">For Public Website incidents:</p>
                            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                <label style="display: flex; align-items: center; gap: 0.5rem;"><input type="checkbox">
                                    Shutdown the website temporarily</label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;"><input type="checkbox">
                                    Block some pages</label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;"><input type="checkbox">
                                    Change the password for updating contents such as CMS and ftp</label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradioc onchange="syncToggle('otherradioc', 'otherboxc')"> Run a virus-check and clean the virus in website management
                                    PCs
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxc disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: flex-start; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiod onchange="syncToggle('otherradiod', 'otherboxd')"
                                    style="margin-top: 0.3rem;"> Post a message notifying
                                    visitors about virus infection and cleanup instructions
                                    <span style="margin-left: auto;">Date:</span>
                                    <input type="date" id=otherboxd disabled
                                        style="width: 150px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradioe onchange="syncToggle('otherradioe', 'otherboxe')"
                                    > Other
                                    <input type="text" id=otherboxe disabled
                                        style="flex: none; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                            </div>

                            <p style="font-size: 0.85rem; margin: 1rem 0 0.5rem;">For Virus Infection incidents:</p>
                            <label style="display: flex; align-items: center; gap: 0.5rem;"><input type="checkbox">
                                Isolate infected devices from the network</label>
                        </div>

                        <!-- Investigation of Damage -->
                        <div id="investigationDamageSection" style="padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                            <h5 style="font-weight: 600; margin-bottom: 0.75rem;">Investigation of Damage</h5>
                            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                <label>
                                    <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 1rem;">* If the
                                        presence or absence of damage or damage situation cannot be determined, you may
                                        ask professionals to perform a server forensic analysis.</p>

                                    <p style="font-size: 0.85rem; margin-bottom: 0.5rem;">For Public Website incidents:</p>

                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiof onchange="syncToggle('otherradiof', 'otherboxf')"
                                    > Check that the website has been infected with a virus
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxf disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiog onchange="syncToggle('otherradiog', 'otherboxg')"> Check for information stored in the server (presence or
                                    absence of personal information)
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxg disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradioh onchange="syncToggle('otherradioh', 'otherboxh')"
                                    > Check the access log to the server (for the possibility of data leak)
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxh disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                 <p style="font-size: 0.85rem; margin: 1rem 0 0.5rem;">For Virus Infection incidents:</p>

                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradioi onchange="syncToggle('otherradioi', 'otherboxi')"
                                    > Check for information stored in devices (presence or absence of important information)
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxi disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradioj onchange="syncToggle('otherradioj', 'otherboxj')"
                                    > Check the access log to the server that holds important information (presence or absence
                                    of unfamiliar access)
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxj disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiok onchange="syncToggle('otherradiok', 'otherboxk')"> Other
                                    <input type="text" id=otherboxk disabled
                                        style="flex: none; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                            </div>
                        </div>

                        <!-- Investigation of Causes -->
                        <div id="investigationCausesSection" style="padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                            <h5 style="font-weight: 600; margin-bottom: 0.75rem;">Investigation of Causes</h5>
                            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiol onchange="syncToggle('otherradiol', 'otherboxl')"
                                    > Check for publicly disclosed vulnerability in server software (OS, middleware, CMS, etc.)
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxl disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiom onchange="syncToggle('otherradiom', 'otherboxm')"
                                    > Check for vulnerability in website management PCs (OS, Flash Player, etc.)
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxm disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradion onchange="syncToggle('otherradion', 'otherboxn')"
                                    > Check that access right to the website setting is appropriate
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxn disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradioo onchange="syncToggle('otherradioo', 'otherboxo')"> Check for unfamiliar files in the server
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxo disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiop onchange="syncToggle('otherradiop', 'otherboxp')"
                                    > Check for illegal codes on the contents
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxp disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradioq onchange="syncToggle('otherradioq', 'otherboxq')"
                                    > Check for illegal descriptions in the directory access control file
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxq disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradior onchange="syncToggle('otherradior', 'otherboxr')"> Check the server log
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxr disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradios onchange="syncToggle('otherradios', 'otherboxs')"> Check the IPS/WAF log
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxs disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <p style="font-size: 0.85rem; margin: 1rem 0 0.5rem;">For Virus Infection incidents:</p>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiot onchange="syncToggle('otherradiot', 'otherboxt')"
                                    > Collect information and obtain analysis result using ATTK
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxt disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiou onchange="syncToggle('otherradiou', 'otherboxu')"
                                    > Check characteristics of the virus (for potential risks)
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxu disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiov onchange="syncToggle('otherradiov', 'otherboxv')"> Check the proxy log
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxv disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiow onchange="syncToggle('otherradiow', 'otherboxw')"
                                    > User interview (suspicious emails or web access)
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxw disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id=otherradiox onchange="syncToggle('otherradiox', 'otherboxx')"> Log investigation of devices (Security log, Web browsing
                                    history, etc.)
                                    <span style="margin-left: auto;">Result:</span>
                                    <input type="text" id=otherboxx disabled
                                        style="width: 200px; padding: 0.3rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                </label>
                            </div>
                        </div>

                        <!-- Others & Recovery -->
                        <div id="othersRecoveryGrid" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                            <div id="othersAdditionalMeasures">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Others
                                    (additional measures):</label>
                                <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 1rem;">*Fill in the blank
                                    if there are other measures taken rather than the above. </p>
                                <textarea rows="5"
                                    style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                            </div>
                            <div id="reopeningWebsiteSection">
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Reopening of the
                                    website:</label>
                                <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                    <input type="checkbox"> TSIS security diagnosis was performed, and passed
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                    <input type="checkbox" id=otherradioy onchange="syncToggle('otherradioy', 'otherboxy')"> Obtain permission of reopening from [CSEC]
                                </label>
                                <label style="display: block; margin-bottom: 0.3rem; font-weight: 600;">Date of
                                    reopening:</label>
                                <input type="date" id=otherboxy disabled
                                    style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;">
                            </div>
                        </div>

                        <div id="recoveryMethodSection" style="margin-top: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Recovery
                                method:</label>
                            <div style="display: flex; gap: 2rem;">
                                <label style="font-weight: 600;">Formatting of devices:</label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;"><input type="radio"
                                        name="formatting" value="performed"> Performed</label>
                                <label style="display: flex; align-items: center; gap: 0.5rem;"><input type="radio"
                                        name="formatting" value="notPerformed"> Not performed</label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 9: Timeline -->
                <div class="section-card" style="grid-column: span 2;">
                    <div class="section-header" style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);">
                        <span class="section-num" style="color: #1d4ed8;">9</span>
                        <h4>Timeline</h4>
                    </div>
                    <div class="section-content">
                        <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 1rem;">Describe chronologically - initial response, stopgap measure, instructions given by CSIRT Leader. Provide as much information as possible for initial report.</p>
                        <table style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="background: #1d4ed8; color: white;">
                                    <th style="padding: 0.75rem; text-align: left; border: 1px solid #ddd;">Date/Time</th>
                                    <th style="padding: 0.75rem; text-align: left; border: 1px solid #ddd;">Situation, Response, etc.</th>
                                </tr>
                            </thead>
                            <tbody id="timelineRowsB">
                                <tr>
                                    <td style="padding: 0.5rem; border: 1px solid #ddd;">
                                        <input type="datetime-local" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                                    </td>
                                    <td style="padding: 0.5rem; border: 1px solid #ddd;">
                                        <textarea rows="2" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;"></textarea>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <button type="button" onclick="addTimelineRowB()" style="margin-top: 0.5rem; padding: 0.5rem 1rem; background: #3b82f6; color: white; border: none; border-radius: 0.5rem; cursor: pointer;">+ Add Row</button>
                    </div>
                </div>

        <!-- Section 10: Assumed Causes -->
                <div class="section-card">
                    <div class="section-header" style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);">
                        <span class="section-num" style="color: #1d4ed8;">10</span>
                        <h4>Assumed Causes</h4>
                    </div>
                    <div class="section-content">
                        <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 0.5rem;">Provide root causes. For example, if person concerned neglected to follow rules, describe why he/she did.</p>
                        <p style="font-size: 0.8rem; color: #ef4444; margin-bottom: 0.5rem;">(Can be omitted for first report)</p>
                        <textarea rows="5" placeholder="Describe assumed root causes" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;"></textarea>
                    </div>
                </div>

        <!-- Section 11: Preventive Measures -->
                <div class="section-card">
                    <div class="section-header" style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);">
                        <span class="section-num" style="color: #1d4ed8;">11</span>
                        <h4>Preventive Measures</h4>
                    </div>
                    <div class="section-content">
                        <p style="font-size: 0.85rem; color: #6b7280; margin-bottom: 0.5rem;">Describe specifically. Attach evidence records, if any, such as a notice of issue and documents provided.</p>
                        <p style="font-size: 0.8rem; color: #ef4444; margin-bottom: 0.5rem;">(Can be omitted for first report)</p>
                        <textarea rows="4" placeholder="Describe preventive measures" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem; margin-bottom: 1rem;"></textarea>
                        
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                            <div>
                                <label style="display: block; margin-bottom: 0.3rem; font-weight: 600;">Name and title of person responsible</label>
                                <div style="padding: 0.6rem; background: #f0f9ff; border: 0.5px solid #bfdbfe; border-radius: 0.5rem;">
                                    <span style="font-weight: 500; color: #374151;">Kaza Saritha, Head of IT Department</span>
                                </div>
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 0.3rem; font-weight: 600;">Date of scheduled completion</label>
                                <input type="date" style="width: 100%; padding: 0.6rem; border: 1px solid #d1d5db; border-radius: 0.5rem;">
                            </div>
                        </div>

                    </div>
                </div>
              <!-- 12. Remarks -->
                <div class="section-card full-width">
                    <div class="section-header">
                        <div class="section-num">12</div>
                        <h4>Remarks</h4>
                    </div>
                    <div class="section-content">
                        <textarea rows="4" placeholder="Additional remarks or notes" style="width: 100%;"></textarea>
                    </div>
                </div>
          </div>

          <!-- Submit Button -->
            <div style="text-align: center; margin-top: 2rem;">
                <button type="button" class="submit-btn" onclick="generateFormBReport()">Submit IT Security Incident Report Form B</button>
            </div>

            <!-- Success Message -->
            <div id="successMessage" class="success-msg">
                IT Security Incident Report (Form B) submitted successfully!
            </div>
      </form>
      
                                </div>


                            </div>
                        </div>
                        `,


    'elearningPending': `<h3>Pending e-Learning</h3><p>Training schedules pending your completion.</p>`,
    'financeDisclosure': `<h3>Disclosure Status</h3><p>Your compliance disclosures and history.</p>`,

    'financeConflict': `<h3>Conflict of Interest</h3><p>Declare conflicts or review policies.</p>`,
    'others': `<section class="quick-links" aria-label="Quick access modules">
                        <article class="quick-card">
                          <header class="quick-card-header">
                            <div class="quick-badge">O</div>
                            <div>
                            <div class="quick-title">Organization Docs</div>
                            </div>
                          </header>
                          <div class="quick-actions">
                            <button class="btn-chip btn-chip-primary" type="button" data-content="Flow charts">Organization charts </button>
                            <button class="btn-chip" type="button" data-content="Template">Toshiba presentation Template</button>
                          </div>
                        </article>

                        <article class="quick-card">
                        <header class="quick-card-header">
                          <div class="quick-badge">FA</div>
                          <div>
                            <div class="quick-title">Finance &amp Accounts</div>
                          <!--  <div class="quick-caption">Company Calender,Directory &amp; more</div> -->
                          </div>
                        </header>
                        <div class="quick-actions">
                          <button class="btn-chip btn-chip-primary" type="button" data-content="financeDisclosure">Disclosure status</button>
                          <button class="btn-chip btn-chip-primary" type="button" data-content="financeConflict">Conflict of Interest</button>
                        </div>
                      </article>
              <!-- other quick cards can be added similarly -->
                      </section>`,
    'AU': `<div class="sidebar-header">
                <p style="color:orange;">*** Add alternative user to address facility/leave/ERP req in your absence.Please remove user when you are back to office ***</p>
                </div>
                <div class="sidebar-search">
                  <input type="search" id="policySearch" placeholder="Search employees..." />
                </div>
                <h4>Alternative User</h4><p>Selected user details will be visible here.</p>
                <h4>Alternative User History</h4><p>No history found</p>`,
    // Add this to your existing contentData object
    // ... your existing content ...

    'Flow charts': `<section class="quick-links" aria-label="Organization Charts">
                          <article class="quick-card">
                            <header class="quick-card-header">
                              <div class="quick-badge">O</div>
                              <div>
                                <div class="quick-title">Organization Charts</div>
                                <div class="quick-caption">Company structure and hierarchy</div>
                              </div>
                            </header>
                            <div class="quick-actions">
                              <button class="btn-chip btn-chip-primary" type="button" data-content="orgChart1">TTDI HQ</button>
                              <button class="btn-chip" type="button" data-content="orgChart2">CO</button>
                              <button class="btn-chip" type="button" data-content="orgChart3">DTR</button>
                              <button class="btn-chip" type="button" data-content="orgChart4">EPC</button>
                              <button class="btn-chip" type="button" data-content="orgChart5">PTR</button>
                              <button class="btn-chip" type="button" data-content="orgChart6">SWG</button>
                              <button class="btn-chip" type="button" data-content="orgChart7">SA</button>
                            </div>
                          </article>
                          </section>`,

    //Templates
    'Template': `<div class="widget">
                                <h3>Toshiba Presentation Template</h3>
                                <p>
                                    <a href="http://ttdi.toshiba-ttdi.com/IT%20Training/Toshiba%20ppt%20Format%202" download; style="color: blue; font-weight: bold;">
                                        Click here to Download
                                    </a>
                                </p>
                            </div>`,


    // Individual org chart content (placeholder examples)
    'orgChart1': `<div class="widget"><h3>TTDI HQ Organization Chart</h3><p>Complete headquarters structure with CEO, directors, and department heads.</p></div>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/OrgChart/Common%20Functions/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'orgChart2': `<div class="widget"><h3>Corporate Office</h3><p>Engineering teams, project managers, and technical leads structure.</p></div>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/OrgChart/CO/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'orgChart3': `<div class="widget"><h3>Distribution Transformers(DTR)</h3><p>HR teams, recruitment, training, and employee relations structure.</p></div>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/OrgChart/DTR/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'orgChart4': `<div class="widget"><h3>EPC</h3><p>Finance, accounts, budgeting, and audit teams structure.</p></div>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/OrgChart/EPC/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'orgChart5': `<div class="widget"><h3>Power Transformers(PTR)</h3><p>Procurement, vendor management, and supply chain structure.</p></div>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/OrgChart/PTR/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'orgChart6': `<div class="widget"><h3>Switch Gear(SWG)</h3><p>Quality assurance, testing, and compliance teams structure.</p></div>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/OrgChart/SWG/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`,

    'orgChart7': `<div class="widget"><h3>Surge Arresters(SA)</h3><p>Quality assurance, testing, and compliance teams structure.</p></div>
                            <iframe 
                                src="https://ttdi.toshiba-ttdi.com/OrgChart/SA/"
                                width="100%" 
                                height="600px"
                                style="border: none;">
                            </iframe>`

};



//functions.......

// Update content area with fade effect and set content class
function loadContent(key) {
    const contentArea = document.getElementById('contentArea');
    if (!contentArea) return;
    if (!(key in contentData)) {
        console.warn('contentData key missing:', key);
        return;
    }
    contentArea.style.opacity = '0.3';
    setTimeout(() => {
        contentArea.innerHTML = contentData[key];
        contentArea.className = `content ${key}`;
        contentArea.style.opacity = '1';
        console.log(key);
        // Handle IT Incidents
        // IT Helpdesk tabs
        if (key === 'itIncidents') {
            console.log('Loading IT Incidents');

            const newITTab = document.getElementById('tab-newIT');
            const loggedITTab = document.getElementById('tab-loggedIT');
            const tabButtons = document.querySelectorAll('.it-tab-btn');

            if (newITTab) newITTab.style.display = 'block';
            if (loggedITTab) loggedITTab.style.display = 'none';

            tabButtons.forEach(btn => {
                btn.onclick = null;  // clear any old handler if needed

                btn.addEventListener('click', () => {
                    const tabName = btn.getAttribute('data-tab');

                    // Reset styles for all buttons (now using the live NodeList)
                    tabButtons.forEach(b => {
                        b.style.background = '#f9fafb';
                        b.style.color = '#666';
                        b.style.fontWeight = 'normal';
                    });

                    // Highlight active button
                    btn.style.background = '#dbeafe';
                    btn.style.color = '#1d4ed8';
                    btn.style.fontWeight = '600';

                    // Show/hide content
                    if (tabName === 'newIT') {
                        if (newITTab) newITTab.style.display = 'block';
                        if (loggedITTab) loggedITTab.style.display = 'none';
                    } else if (tabName === 'loggedIT') {
                        if (newITTab) newITTab.style.display = 'none';
                        if (loggedITTab) loggedITTab.style.display = 'block';

                        // Load incidents from DB when Logged tab is shown
                        fetchItIncidents();
                    }
                });
            });
        }


        // Handle Safety tabs
        if (key == 'safetyIncidents') {
            const incidentsBtn = document.getElementById('incidentsBtn');
            const newIncidentBtn = document.getElementById('newIncidentBtn');
            const incidentsContent = document.getElementById('incidentsContent');

            incidentsContent.style.display = 'block';

            incidentsBtn.addEventListener('click', () => {
                incidentsContent.style.display = 'block';
                incidentsBtn.style.background = '#dbeafe';
                incidentsBtn.style.color = '#1d4ed8';
                incidentsBtn.style.fontWeight = '600';
                newIncidentBtn.style.background = '#f9fafb';
                newIncidentBtn.style.color = '#666';
                newIncidentBtn.style.fontWeight = 'normal';
            });

            newIncidentBtn.addEventListener('click', () => {
                loadContent('newIncident');
            });
        }

        // New Incident Form Logic
        if (key == 'newIncident') {
            const incidentsBtn = document.getElementById('incidentsBtn');
            const submitBtn = document.getElementById('submitIncident');

            document.getElementById('reportedOn').value = new Date().toISOString().slice(0, 16).replace('T', ' ');

            const formElements = ['division', 'unit', 'section', 'workCenter', 'location', 'area',
                'victim', 'victimAge', 'incidentDate', 'incidentTime', 'subject',
                'responsiblePerson', 'description', 'rootCause', 'correctiveAction',
                'riskLevel', 'riskCategory'];

            function validateForm() {
                const allFilled = formElements.every(id => {
                    const el = document.getElementById(id);
                    return el.value && el.value.trim() !== '';
                });

                submitBtn.disabled = !allFilled;
                submitBtn.style.background = allFilled ? '#10b981' : '#9ca3af';
                submitBtn.style.cursor = allFilled ? 'pointer' : 'not-allowed';
            }

            formElements.forEach(id => {
                document.getElementById(id).addEventListener('input', validateForm);
                document.getElementById(id).addEventListener('change', validateForm);
            });

            submitBtn.addEventListener('click', () => {
                if (!submitBtn.disabled) {
                    alert('Incident submitted successfully!');
                    loadContent('safetyIncidents');
                }
            });

            incidentsBtn.addEventListener('click', () => {
                loadContent('safetyIncidents');
            });
        }

        // After loading policy group list, bind click for policy items
        if (key.endsWith('Group')) {
            contentArea.querySelectorAll('.policy-item').forEach(btn => {
                btn.addEventListener('click', () => {
                    const itemKey = btn.getAttribute('data-content');
                    if (itemKey && itemKey in contentData) {
                        loadContent(itemKey);
                    }
                });
            });
        }

    }, 200);
}


// IT incidents detail view
// IT incidents detail view - Opens Form A or Form B HTML report
async function openItIncidentView(incidentId) {
    try {
        console.log('Opening incident view for:', incidentId);

        // Fetch incident data from backend
        const result = await fetchAPI(`/it-incidents/${encodeURIComponent(incidentId)}`);

        // Backend returns: { success: true, form_type: 'A'|'B', data: {...} }
        const formType = result.form_type || '';
        const data = result.data || {};

        console.log('Form Type:', formType, 'Data keys:', Object.keys(data));

        if (!formType) {
            alert('Error: Missing form type');
            console.error('Full result:', result);
            return;
        }

        if (Object.keys(data).length === 0) {
            alert('Error: No form data found');
            console.error('Full result:', result);
            return;
        }

        // Generate the appropriate HTML based on form type
        let reportHTML = '';

        if (formType === 'A') {
            reportHTML = generateFormAReportHTML(data, incidentId);
        } else if (formType === 'B') {
            reportHTML = generateFormBReportHTML(data, incidentId);
        } else {
            alert('Unknown form type: ' + formType);
            return;
        }

        // Open in popup window
        const popup = window.open('', 'ITIncidentView', 'width=1200,height=900,resizable=yes,scrollbars=yes');
        if (!popup) {
            alert('Popup blocked. Please allow popups for this site.');
            return;
        }

        popup.document.write(reportHTML);
        popup.document.close();

    } catch (err) {
        console.error('Error opening IT incident view:', err);
        alert('Failed to load incident details: ' + err.message);
    }
}

function generateFormAReportHTML(data, incidentId) {
    return `
        <!DOCTYPE html>
            <html>
            <head>
                <title>Information Security Incident Report - Form A</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; font-size: 12px; }
                    .report-container { max-width: 1200px; margin: 0 auto; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    table, th, td { border: 1px solid #000; }
                    th, td { padding: 8px; text-align: left; vertical-align: top; }
                    th { background: #f0f0f0; font-weight: 600; width: 40%; }
                    .header-section { background: #1d4ed8; color: white; padding: 15px; margin-bottom: 20px; }
                    .section-title { background: #e8f4f8; font-weight: bold; padding: 10px; margin-top: 15px; }
                    .review-btn { 
                        background: #3b82f6; 
                        color: white; 
                        padding: 12px 30px; 
                        border: none; 
                        border-radius: 5px; 
                        cursor: pointer; 
                        font-size: 14px;
                        margin: 20px 0;
                    }
                    .review-btn:hover { background: #2563eb; }
                    .editable { background: #fffbeb; }
                    textarea { width: 100%; min-height: 60px; padding: 5px; }
                    input[type="text"], input[type="date"], input[type="datetime-local"] { 
                        width: 30%; padding: 5px; 
                    }
                    
                    input[type="checkbox"]:disabled {
                        opacity: 0.8;
                        cursor: default;
                    }
                </style>
            </head>
            <body>
                <div class="report-container">
                    <div class="header-section">
                        <h2>Information Security Incident Report (Format A)</h2>
                        <p>Use this format when "Theft/loss Information Devices/Medium," or "Sending Emails, etc. to wrong destination" occur.</p>
                    </div>

                <!-- Top Section -->
                <table>
                    <tr>
                        <th>Reported on:</th>
                        <td id="edit-reportedDate">${data.reportedDate || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>To:</th>
                        <td>Manager of Cyber Security Center of Corporate Technology Planning Div.<br>
                        (email address: HDQ-CSEC-head@ml.toshiba.co.jp)</td>
                    </tr>
                    <tr>
                        <th>Scope of disclosure:</th>
                        <td>Cyber Security Center of Corporate Technology Planning Div., Legal Affairs Div., reporting division/department, and those permitted by the managers thereof</td>
                    </tr>
                </table>

                <!-- CSIRT Leader Section -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">CSIRT Leader of Toshiba or Key group company (Division in Charge)</th>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td>${data.csirtName || 'Marumoto Shuichiro'}</td>
                    </tr>
                    <tr>
                        <th>Designation and Division</th>
                        <td>${data.csirtJobTitle || 'Director'}, ${data.csirtDivision || 'CO'}</td>
                    </tr>
                </table>

                <!-- Department Information -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">Case Details</th>
                    </tr>
                    <tr>
                        <th>Company name & department</th>
                        <td id="edit-company">${data.companyName || 'N/A'}, ${data.personInvolvedDept || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>Name, job title and phone of person making report</th>
                        <td id="edit-reporter">${data.reporterName || 'N/A'}, ${data.reporterJobTitle || 'N/A'} (Phone: ${data.reporterPhone || 'N/A'})</td>
                    </tr>
                    <tr>
                        <th>Job category, job title and name of the person involved in incident</th>
                        <td id="edit-personInvolved">
                            Name & Job Title: ${data.personInvolvedName || 'N/A'}, ${data.personInvolvedJobTitle || 'N/A'}<br>
                            Job category: ${data.personInvolvedDivision || 'N/A'}<br>
                            ${data.jobCategory ? `Category: ${data.jobCategory}<br>` : ''}
                            ${data.outsourcee ? `Outsourcee: ${data.outsourcee}<br>` : ''}
                        </td>
                    </tr>
                </table>

                <!-- Incident Type -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">Incident Type and Device Involved</th>
                    </tr>
                    ${data.incidentType === 'theftLoss' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Theft/loss
                        </th>
                        <td>${(data.theftItems && data.theftItems.length > 0) ? data.theftItems.join(', ') : 'N/A'}
                            ${data.theftItemOther ? `<br>Other: ${data.theftItemOther}` : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'wrongDestination' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Sending to wrong destination (to a person outside Toshiba Group)
                        </th>
                        <td>${(data.wrongDestMethods && data.wrongDestMethods.length > 0) ? data.wrongDestMethods.join(', ') : 'N/A'}
                            ${data.wrongDestMethodOther ? `<br>Other: ${data.wrongDestMethodOther}` : ''}
                        </td>
                    </tr>
                    ` : ''}
                </table>

                <!-- Main Content Sections 1-12 -->
                <table>
                    <tr>
                        <th>1. Report status</th>
                        <td class="editable" id="edit-reportStatus">${data.reportStatus || 'First'}</td>
                    </tr>
                    <tr>
                        <th>2. Date and time of incident</th>
                        <td id="edit-incidentDateTime">${data.incidentDateTime || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>3. Date and time of incident discovered</th>
                        <td id="edit-discoveredDateTime">${data.discoveredDateTime || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>4. What made you notice incident</th>
                        <td id="edit-whatMadeNotice"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.whatMadeNotice || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>5. Incident overview<br><small>* General overview of incident, including causes</small></th>
                        <td id="edit-incidentOverview">
                            <textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.incidentOverview || ''}</textarea>
                            ${data.incidentType === 'theftLoss' ? `
                            <br><small>＜Fill in the following section if the incident is Theft/loss＞</small><br>
                            Location of theft/loss: <input type="text" id="input-locationOccurred" class="editable" value="${data.locationOccurred || ''}" style="width: 40%;"><br>
                            Alcohol intake: 
                            <label><input type="radio" class="editable" name="alcoholIntake" value="yes" ${data.alcoholIntake === 'yes' ? 'checked' : ''}> Yes</label>
                            <label><input type="radio" class="editable" name="alcoholIntake" value="no" ${data.alcoholIntake === 'no' ? 'checked' : ''}> No</label>
                            ` : ''}
                        </td>
                    </tr>
                    <tr>
                        <th>6. Information that was, or can possibly be, leaked<br><small>* If a loss includes customers' information, write their company names.</small></th>
                        <td id="edit-infoLeaked">
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.infoLeaked || ''}</textarea><br><br>
                            <small>＜Fill in the following section if the incident includes loss of personal information＞</small><br>
                            <strong>Data items:</strong>
                            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-top: 8px;">
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.name ? 'checked' : ''}> Name</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.birthDate ? 'checked' : ''}> Birth date</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.gender ? 'checked' : ''}> Gender</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.address ? 'checked' : ''}> Address</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.phone ? 'checked' : ''}> Phone number</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.email ? 'checked' : ''}> Email address</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.other ? 'checked' : ''}> Other</label>
                            </div><br>
                            <strong>Records on:</strong> <input type="number" id="input-recordsCount" class="editable" disabled value="${data.recordsCount || '0'}" style="width: 100px;"> people<br>
                            <strong>(Breakdown:</strong><br>
                            &nbsp;&nbsp;Customers' info: <input type="number" id="input-customersInfo" class="editable" disabled value="${data.customersInfo || '0'}" style="width: 100px;"> people<br>
                            &nbsp;&nbsp;Employees' info: <input type="number" id="input-employeesInfo" class="editable" disabled value="${data.employeesInfo || '0'}" style="width: 100px;"> people<br>
                            &nbsp;&nbsp;Other contacts: <input type="number" id="input-otherContacts" class="editable" disabled value="${data.otherContacts || '0'}" style="width: 100px;"> people<strong>)</strong><br><br>
                            <strong>Secondary damage in event of misuse:</strong><br>
                            <label><input type="radio" class="editable" disabled name="secondaryDamage" value="possible" ${data.secondaryDamage === 'possible' ? 'checked' : ''}> Possible</label>
                            <label><input type="radio" class="editable" disabled name="secondaryDamage" value="none" ${data.secondaryDamage === 'none' ? 'checked' : ''}> None</label><br>
                            <strong>Description:</strong><br>
                            <textarea id="input-secondaryDamageDesc" class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 60px;">${data.secondaryDamageDesc || ''}</textarea>
                        </td>
                    </tr>
                </table>

                <!-- Section 7: Information Security Measures (if Theft/Loss) -->
                ${data.incidentType === 'theftLoss' ? `
                <table>
                    <tr>
                        <th colspan="2" class="section-title">7. Information security measures that were taken</th>
                    </tr>
                    <tr>
                        <th>Permission from manager to take out a device</th>
                        <td id="edit-managerPermission">
                            <label><input class="editable" type="radio" name="managerPermission" value="obtained" ${data.managerPermission === 'obtained' ? 'checked' : ''}> Obtained permission (incl. blanket permission covering predefined period)</label><br>
                            <label><input class="editable" type="radio" name="managerPermission" value="notObtained" ${data.managerPermission === 'notObtained' ? 'checked' : ''}> Not obtained permission</label>
                        </td>
                    </tr>
                    <tr>
                        <th>Password (incl. fingerprint authentication)</th>
                        <td id="edit-password">
                            ${(data.passwordTypes || []).map(type => {
        const labels = {
            'bootTime': 'At boot time',
            'osStartup': 'On OS startup',
            'unlockScreen': 'When unlocking screen',
            'sleepMode': 'When exiting Sleep mode',
            'notSubject': 'Not subject to this requirement'
        };
        return `<label><input class="editable" type="checkbox" value="${type}" checked> ${labels[type] || type}</label><br>`;
    }).join('')}
                            ${data.passwordOther ? `<label><input class="editable" type="checkbox" checked> Other: <input class="editable" type="text" id="input-passwordOther" value="${data.passwordOther}"></label>` : ''}
                        </td>
                    </tr>
                    <tr>
                        <th>Encryption</th>
                        <td id="edit-encryption">
                            <strong>&lt;For Windows PCs and storage media.&gt;</strong><br>
                            Windows PC: 
                            <label><input class="editable" type="radio" name="windowsEncryption" value="encrypted" ${data.windowsEncryption === 'encrypted' ? 'checked' : ''}> Encrypted</label><br>
                            (Encryption tool: 
                            ${(data.encryptionTools || []).map(tool => `<label><input class="editable" type="checkbox" checked> ${tool}</label>`).join(' ')}
                            ${data.encryptionToolOther ? `<label>Other: <input class="editable" type="text" id="input-encryptionToolOther" value="${data.encryptionToolOther}"></label>` : ''}
                            )<br>
                            <label><input class="editable" type="radio" name="windowsEncryption" value="notEncrypted" ${data.windowsEncryption === 'notEncrypted' ? 'checked' : ''}> Not encrypted</label><br>
                            Storage medium: 
                            <label><input class="editable" type="radio" name="storageEncryption" value="allEncrypted" ${data.storageEncryption === 'allEncrypted' ? 'checked' : ''}> All company information has been encrypted</label><br>
                            <label><input class="editable" type="radio" name="storageEncryption" value="unencrypted" ${data.storageEncryption === 'unencrypted' ? 'checked' : ''}> There is unencrypted company information</label>
                        </td>
                    </tr>
                    <tr>
                        <th>Loss prevention measures</th><br><small>* Describe practice(s) that were taken for prevention of loss.</small></th>
                            
                        <td id="edit-lossPrevention">
                            <strong>&lt;Required for cell phones and smartphones&gt;</strong><br>
                            <label><input class="editable" type="radio" name="lossPreventionStrap" value="noStrap" ${data.lossPreventionStrap === 'noStrap' ? 'checked' : ''}> Device did not have strap</label><br>
                            <label><input class="editable" type="radio" name="lossPreventionStrap" value="strapNotUsed" ${data.lossPreventionStrap === 'strapNotUsed' ? 'checked' : ''}> Device had strap, but person concerned neglected to clip it to clothes or bag</label><br>
                            <label><input class="editable" type="radio" name="lossPreventionStrap" value="strapUsed" ${data.lossPreventionStrap === 'strapUsed' ? 'checked' : ''}> Device had strap, and person concerned had it clipped to clothes or bag</label>
                        </td>
                    </tr>
                    <tr>
                        <th>Others</th>
                        <td class="editable" id="edit-securityOther"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.securityMeasuresOther || ''}</textarea></td>
                    </tr>
                </table>

                <!-- Section 8: Post-incident responses -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">8. Post-incident responses<br><small>* Actions taken to minimize potential damage</small></th>
                    </tr>
                    <tr>
                        <th>Searching & reporting</th>
                        <td id="edit-searchActions">
                            <label><input class="editable" type="checkbox" ${data.searchedPlace ? 'checked' : ''}> Searched likely place 
                            (<input class="editable" type="text" id="input-searchedPlaceDesc" value="${data.searchedPlaceDesc || ''}" style="width: 200px;">)</label><br>
                            
                            <label><input class="editable" type="checkbox" ${data.gpsSearch ? 'checked' : ''}> Performed GPS search</label>
                            (Result: 
                            <label><input class="editable" type="radio" name="gpsResult" value="succeeded" ${data.gpsResult === 'succeeded' ? 'checked' : ''}> Succeeded</label>
                            <label><input class="editable" type="radio" name="gpsResult" value="failed" ${data.gpsResult === 'failed' ? 'checked' : ''}> Failed</label>)<br>
                            <label><input class="editable" type="checkbox" ${data.notSubjectGPS ? 'checked' : ''}> Not subject to GPS search</label><br>
                            
                            <label><input class="editable" type="checkbox" ${data.reportedTransport ? 'checked' : ''}> Reported loss to transport</label>
                            (Date and time: <input class="editable" type="datetime-local" id="input-transportDateTime" value="${data.reportedTransportDateTime || ''}" style="width: 200px;">, 
                            Reported place: <input class="editable" type="text" id="input-transportPlace" value="${data.reportedTransportPlace || ''}" style="width: 200px;">)<br>
                            
                            <label><input class="editable" type="checkbox" ${data.reportedPolice ? 'checked' : ''}> Reported loss to the police</label>
                            (Date and time: <input class="editable" type="datetime-local" id="input-policeDateTime" value="${data.reportedPoliceDateTime || ''}" style="width: 200px;">, 
                            Reported place: <input class="editable" type="text" id="input-policePlace" value="${data.reportedPolicePlace || ''}" style="width: 200px;">)
                        </td>
                    </tr>
                    <tr>
                        <th>Measures taken to minimize damage</th>
                        <td id="edit-damageMinimization">
                            <label><input class="editable" type="checkbox" ${data.disableIntranet ? 'checked' : ''}> Requested overseeing department to disable lost device to connect to Intranet (e.g., certificate revocation)</label>
                            <label><input class="editable" type="checkbox" ${data.disableIntranetNA ? 'checked' : ''}> Not subject to this requirement</label><br>
                            
                            <label><input class="editable" type="checkbox" ${data.remoteWipe ? 'checked' : ''}> Requested overseeing department to execute remote wipe</label>
                            (Result: 
                            <label><input class="editable" type="radio" name="remoteWipeResult" value="succeeded" ${data.remoteWipeResult === 'succeeded' ? 'checked' : ''}> Succeeded</label>
                            <label><input class="editable" type="radio" name="remoteWipeResult" value="waiting" ${data.remoteWipeResult === 'waiting' ? 'checked' : ''}> Yet to succeed</label>
                            <label><input class="editable" type="radio" name="remoteWipeResult" value="failed" ${data.remoteWipeResult === 'failed' ? 'checked' : ''}> Failed</label>)
                            <label><input class="editable" type="checkbox" ${data.remoteWipeNA ? 'checked' : ''}> Not subject to this requirement</label><br>
                            
                            <label><input class="editable" type="checkbox" ${data.closeLine ? 'checked' : ''}> Requested carrier to close communication line</label>
                            (Telephone number: <input class="editable" type="tel" id="input-phoneNumber" value="${data.phoneNumber || ''}" style="width: 150px;">)
                            <label><input class="editable" type="checkbox" ${data.closeLineNA ? 'checked' : ''}> Not subject to this requirement</label>
                        </td>
                    </tr>
                    <tr>
                        <th>Others</th>
                        <td id="edit-postIncidentOther"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.otherActionsTheft || ''}</textarea></td>
                    </tr>
                </table>
                ` : ''}

                <!-- Section 7 & 8: For Wrong Destination -->
                ${data.incidentType === 'wrongDestination' ? `
                <table>
                    <tr>
                        <th colspan="2" class="section-title">7. Information security measures that were taken</th>
                    </tr>
                    <tr>
                        <th></th>
                        <td id="edit-wrongDestSecurity"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.securityMeasuresWrongDest || ''}</textarea></td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th colspan="2" class="section-title">8. Post-incident responses<br><small>* Actions taken to minimize potential damage</small></th>
                    </tr>
                    <tr>
                        <th>Request a recipient to delete the wrongly sent email</th>
                        <td id="edit-deleteRequest">
                            <label><input class="editable" type="radio" name="deleteRequest" value="requested" ${data.deleteRequest === 'requested' ? 'checked' : ''}> Requested</label>
                            <label><input class="editable" type="radio" name="deleteRequest" value="notRequested" ${data.deleteRequest === 'notRequested' ? 'checked' : ''}> Not requested</label><br>
                            Reason: <textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.deleteRequestReason || ''}</textarea>
                        </td>
                    </tr>
                    <tr>
                        <th>Others</th>
                        <td id="edit-wrongDestOther"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.otherActionsWrongDest || ''}</textarea></td>
                    </tr>
                </table>
                ` : ''}

                <!-- Section 9: Timeline -->
                <table id="timeline-table">
                    <tr>
                        <th colspan="2" class="section-title">9. Timeline<br><small>* Describe chronologically: Initial response, Stopgap measure, Instructions given by CSIRT Leader</small></th>
                    </tr>
                    <tr>
                        <th style="width: 30%;">Date/time</th>
                        <th>Situation, response, etc.</th>
                    </tr>
                    ${(data.timeline && data.timeline.length > 0) ? data.timeline.map(item => `
                    <tr class="timeline-row">
                        <td><input class="editable" type="datetime-local" value="${item.dateTime || ''}" style="width: 100%; box-sizing: border-box;" /></td>
                        <td><textarea class="editable" style="width: 100%; box-sizing: border-box;">${item.situation || ''}</textarea></td>
                    </tr>
                    `).join('') : '<tr class="timeline-row"><td colspan="2">No timeline entries</td></tr>'}
                </table>
                <div id="report-actions" style="display: none; margin-bottom: 12px;">
                    <button class="action-btn btn-level" onclick="addTimelineRow()">
                        ➕ Add Timeline
                    </button>
                </div>

                <!-- Sections 10-12 -->
                <table>
                    <tr>
                        <th>10. Assumed causes<br><small>* Provide root causes. For example, if person concerned neglected to follow rules, describe why he/she did.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                        <td id="edit-assumedCauses"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.assumedCauses || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>11. Preventive measures<br><small>* Describe specifically. Attach evidence records, if any, such as a notice of issue and documents provided.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                        <td id="edit-preventiveMeasures">
                            <textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.preventiveMeasures || ''}</textarea><br>
                            Name and job title of person responsible for implementation: <input type="text" id="input-responsiblePerson" class="editable" value="${data.responsiblePerson || 'Kaza Saritha, Head of IT Department'}" style="width: 50%;"><br>
                            Date of scheduled completion: <input type="date" id="input-completionDate" class="editable" value="${data.completionDate || ''}" style="width: 25%;">
                        </td>
                    </tr>
                    <tr>
                        <th>12. Remarks</th>
                        <td id="edit-remarks"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.remarks || ''}</textarea></td>
                    </tr>
                </table>

                <div style="margin-top: 20px;">
                    <p style="font-size: 11px;"><strong>*1 Local wipe:</strong> A function to delete data of devices when failed a specified number of login attempts for unlocking the entry of a password.</p>
                    <p style="font-size: 11px;"><strong>*2 Mobile Device Management Tool:</strong> A tool for the centralized registration and administration of mobile devices such as tablets and smartphones, including their information and configuration settings</p>
                </div>

                <!-- Review/Edit Button -->
                <div style="text-align: center; margin: 30px 0;">
                    <button class="review-btn" id="editBtn" onclick="enableEditing()">Review & Edit Report</button>
                    <button class="review-btn" style="background: #10b981; display: none;" id="saveBtn" onclick="saveChanges()">💾 Save Changes</button>
                    <button class="review-btn" onclick="window.print()">Print Report</button>                   
                </div>
            </div>

            <script>
                const INCIDENT_ID = '${incidentId}' || 'UNKNOWN';
                const INCIDENT_TYPE = '${data.incidentType}';
                const API_BASE = 'http://localhost:5000';

                async function saveChanges() {
                    if (!confirm('Save all changes to incident ' + INCIDENT_ID + '?')) return;

                    const saveBtn = document.getElementById('saveBtn');
                    const reportActions = document.getElementById('report-actions');
                    saveBtn.disabled = true;
                    saveBtn.textContent = '⏳ Saving...';

                    try {
                        // ===== HELPER FUNCTIONS =====
                        function getValueById(id) {
                            const el = document.getElementById(id);
                            if (!el) return '';
                
                            if (el.tagName === 'TD') {
                                const input = el.querySelector('input, textarea');
                                if (input) return input.value.trim();
                                return el.textContent.trim();
                            }
                
                            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
                                return el.value.trim();
                            }
                
                            return el.textContent.trim();
                        }

                        function getRadioValue(name) {
                            const radio = document.querySelector(\`input[name="\${name}"]:checked\`);
                            return radio ? radio.value : '';
                        }

                        function getCheckboxValues(name) {
                            const checkboxes = document.querySelectorAll(\`input[name="\${name}"]:checked\`);
                            return Array.from(checkboxes).map(cb => cb.value);
                        }

                        function isChecked(selector) {
                            const el = document.querySelector(selector);
                            return el ? el.checked : false;
                        }

                        // ===== COLLECT TIMELINE DATA =====
                        console.log('📅 Collecting timeline from report...');
                        const timeline = [];
                        const timelineTables = document.querySelectorAll('table');
            
                        let timelineTable = null;
                        timelineTables.forEach(table => {
                            const headers = table.querySelectorAll('th');
                            headers.forEach(th => {
                                if (th.textContent.includes('Timeline') || th.textContent.includes('Date/time')) {
                                    timelineTable = table;
                                }
                            });
                        });

                        if (timelineTable) {
                            const tbody = timelineTable.querySelector('tbody');
                            if (tbody) {
                                const rows = tbody.querySelectorAll('tr');
                                console.log(\`  Found \${rows.length} timeline rows\`);
                    
                                rows.forEach((row, index) => {
                                    const cells = row.querySelectorAll('td');
                                    if (cells.length >= 2) {
                                        const dateInput = cells[0].querySelector('input[type="datetime-local"]');
                                        const textarea = cells[1].querySelector('textarea');
                            
                                        if (dateInput && textarea) {
                                            const dateTime = dateInput.value.trim();
                                            const situation = textarea.value.trim();
                                
                                            console.log(\`  Row \${index}: dateTime="\${dateTime}", situation="\${situation.substring(0, 30)}..."\`);
                                
                                            if (dateTime || situation) {
                                                timeline.push({ dateTime, situation });
                                            }
                                        }
                                    }
                                });
                            }
                        }
                        console.log(\`✅ Collected \${timeline.length} timeline entries\`);

                        // ===== COLLECT DATA ITEMS =====
                        const dataItems = {
                            name: false,
                            birthDate: false,
                            gender: false,
                            address: false,
                            phone: false,
                            email: false,
                            other: false
                        };

                        const dataItemCheckboxes = document.querySelectorAll('input.editable[type="checkbox"]');
                        dataItemCheckboxes.forEach(cb => {
                            if (!cb.checked) return;
                            const label = cb.parentElement?.textContent?.toLowerCase() || '';
                            if (label.includes('name') && !label.includes('birth')) dataItems.name = true;
                            else if (label.includes('birth')) dataItems.birthDate = true;
                            else if (label.includes('gender')) dataItems.gender = true;
                            else if (label.includes('address')) dataItems.address = true;
                            else if (label.includes('phone')) dataItems.phone = true;
                            else if (label.includes('email')) dataItems.email = true;
                            else if (label.includes('other')) dataItems.other = true;
                        });

                        // ===== BUILD UPDATED DATA OBJECT WITH ALL SECTION 7, 8, 9 DATA =====
                        const updatedData = {
                            // Basic info
                            reportedDate: getValueById('edit-reportedDate'),
                            csirtName: getValueById('edit-csirtName'),
                            csirtDesignation: getValueById('edit-csirtDesignation'),
                            companyName: getValueById('edit-company'),
                            reporterName: getValueById('edit-reporter'),
                            personInvolved: getValueById('edit-personInvolved'),
                            reportStatus: getValueById('edit-reportStatus'),
                            incidentDateTime: getValueById('edit-incidentDateTime'),
                            discoveredDateTime: getValueById('edit-discoveredDateTime'),
                            whatMadeNotice: getValueById('edit-whatMadeNotice'),
                            incidentOverview: getValueById('edit-incidentOverview'),
                            locationOccurred: document.getElementById('input-locationOccurred')?.value || '',
                            alcoholIntake: getRadioValue('alcoholIntake'),
                
                            // Section 6
                            infoLeaked: getValueById('edit-infoLeaked'),
                            dataItems: dataItems,
                            recordsCount: document.getElementById('input-recordsCount')?.value || '0',
                            customersInfo: document.getElementById('input-customersInfo')?.value || '0',
                            employeesInfo: document.getElementById('input-employeesInfo')?.value || '0',
                            otherContacts: document.getElementById('input-otherContacts')?.value || '0',
                            secondaryDamage: getRadioValue('secondaryDamage'),
                            secondaryDamageDesc: document.getElementById('secondaryTextbox')?.value || 
                                                    document.getElementById('secondaryTextbox1')?.value || '',
                
                            // ===== SECTION 7 - ALL DATA =====
                            managerPermission: getRadioValue('managerPermission'),
                            passwordTypes: getCheckboxValues('passwordType'),
                            passwordOther: document.getElementById('input-passwordOther')?.value || '',
                            windowsEncryption: getRadioValue('windowsEncryption'),
                            encryptionTools: getCheckboxValues('encryptionTool'),
                            encryptionToolOther: document.getElementById('input-encryptionToolOther')?.value || '',
                            storageEncryption: getRadioValue('storageEncryption'),
                            lossPreventionStrap: getRadioValue('lossPreventionStrap'),
                            securityMeasuresOther: getValueById('edit-securityOther'),
                            securityMeasures: getValueById('edit-securityMeasures'),
                
                            // ===== SECTION 8 - ALL DATA =====
                            searchedPlace: isChecked('input[value="searchedPlace"]'),
                            searchedPlaceDesc: document.getElementById('input-searchedPlaceDesc')?.value || '',
                            gpsSearch: isChecked('input[value="gpsSearch"]'),
                            gpsResult: getRadioValue('gpsResult'),
                            notSubjectGPS: isChecked('input[value="notSubjectGPS"]'),
                            reportedTransport: isChecked('input[value="reportedTransport"]'),
                            reportedTransportDateTime: document.getElementById('input-transportDateTime')?.value || '',
                            reportedTransportPlace: document.getElementById('input-transportPlace')?.value || '',
                            reportedPolice: isChecked('input[value="reportedPolice"]'),
                            reportedPoliceDateTime: document.getElementById('input-policeDateTime')?.value || '',
                            reportedPolicePlace: document.getElementById('input-policePlace')?.value || '',
                            disableIntranet: isChecked('input[value="disableIntranet"]'),
                            disableIntranetNA: isChecked('input[name="intranetGroup"][value="notSubject"]'),
                            remoteWipe: isChecked('input[value="remoteWipe"]'),
                            remoteWipeResult: getRadioValue('remoteWipeResult'),
                            remoteWipeNA: isChecked('input[name="wipeGroup"][value="notSubject"]'),
                            closeLine: isChecked('input[value="closeLine"]'),
                            phoneNumber: document.getElementById('input-phoneNumber')?.value || '',
                            closeLineNA: isChecked('input[name="lineGroup"][value="notSubject"]'),
                            otherActionsTheft: getValueById('edit-otherActionsTheft'),
                            deleteRequest: getRadioValue('deleteRequest'),
                            deleteRequestReason: getValueById('edit-deleteRequestReason'),
                            otherActionsWrongDest: getValueById('edit-otherActionsWrongDest'),
                            postIncidentActions: getValueById('edit-postIncidentActions'),
                
                            // ===== SECTION 9 - TIMELINE =====
                            timeline: timeline,
                
                            // Sections 10-12
                            assumedCauses: getValueById('edit-assumedCauses'),
                            preventiveMeasures: getValueById('edit-preventiveMeasures'),
                            responsiblePerson: document.getElementById('input-responsiblePerson')?.value || '',
                            completionDate: document.getElementById('input-completionDate')?.value || '',
                            remarks: getValueById('edit-remarks')
                        };

                        console.log('📤 Sending update with complete data:');
                        console.log('  Section 7 - Password Types:', updatedData.passwordTypes?.length || 0);
                        console.log('  Section 7 - Encryption Tools:', updatedData.encryptionTools?.length || 0);
                        console.log('  Section 7 - Security Other:', updatedData.securityMeasuresOther ? 'YES' : 'NO');
                        console.log('  Section 8 - Other Actions:', updatedData.otherActionsTheft ? 'YES' : 'NO');
                        console.log('  Section 9 - Timeline entries:', updatedData.timeline.length);

                        const response = await fetch(API_BASE + '/api/it-incidents/' + encodeURIComponent(INCIDENT_ID), {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ form_data: updatedData })
                        });

                        if (!response.ok) {
                            let errorMessage = 'Server error: ' + response.status + ' ' + response.statusText;
                            try {
                                const errorData = await response.json();
                                errorMessage = errorData.error || errorMessage;
                            } catch (e) {
                                if (response.status === 405) {
                                    errorMessage = 'Update endpoint not implemented on server.';
                                }
                            }
                            throw new Error(errorMessage);
                        }

                        const result = await response.json();

                        if (result.success) {
                            alert('✅ Changes saved successfully! All sections including 7, 8, 9 updated.');
                
                            // Disable editing
                            document.querySelectorAll('.editable').forEach(el => {
                                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                                    el.disabled = true;
                                } else {
                                    el.contentEditable = false;
                                }
                                el.style.border = '';
                                el.style.background = '#fffbeb';
                            });
                
                            saveBtn.style.display = 'none';
                            document.getElementById('editBtn').style.display = 'inline-block';
                            if (reportActions) reportActions.style.display = 'none';
                        } else {
                            alert('❌ Failed to save: ' + (result.error || 'Unknown error'));
                        }
                    } catch (err) {
                        console.error('Save error:', err);
                        alert('❌ Error saving: ' + err.message);
                    } finally {
                        saveBtn.disabled = false;
                        saveBtn.textContent = '💾 Save Changes';
                    }
                }

                function enableEditing() {
                    const editables = document.querySelectorAll('.editable');
                    const reportActions = document.getElementById('report-actions');
        
                    editables.forEach(el => {
                        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
                            el.disabled = false;
                            el.readOnly = false;
                        } else {
                            el.contentEditable = true;
                        }
                        el.style.border = '2px solid #3b82f6';
                        el.style.background = '#ffffff';
                    });
        
                    document.getElementById('editBtn').style.display = 'none';
                    document.getElementById('saveBtn').style.display = 'inline-block';
                    if (reportActions) reportActions.style.display = 'block';
        
                    alert('✏️ Editing enabled! All fields including Sections 7, 8, 9 are now editable.');
                }

                function addTimelineRow() {
                    const tables = document.querySelectorAll('table');
                    let timelineTable = null;
        
                    tables.forEach(table => {
                        const headers = table.querySelectorAll('th');
                        headers.forEach(th => {
                            if (th.textContent.includes('Timeline') || th.textContent.includes('Date/time')) {
                                timelineTable = table;
                            }
                        });
                    });
        
                    if (!timelineTable) {
                        console.error('Timeline table not found');
                        alert('❌ Timeline table not found');
                        return;
                    }
        
                    const tbody = timelineTable.querySelector('tbody');
                    if (!tbody) {
                        console.error('Timeline tbody not found');
                        alert('❌ Timeline tbody not found');
                        return;
                    }
        
                    // Remove "no entries" row if exists
                    const rows = tbody.querySelectorAll('tr');
                    if (rows.length === 1) {
                        const firstCell = rows[0].cells[0];
                        if (firstCell && firstCell.colSpan === 2 && firstCell.textContent.includes('No timeline entries')) {
                            rows[0].remove();
                        }
                    }
        
                    const newRow = tbody.insertRow(-1);
                    newRow.className = 'timeline-row';
        
                    const cell1 = newRow.insertCell(0);
                    const dateInput = document.createElement('input');
                    dateInput.type = 'datetime-local';
                    dateInput.className = 'editable timeline-datetime';
                    dateInput.style.cssText = 'width: 100%; box-sizing: border-box; border: 2px solid #3b82f6; background: #ffffff; padding: 5px;';
                    dateInput.disabled = false;
                    cell1.appendChild(dateInput);
        
                    const cell2 = newRow.insertCell(1);
                    const textarea = document.createElement('textarea');
                    textarea.className = 'editable timeline-situation';
                    textarea.style.cssText = 'width: 100%; box-sizing: border-box; border: 2px solid #3b82f6; background: #ffffff; min-height: 60px; padding: 5px;';
                    textarea.disabled = false;
                    cell2.appendChild(textarea);
        
                    console.log('✅ Timeline row added');
                    alert('✅ New timeline entry added! Fill in the details and click Save.');
                }
                </script>
        </body>
        </html>
            `;
}

function generateFormBReportHTML(data, incidentId) {
    return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Information Security Incident Report - Form B</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; font-size: 12px; }
                .report-container { max-width: 1200px; margin: 0 auto; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                table, th, td { border: 1px solid #000; }
                th, td { padding: 8px; text-align: left; vertical-align: top; }
                th { background: #f0f0f0; font-weight: 600; width: 40%; }
                .header-section { background: #1d4ed8; color: white; padding: 15px; margin-bottom: 20px; }
                .section-title { background: #e8f4f8; font-weight: bold; padding: 10px; margin-top: 15px; }
                .review-btn {
                    background: #3b82f6;
                    color: white;
                    padding: 12px 30px;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 14px;
                    margin: 20px 0;
                }
                .review-btn:hover { background: #2563eb; }
                .editable { background: #fffbeb; }
                textarea { width: 100%; min-height: 60px; padding: 5px; box-sizing: border-box; }
                input[type="text"], input[type="date"], input[type="datetime-local"], input[type="number"] {
                    width: 30%; padding: 5px; box-sizing: border-box;
                }
                input[type="checkbox"]:disabled, input[type="radio"]:disabled {
                    opacity: 0.8;
                    cursor: default;
                }
                .checkbox-grid {
                                display: grid;
                                grid-template-columns: repeat(4, 1fr);
                                gap: 6px;
                                margin-top: 8px;
                            }
                            .radio-group {
                                margin: 5px 0;
                            }
            </style>
        </head>
        <body>
            <div class="report-container">
                <div class="header-section">
                    <h2>Information Security Incident Report (Format B)</h2>
                    <p>Use this format for incidents other than "Theft/loss Information Devices/Medium" or "Sending Emails, etc. to wrong destination"</p>
                </div>

                <!-- Top Section -->
                <table>
                    <tr>
                        <th>Reported on:</th>
                        <td id="edit-reportedDate">${data.reportedDate || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>To:</th>
                        <td>Manager of Cyber Security Center of Corporate Technology Planning Div.<br>
                        (email address: HDQ-CSEC-head@ml.toshiba.co.jp)</td>
                    </tr>
                    <tr>
                        <th>Scope of disclosure:</th>
                        <td>Cyber Security Center of Corporate Technology Planning Div., Legal Affairs Div., reporting division/department, and those permitted by the managers thereof</td>
                    </tr>
                </table>

                <!-- CSIRT Leader Section -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">CSIRT Leader of Toshiba or Key group company (Division in Charge)</th>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td id="edit-csirtName">${data.csirtName || 'Marumoto Shuichiro'}</td>
                    </tr>
                    <tr>
                        <th>Designation and Division</th>
                        <td id="edit-csirtDesignation">${data.csirtJobTitle || 'Director'}, ${data.csirtDivision || 'CO'}</td>
                    </tr>
                </table>

                <!-- Department Information -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">Case Details</th>
                    </tr>
                    <tr>
                        <th>Company name & department</th>
                        <td id="edit-company">${data.companyName || 'N/A'}, ${data.personInvolvedDept || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>Name, job title and phone of person making report</th>
                        <td id="edit-reporter">${data.reporterName || 'N/A'}, ${data.reporterJobTitle || 'N/A'} (Phone: ${data.reporterPhone || 'N/A'})</td>
                    </tr>
                    <tr>
                        <th>Job category, job title and name of the person involved in incident</th>
                        <td id="edit-personInvolved">
                            Name & Job Title: ${data.personInvolvedName || 'N/A'}, ${data.personInvolvedJobTitle || 'N/A'}<br>
                            Department: ${data.personInvolvedDept || 'N/A'}<br>
                            ${data.jobCategory ? `Job category: ${data.jobCategory}<br>` : ''}
                            ${data.outsourcee ? `Outsourcee: ${data.outsourcee}<br>` : ''}
                        </td>
                    </tr>
                </table>

                <!-- Incident Type -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">Incident Type</th>
                    </tr>
                    ${data.incidentType === 'publicWebsite' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Unauthorized access to publicly accessible websites, defacement, etc.
                        </th>
                        <td>
                            Affected URL: ${data.affectedUrl || 'N/A'}<br>
                            ${data.publicWebsiteTypes && data.publicWebsiteTypes.length > 0 ? 'Types: ' + data.publicWebsiteTypes.join(', ') : ''}
                            ${data.publicWebsiteOther ? '<br>Other: ' + data.publicWebsiteOther : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'virusInfection' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Virus infection, etc.
                        </th>
                        <td>
                            Virus name: ${data.virusName || 'N/A'}<br>
                            ${data.virusTypes && data.virusTypes.length > 0 ? 'Types: ' + data.virusTypes.join(', ') : ''}
                            ${data.virusOther ? '<br>Other: ' + data.virusOther : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'intranetUnauthorized' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Unauthorized access to/from Intranet information systems
                        </th>
                        <td>
                            Affected system: ${data.affectedSystem || 'N/A'}<br>
                            ${data.intranetTypes && data.intranetTypes.length > 0 ? 'Types: ' + data.intranetTypes.join(', ') : ''}
                            ${data.intranetOther ? '<br>Other: ' + data.intranetOther : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'dos' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            DoS/DDoS attack
                        </th>
                        <td>
                            Target: ${data.dosTarget || 'N/A'}<br>
                            ${data.dosTypes && data.dosTypes.length > 0 ? 'Types: ' + data.dosTypes.join(', ') : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'targetedAttack' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Targeted attack
                        </th>
                        <td>
                            Attack vector: ${data.attackVector || 'N/A'}<br>
                            ${data.targetedAttackTypes && data.targetedAttackTypes.length > 0 ? 'Types: ' + data.targetedAttackTypes.join(', ') : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'otherIncident' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Other
                        </th>
                        <td>${data.otherIncidentDesc || 'N/A'}</td>
                    </tr>
                    ` : ''}
                </table>

                <!-- Main Content Sections 1-12 -->
                <table>
                    <tr>
                        <th>1. Report status</th>
                        <td class="editable" id="edit-reportStatus">${data.reportStatus || 'First'}</td>
                    </tr>
                    <tr>
                        <th>2. Date and time of incident</th>
                        <td id="edit-incidentDateTime">${data.incidentDateTime || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>3. Date and time of incident discovered</th>
                        <td id="edit-discoveredDateTime">${data.discoveredDateTime || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>4. What made you notice incident</th>
                        <td id="edit-whatMadeNotice"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box;">${data.whatMadeNotice || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>5. Incident overview<br><small>* General overview of incident, including causes</small></th>
                        <td id="edit-incidentOverview">
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 100px;">${data.incidentOverview || ''}</textarea>
                            ${data.incidentType === 'publicWebsite' ? `
                            <br><small>＜Fill in the following section if the incident is "Unauthorized access to publicly accessible websites, defacement, etc."＞</small><br>
                            <strong>Number of devices affected:</strong> <input type="number" id="input-publicDeviceCount" class="editable" disabled value="${data.publicDeviceCount || '0'}" style="width: 100px;"> devices
                            ` : ''}
                            ${data.incidentType === 'virusInfection' ? `
                            <br><small>＜Fill in the following section if the incident is "Virus infection, etc."＞</small><br>
                            <strong>Number of devices affected:</strong> <input type="number" id="input-virusDeviceCount" class="editable" disabled value="${data.virusDeviceCount || '0'}" style="width: 100px;"> devices
                            ` : ''}
                            ${data.incidentType === 'intranetUnauthorized' ? `
                            <br><small>＜Fill in the following section if the incident is "Unauthorized access to/from Intranet information systems"＞</small><br>
                            <strong>Number of devices affected (Intranet):</strong> <input type="number" id="input-intranetDeviceCount" class="editable" disabled value="${data.intranetDeviceCount || '0'}" style="width: 100px;"> devices<br>
                            <strong>Number of devices affected (Mobile):</strong> <input type="number" id="input-mobileDeviceCount" class="editable" disabled value="${data.mobileDeviceCount || '0'}" style="width: 100px;"> devices
                            ` : ''}
                        </td>
                    </tr>
                    <tr>
                        <th>6. Information that was, or can possibly be, leaked<br><small>* If the incident includes loss of customers' information, write their company names.</small></th>
                        <td id="edit-infoLeaked">
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.infoLeaked || ''}</textarea><br><br>
                            <small>＜Fill in the following section if the incident includes loss of personal information＞</small><br>
                            <strong>Data items:</strong>
                            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-top: 8px;">
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.name ? 'checked' : ''}> Name</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.birthDate ? 'checked' : ''}> Birth date</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.gender ? 'checked' : ''}> Gender</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.address ? 'checked' : ''}> Address</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.phone ? 'checked' : ''}> Phone number</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.email ? 'checked' : ''}> Email address</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.other ? 'checked' : ''}> Other</label>
                            </div><br>
                            <strong>Records on:</strong> <input type="number" id="input-recordsCount" class="editable" disabled value="${data.recordsCount || '0'}" style="width: 100px;"> people<br>
                            <strong>(Breakdown:</strong><br>
                            &nbsp;&nbsp;Customers' info: <input type="number" id="input-customersInfo" class="editable" disabled value="${data.customersInfo || '0'}" style="width: 100px;"> people<br>
                            &nbsp;&nbsp;Employees' info: <input type="number" id="input-employeesInfo" class="editable" disabled value="${data.employeesInfo || '0'}" style="width: 100px;"> people<br>
                            &nbsp;&nbsp;Other contacts: <input type="number" id="input-otherContacts" class="editable" disabled value="${data.otherContacts || '0'}" style="width: 100px;"> people<strong>)</strong><br><br>
                            <strong>Secondary damage in event of misuse:</strong><br>
                            <label><input type="radio" class="editable" disabled name="secondaryDamage" value="possible" ${data.secondaryDamage === 'possible' ? 'checked' : ''}> Possible</label>
                            <label><input type="radio" class="editable" disabled name="secondaryDamage" value="none" ${data.secondaryDamage === 'none' ? 'checked' : ''}> None</label><br>
                            <strong>Description:</strong><br>
                            <textarea id="input-secondaryDamageDesc" class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 60px;">${data.secondaryDamageDesc || ''}</textarea>
                        </td>
                    </tr>
                    <tr>
                        <th>7. Information security measures that were taken</th>
                        <td id="edit-securityMeasures"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.securityMeasures || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>8. Post-incident responses<br><small>* Actions taken to minimize potential damage</small></th>
  
                        <td id="edit-postIncidentActions"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 100px;">${data.postIncidentActions || ''}</textarea></td>
                    </tr>
                </table>

                <!-- Section 9: Timeline -->
                <div>
                <table  id="timeline-table">
                    <tr>
                        <th colspan="2" class="section-title">9. Timeline<br><small>* Describe chronologically: Initial response, Stopgap measure, Instructions given by CSIRT Leader</small></th>
                    </tr>
                    <tr>
                        <th style="width: 30%;">Date/time</th>
                        <th>Situation, response, etc.</th>
                    </tr>
                    ${data.timeline.map(item => `
                    <tr>
                        <td><input class="editable" disabled type="datetime-local" value="${item.dateTime || ''}" style="width: 100%; box-sizing: border-box;" /></td>
                        <td><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 60px;">${item.situation || ''}</textarea></td>
                    </tr>
                    `).join('')}
                                    ${data.timeline.length === 0 ? '<tr class="timeline-row"><td colspan="2">No timeline entries</td></tr>' : ''}
                                </table>
                                <button class="review-btn" id="report-actions" style="display: none; style="background: #09bb53; padding: 8px 10px; margin: 0px 0 20px 0;" onclick="addTimelineRow()">
                                        Add Timeline Row
                                </button>
                            </div>
                <!-- Sections 10-12 -->
                <table>
                    <tr>
                        <th>10. Assumed causes<br><small>* Provide root causes. For example, if person concerned neglected to follow rules, describe why he/she did.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                        <td id="edit-assumedCauses"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.assumedCauses || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>11. Preventive measures<br><small>* Describe specifically. Attach evidence records, if any, such as a notice of issue and documents provided.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                        <td id="edit-preventiveMeasures">
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.preventiveMeasures || ''}</textarea><br>
                            <strong>Name and job title of person responsible for implementation:</strong><br>
                            <input type="text" id="input-responsiblePerson" class="editable" disabled value="${data.responsiblePerson || ''}" style="width: 100%;"><br>
                            <strong>Date of (scheduled) completion:</strong><br>
                            <input type="date" id="input-completionDate" class="editable" disabled value="${data.completionDate || ''}" style="width: 100%;">
                        </td>
                    </tr>
                    <tr>
                        <th>12. Remarks</th>
                        <td id="edit-remarks"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 60px;">${data.remarks || ''}</textarea></td>
                    </tr>
                </table>

                <!-- Review/Edit Button -->
                <div style="text-align: center; margin: 30px 0;">
                    <button class="review-btn" id="editBtn" onclick="enableEditing()">Review & Edit Report</button>
                    <button class="review-btn" style="background: #10b981; display: none;" id="saveBtn" onclick="saveChanges()">💾 Save Changes</button>
                    <button class="review-btn" onclick="window.print()">Print Report</button>
                </div>
            </div>

            <script>
                const INCIDENT_ID = '${incidentId}' || 'UNKNOWN';
                const INCIDENT_TYPE = '${data.incidentType}';
                const API_BASE = 'http://localhost:5000';

                async function saveChanges() {
                    if (!confirm('Save all changes to incident ' + INCIDENT_ID + '?')) return;

                    const saveBtn = document.getElementById('saveBtn');
                    const reportActions = document.getElementById('report-actions');
                    saveBtn.disabled = true;
                    saveBtn.textContent = '⏳ Saving...';

                    try {
                        // ===== HELPER FUNCTIONS =====
                        function getValueById(id) {
                            const el = document.getElementById(id);
                            if (!el) return '';
                
                            if (el.tagName === 'TD') {
                                const input = el.querySelector('input, textarea');
                                if (input) return input.value.trim();
                                return el.textContent.trim();
                            }
                
                            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
                                return el.value.trim();
                            }
                
                            return el.textContent.trim();
                        }

                        function getRadioValue(name) {
                            const radio = document.querySelector(\`input[name="\${name}"]:checked\`);
                            return radio ? radio.value : '';
                        }

                        function getCheckboxValues(name) {
                            const checkboxes = document.querySelectorAll(\`input[name="\${name}"]:checked\`);
                            return Array.from(checkboxes).map(cb => cb.value);
                        }

                        function isChecked(selector) {
                            const el = document.querySelector(selector);
                            return el ? el.checked : false;
                        }

                        // ===== COLLECT TIMELINE DATA =====
                        console.log('📅 Collecting timeline from report...');
                        const timeline = [];
                        const timelineTables = document.querySelectorAll('table');
            
                        let timelineTable = null;
                        timelineTables.forEach(table => {
                            const headers = table.querySelectorAll('th');
                            headers.forEach(th => {
                                if (th.textContent.includes('Timeline') || th.textContent.includes('Date/time')) {
                                    timelineTable = table;
                                }
                            });
                        });

                        if (timelineTable) {
                            const tbody = timelineTable.querySelector('tbody');
                            if (tbody) {
                                const rows = tbody.querySelectorAll('tr');
                                console.log(\`  Found \${rows.length} timeline rows\`);
                    
                                rows.forEach((row, index) => {
                                    const cells = row.querySelectorAll('td');
                                    if (cells.length >= 2) {
                                        const dateInput = cells[0].querySelector('input[type="datetime-local"]');
                                        const textarea = cells[1].querySelector('textarea');
                            
                                        if (dateInput && textarea) {
                                            const dateTime = dateInput.value.trim();
                                            const situation = textarea.value.trim();
                                
                                            console.log(\`  Row \${index}: dateTime="\${dateTime}", situation="\${situation.substring(0, 30)}..."\`);
                                
                                            if (dateTime || situation) {
                                                timeline.push({ dateTime, situation });
                                            }
                                        }
                                    }
                                });
                            }
                        }
                        console.log(\`✅ Collected \${timeline.length} timeline entries\`);

                        // ===== COLLECT DATA ITEMS =====
                        const dataItems = {
                            name: false,
                            birthDate: false,
                            gender: false,
                            address: false,
                            phone: false,
                            email: false,
                            other: false
                        };

                        const dataItemCheckboxes = document.querySelectorAll('input.editable[type="checkbox"]');
                        dataItemCheckboxes.forEach(cb => {
                            if (!cb.checked) return;
                            const label = cb.parentElement?.textContent?.toLowerCase() || '';
                            if (label.includes('name') && !label.includes('birth')) dataItems.name = true;
                            else if (label.includes('birth')) dataItems.birthDate = true;
                            else if (label.includes('gender')) dataItems.gender = true;
                            else if (label.includes('address')) dataItems.address = true;
                            else if (label.includes('phone')) dataItems.phone = true;
                            else if (label.includes('email')) dataItems.email = true;
                            else if (label.includes('other')) dataItems.other = true;
                        });

                        // ===== COLLECT ALL EDITABLE FIELDS =====
                        const numberInputs = document.querySelectorAll('input[type="number"].editable');
                        const textInputs = document.querySelectorAll('input[type="text"].editable');
                        const dateInputs = document.querySelectorAll('input[type="date"].editable');
                        const datetimeInputs = document.querySelectorAll('input[type="datetime-local"].editable');
                        const telInputs = document.querySelectorAll('input[type="tel"].editable');
                        const textareas = document.querySelectorAll('textarea.editable');

                        console.log('📝 Collecting editable fields:');
                        console.log(\`  Number inputs: \${numberInputs.length}\`);
                        console.log(\`  Text inputs: \${textInputs.length}\`);
                        console.log(\`  Textareas: \${textareas.length}\`);
                        console.log(\`  Radio groups: passwordType, encryptionTool, etc.\`);

                        // ===== BUILD UPDATED DATA OBJECT WITH ALL SECTION 7, 8, 9 DATA =====
                        const updatedData = {
                            // Basic info
                            reportedDate: getValueById('edit-reportedDate'),
                            csirtName: getValueById('edit-csirtName'),
                            csirtDesignation: getValueById('edit-csirtDesignation'),
                            companyName: getValueById('edit-company'),
                            reporterName: getValueById('edit-reporter'),
                            personInvolved: getValueById('edit-personInvolved'),
                            reportStatus: getValueById('edit-reportStatus'),
                            incidentDateTime: getValueById('edit-incidentDateTime'),
                            discoveredDateTime: getValueById('edit-discoveredDateTime'),
                            whatMadeNotice: getValueById('edit-whatMadeNotice'),
                            incidentOverview: getValueById('edit-incidentOverview'),
                            // Incident type specific fields
                            publicDeviceCount: document.getElementById('input-publicDeviceCount')?.value || '0',
                            virusDeviceCount: document.getElementById('input-virusDeviceCount')?.value || '0',
                            intranetDeviceCount: document.getElementById('input-intranetDeviceCount')?.value || '0',
                            mobileDeviceCount: document.getElementById('input-mobileDeviceCount')?.value || '0',
                
                            // Section 6
                            infoLeaked: getValueById('edit-infoLeaked'),
                            dataItems: dataItems,
                            recordsCount: document.getElementById('input-recordsCount')?.value || '0',
                            customersInfo: document.getElementById('input-customersInfo')?.value || '0',
                            employeesInfo: document.getElementById('input-employeesInfo')?.value || '0',
                            otherContacts: document.getElementById('input-otherContacts')?.value || '0',
                            secondaryDamage: getRadioValue('secondaryDamage'),
                            secondaryDamageDesc: document.getElementById('input-secondaryDamageDesc')?.value || '',
                
                            // ===== SECTION 7 - ALL DATA =====
                            managerPermission: getRadioValue('managerPermission'),
                            passwordTypes: getCheckboxValues('passwordType'),
                            passwordOther: getValueById('edit-passwordOther') || '',
                            windowsEncryption: getRadioValue('windowsEncryption'),
                            encryptionTools: getCheckboxValues('encryptionTool'),
                            encryptionToolOther: getValueById('edit-encryptionToolOther') || '',
                            storageEncryption: getRadioValue('storageEncryption'),
                            lossPreventionStrap: getRadioValue('lossPreventionStrap'),
                            securityMeasuresOther: getValueById('edit-securityOther'),
                            securityMeasures: getValueById('edit-securityMeasures'),
                
                            // ===== SECTION 8 - ALL DATA =====
                            searchedPlace: isChecked('input[value="searchedPlace"]'),
                            searchedPlaceDesc: getValueById('edit-searchedPlaceDesc') || '',
                            gpsSearch: isChecked('input[value="gpsSearch"]'),
                            gpsResult: getRadioValue('gpsResult'),
                            notSubjectGPS: isChecked('input[value="notSubjectGPS"]'),
                            reportedTransport: isChecked('input[value="reportedTransport"]'),
                            reportedTransportDateTime: getValueById('edit-transportDateTime') || '',
                            reportedTransportPlace: getValueById('edit-transportPlace') || '',
                            reportedPolice: isChecked('input[value="reportedPolice"]'),
                            reportedPoliceDateTime: getValueById('edit-policeDateTime') || '',
                            reportedPolicePlace: getValueById('edit-policePlace') || '',
                            disableIntranet: isChecked('input[value="disableIntranet"]'),
                            disableIntranetNA: isChecked('input[name="intranetGroup"][value="notSubject"]'),
                            remoteWipe: isChecked('input[value="remoteWipe"]'),
                            remoteWipeResult: getRadioValue('remoteWipeResult'),
                            remoteWipeNA: isChecked('input[name="wipeGroup"][value="notSubject"]'),
                            closeLine: isChecked('input[value="closeLine"]'),
                            phoneNumber: getValueById('edit-phoneNumber') || '',
                            closeLineNA: isChecked('input[name="lineGroup"][value="notSubject"]'),
                            otherActionsTheft: getValueById('edit-otherActionsTheft'),
                            deleteRequest: getRadioValue('deleteRequest'),
                            deleteRequestReason: getValueById('edit-deleteRequestReason'),
                            otherActionsWrongDest: getValueById('edit-otherActionsWrongDest'),
                            postIncidentActions: getValueById('edit-postIncidentActions'),
                
                            // ===== SECTION 9 - TIMELINE =====
                            timeline: timeline,
                
                            // Sections 10-12
                            assumedCauses: getValueById('edit-assumedCauses'),
                            preventiveMeasures: getValueById('edit-preventiveMeasures'),
                            responsiblePerson: document.getElementById('input-responsiblePerson')?.value || '',
                            completionDate: document.getElementById('input-completionDate')?.value || '',
                            remarks: getValueById('edit-remarks')
                        };

                        console.log('📤 Sending update with complete data:');
                        console.log('  Section 7 - Password Types:', updatedData.passwordTypes?.length || 0);
                        console.log('  Section 7 - Encryption Tools:', updatedData.encryptionTools?.length || 0);
                        console.log('  Section 7 - Security Other:', updatedData.securityMeasuresOther ? 'YES' : 'NO');
                        console.log('  Section 8 - Other Actions:', updatedData.otherActionsTheft ? 'YES' : 'NO');
                        console.log('  Section 9 - Timeline entries:', updatedData.timeline.length);

                        const response = await fetch(API_BASE + '/api/it-incidents/' + encodeURIComponent(INCIDENT_ID), {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ form_data: updatedData })
                        });

                        if (!response.ok) {
                            let errorMessage = 'Server error: ' + response.status + ' ' + response.statusText;
                            try {
                                const errorData = await response.json();
                                errorMessage = errorData.error || errorMessage;
                            } catch (e) {
                                if (response.status === 405) {
                                    errorMessage = 'Update endpoint not implemented on server.';
                                }
                            }
                            throw new Error(errorMessage);
                        }

                        const result = await response.json();

                        if (result.success) {
                            alert('✅ Changes saved successfully! All sections including 7, 8, 9 updated.');
                
                            // Disable editing
                            document.querySelectorAll('.editable').forEach(el => {
                                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                                    el.disabled = true;
                                } else {
                                    el.contentEditable = false;
                                }
                                el.style.border = '';
                                el.style.background = '#fffbeb';
                            });
                
                            saveBtn.style.display = 'none';
                            document.getElementById('editBtn').style.display = 'inline-block';
                            if (reportActions) reportActions.style.display = 'none';
                        } else {
                            alert('❌ Failed to save: ' + (result.error || 'Unknown error'));
                        }
                    } catch (err) {
                        console.error('Save error:', err);
                        alert('❌ Error saving: ' + err.message);
                    } finally {
                        saveBtn.disabled = false;
                        saveBtn.textContent = '💾 Save Changes';
                    }
                }

                function enableEditing() {
                    const editables = document.querySelectorAll('.editable');
                    const reportActions = document.getElementById('report-actions');
        
                    editables.forEach(el => {
                        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
                            el.disabled = false;
                            el.readOnly = false;
                        } else {
                            el.contentEditable = true;
                        }
                        el.style.border = '2px solid #3b82f6';
                        el.style.background = '#ffffff';
                    });
        
                    document.getElementById('editBtn').style.display = 'none';
                    document.getElementById('saveBtn').style.display = 'inline-block';
                    if (reportActions) reportActions.style.display = 'block';
        
                    alert('✏️ Editing enabled! All fields including Sections 7, 8, 9 are now editable.');
                }

                function addTimelineRow() {
                    const tables = document.querySelectorAll('table');
                    let timelineTable = null;
        
                    tables.forEach(table => {
                        const headers = table.querySelectorAll('th');
                        headers.forEach(th => {
                            if (th.textContent.includes('Timeline') || th.textContent.includes('Date/time')) {
                                timelineTable = table;
                            }
                        });
                    });
        
                    if (!timelineTable) {
                        console.error('Timeline table not found');
                        alert('❌ Timeline table not found');
                        return;
                    }
        
                    const tbody = timelineTable.querySelector('tbody');
                    if (!tbody) {
                        console.error('Timeline tbody not found');
                        alert('❌ Timeline tbody not found');
                        return;
                    }
        
                    // Remove "no entries" row if exists
                    const rows = tbody.querySelectorAll('tr');
                    if (rows.length === 1) {
                        const firstCell = rows[0].cells[0];
                        if (firstCell && firstCell.colSpan === 2 && firstCell.textContent.includes('No timeline entries')) {
                            rows[0].remove();
                        }
                    }
        
                    const newRow = tbody.insertRow(-1);
                    newRow.className = 'timeline-row';
        
                    const cell1 = newRow.insertCell(0);
                    const dateInput = document.createElement('input');
                    dateInput.type = 'datetime-local';
                    dateInput.className = 'editable timeline-datetime';
                    dateInput.style.cssText = 'width: 100%; box-sizing: border-box; border: 2px solid #3b82f6; background: #ffffff; padding: 5px;';
                    dateInput.disabled = false;
                    cell1.appendChild(dateInput);
        
                    const cell2 = newRow.insertCell(1);
                    const textarea = document.createElement('textarea');
                    textarea.className = 'editable timeline-situation';
                    textarea.style.cssText = 'width: 100%; box-sizing: border-box; border: 2px solid #3b82f6; background: #ffffff; min-height: 60px; padding: 5px;';
                    textarea.disabled = false;
                    cell2.appendChild(textarea);
        
                    console.log('✅ Timeline row added');
                    alert('✅ New timeline entry added! Fill in the details and click Save.');
                }
            </script>
        </body>
        </html>
            `;
}
// see from here======================
function openIncidentView(incidentId) {
    const incidentData = {
        'FY25-DTR-CRG235': {
            reportedBy: 'TTDI000123 - D',
            reportedOn: '2026-01-08 14:30',
            incidentType: 'Non-reportable',
            division: 'DTR', unit: 'Unit 10 - IT Dept', section: 'IT Support', workCenter: 'Server Room',
            location: 'Rudraram', area: 'Core assembly', victim: 'TTDI001234', victimAge: '32', doj: '2023-03-15',
            incidentDate: '2026-01-08', incidentTime: '14:30', subject: 'Server room ventilation failure',
            responsiblePerson: 'TTDI000456 - Manager IT', description: 'Ventilation system failed during peak load...',
            rootCause: 'Filter blockage due to dust accumulation...', correctiveAction: 'Immediate filter replacement...',
            riskLevel: 'Low', riskCategory: 'Near-miss'
        },
        // Add similar data objects for other 9 IDs
        'FY25-PTR-FIR456': { reportedBy: 'TTDI000789 - R', reportedOn: '2026-01-07 09:15', /* etc */ },
        // Continue for all IDs...
    };

    const data = incidentData[incidentId] || incidentData['FY25-DTR-CRG235']; // Fallback

    const popupHtml = `
                        <!DOCTYPE html>
                        <html>
                        <head>
                        <title>Incident View - ${incidentId}</title>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1">
                        <style>
                            * { box-sizing: border-box; margin: 0; padding: 0; }
                            body { font-family: system-ui, -apple-system, sans-serif; background: #f5f7fb; color: #111827; line-height: 1.6; }
                            .container { max-width: 900px; margin: 0 auto; background: white; border-radius: 0.9rem; box-shadow: 0 12px 30px rgba(15,23,42,0.08); overflow: auto; }
                            .header { background: linear-gradient(135deg, #1d4ed8 0%, #3b82f6 100%); color: white; padding: 1rem 2rem; }
                            .header h1 { font-size: 1.4rem; font-weight: 700; margin-bottom: 0.25rem; }
                            .incident-id { font-size: 1.1rem; font-weight: 600; opacity: 0.95; }
                            .content { padding: 1rem; }
                            .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; margin-bottom: 1rem; }
                            .card { background: #f8fafc; padding: 1rem; border-radius: 0.8rem; border: 1px solid #e5e7eb; }
                            .card h3 { font-size: 0.95rem; font-weight: 600; color: #374151; margin-bottom: 1rem; }
                            .detail { display: flex; flex-direction: column; gap: 0.75rem; font-size: 0.88rem; }
                            .detail-row { display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #f1f5f9; }
                            .detail-row:last-child { border-bottom: none; }
                            .label { font-weight: 600; color: #4b5563; }
                            .value { color: #111827; }
                            .status-badge { padding: 0.2rem 0.75rem; border-radius: 999px; font-size: 0.8rem; font-weight: 600; }
                            .low { background: #dcfce7; color: #166534; }
                            .medium { background: #fed7aa; color: #c2410c; }
                            .high { background: #fecaca; color: #991b1b; }
                            .text-content { white-space: pre-wrap; line-height: 1.7; }
                            .btn-group { display: flex; gap: 1rem; justify-content: center; padding: 1rem 0; }
                            .btn { padding: 0.75rem 1.75rem; border: none; border-radius: 0.7rem; font-size: 0.9rem; font-weight: 600; cursor: pointer; transition: all 0.2s ease; }
                            .btn-primary { background: #6b7280; color: white; }
                            .btn-secondary { background: #6b7280; color: white; }
                            .btn:hover { transform: translateY(-1px); box-shadow: 0 8px 20px rgba(0,0,0,0.15); }
                            @media (max-width: 768px) { .grid { grid-template-columns: 1fr; } }
                        </style>
                        </head>
                        <body>
                        <div class="container">
                            <div class="header">
                            <h1>Incident Report Details</h1>
                            <div class="incident-id">${incidentId}</div>
                            <button class="btn btn-primary">Root Cause</button>
                            <button class="btn btn-primary">Counter Measures</button>
                            <button class="btn btn-primary">OHC</button>
                            </div>

                            <div id="modalOverlay" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; justify-content:center; align-items:center;">
                                <div style="background:white; width:90%; max-width:800px; max-height:90vh; border-radius:1rem; position:relative; padding:1rem; overflow-y:auto; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);">
                                    <button onclick="closeModal()" style="position:absolute; top:1rem; right:1rem; border:none; background:none; font-size:1.5rem; cursor:pointer; color:#666;">&times;</button>
                                    <div id="modalContent"></div>
                                </div>
                            </div>

                            <div class="content">
                            <div class="grid">
                                <div class="card">
                                <h3>Report Details</h3>
                                <div class="detail">
                                    <div class="detail-row"><span class="label">Location:</span><span class="value">${data.location}</span></div>
                                    <div class="detail-row"><span class="label">Reported By:</span><span class="value">${data.reportedBy}</span></div>
                                    <div class="detail-row"><span class="label">Reported On:</span><span class="value">${data.reportedOn}</span></div>
                                    <div class="detail-row"><span class="label">Incident Type:</span><span class="value">${data.incidentType}</span></div>
                                </div>
                                </div>
                                <div class="card">
                                <h3>Location Details</h3>
                                <div class="detail">
                                    <div class="detail-row"><span class="label">Division:</span><span class="value">${data.division}</span></div>
                                    <div class="detail-row"><span class="label">Unit:</span><span class="value">${data.unit}</span></div>
                                    <div class="detail-row"><span class="label">Section:</span><span class="value">${data.section}</span></div>
                                    <div class="detail-row"><span class="label">Work Center:</span><span class="value">${data.workCenter}</span></div>
                                </div>
                                </div>
                                <div class="card">
                                <h3>Victim Details</h3>
                                <div class="detail">
                                    <div class="detail-row"><span class="label">Area:</span><span class="value">${data.area}</span></div>
                                    <div class="detail-row"><span class="label">Victim:</span><span class="value">${data.victim}</span></div>
                                    <div class="detail-row"><span class="label">Victim Age:</span><span class="value">${data.victimAge}</span></div>
                                    <div class="detail-row"><span class="label">Date of Joining:</span><span class="value">${data.doj}</span></div>
                                </div>
                                </div>
                            </div>
                    
                            <div style="display: grid; grid-template-columns: 1fr 2fr 1fr; gap: 0.5rem; margin-bottom: 1rem;">
                                <div class="card">
                                <h3>Incident Details</h3>
                                <div class="detail">
                                    <div class="detail-row"><span class="label">Date & Time:</span><span class="value">${data.incidentDate} ${data.incidentTime}</span></div>
                                    <div class="detail-row"><span class="label">Subject:</span><span class="value">${data.subject}</span></div>
                                    <div class="detail-row"><span class="label">Responsible Person:</span><span class="value">${data.responsiblePerson}</span></div>
                                </div>
                                </div>
                                <div class="card">
                                <h3>Description</h3>
                                <div class="text-content">${data.description}</div>
                                </div>
                                <div class="card">
                                <h3>Risk Assessment</h3>
                                <div style="display: flex; flex-direction: column; gap: 1rem;">
                                    <div class="detail-row"><span class="label">Risk Level:</span>
                                    <span class="status-badge ${data.riskLevel.toLowerCase()}">${data.riskLevel}</span>
                                    </div>
                                    <div class="detail-row"><span class="label">Risk Category:</span><span class="value">${data.riskCategory}</span></div>
                                </div>
                                </div>
                            </div>
                    
                            <div class="card" style="margin-bottom: 0;">
                                <h3>Analysis</h3>
                                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem;">
                                <div>
                                    <div class="detail-row"><span class="label">Preliminary Root Cause:</span></div>
                                    <div class="text-content">${data.rootCause}</div>
                                </div>
                                <div>
                                    <div class="detail-row"><span class="label">Preliminary Corrective Action:</span></div>
                                    <div class="text-content">${data.correctiveAction}</div>
                                </div>
                                </div>
                            </div>
                            </div>
                
                        </div>

                        <script>
                            // MOVING FUNCTIONS INSIDE THE POPUP HTML
                            function openModal(contentHtml) {
                                document.getElementById('modalContent').innerHTML = contentHtml;
                                document.getElementById('modalOverlay').style.display = 'flex';
                            }

                            function closeModal() {
                                document.getElementById('modalOverlay').style.display = 'none';
                            }

                            // Click Handlers inside the popup context
                            document.querySelectorAll('.btn-primary').forEach(button => {
                                button.onclick = function() {
                                    const type = this.innerText;
                                    const incidentId = "${incidentId}"; // Using the variable from the parent
                            
                                    if (type === 'Root Cause') {
                                        openModal('<h3>Root Cause Analysis</h3><textarea style="width:100%; height:150px; margin-top:10px; padding:10px; border-radius:8px; border:1px solid #ccc;"></textarea><button class="btn btn-secondary" style="margin-top:10px; background:#1d4ed8">Save</button>');
                                    } 
                                    else if (type === 'Counter Measures') {
                                        openModal(\`
                                            <h3>Counter Measures</h3>
                                            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:5px; margin-top:10px;">
                                                <div><label>Category</label><select style="width:100%; padding:8px;"><option>People</option></select></div>
                                                <div><label>Sub-Category</label><select style="width:100%; padding:8px;"><option>A</option></select></div>
                                            </div>
                                            <div style="margin-top:10px;"><label>Responsible</label><input type="text" style="width:100%; padding:8px;"></div>
                                            <div style="margin-top:10px;"><label>Action</label><textarea style="width:100%; height:60px;"></textarea></div>
                                            <div style="margin-top:10px;"><label>Target Date</label><input type="date" style="width:100%; padding:8px;"></div>
                                            <button class="btn btn-secondary" style="margin-top:15px; width:100%; background:#1d4ed8">Submit</button>
                                            <table style="width:100%; margin-top:20px; border-collapse: collapse; font-size:12px;">
                                                <tr style="background:#eee"><th>Cat</th><th>Resp</th><th>Date</th></tr>
                                                <tr><td>People</td><td>John</td><td>2026-01-10</td></tr>
                                            </table>
                                        \`);
                                    }
                                    else if (type === 'OHC') {
                                        openModal(\`
                                            <h3>OHC Details</h3>
                                            <p style="margin-bottom:10px;">ID: \${incidentId}</p>
                                            <div style="margin-top:10px;"><label>Name/ID</label><input type="text" style="width:100%; padding:8px;"></div>
                                            <div style="margin-top:10px;"><label>Injury</label><select style="width:100%; padding:8px;"><option>Burn</option></select></div>
                                            <div style="display:flex; gap:10px; margin-top:10px;">
                                                <div style="flex:1;"><label>Date</label><input type="date" style="width:100%; padding:8px;"></div>
                                                <div style="flex:1;"><label>Time</label><input type="time" style="width:100%; padding:8px;"></div>
                                            </div>
                                            <div style="margin-top:10px;"><label>Remarks</label><textarea style="width:100%; height:60px;"></textarea></div>
                                            <button class="btn btn-secondary" style="margin-top:15px; width:100%; background:#1d4ed8">Add</button>
                                        \`);
                                    }
                                };
                            });
                        <\/script>
                        </body>
                        </html>
                    `;

    const popup = window.open('', 'incidentView', 'width=800,height=800,resizable=yes,scrollbars=yes');
    popup.document.write(popupHtml);
    popup.document.close();
}

// Clear active class on nav links
function clearActiveNav() {
    document.querySelectorAll('.nav-link, .btn').forEach(el => {
        el.classList.remove('active');
    });
}

// Setup all event listeners after DOM content loaded
document.addEventListener('DOMContentLoaded', () => {
    // Date display
    const label = document.getElementById('currentDateLabel');
    if (label) {
        const now = new Date();
        label.textContent = now.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).replace(',', '');
    }

    // User dropdown toggling
    const chip = document.getElementById('userChip');
    const dropdown = document.getElementById('userDropdown');
    if (chip && dropdown) {
        chip.addEventListener('click', e => {
            e.stopPropagation();
            const isOpen = dropdown.classList.toggle('open');
            chip.setAttribute('aria-expanded', String(isOpen));
        });
        document.addEventListener('click', () => {
            if (dropdown.classList.contains('open')) {
                dropdown.classList.remove('open');
                chip.setAttribute('aria-expanded', 'false');
            }
        });
    }

    // Initial load home content
    loadContent('home');

    // Nav link clicks
    document.querySelectorAll('.nav-link').forEach(btn => {
        btn.addEventListener('click', () => {
            clearActiveNav();
            btn.classList.add('active');
            const key = btn.getAttribute('data-content');

            // HIDE THE ENTIRE CONTAINERS (not just the forms)
            const helpdeskContainer = document.querySelector('.helpdesk-container');
            const formatAContent = document.getElementById('formatAContent');
            const formatBContent = document.getElementById('formatBContent');

            // Hide helpdesk-container (which contains Form B)
            if (helpdeskContainer) {
                helpdeskContainer.style.display = 'none';
                console.log('🔒 Hidden helpdesk-container');
            }

            // Also hide Form A
            if (formatAContent) {
                formatAContent.style.display = 'none';
                console.log('🔒 Hidden formatAContent');
            }

            // Direct hide of Form B (backup)
            if (formatBContent) {
                formatBContent.style.display = 'none';
                console.log('🔒 Hidden formatBContent');
            }

            loadContent(key);
        });
    });




    // Quick chips inside content: dynamically bind on content load
    // For initial home content, bind now, later bind inside loadContent if dynamic content added
    // Quick chips inside content dynamically bind on content load
    document.body.addEventListener('click', (e) => {
        const target = e.target.closest('.btn-chip, .btn');
        if (target) {
            e.preventDefault();
            clearActiveNav();
            const key = target.getAttribute('data-content');

            if (key) {
                // ========== ADD THIS BLOCK ==========
                // FORCE HIDE FORMS HERE TOO
                const formatAContent = document.getElementById('formatAContent');
                const formatBContent = document.getElementById('formatBContent');

                if (formatAContent) {
                    formatAContent.style.display = 'none';
                    formatAContent.style.visibility = 'hidden';
                }
                if (formatBContent) {
                    formatBContent.style.display = 'none';
                    formatBContent.style.visibility = 'hidden';
                }
                // ========== END OF NEW BLOCK ==========

                loadContent(key);
            }
        }
    });



    // Policy group header clicks - load group list in content area
    document.querySelectorAll('.policy-group-header').forEach(header => {
        header.addEventListener('click', () => {
            const groupKey = header.getAttribute('data-group');
            if (groupKey && (groupKey in contentData)) {
                clearActiveNav();
                loadContent(groupKey);
            }
        });
    });

    // Policy search filter
    const searchInput = document.getElementById('policySearch');
    const groupsContainer = document.getElementById('policyGroups');
    if (searchInput && groupsContainer) {
        searchInput.addEventListener('input', () => {
            const term = searchInput.value.trim().toLowerCase();
            groupsContainer.querySelectorAll('.policy-group-header').forEach(header => {
                const groupKey = header.getAttribute('data-group');
                if (!groupKey) return;
                const groupList = contentData[groupKey];
                if (!groupList) return;
                // Simple check if group name or its list includes term
                if (header.textContent.toLowerCase().includes(term) || groupList.toLowerCase().includes(term)) {
                    header.style.display = '';
                } else {
                    header.style.display = 'none';
                }
            });
        });
    }
    setTimeout(initSlider, 100);  // Small delay to ensure content is rendered
});

const formatter = new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
});

// Unit mappings by division
const unitData = {
    'DTR': ['Unit 1 - Fabrication', 'Unit 2 - Welding', 'Unit 3 - Main Stores', 'Unit 4 - Maintenance', 'Unit 5 - Assembly', 'Unit 10 - IT Dept'],
    'PTR': ['Unit 6 - Packing', 'Unit 7 - Paint Shop', 'Unit 8 - Testing', 'Unit 9 - Quality'],
    'CO': ['Admin Block', 'Corporate Office', 'HR Dept', 'Finance Dept'],
    'SA': ['Sales Office', 'Marketing Team'],
    'SWG': ['R&D Lab', 'Design Center']
};

// Section mappings by unit (sample data)
const sectionData = {
    'Unit 1 - Fabrication': ['Main Shop Floor', 'Cutting Area', 'Bending Section'],
    'Unit 2 - Welding': ['Welding Bay', 'Grinding Zone'],
    'Unit 3 - Main Stores': ['Central Stores', 'Dispatch Area'],
    // Add more mappings as needed
};

// Workcenter mappings (sample)
const workCenterData = {
    'Main Shop Floor': ['Machine 1', 'Machine 2', 'Assembly Line A']
};

function updateUnits() {
    const division = document.getElementById('division').value;
    const unitSelect = document.getElementById('unit');
    const sectionSelect = document.getElementById('section');
    const workCenterSelect = document.getElementById('workCenter');

    unitSelect.innerHTML = '<option value="">Select Unit</option>';
    sectionSelect.innerHTML = '<option value="">Select Section</option>';
    workCenterSelect.innerHTML = '<option value="">Select Work Center</option>';

    unitSelect.disabled = !division;
    sectionSelect.disabled = !unit;
    workCenterSelect.disabled = !section;

    if (division && unitData[division]) {
        unitData[division].forEach(unit => {
            unitSelect.innerHTML += `<option value="${unit}">${unit}</option>`;
        });
    }
}

function updateSections() {
    const unit = document.getElementById('unit').value;
    // Similar logic for sections and workcenters
}

function searchPerson() {
    const person = document.getElementById('responsiblePerson').value;
    alert('Searching for: ' + person);
}


function updateCurrentDateLabel() {
    const label = document.getElementById('currentDateLabel');
    if (!label) return;

    const now = new Date();
    // Format once and remove comma between date and time
    label.textContent = formatter.format(now).replace(',', '');
}

// Calendar functionality - Add before your existing script closes


function showPage(route) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active', 'fade-in');
    });

    // Show target page with animation
    const targetPage = document.getElementById(route);
    if (targetPage) {
        targetPage.classList.add('active', 'fade-in');

        // Initialize calendar if showing calendar page
        if (route === 'calendar') {
            setTimeout(initCalendar, 150);
        }
    }

    // Update active nav link (includes .btn now)
    document.querySelectorAll('nav a, .btn[data-route]').forEach(link => {
        link.classList.toggle('active', link.dataset.route === route);
    });

    // Update URL without reload
    window.history.pushState({ route }, '', `#${route}`);
}

// Navigation event listeners (works for both nav a and .btn)
document.querySelectorAll('nav a[data-route], .btn[data-route]').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const route = link.dataset.route;
        if (routes[route]) {
            showPage(route);
        }
    });
});

// Slider variables
let slideIndex = 0;
let slideTimer = null;


window.initSlider = function () {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');

    if (slides.length === 0) return;

    if (slideTimer) clearInterval(slideTimer);

    slideTimer = setInterval(window.showSlides, 3000);
};

// Auto Slide Logic
window.showSlides = function () {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');

    if (slides.length === 0) return;

    slides.forEach(slide => slide.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));

    slideIndex++;
    if (slideIndex > slides.length) slideIndex = 1;

    slides[slideIndex - 1].classList.add('active');
    if (dots.length > 0) dots[slideIndex - 1].classList.add('active');
};

// Manual Navigation (for onclick in HTML)
window.currentSlide = function (n) {
    if (slideTimer) clearInterval(slideTimer);

    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');

    if (slides.length === 0) return;

    slideIndex = n;
    if (slideIndex > slides.length) slideIndex = 1;
    if (slideIndex < 1) slideIndex = slides.length;

    slides.forEach(slide => slide.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));

    slides[slideIndex - 1].classList.add('active');
    if (dots.length > 0) dots[slideIndex - 1].classList.add('active');

    slideTimer = setInterval(window.showSlides, 3000);
};

// Mobile sidebar toggle
document.addEventListener('DOMContentLoaded', () => {
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const sidebar = document.querySelector('.sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    function toggleSidebar() {
        hamburgerBtn.classList.toggle('active');
        sidebar.classList.toggle('active');
        sidebarOverlay.classList.toggle('active');
        document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
    }

    if (hamburgerBtn) {
        hamburgerBtn.addEventListener('click', toggleSidebar);
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', toggleSidebar);
    }
});

function toggleGPSFields() {
    const isGPSPerformed = document.querySelector('input[value="gpsSearch"]').checked;
    const resultInputs = document.querySelectorAll('input[name="gpsResult"]');
    const container = document.getElementById('gpsResultContainer');

    resultInputs.forEach(input => {
        input.disabled = !isGPSPerformed;
    });

    // Visual feedback: dim the section when disabled
    container.style.opacity = isGPSPerformed ? "1" : "0.5";
}

function toggleInputs(checkboxId, containerId) {
    const checkbox = document.getElementById(checkboxId);
    const container = document.getElementById(containerId);
    // Find all input elements inside the container
    const inputs = container.querySelectorAll('input');

    if (checkbox.checked) {
        // Enable inputs and restore full opacity
        inputs.forEach(input => input.disabled = false);
        container.style.opacity = "1";
    } else {
        // Disable inputs and dim the section
        inputs.forEach(input => input.disabled = true);
        container.style.opacity = "0.5";
    }
}

function toggleDamageFields() {
    // Remote Wipe Logic
    const remoteWipeActive = document.querySelector('input[name="wipeGroup"][value="remoteWipe"]').checked;
    const wipeContainer = document.getElementById('wipeResults');
    const wipeRadios = wipeContainer.querySelectorAll('input[type="radio"]');

    wipeRadios.forEach(r => r.disabled = !remoteWipeActive);
    wipeContainer.style.opacity = remoteWipeActive ? "1" : "0.5";

    // Communication Line Logic
    const lineActive = document.querySelector('input[name="lineGroup"][value="closeLine"]').checked;
    const phoneContainer = document.getElementById('phoneInputContainer');
    const phoneInput = document.getElementById('telNumber');

    phoneInput.disabled = !lineActive;
    phoneContainer.style.opacity = lineActive ? "1" : "0.5";
}

function toggleSecondaryDamage() {
    const isPossible = document.getElementById('secondaryPossible').checked;
    const textbox = document.getElementById('secondaryTextbox');

    const isPossible1 = document.getElementById('secondaryPossible1').checked;
    const textbox1 = document.getElementById('secondaryTextbox1');

    if (isPossible) {
        textbox.disabled = false;
        textbox.style.opacity = "1";
    } else {
        textbox.disabled = true;
        textbox.style.opacity = "0.5";
        textbox.value = ""; // This clears the box and restores the placeholder
    }

    if (isPossible1) {
        textbox1.disabled = false;
        textbox1.style.opacity = "1";
    } else {
        textbox1.disabled = true;
        textbox1.style.opacity = "0.5";
        textbox1.value = ""; // This clears the box and restores the placeholder
    }
}

function toggleDescription() {
    const otherRadio = document.getElementById('typeOther');
    const descBox = document.getElementById('incidentDesc');

    if (otherRadio.checked) {
        descBox.disabled = false;
        descBox.style.opacity = "1";
    } else {
        descBox.disabled = true;
        descBox.style.opacity = "0.5";
        descBox.value = ""; // Optional: clears text if they switch back to a different radio
    }
}

function syncToggle(checkboxId, targetId) {
    const checkbox = document.getElementById(checkboxId);
    const target = document.getElementById(targetId);

    if (checkbox.checked) {
        target.disabled = false;
        target.style.opacity = "1";
    } else {
        target.disabled = true;
        target.style.opacity = "0.5";
        target.value = ""; // Clears the text when unchecked
    }
}

function syncToggle1(radioId, targetId) {
    const radio = document.getElementById(radioId);
    const target = document.getElementById(targetId);

    if (radio.checked) {
        target.disabled = false;
        target.style.opacity = "1";
        target.focus(); // Good UX: focus the box when enabled
    } else {
        target.disabled = true;
        target.style.opacity = "0.5";
        target.value = "";
    }
}

function togglePatchingOptions(enable) {
    const checkboxes = document.querySelectorAll('.patch-option');
    const otherText = document.getElementById('otherboxb');
    const otherCheckbox = document.getElementById('otherradiob');

    checkboxes.forEach(cb => {
        cb.disabled = !enable;
        // Optional: Uncheck them if "Not used" is selected
        if (!enable) cb.checked = false;
    });

    // Handle the text box logic
    if (!enable) {
        otherText.disabled = true;
        otherText.value = ''; // Clear text if disabled
    } else {
        // Only enable text box if 'Other' was already checked
        otherText.disabled = !otherCheckbox.checked;
    }
}

function showFormatA() {
    // Hide selection page
    document.getElementById('itIncidentSelection').style.display = 'none';

    // Show Form A content
    document.getElementById('formatAContent').style.display = 'block';

    // Initialize Form A - Set current date and user details
    initializeFormA();
}

// Add this new function
function initializeFormA() {
    // Set current date
    const today = new Date();
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const reportedDateElement = document.getElementById('reportedDate');
    if (reportedDateElement) {
        reportedDateElement.textContent = today.toLocaleDateString('en-US', options);
    }

    // Set current user (you can get this from your session or global variable)
    const currentUser = {
        name: 'Sarah Johnson',
        id: 'CHR00001',
        title: 'Engineer',
        phone: '+83456789021'
    };

    const currentUserNameElement = document.getElementById('currentUserName');
    const currentUserIdElement = document.getElementById('currentUserId');
    const currentUsertitleElement = document.getElementById('currenttitle');
    const currentUserphoneElement = document.getElementById('currentphone');

    if (currentUserNameElement) {
        currentUserNameElement.textContent = currentUser.name;
    }

    if (currentUserIdElement) {
        currentUserIdElement.textContent = currentUser.id;
    }
    if (currentUsertitleElement) {
        currentUsertitleElement.textContent = currentUser.title;
    }
    if (currentUserphoneElement) {
        currentUserphoneElement.textContent = currentUser.phone;
    }

    // Initialize section visibility
    const theftLossSection = document.getElementById('theftLossSection');
    const wrongDestSection = document.getElementById('wrongDestinationSection');

    if (theftLossSection) theftLossSection.style.display = 'none';
    if (wrongDestSection) wrongDestSection.style.display = 'none';


    toggleIncidentSections('theftLoss');
}

function showFormatB() {
    // Hide selection page
    const itSelection = document.getElementById('itIncidentSelection');
    if (itSelection) itSelection.style.display = 'none';

    // Get containers
    const helpdeskContainer = document.querySelector('.helpdesk-container');
    const formatAContent = document.getElementById('formatAContent');
    const formatBContent = document.getElementById('formatBContent');

    // Hide Form A
    if (formatAContent) {
        formatAContent.style.display = 'none';
    }

    // SHOW helpdesk-container (parent of Form B)
    if (helpdeskContainer) {
        helpdeskContainer.style.display = 'block';
        console.log('✅ Showing helpdesk-container');
    }

    // Show Form B
    if (formatBContent) {
        formatBContent.style.display = 'block';
        formatBContent.style.visibility = 'visible';
        console.log('✅ Showing formatBContent');
    }

    // Initialize Form B
    initializeFormB();
}


function initializeFormB() {
    // Set current date
    const today = new Date();
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const reportedDateElement = document.getElementById('reportedDateB');  // Use B suffix for Form B elements
    if (reportedDateElement) {
        reportedDateElement.textContent = today.toLocaleDateString('en-US', options);
    }

    // Set current user (same as Form A)
    const currentUser = {
        name: 'Sarah Johnson',
        id: 'CHR00001',
        title: 'Engineer',
        phone: '+83456789021'
    };

    const currentUserNameElement = document.getElementById('currentUserNameB');
    const currentUserIdElement = document.getElementById('currentUserIdB');
    const currentUsertitleElement = document.getElementById('currenttitleB');
    const currentUserphoneElement = document.getElementById('currentphoneB');

    if (currentUserNameElement) {
        currentUserNameElement.textContent = currentUser.name;
    }

    if (currentUserIdElement) {
        currentUserIdElement.textContent = currentUser.id;
    }
    if (currentUsertitleElement) {
        currentUsertitleElement.textContent = currentUser.title;
    }
    if (currentUserphoneElement) {
        currentUserphoneElement.textContent = currentUser.phone;
    }

    const publicWebsiteCheckbox = document.querySelector('input[name="incidentType"][value="publicWebsite"]');
    const virusInfectionCheckbox = document.querySelector('input[name="incidentType"][value="virusInfection"]');
    const otherCheckbox = document.querySelector('input[name="incidentType"][value="other"]');

    if (publicWebsiteCheckbox) {
        publicWebsiteCheckbox.addEventListener('change', handleIncidentTypeChange);
    }
    if (virusInfectionCheckbox) {
        virusInfectionCheckbox.addEventListener('change', handleIncidentTypeChange);
    }
    if (otherCheckbox) {
        otherCheckbox.addEventListener('change', handleIncidentTypeChange);
    }

    // Examples: Hide/show specific sections like publicWebsite/virus sections
    toggleSection7Content('none');
    toggleSection8Content('none');

    // Reset employee search and other form-specific init
    const detailsDiv = document.getElementById('employeeDetails');
    if (detailsDiv) detailsDiv.style.display = 'none';
}


function backToSelection() {
    document.getElementById('itIncidentSelection').style.display = 'block';
    document.getElementById('formatAContent').style.display = 'none';
    document.getElementById('formatBContent').style.display = 'none';
}

function populateFormForEdit(data) {
    // Close the report window
    if (window.reportWindow && !window.reportWindow.closed) {
        window.reportWindow.close();
    }

    // Show the form again
    document.getElementById('itIncidentSelection').style.display = 'none';
    document.getElementById('formatAContent').style.display = 'block';

    // Section 6: Restore checkbox states for Data Items
    const dataItemsCheckboxes = document.querySelectorAll('input[name="dataItems"]');
    dataItemsCheckboxes.forEach(cb => {
        cb.checked = data.dataItems && data.dataItems.includes(cb.value);
    });

    // Section 6: Restore numeric fields
    const numberInputs = document.querySelectorAll('#formatAContent input[type="number"]');
    if (numberInputs[0]) numberInputs[0].value = data.recordsCount || '';
    if (numberInputs[1]) numberInputs[1].value = data.customersInfo || '';
    if (numberInputs[2]) numberInputs[2].value = data.employeesInfo || '';
    if (numberInputs[3]) numberInputs[3].value = data.otherContacts || '';

    // Section 6: Restore textarea for information leaked
    const infoLeakedTextarea = document.querySelector('#formatAContent textarea[placeholder*="information at risk"]');
    if (infoLeakedTextarea) {
        infoLeakedTextarea.value = data.infoLeaked || '';
    }

    // Section 6: Restore secondary damage radio buttons
    const secondaryDamageRadios = document.querySelectorAll('input[name="secondaryDamage"]');
    secondaryDamageRadios.forEach(radio => {
        if (radio.value === data.secondaryDamage) {
            radio.checked = true;
        }
    });

    // Section 6: Restore secondary damage description
    const secondaryDamageDesc = document.querySelector('textarea[placeholder*="If possible, describe"]');
    if (secondaryDamageDesc) {
        secondaryDamageDesc.value = data.secondaryDamageDesc || '';
    }

    // Add more restoration logic for other sections as needed

    // Scroll to top
    window.scrollTo(0, 0);

    alert('Form loaded for editing. Make your changes and submit again.');
}
// Function to collect Form A data
function collectFormAData() {
    console.log('🔍 Starting Form A data collection...');

    const formatA = document.getElementById('formatAContent');
    if (!formatA) {
        console.error('❌ formatAContent not found');
        return {};
    }

    // ===== HELPER FUNCTIONS =====
    const getValue = (selector) => {
        const el = formatA.querySelector(selector);
        if (!el) return '';
        return el.value ? el.value.trim() : '';
    };

    const getText = (selector) => {
        const el = formatA.querySelector(selector);
        return el ? el.textContent.trim() : '';
    };

    const getRadio = (name) => {
        const el = formatA.querySelector(`input[name="${name}"]:checked`);
        return el ? el.value : '';
    };

    const getCheckboxes = (name) => {
        return Array.from(formatA.querySelectorAll(`input[name="${name}"]:checked`))
            .map(cb => cb.value);
    };

    const isChecked = (selector) => {
        const el = formatA.querySelector(selector);
        return el ? el.checked : false;
    };

    const getSectionByNumber = (sectionNum) => {
        const sections = formatA.querySelectorAll('.section-card');
        for (const section of sections) {
            const numSpan = section.querySelector('.section-num');
            if (numSpan && numSpan.textContent.trim() === sectionNum.toString()) {
                return section;
            }
        }
        return null;
    };

    const getTextareaBySection = (sectionNum) => {
        const section = getSectionByNumber(sectionNum);
        if (section) {
            const ta = section.querySelector('textarea');
            return ta ? ta.value.trim() : '';
        }
        return '';
    };

    const getDateTimeBySection = (sectionNum) => {
        const section = getSectionByNumber(sectionNum);
        if (section) {
            const input = section.querySelector('input[type="datetime-local"]');
            return input ? input.value : '';
        }
        return '';
    };

    // ===== COLLECT DATA ITEMS (Section 6) =====
    const dataItems = {
        name: false,
        birthDate: false,
        gender: false,
        address: false,
        phone: false,
        email: false,
        other: false
    };

    const dataItemCheckboxes = formatA.querySelectorAll('input[name="dataItems"]');
    dataItemCheckboxes.forEach(cb => {
        if (cb.checked) {
            const label = cb.parentElement?.textContent?.toLowerCase() || '';
            if (label.includes('name') && !label.includes('birth')) dataItems.name = true;
            else if (label.includes('birth')) dataItems.birthDate = true;
            else if (label.includes('gender')) dataItems.gender = true;
            else if (label.includes('address')) dataItems.address = true;
            else if (label.includes('phone')) dataItems.phone = true;
            else if (label.includes('email')) dataItems.email = true;
            else if (label.includes('other')) dataItems.other = true;
        }
    });

    // ===== COLLECT TIMELINE DATA (SECTION 9) =====
    console.log('📅 Collecting Section 9 timeline data...');
    const timeline = [];
    const timelineRows = formatA.querySelectorAll('#timelineRowsA tr');
    console.log(`  Found ${timelineRows.length} timeline rows`);

    timelineRows.forEach((row, index) => {
        const dateTimeInput = row.querySelector('input[type="datetime-local"]');
        const situationTextarea = row.querySelector('textarea');

        if (dateTimeInput && situationTextarea) {
            const dateTime = dateTimeInput.value.trim();
            const situation = situationTextarea.value.trim();

            console.log(`  Row ${index}: dateTime="${dateTime}", situation="${situation.substring(0, 30)}..."`);

            // Only add if at least one field has data
            if (dateTime || situation) {
                timeline.push({ dateTime, situation });
            }
        }
    });
    console.log(`✅ Collected ${timeline.length} timeline entries`);

    // ===== COLLECT ASSET IDs (from dynamic checkboxes) =====
    const assetIds = [];
    const assetCheckboxes = formatA.querySelectorAll('#dynamicAssetContainer input[type="checkbox"]:checked');
    assetCheckboxes.forEach(cb => {
        assetIds.push(cb.value);
    });

    // ===== SECTION 7: COMPREHENSIVE DATA COLLECTION =====
    console.log('🔐 Collecting Section 7 security measures data...');

    const managerPermission = getRadio('managerPermission');
    console.log('  Manager Permission:', managerPermission);

    const passwordTypes = getCheckboxes('passwordType');
    console.log('  Password Types:', passwordTypes);

    const passwordOther = getValue('#otherTextbox3');
    console.log('  Password Other:', passwordOther);

    const windowsEncryption = getRadio('windowsEncryption');
    console.log('  Windows Encryption:', windowsEncryption);

    const encryptionTools = getCheckboxes('encryptionTool');
    console.log('  Encryption Tools:', encryptionTools);

    const encryptionToolOther = getValue('#otherTextbox4');
    console.log('  Encryption Tool Other:', encryptionToolOther);

    const storageEncryption = getRadio('storageEncryption');
    console.log('  Storage Encryption:', storageEncryption);

    const lossPreventionStrap = getRadio('lossPreventionStrap');
    console.log('  Loss Prevention Strap:', lossPreventionStrap);

    // Get "Others" textarea from Section 7
    const section7 = getSectionByNumber(7);
    let securityMeasuresOther = '';
    let securityMeasuresWrongDest = '';

    if (section7) {
        const textareas = section7.querySelectorAll('textarea');
        if (getRadio('incidentType') === 'theftLoss') {
            // The LAST textarea in Section 7 (Theft/Loss) is "Others"
            if (textareas.length > 0) {
                securityMeasuresOther = textareas[textareas.length - 1].value.trim();
            }
        } else {
            // For Wrong Destination, it's the only textarea in Section 7
            if (textareas.length > 0) {
                securityMeasuresWrongDest = textareas[0].value.trim();
            }
        }
    }
    console.log('  Security Measures Other:', securityMeasuresOther);

    // ===== SECTION 8: COMPREHENSIVE DATA COLLECTION =====
    console.log('📋 Collecting Section 8 post-incident actions...');

    const searchedPlace = isChecked('input[name="searchActions"][value="searchedPlace"]');
    const gpsSearch = isChecked('input[value="gpsSearch"]');
    const gpsResult = getRadio('gpsResult');
    const notSubjectGPS = isChecked('input[value="notSubjectGPS"]');
    const reportedTransport = isChecked('input[name="searchActions"][value="reportedTransport"]');
    const reportedPolice = isChecked('input[name="searchActions"][value="reportedPolice"]');
    const disableIntranet = isChecked('input[value="disableIntranet"]');
    const disableIntranetNA = isChecked('input[name="intranetGroup"][value="notSubject"]');
    const remoteWipe = isChecked('input[name="wipeGroup"][value="remoteWipe"]');
    const remoteWipeResult = getRadio('remoteWipeResult');
    const remoteWipeNA = isChecked('input[name="wipeGroup"][value="notSubject"]');
    const closeLine = isChecked('input[name="lineGroup"][value="closeLine"]');
    const closeLineNA = isChecked('input[name="lineGroup"][value="notSubject"]');

    // Get all text and datetime values from Section 8
    const section8 = getSectionByNumber(8);
    let searchedPlaceDesc = '';
    let reportedTransportDateTime = '';
    let reportedTransportPlace = '';
    let reportedPoliceDateTime = '';
    let reportedPolicePlace = '';
    let phoneNumber = '';
    let otherActionsTheft = '';

    if (section8) {
        const textInputs = section8.querySelectorAll('input[type="text"]');
        if (textInputs.length >= 3) {
            searchedPlaceDesc = textInputs[0]?.value.trim() || '';
            reportedTransportPlace = textInputs[1]?.value.trim() || '';
            reportedPolicePlace = textInputs[2]?.value.trim() || '';
        }

        const datetimeInputs = section8.querySelectorAll('input[type="datetime-local"]');
        if (datetimeInputs.length >= 2) {
            reportedTransportDateTime = datetimeInputs[0]?.value || '';
            reportedPoliceDateTime = datetimeInputs[1]?.value || '';
        }

        const telInput = section8.querySelector('input[type="tel"]');
        phoneNumber = telInput?.value.trim() || '';

        const textareas = section8.querySelectorAll('textarea');
        if (textareas.length > 0) {
            otherActionsTheft = textareas[0].value.trim();
        }
    }

    console.log('  Searched Place:', searchedPlace);
    console.log('  Searched Place Desc:', searchedPlaceDesc);
    console.log('  GPS Search:', gpsSearch, 'Result:', gpsResult);
    console.log('  Reported Transport:', reportedTransport);
    console.log('  Reported Police:', reportedPolice);
    console.log('  Remote Wipe:', remoteWipe, 'Result:', remoteWipeResult);
    console.log('  Close Line:', closeLine, 'Phone:', phoneNumber);
    console.log('  Other Actions:', otherActionsTheft);

    // Wrong Destination specific fields
    const deleteRequest = getRadio('deleteRequest');
    const section8 = getSectionByNumber(8);
    let deleteRequestReason = '';
    let otherActionsWrongDest = '';
    
    if (section8 && getRadio('incidentType') === 'wrongDestination') {
        const textareas = section8.querySelectorAll('textarea');
        if (textareas.length >= 2) {
            deleteRequestReason = textareas[0].value.trim();
            otherActionsWrongDest = textareas[1].value.trim();
        }
    }

    // ===== BUILD FORM DATA OBJECT =====
    const data = {
        // Header Information
        reportedDate: getText('#reportedDate') || new Date().toISOString().split('T')[0],
        csirtName: 'Marumoto Shuichiro',
        csirtJobTitle: 'Director',
        csirtDivision: 'CO',

        // Reporter Information
        reporterName: getText('#currentUserName') || 'N/A',
        reporterJobTitle: getText('#currenttitle') || 'N/A',
        reporterPhone: getText('#currentphone') || 'N/A',
        companyName: getText('#empComp') || 'TTDI',

        // Person Involved
        personInvolvedName: getText('#empName') || 'N/A',
        personInvolvedJobTitle: getText('#empJobTitle') || 'N/A',
        personInvolvedDept: getText('#empDept') || 'N/A',
        personInvolvedDivision: getText('#empDiv') || 'N/A',

        jobCategory: getRadio('jobCategory'),
        outsourcee: getValue('input[name="outsourcee"]'),

        // Incident Type
        incidentType: getRadio('incidentType'),

        // Theft/Loss items
        theftItems: [...getCheckboxes('theftItem').filter(v => v !== 'Other'), ...assetIds],
        theftItemOther: getValue('#otherTextbox1'),

        // Wrong Destination methods
        wrongDestMethods: getCheckboxes('wrongDestMethod').filter(v => v !== 'Other'),
        wrongDestMethodOther: getValue('#otherTextbox'),

        // Sections 1-6
        reportStatus: getRadio('reportStatus') || 'First',
        incidentDateTime: getDateTimeBySection(2),
        discoveredDateTime: getDateTimeBySection(3),
        whatMadeNotice: getTextareaBySection(5),
        incidentOverview: (() => {
            const section5 = getSectionByNumber(5);
            if (section5) {
                const textareas = section5.querySelectorAll('textarea');
                return textareas[0] ? textareas[0].value.trim() : '';
            }
            return '';
        })(),
        locationOccurred: (() => {
            const section4 = getSectionByNumber(4);
            if (section4) {
                const inputs = section4.querySelectorAll('input[type="text"]');
                return inputs[0] ? inputs[0].value.trim() : '';
            }
            return '';
        })(),
        alcoholIntake: getRadio('alcoholIntake'),
        infoLeaked: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const textareas = section6.querySelectorAll('textarea');
                return textareas[0] ? textareas[0].value.trim() : '';
            }
            return '';
        })(),
        dataItems: dataItems,
        recordsCount: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const numInputs = section6.querySelectorAll('input[type="number"]');
                return numInputs[0] ? numInputs[0].value : '0';
            }
            return '0';
        })(),
        customersInfo: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const numInputs = section6.querySelectorAll('input[type="number"]');
                return numInputs[1] ? numInputs[1].value : '0';
            }
            return '0';
        })(),
        employeesInfo: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const numInputs = section6.querySelectorAll('input[type="number"]');
                return numInputs[2] ? numInputs[2].value : '0';
            }
            return '0';
        })(),
        otherContacts: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const numInputs = section6.querySelectorAll('input[type="number"]');
                return numInputs[3] ? numInputs[3].value : '0';
            }
            return '0';
        })(),
        secondaryDamage: getRadio('secondaryDamage'),
        secondaryDamageDesc: getValue('#secondaryTextbox'),

        // ===== SECTION 7: ALL DATA =====
        managerPermission: managerPermission,
        passwordTypes: passwordTypes,
        passwordOther: passwordOther,
        windowsEncryption: windowsEncryption,
        encryptionTools: encryptionTools,
        encryptionToolOther: encryptionToolOther,
        storageEncryption: storageEncryption,
        lossPreventionStrap: lossPreventionStrap,
        securityMeasuresOther: securityMeasuresOther,
        securityMeasuresWrongDest: securityMeasuresWrongDest,

        // ===== SECTION 8: ALL DATA =====
        searchedPlace: searchedPlace,
        searchedPlaceDesc: searchedPlaceDesc,
        gpsSearch: gpsSearch,
        gpsResult: gpsResult,
        notSubjectGPS: notSubjectGPS,
        reportedTransport: reportedTransport,
        reportedTransportDateTime: reportedTransportDateTime,
        reportedTransportPlace: reportedTransportPlace,
        reportedPolice: reportedPolice,
        reportedPoliceDateTime: reportedPoliceDateTime,
        reportedPolicePlace: reportedPolicePlace,
        disableIntranet: disableIntranet,
        disableIntranetNA: disableIntranetNA,
        remoteWipe: remoteWipe,
        remoteWipeResult: remoteWipeResult,
        remoteWipeNA: remoteWipeNA,
        closeLine: closeLine,
        phoneNumber: phoneNumber,
        closeLineNA: closeLineNA,
        otherActionsTheft: otherActionsTheft,
        deleteRequest: deleteRequest,
        deleteRequestReason: deleteRequestReason,
        otherActionsWrongDest: otherActionsWrongDest,

        // ===== SECTION 9: TIMELINE =====
        timeline: timeline,

        // Sections 10-12
        assumedCauses: getTextareaBySection(10),
        preventiveMeasures: getTextareaBySection(11),
        responsiblePerson: (() => {
            const section11 = getSectionByNumber(11);
            if (section11) {
                const textInputs = section11.querySelectorAll('input[type="text"]');
                return textInputs[0] ? textInputs[0].value.trim() : '';
            }
            return '';
        })(),
        completionDate: (() => {
            const section11 = getSectionByNumber(11);
            if (section11) {
                const dateInputs = section11.querySelectorAll('input[type="date"]');
                return dateInputs[0] ? dateInputs[0].value : '';
            }
            return '';
        })(),
        remarks: getTextareaBySection(12)
    };

    console.log('');
    console.log('='.repeat(60));
    console.log('📊 FORM A DATA COLLECTION SUMMARY:');
    console.log('='.repeat(60));
    console.log('Section 7 - Password Types:', data.passwordTypes.length);
    console.log('Section 7 - Encryption Tools:', data.encryptionTools.length);
    console.log('Section 7 - Security Other:', data.securityMeasuresOther ? 'YES' : 'NO');
    console.log('Section 8 - Other Actions:', data.otherActionsTheft ? 'YES' : 'NO');
    console.log('Section 9 - Timeline Entries:', data.timeline.length);
    console.log('='.repeat(60));

    return data;
}





function getTimelineDataB() {
    const timeline = [];
    const rows = document.querySelectorAll('#timelineRowsB tr');
    rows.forEach(row => {
        const dateTime = row.querySelector('input[type="datetime-local"]')?.value || '';
        const situation = row.querySelector('textarea')?.value || '';
        if (dateTime || situation) {
            timeline.push({ dateTime, situation });
        }
    });
    return timeline;
}

// Helper function to get selected checkbox values
function getSelectedCheckboxValues(selector) {
    const checkboxes = document.querySelectorAll(selector);
    const values = [];
    checkboxes.forEach(cb => {
        if (cb.value !== 'Other') {
            values.push(cb.value);
        }
    });
    return values;
}

// Helper function to get selected checkbox text labels
function getSelectedCheckboxText(selector) {
    const checkboxes = document.querySelectorAll(selector);
    const values = [];
    checkboxes.forEach(cb => {
        const label = cb.parentElement.textContent.trim();
        if (label) values.push(label);
    });
    return values;
}

// Helper function to get timeline data
function getTimelineDataA() {
    const timeline = [];
    const rows = document.querySelectorAll('#timelineRowsA tr');
    rows.forEach(row => {
        const dateTime = row.querySelector('input[type="datetime-local"]')?.value;
        const situation = row.querySelector('textarea')?.value;
        if (dateTime && situation) {
            timeline.push({ dateTime, situation });
        }
    });
    return timeline;
}

// Helper functions
function getDeviceType() {
    const types = [];
    document.querySelectorAll('input[name="deviceType"]:checked').forEach(el => {
        types.push(el.value);
    });
    return types;
}

function getDeviceDetails() {
    return {
        pcTablet: document.querySelector('input[name="pcTabletCount"]')?.value || '',
        smartphone: document.querySelector('input[name="smartphoneCount"]')?.value || '',
        usbMemory: document.querySelector('input[name="usbCount"]')?.value || '',
        other: document.querySelector('input[name="otherDeviceType"]')?.value || ''
    };
}

function getInformationSecurity() {
    return {
        passwordSet: document.querySelector('input[name="passwordSet"]:checked')?.value || '',
        passwordStrength: document.querySelector('input[name="passwordStrength"]:checked')?.value || '',
        encryption: document.querySelector('input[name="encryption"]:checked')?.value || '',
        biometrics: document.querySelector('input[name="biometrics"]:checked')?.value || ''
    };
}

function getCheckedValues(selector) {
    const values = [];
    document.querySelectorAll(selector + ':checked').forEach(el => {
        values.push(el.nextSibling?.textContent || el.value);
    });
    return values;
}

function getSearchActions() {
    return {
        searchedPlace: document.querySelector('input[name="searchActions"][value="searchedPlace"]')?.checked || false,
        gpsSearch: document.querySelector('input[name="searchActions"][value="gpsSearch"]')?.checked || false,
        gpsResult: document.querySelector('input[name="gpsResult"]:checked')?.value || '',
        reportedTransport: document.querySelector('input[name="searchActions"][value="reportedTransport"]')?.checked || false,
        reportedPolice: document.querySelector('input[name="searchActions"][value="reportedPolice"]')?.checked || false
    };
}

function getDamageMinimization() {
    return {
        disableIntranet: document.querySelector('input[name="damageMinimization"][value="disableIntranet"]')?.checked || false,
        remoteWipe: document.querySelector('input[name="damageMinimization"][value="remoteWipe"]')?.checked || false,
        remoteWipeResult: document.querySelector('input[name="remoteWipeResult"]:checked')?.value || '',
        closeLine: document.querySelector('input[name="damageMinimization"][value="closeLine"]')?.checked || false,
        phoneNumber: document.querySelector('input[type="tel"][placeholder="Enter phone number"]')?.value || ''
    };
}

function getTimelineDataA() {
    const timeline = [];
    document.querySelectorAll('#timelineRowsA tr').forEach(row => {
        const dateTime = row.querySelector('input[type="datetime-local"]')?.value || '';
        const situation = row.querySelector('textarea')?.value || '';
        if (dateTime || situation) {
            timeline.push({ dateTime, situation });
        }
    });
    return timeline;
}

async function saveItIncident(formType, data) {
    console.log('💾 saveItIncident called');
    console.log('   Form Type:', formType);
    console.log('   Data fields:', Object.keys(data).length);

    try {
        const result = await fetchAPI('/it-incidents', {
            method: 'POST',
            body: JSON.stringify({
                formtype: formType,    // ✅ No underscore
                formdata: data         // ✅ No underscore
            })
        });

        console.log('   Backend response:', result);

        if (!result.success) {
            throw new Error(result.error || 'Failed to save incident');
        }

        console.log('✅ Incident saved successfully:', result.incidentid);
        return result.incidentid;  // Returns "ITA-2026-001" or "ITB-2026-001"

    } catch (err) {
        console.error('❌ Error in saveItIncident:', err);
        throw err;
    }
}



let currentFormDataA = null;
async function generateFormAReport() {
    console.log('🚀 Starting Form A Report Generation...');

    // Collect form data
    const data = collectFormAData();
    currentFormDataA = data;

    // Validate required fields
    if (!data.reporterName || data.reporterName === 'N/A') {
        alert('⚠️ Reporter name is missing. Please check the form.');
        console.error('Missing reporter name');
        return;
    }

    if (!data.incidentType) {
        alert('⚠️ Please select an incident type (Theft/Loss or Wrong Destination)');
        return;
    }

    if (!data.incidentDateTime) {
        alert('⚠️ Please enter the incident date and time');
        return;
    }

    // Save to database
    let incidentId;
    try {
        console.log('💾 Saving to database...');
        incidentId = await saveItIncident('A', data);
        data.incidentId = incidentId;
        console.log('✅ Saved successfully with ID:', incidentId);
    } catch (err) {
        console.error('❌ Save failed:', err);
        alert('Failed to save IT incident: ' + err.message);
        return;
    }

    // Generate report HTML (your existing code continues here...)
    const reportHTMLA = `
        <!DOCTYPE html>
            <html>
            <head>
                <title>Information Security Incident Report - Form A</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; font-size: 12px; }
                    .report-container { max-width: 1200px; margin: 0 auto; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    table, th, td { border: 1px solid #000; }
                    th, td { padding: 8px; text-align: left; vertical-align: top; }
                    th { background: #f0f0f0; font-weight: 600; width: 40%; }
                    .header-section { background: #1d4ed8; color: white; padding: 15px; margin-bottom: 20px; }
                    .section-title { background: #e8f4f8; font-weight: bold; padding: 10px; margin-top: 15px; }
                    .review-btn { 
                        background: #3b82f6; 
                        color: white; 
                        padding: 12px 30px; 
                        border: none; 
                        border-radius: 5px; 
                        cursor: pointer; 
                        font-size: 14px;
                        margin: 20px 0;
                    }
                    .review-btn:hover { background: #2563eb; }
                    .editable { background: #fffbeb; }
                    textarea { width: 100%; min-height: 60px; padding: 5px; }
                    input[type="text"], input[type="date"], input[type="datetime-local"] { 
                        width: 30%; padding: 5px; 
                    }
                    
                    input[type="checkbox"]:disabled {
                        opacity: 0.8;
                        cursor: default;
                    }
                </style>
            </head>
            <body>
                <div class="report-container">
                    <div class="header-section">
                        <h2>Information Security Incident Report (Format A)</h2>
                        <p>Use this format when "Theft/loss Information Devices/Medium," or "Sending Emails, etc. to wrong destination" occur.</p>
                    </div>

                <!-- Top Section -->
                <table>
                    <tr>
                        <th>Reported on:</th>
                        <td id="edit-reportedDate">${data.reportedDate || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>To:</th>
                        <td>Manager of Cyber Security Center of Corporate Technology Planning Div.<br>
                        (email address: HDQ-CSEC-head@ml.toshiba.co.jp)</td>
                    </tr>
                    <tr>
                        <th>Scope of disclosure:</th>
                        <td>Cyber Security Center of Corporate Technology Planning Div., Legal Affairs Div., reporting division/department, and those permitted by the managers thereof</td>
                    </tr>
                </table>

                <!-- CSIRT Leader Section -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">CSIRT Leader of Toshiba or Key group company (Division in Charge)</th>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td>${data.csirtName || 'Marumoto Shuichiro'}</td>
                    </tr>
                    <tr>
                        <th>Designation and Division</th>
                        <td>${data.csirtJobTitle || 'Director'}, ${data.csirtDivision || 'CO'}</td>
                    </tr>
                </table>

                <!-- Department Information -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">Case Details</th>
                    </tr>
                    <tr>
                        <th>Company name & department</th>
                        <td id="edit-company">${data.companyName || 'N/A'}, ${data.personInvolvedDept || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>Name, job title and phone of person making report</th>
                        <td id="edit-reporter">${data.reporterName || 'N/A'}, ${data.reporterJobTitle || 'N/A'} (Phone: ${data.reporterPhone || 'N/A'})</td>
                    </tr>
                    <tr>
                        <th>Job category, job title and name of the person involved in incident</th>
                        <td id="edit-personInvolved">
                            Name & Job Title: ${data.personInvolvedName || 'N/A'}, ${data.personInvolvedJobTitle || 'N/A'}<br>
                            Job category: ${data.personInvolvedDivision || 'N/A'}<br>
                            ${data.jobCategory ? `Category: ${data.jobCategory}<br>` : ''}
                            ${data.outsourcee ? `Outsourcee: ${data.outsourcee}<br>` : ''}
                        </td>
                    </tr>
                </table>

                <!-- Incident Type -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">Incident Type and Device Involved</th>
                    </tr>
                    ${data.incidentType === 'theftLoss' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Theft/loss
                        </th>
                        <td>${(data.theftItems && data.theftItems.length > 0) ? data.theftItems.join(', ') : 'N/A'}
                            ${data.theftItemOther ? `<br>Other: ${data.theftItemOther}` : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'wrongDestination' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Sending to wrong destination (to a person outside Toshiba Group)
                        </th>
                        <td>${(data.wrongDestMethods && data.wrongDestMethods.length > 0) ? data.wrongDestMethods.join(', ') : 'N/A'}
                            ${data.wrongDestMethodOther ? `<br>Other: ${data.wrongDestMethodOther}` : ''}
                        </td>
                    </tr>
                    ` : ''}
                </table>

                <!-- Main Content Sections 1-12 -->
                <table>
                    <tr>
                        <th>1. Report status</th>
                        <td class="editable" id="edit-reportStatus">${data.reportStatus || 'First'}</td>
                    </tr>
                    <tr>
                        <th>2. Date and time of incident</th>
                        <td id="edit-incidentDateTime">${data.incidentDateTime || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>3. Date and time of incident discovered</th>
                        <td id="edit-discoveredDateTime">${data.discoveredDateTime || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>4. What made you notice incident</th>
                        <td id="edit-whatMadeNotice"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.whatMadeNotice || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>5. Incident overview<br><small>* General overview of incident, including causes</small></th>
                        <td id="edit-incidentOverview">
                            <textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.incidentOverview || ''}</textarea>
                            ${data.incidentType === 'theftLoss' ? `
                            <br><small>＜Fill in the following section if the incident is Theft/loss＞</small><br>
                            Location of theft/loss: <input type="text" class="editable" value="${data.locationOccurred || ''}" style="width: 40%;"><br>
                            Alcohol intake: 
                            <label><input type="radio" class="editable" name="alcoholIntake" value="yes" ${data.alcoholIntake === 'yes' ? 'checked' : ''}> Yes</label>
                            <label><input type="radio" class="editable" name="alcoholIntake" value="no" ${data.alcoholIntake === 'no' ? 'checked' : ''}> No</label>
                            ` : ''}
                        </td>
                    </tr>
                    <tr>
                        <th>6. Information that was, or can possibly be, leaked<br><small>* If a loss includes customers' information, write their company names.</small></th>
                        <td id="edit-infoLeaked">
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.infoLeaked || ''}</textarea><br><br>
                            <small>＜Fill in the following section if the incident includes loss of personal information＞</small><br>
                            <strong>Data items:</strong>
                            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-top: 8px;">
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.name ? 'checked' : ''}> Name</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.birthDate ? 'checked' : ''}> Birth date</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.gender ? 'checked' : ''}> Gender</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.address ? 'checked' : ''}> Address</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.phone ? 'checked' : ''}> Phone number</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.email ? 'checked' : ''}> Email address</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.other ? 'checked' : ''}> Other</label>
                            </div><br>
                            <strong>Records on:</strong> <input type="number" class="editable" disabled value="${data.recordsCount || '0'}" style="width: 100px;"> people<br>
                            <strong>(Breakdown:</strong><br>
                            &nbsp;&nbsp;Customers' info: <input type="number" class="editable" disabled value="${data.customersInfo || '0'}" style="width: 100px;"> people<br>
                            &nbsp;&nbsp;Employees' info: <input type="number" class="editable" disabled value="${data.employeesInfo || '0'}" style="width: 100px;"> people<br>
                            &nbsp;&nbsp;Other contacts: <input type="number" class="editable" disabled value="${data.otherContacts || '0'}" style="width: 100px;"> people<strong>)</strong><br><br>
                            <strong>Secondary damage in event of misuse:</strong><br>
                            <label><input type="radio" class="editable" disabled name="secondaryDamage" value="possible" ${data.secondaryDamage === 'possible' ? 'checked' : ''}> Possible</label>
                            <label><input type="radio" class="editable" disabled name="secondaryDamage" value="none" ${data.secondaryDamage === 'none' ? 'checked' : ''}> None</label><br>
                            <strong>Description:</strong><br>
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 60px;">${data.secondaryDamageDesc || ''}</textarea>
                        </td>
                    </tr>
                </table>

                <!-- Section 7: Information Security Measures (if Theft/Loss) -->
                ${data.incidentType === 'theftLoss' ? `
                <table>
                    <tr>
                        <th colspan="2" class="section-title">7. Information security measures that were taken</th>
                    </tr>
                    <tr>
                        <th>Permission from manager to take out a device</th>
                        <td id="edit-managerPermission">
                            <label><input class="editable" type="radio" name="managerPermission" value="obtained" ${data.managerPermission === 'obtained' ? 'checked' : ''}> Obtained permission (incl. blanket permission covering predefined period)</label><br>
                            <label><input class="editable" type="radio" name="managerPermission" value="notObtained" ${data.managerPermission === 'notObtained' ? 'checked' : ''}> Not obtained permission</label>
                        </td>
                    </tr>
                    <tr>
                        <th>Password (incl. fingerprint authentication)</th>
                        <td id="edit-password">
                            ${(data.passwordTypes || []).map(type => {
        const labels = {
            'bootTime': 'At boot time',
            'osStartup': 'On OS startup',
            'unlockScreen': 'When unlocking screen',
            'sleepMode': 'When exiting Sleep mode',
            'notSubject': 'Not subject to this requirement'
        };
        return `<label><input class="editable" type="checkbox" value="${type}" checked> ${labels[type] || type}</label><br>`;
    }).join('')}
                            ${data.passwordOther ? `<label><input class="editable" type="checkbox" checked> Other: <input class="editable" type="text" value="${data.passwordOther}"></label>` : ''}
                        </td>
                    </tr>
                    <tr>
                        <th>Encryption</th>
                        <td id="edit-encryption">
                            <strong>&lt;For Windows PCs and storage media.&gt;</strong><br>
                            Windows PC: 
                            <label><input class="editable" type="radio" name="windowsEncryption" value="encrypted" ${data.windowsEncryption === 'encrypted' ? 'checked' : ''}> Encrypted</label><br>
                            (Encryption tool: 
                            ${(data.encryptionTools || []).map(tool => `<label><input class="editable" type="checkbox" checked> ${tool}</label>`).join(' ')}
                            ${data.encryptionToolOther ? `<label>Other: <input class="editable" type="text" value="${data.encryptionToolOther}"></label>` : ''}
                            )<br>
                            <label><input class="editable" type="radio" name="windowsEncryption" value="notEncrypted" ${data.windowsEncryption === 'notEncrypted' ? 'checked' : ''}> Not encrypted</label><br>
                            Storage medium: 
                            <label><input class="editable" type="radio" name="storageEncryption" value="allEncrypted" ${data.storageEncryption === 'allEncrypted' ? 'checked' : ''}> All company information has been encrypted</label><br>
                            <label><input class="editable" type="radio" name="storageEncryption" value="unencrypted" ${data.storageEncryption === 'unencrypted' ? 'checked' : ''}> There is unencrypted company information</label>
                        </td>
                    </tr>
                    <tr>
                        <th>Loss prevention measures</th><br><small>* Describe practice(s) that were taken for prevention of loss.</small></th>
                           
                        <td id="edit-lossPrevention">
                            <strong>&lt;Required for cell phones and smartphones&gt;</strong><br>
                            <label><input class="editable" type="radio" name="lossPreventionStrap" value="noStrap" ${data.lossPreventionStrap === 'noStrap' ? 'checked' : ''}> Device did not have strap</label><br>
                            <label><input class="editable" type="radio" name="lossPreventionStrap" value="strapNotUsed" ${data.lossPreventionStrap === 'strapNotUsed' ? 'checked' : ''}> Device had strap, but person concerned neglected to clip it to clothes or bag</label><br>
                            <label><input class="editable" type="radio" name="lossPreventionStrap" value="strapUsed" ${data.lossPreventionStrap === 'strapUsed' ? 'checked' : ''}> Device had strap, and person concerned had it clipped to clothes or bag</label>
                        </td>
                    </tr>
                    <tr>
                            <th>Local wipe</th>
                            <td colspan="2" id="edit-localWipe">
                                <strong>&lt;For iOS and Android devices&gt;</strong><br>
                                ☑ Registered 
                            </td>
                        </tr>
                        <tr>
                            <th>MDM registration</th>
                            <td colspan="2" id="edit-mdm">
                                <strong>&lt;For iOS and Android devices&gt;</strong><br>
                                ☑ Registered 
                            </td>
                        </tr>
                    <tr>
                        <th>Others</th><br><small>*Fill in the blank if there are other measures taken rather than the above.</small></th>
                        <td id="edit-securityOther"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.securityMeasuresOther || ''}</textarea></td>
                    </tr>
                </table>

                <!-- Section 8: Post-incident responses -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">8. Post-incident responses<br><small>* Actions taken to minimize potential damage</small></th>
                    </tr>
                    <tr>
                        <th>Searching & reporting</th>
                        <td id="edit-searchActions">
                            <label><input class="editable" type="checkbox" ${data.searchedPlace ? 'checked' : ''}> Searched likely place 
                            (<input class="editable" type="text" value="${data.searchedPlaceDesc || ''}" style="width: 200px;">)</label><br>
                            
                            <label><input class="editable" type="checkbox" ${data.gpsSearch ? 'checked' : ''}> Performed GPS search</label>
                            (Result: 
                            <label><input class="editable" type="radio" name="gpsResult" value="succeeded" ${data.gpsResult === 'succeeded' ? 'checked' : ''}> Succeeded</label>
                            <label><input class="editable" type="radio" name="gpsResult" value="failed" ${data.gpsResult === 'failed' ? 'checked' : ''}> Failed</label>)<br>
                            <label><input class="editable" type="checkbox" ${data.notSubjectGPS ? 'checked' : ''}> Not subject to GPS search</label><br>
                            
                            <label><input class="editable" type="checkbox" ${data.reportedTransport ? 'checked' : ''}> Reported loss to transport</label>
                            (Date and time: <input class="editable" type="datetime-local" value="${data.reportedTransportDateTime || ''}" style="width: 200px;">, 
                            Reported place: <input class="editable" type="text" value="${data.reportedTransportPlace || ''}" style="width: 200px;">)<br>
                            
                            <label><input class="editable" type="checkbox" ${data.reportedPolice ? 'checked' : ''}> Reported loss to the police</label>
                            (Date and time: <input class="editable" type="datetime-local" value="${data.reportedPoliceDateTime || ''}" style="width: 200px;">, 
                            Reported place: <input class="editable" type="text" value="${data.reportedPolicePlace || ''}" style="width: 200px;">)
                        </td>
                    </tr>
                    <tr>
                        <th>Measures taken to minimize damage</th>
                        <td id="edit-damageMinimization">
                            <label><input class="editable" type="checkbox" ${data.disableIntranet ? 'checked' : ''}> Requested overseeing department to disable lost device to connect to Intranet (e.g., certificate revocation)</label>
                            <label><input class="editable" type="checkbox" ${data.disableIntranetNA ? 'checked' : ''}> Not subject to this requirement</label><br>
                            
                            <label><input class="editable" type="checkbox" ${data.remoteWipe ? 'checked' : ''}> Requested overseeing department to execute remote wipe</label>
                            (Result: 
                            <label><input class="editable" type="radio" name="remoteWipeResult" value="succeeded" ${data.remoteWipeResult === 'succeeded' ? 'checked' : ''}> Succeeded</label>
                            <label><input class="editable" type="radio" name="remoteWipeResult" value="waiting" ${data.remoteWipeResult === 'waiting' ? 'checked' : ''}> Yet to succeed</label>
                            <label><input class="editable" type="radio" name="remoteWipeResult" value="failed" ${data.remoteWipeResult === 'failed' ? 'checked' : ''}> Failed</label>)
                            <label><input class="editable" type="checkbox" ${data.remoteWipeNA ? 'checked' : ''}> Not subject to this requirement</label><br>
                            
                            <label><input class="editable" type="checkbox" ${data.closeLine ? 'checked' : ''}> Requested carrier to close communication line</label>
                            (Telephone number: <input class="editable" type="tel" value="${data.phoneNumber || ''}" style="width: 150px;">)
                            <label><input class="editable" type="checkbox" ${data.closeLineNA ? 'checked' : ''}> Not subject to this requirement</label>
                        </td>
                    </tr>
                    <tr>
                        <th>Others</th>
                        <td id="edit-postIncidentOther"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.otherActionsTheft || ''}</textarea></td>
                    </tr>
                </table>
                ` : ''}

                <!-- Section 7 & 8: For Wrong Destination -->
                ${data.incidentType === 'wrongDestination' ? `
                <table>
                    <tr>
                        <th colspan="2" class="section-title">7. Information security measures that were taken</th>
                    </tr>
                    <tr>
                        <th></th>
                        <td id="edit-wrongDestSecurity"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.securityMeasuresWrongDest || ''}</textarea></td>
                    </tr>
                </table>
                <table>
                    <tr>
                        <th colspan="2" class="section-title">8. Post-incident responses<br><small>* Actions taken to minimize potential damage</small></th>
                    </tr>
                    <tr>
                        <th>Request a recipient to delete the wrongly sent email</th>
                        <td id="edit-deleteRequest">
                            <label><input class="editable" type="radio" name="deleteRequest" value="requested" ${data.deleteRequest === 'requested' ? 'checked' : ''}> Requested</label>
                            <label><input class="editable" type="radio" name="deleteRequest" value="notRequested" ${data.deleteRequest === 'notRequested' ? 'checked' : ''}> Not requested</label><br>
                            Reason: <textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.deleteRequestReason || ''}</textarea>
                        </td>
                    </tr>
                    <tr>
                        <th>Others</th>
                        <td id="edit-wrongDestOther"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.otherActionsWrongDest || ''}</textarea></td>
                    </tr>
                </table>
                ` : ''}

                <!-- Section 9: Timeline -->
                <table id="timeline-table">
                    <tr>
                        <th colspan="2" class="section-title">9. Timeline<br><small>* Describe chronologically: Initial response, Stopgap measure, Instructions given by CSIRT Leader</small></th>
                    </tr>
                    <tr>
                        <th style="width: 30%;">Date/time</th>
                        <th>Situation, response, etc.</th>
                    </tr>
                    ${(data.timeline && data.timeline.length > 0) ? data.timeline.map(item => `
                    <tr class="timeline-row">
                        <td><input class="editable" type="datetime-local" value="${item.dateTime || ''}" style="width: 100%; box-sizing: border-box;" /></td>
                        <td><textarea class="editable" style="width: 100%; box-sizing: border-box;">${item.situation || ''}</textarea></td>
                    </tr>
                    `).join('') : '<tr class="timeline-row"><td colspan="2">No timeline entries</td></tr>'}
                </table>
                <div id="report-actions" style="display: none; margin-bottom: 12px;">
                    <button class="action-btn btn-level" onclick="addTimelineRow()">
                        ➕ Add Timeline
                    </button>
                </div>

                <!-- Sections 10-12 -->
                <table>
                    <tr>
                        <th>10. Assumed causes<br><small>* Provide root causes. For example, if person concerned neglected to follow rules, describe why he/she did.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                        <td id="edit-assumedCauses"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.assumedCauses || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>11. Preventive measures<br><small>* Describe specifically. Attach evidence records, if any, such as a notice of issue and documents provided.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                        <td id="edit-preventiveMeasures">
                            <textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.preventiveMeasures || ''}</textarea><br>
                            Name and job title of person responsible for implementation: <input type="text" id="input-responsiblePerson" class="editable" value="${data.responsiblePerson || 'Kaza Saritha, Head of IT Department'}" style="width: 50%;"><br>
                            Date of scheduled completion: <input type="date" id="input-completionDate" class="editable" value="${data.completionDate || ''}" style="width: 25%;">
                        </td>
                    </tr>
                    <tr>
                        <th>12. Remarks</th>
                        <td id="edit-remarks"><textarea class="editable" style="width: 100%; box-sizing: border-box;">${data.remarks || ''}</textarea></td>
                    </tr>
                </table>

                <div style="margin-top: 20px;">
                    <p style="font-size: 11px;"><strong>*1 Local wipe:</strong> A function to delete data of devices when failed a specified number of login attempts for unlocking the entry of a password.</p>
                    <p style="font-size: 11px;"><strong>*2 Mobile Device Management Tool:</strong> A tool for the centralized registration and administration of mobile devices such as tablets and smartphones, including their information and configuration settings</p>
                </div>

                <!-- Review/Edit Button -->
                <div style="text-align: center; margin: 30px 0;">
                    <button class="review-btn" id="editBtn" onclick="enableEditing()">Review & Edit Report</button>
                    <button class="review-btn" style="background: #10b981; display: none;" id="saveBtn" onclick="saveChanges()">💾 Save Changes</button>
                    <button class="review-btn" onclick="window.print()">Print Report</button>                   
                </div>
            </div>

            <script>
                const INCIDENT_ID = '${incidentId}' || 'UNKNOWN';
                const INCIDENT_TYPE = '${data.incidentType}';
                const API_BASE = 'http://localhost:5000';

                function enableEditing() {
                    const editables = document.querySelectorAll('.editable');
                    editables.forEach(el => {
                        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
                            el.disabled = false;
                            el.readOnly = false;
                        } else {
                            el.contentEditable = true;
                        }
                        el.style.border = '2px solid #3b82f6';
                        el.style.background = '#ffffff';
                    });
                    document.getElementById('editBtn').style.display = 'none';
                    document.getElementById('saveBtn').style.display = 'inline-block';
                    document.getElementById('report-actions').style.display = 'block';
                    alert('✏️ Editing enabled! Click inside highlighted fields to modify.');
                }
                function addTimelineRow() {
 
                        const table = document.getElementById('timeline-table');
                        const rows = table.querySelectorAll('.timeline-row');
                        if (rows.length === 1) {
                            const firstCell = rows[0].cells[0];
                            if (firstCell && firstCell.colSpan === 2 && firstCell.textContent.includes('No timeline entries')) {
                                rows[0].remove();
                            }
                        }
                       
                        const newRow = table.insertRow(-1); // Insert at the end
                        newRow.className = 'timeline-row';
                       
                        // Create date/time cell
                        const cell1 = newRow.insertCell(0);
                        const dateInput = document.createElement('input');
                        dateInput.type = 'datetime-local';
                        dateInput.className = 'editable';
                        dateInput.style.width = '100%';
                        dateInput.style.boxSizing = 'border-box';
                        dateInput.style.border = '2px solid #3b82f6';
                        cell1.appendChild(dateInput);
                       
                        // Create situation cell
                        const cell2 = newRow.insertCell(1);
                        const textarea = document.createElement('textarea');
                        textarea.className = 'editable';
                        textarea.style.width = '100%';
                        textarea.style.boxSizing = 'border-box';
                        textarea.style.border = '2px solid #3b82f6';
                        textarea.style.minHeight = '60px';
                        cell2.appendChild(textarea);
                    }
                    
                async function saveChanges() {
                    if (!confirm('Save all changes to incident ' + INCIDENT_ID + '?')) return;

                    const saveBtn = document.getElementById('saveBtn');
                    saveBtn.disabled = true;
                    saveBtn.textContent = '⏳ Saving...';

                    try {
                        function getValue(id) {
                            const el = document.getElementById(id);
                            if (!el) return '';
                            return el.tagName === 'TEXTAREA' || el.tagName === 'INPUT'
                                ? (el.value || '').trim()
                                : (el.textContent || '').trim();
                        }
                        
                        function getTextAreaValue(id) {
                            const el = document.getElementById(id);
                            if (!el) return '';
                            const ta = el.querySelector('textarea');
                            if (ta) return (ta.value || '').trim();
                            return el.tagName === 'TEXTAREA' ? (el.value || '').trim() : (el.textContent || '').trim();
                        }

                        const updatedData = {
                            reportedDate: getValue('edit-reportedDate'),
                            companyName: getValue('edit-company'),
                            reporterName: getValue('edit-reporter'),
                            personInvolved: getValue('edit-personInvolved'),
                            reportStatus: getValue('edit-reportStatus'),
                            incidentDateTime: getValue('edit-incidentDateTime'),
                            discoveredDateTime: getValue('edit-discoveredDateTime'),
                            whatMadeNotice: getTextAreaValue('edit-whatMadeNotice'),
                            incidentOverview: getTextAreaValue('edit-incidentOverview'),
                            incidentType: INCIDENT_TYPE,
                            locationOccurred: getValue('input-locationOccurred'),
                            alcoholIntake: document.querySelector('input[name="alcoholIntake"]:checked')?.value || '',
                            recordsCount: getValue('input-recordsCount'),
                            customersInfo: getValue('input-customersInfo'),
                            employeesInfo: getValue('input-employeesInfo'),
                            otherContacts: getValue('input-otherContacts'),
                            secondaryDamage: document.querySelector('input[name="secondaryDamage"]:checked')?.value || '',
                            secondaryDamageDesc: getValue('input-secondaryDamageDesc'),
                            infoLeaked: getTextAreaValue('edit-infoLeaked'),
                            managerPermission: document.querySelector('input[name="managerPermission"]:checked')?.value || '',
                            windowsEncryption: document.querySelector('input[name="windowsEncryption"]:checked')?.value || '',
                            storageEncryption: document.querySelector('input[name="storageEncryption"]:checked')?.value || '',
                            lossPreventionStrap: document.querySelector('input[name="lossPreventionStrap"]:checked')?.value || '',
                            securityMeasuresOther: getTextAreaValue('edit-securityOther'),
                            securityMeasuresWrongDest: getTextAreaValue('edit-wrongDestSecurity'),
                            searchedPlaceDesc: getValue('input-searchedPlaceDesc'),
                            gpsResult: document.querySelector('input[name="gpsResult"]:checked')?.value || '',
                            reportedTransportDateTime: getValue('input-transportDateTime'),
                            reportedTransportPlace: getValue('input-transportPlace'),
                            reportedPoliceDateTime: getValue('input-policeDateTime'),
                            reportedPolicePlace: getValue('input-policePlace'),
                            remoteWipeResult: document.querySelector('input[name="remoteWipeResult"]:checked')?.value || '',
                            phoneNumber: getValue('input-phoneNumber'),
                            otherActionsTheft: getTextAreaValue('edit-postIncidentOther'),
                            deleteRequest: document.querySelector('input[name="deleteRequest"]:checked')?.value || '',
                            deleteRequestReason: (function() {
                                const el = document.getElementById('edit-deleteRequest');
                                if (!el) return '';
                                const ta = el.querySelector('textarea');
                                return ta ? ta.value.trim() : '';
                            })(),
                            otherActionsWrongDest: getTextAreaValue('edit-wrongDestOther'),
                            assumedCauses: getTextAreaValue('edit-assumedCauses'),
                            preventiveMeasures: getTextAreaValue('edit-preventiveMeasures'),
                            responsiblePerson: getValue('input-responsiblePerson'),
                            completionDate: getValue('input-completionDate'),
                            remarks: getTextAreaValue('edit-remarks')
                        };

                        // Collect timeline rows
                        const timelineInputs = document.querySelectorAll('input[type="datetime-local"].editable');
                        if (timelineInputs.length > 0) {
                            updatedData.timeline = [];
                            timelineInputs.forEach(dateInput => {
                                const situationTA = dateInput.closest('tr')?.querySelector('textarea.editable');
                                if (dateInput && situationTA) {
                                    updatedData.timeline.push({
                                        dateTime: dateInput.value.trim(),
                                        situation: situationTA.value.trim()
                                    });
                                }
                            });
                        }

                        const response = await fetch(API_BASE + '/api/it-incidents/' + encodeURIComponent(INCIDENT_ID), {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ form_data: updatedData })
                        });

                        if (!response.ok) {
                            let errorMessage = 'Server error: ' + response.status + ' ' + response.statusText;
                            try {
                                const errorData = await response.json();
                                errorMessage = errorData.error || errorMessage;
                            } catch (e) {
                                if (response.status === 405) {
                                    errorMessage = 'Update endpoint not implemented on server. Please contact IT support.';
                                }
                            }
                            throw new Error(errorMessage);
                        }

                        const result = await response.json();

                        if (result.success) {
                            alert('✅ Changes saved successfully!');
                            document.querySelectorAll('.editable').forEach(el => {
                                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                                    el.disabled = true;
                                } else {
                                    el.contentEditable = false;
                                }
                                el.style.border = '';
                                el.style.background = '#fffbeb';
                            });
                            document.getElementById('saveBtn').style.display = 'none';
                            document.getElementById('editBtn').style.display = 'inline-block';
                        } else {
                            alert('❌ Failed to save: ' + (result.error || 'Unknown error'));
                        }
                    } catch (err) {
                        alert('❌ Error saving: ' + err.message);
                    } finally {
                        saveBtn.disabled = false;
                        saveBtn.textContent = '💾 Save Changes';
                    }
                }
            </script>
        </body>
        </html>
    `;

    window.reportWindow = window.open('', 'ITSecurityReportFormA', 'width=1200,height=900,resizable=yes,scrollbars=yes');
    window.reportWindow.document.write(reportHTMLA);
    window.reportWindow.document.close();

    console.log('✅ Form A report generated successfully');
}


// === Replace your existing collectFormBData() with this ===
// ========================================
// FIXED FORM B DATA COLLECTION FUNCTION
// ========================================

function collectFormBData() {
    console.log('🔍 Starting Form B data collection...');

    const formatB = document.getElementById('formatBContent');
    if (!formatB) {
        console.error('❌ formatBContent not found');
        return {};
    }

    // ===== HELPER FUNCTIONS =====
    const getValue = (selector) => {
        const el = formatB.querySelector(selector);
        if (!el) return '';
        return el.value ? el.value.trim() : '';
    };

    const getText = (selector) => {
        const el = formatB.querySelector(selector);
        return el ? el.textContent.trim() : '';
    };

    const getRadio = (name) => {
        const el = formatB.querySelector(`input[name="${name}"]:checked`);
        return el ? el.value : '';
    };

    const getCheckboxes = (name) => {
        return Array.from(formatB.querySelectorAll(`input[name="${name}"]:checked`))
            .map(cb => cb.value);
    };

    const getSectionByNumber = (sectionNum) => {
        const sections = formatB.querySelectorAll('.section-card');
        for (const section of sections) {
            const numSpan = section.querySelector('.section-num');
            if (numSpan && numSpan.textContent.trim() === sectionNum.toString()) {
                return section;
            }
        }
        return null;
    };

    const getTextareaBySection = (sectionNum) => {
        const section = getSectionByNumber(sectionNum);
        if (section) {
            const ta = section.querySelector('textarea');
            return ta ? ta.value.trim() : '';
        }
        return '';
    };

    const getDateTimeBySection = (sectionNum) => {
        const section = getSectionByNumber(sectionNum);
        if (section) {
            const input = section.querySelector('input[type="datetime-local"]');
            return input ? input.value : '';
        }
        return '';
    };

    // ===== COLLECT EMPLOYEE DATA =====
    const empDetailsDiv = formatB.querySelector('#employeeDetails, .employee-details');
    const getEmployeeField = (labelText) => {
        if (!empDetailsDiv) return 'N/A';
        const spans = empDetailsDiv.querySelectorAll('span');
        for (let i = 0; i < spans.length; i++) {
            const span = spans[i];
            if (span.textContent.includes(labelText) && spans[i + 1]) {
                return spans[i + 1].textContent.trim();
            }
        }
        return 'N/A';
    };

    // ===== COLLECT DATA ITEMS (Section 6) =====
    const section6 = getSectionByNumber(6);
    const dataItems = {
        name: false,
        birthDate: false,
        gender: false,
        address: false,
        phone: false,
        email: false,
        other: false
    };

    if (section6) {
        const checkboxes = section6.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(cb => {
            if (!cb.checked) return;
            const label = cb.parentElement?.textContent?.toLowerCase() || '';
            if (label.includes('name') && !label.includes('birth')) dataItems.name = true;
            else if (label.includes('birth')) dataItems.birthDate = true;
            else if (label.includes('gender')) dataItems.gender = true;
            else if (label.includes('address')) dataItems.address = true;
            else if (label.includes('phone')) dataItems.phone = true;
            else if (label.includes('email')) dataItems.email = true;
            else if (label.includes('other')) dataItems.other = true;
        });
    }

    // ===== COLLECT TIMELINE (SECTION 9) =====
    console.log('📅 Collecting Form B Section 9 timeline data...');
    const timeline = [];
    const section9 = getSectionByNumber(9);
    if (section9) {
        const table = section9.querySelector('table');
        if (table) {
            const rows = table.querySelectorAll('tbody tr');
            console.log(`  Found ${rows.length} timeline rows`);

            rows.forEach((row, index) => {
                const dateInput = row.querySelector('input[type="datetime-local"]');
                const situationTA = row.querySelector('textarea');
                if (dateInput && situationTA) {
                    const dateTime = dateInput.value.trim();
                    const situation = situationTA.value.trim();

                    console.log(`  Row ${index}: dateTime="${dateTime}", situation="${situation.substring(0, 30)}..."`);

                    if (dateTime || situation) {
                        timeline.push({ dateTime, situation });
                    }
                }
            });
        }
    }
    console.log(`✅ Collected ${timeline.length} timeline entries`);

    // ===== COLLECT INCIDENT TYPE =====
    let incidentType = '';
    const incidentRadios = formatB.querySelectorAll('input[name="incidentType"]');
    incidentRadios.forEach(radio => {
        if (radio.checked) incidentType = radio.value;
    });

    // ===== COLLECT DEVICE COUNTS =====
    const deviceCounts = {
        publicDeviceCount: '0',
        virusDeviceCount: '0',
        intranetDeviceCount: '0',
        mobileDeviceCount: '0'
    };

    const section5 = getSectionByNumber(5);
    if (section5) {
        const numberInputs = section5.querySelectorAll('input[type="number"]');
        if (numberInputs.length > 0) {
            if (incidentType === 'publicWebsite') {
                deviceCounts.publicDeviceCount = numberInputs[0]?.value || '0';
            } else if (incidentType === 'virusInfection') {
                deviceCounts.virusDeviceCount = numberInputs[0]?.value || '0';
            } else if (incidentType === 'intranetUnauthorized') {
                deviceCounts.intranetDeviceCount = numberInputs[0]?.value || '0';
                deviceCounts.mobileDeviceCount = numberInputs[1]?.value || '0';
            }
        }
    }

    // ===== SECTION 7: SECURITY MEASURES =====
    console.log('🔐 Collecting Form B Section 7 security measures...');
    const section7 = getSectionByNumber(7);
    let securityMeasures = '';
    if (section7) {
        const textarea = section7.querySelector('textarea');
        securityMeasures = textarea ? textarea.value.trim() : '';
    }
    console.log('  Security Measures:', securityMeasures ? 'YES (' + securityMeasures.length + ' chars)' : 'NO');

    // ===== SECTION 8: POST-INCIDENT ACTIONS =====
    console.log('📋 Collecting Form B Section 8 post-incident actions...');
    const section8 = getSectionByNumber(8);
    let postIncidentActions = '';
    if (section8) {
        const textarea = section8.querySelector('textarea');
        postIncidentActions = textarea ? textarea.value.trim() : '';
    }
    console.log('  Post-Incident Actions:', postIncidentActions ? 'YES (' + postIncidentActions.length + ' chars)' : 'NO');

    // ===== BUILD DATA OBJECT =====
    const data = {
        // Header
        reportedDate: getText('#reportedDateB') || new Date().toISOString().split('T')[0],
        csirtName: 'Marumoto Shuichiro',
        csirtJobTitle: 'Director',
        csirtDivision: 'CO',

        // Reporter
        reporterName: getText('#currentUserNameB') || 'N/A',
        reporterJobTitle: getText('#currenttitleB') || 'N/A',
        reporterPhone: getText('#currentphoneB') || 'N/A',
        companyName: 'TTDI',

        // Person Involved
        personInvolvedName: getEmployeeField('Name:'),
        personInvolvedJobTitle: getEmployeeField('Job Title:'),
        personInvolvedDept: getEmployeeField('Department:'),
        personInvolvedDivision: getEmployeeField('Division:'),

        jobCategory: getRadio('jobCategory'),
        outsourcee: getValue('input[placeholder*="outsourcee"], input[placeholder*="Outsourcee"]'),

        // Incident Type & Device Counts
        incidentType: incidentType,
        ...deviceCounts,

        // Report Status
        reportStatus: getRadio('reportStatus') || 'First',

        // Sections 2-6
        incidentDateTime: getDateTimeBySection(2),
        discoveredDateTime: getDateTimeBySection(3),
        whatMadeNotice: getTextareaBySection(4),
        incidentOverview: getTextareaBySection(5),
        infoLeaked: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const textareas = section6.querySelectorAll('textarea');
                return textareas[0] ? textareas[0].value.trim() : '';
            }
            return '';
        })(),
        dataItems: dataItems,
        recordsCount: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const numInputs = section6.querySelectorAll('input[type="number"]');
                return numInputs[0] ? numInputs[0].value : '0';
            }
            return '0';
        })(),
        customersInfo: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const numInputs = section6.querySelectorAll('input[type="number"]');
                return numInputs[1] ? numInputs[1].value : '0';
            }
            return '0';
        })(),
        employeesInfo: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const numInputs = section6.querySelectorAll('input[type="number"]');
                return numInputs[2] ? numInputs[2].value : '0';
            }
            return '0';
        })(),
        otherContacts: (() => {
            const section6 = getSectionByNumber(6);
            if (section6) {
                const numInputs = section6.querySelectorAll('input[type="number"]');
                return numInputs[3] ? numInputs[3].value : '0';
            }
            return '0';
        })(),
        secondaryDamage: getRadio('secondaryDamage'),
        secondaryDamageDesc: getValue('#secondaryTextbox1'),

        // ===== SECTION 7 =====
        securityMeasures: securityMeasures,

        // ===== SECTION 8 =====
        postIncidentActions: postIncidentActions,

        // ===== SECTION 9 =====
        timeline: timeline,

        // Sections 10-12
        assumedCauses: getTextareaBySection(10),
        preventiveMeasures: (() => {
            const section11 = getSectionByNumber(11);
            if (section11) {
                const textareas = section11.querySelectorAll('textarea');
                return textareas[0] ? textareas[0].value.trim() : '';
            }
            return '';
        })(),
        responsiblePerson: (() => {
            const section11 = getSectionByNumber(11);
            if (section11) {
                const input = section11.querySelector('input[type="text"]');
                return input ? input.value.trim() : '';
            }
            return '';
        })(),
        completionDate: (() => {
            const section11 = getSectionByNumber(11);
            if (section11) {
                const input = section11.querySelector('input[type="date"]');
                return input ? input.value : '';
            }
            return '';
        })(),
        remarks: getTextareaBySection(12)
    };

    console.log('');
    console.log('='.repeat(60));
    console.log('📊 FORM B DATA COLLECTION SUMMARY:');
    console.log('='.repeat(60));
    console.log('Section 7 - Security Measures:', data.securityMeasures ? 'YES' : 'NO');
    console.log('Section 8 - Post-Incident:', data.postIncidentActions ? 'YES' : 'NO');
    console.log('Section 9 - Timeline Entries:', data.timeline.length);
    console.log('='.repeat(60));

    return data;
}







let currentFormDataB = null;
async function generateFormBReport() {
    console.log('🚀 Starting Form B Report Generation...');

    // Collect form data
    const data = collectFormBData();
    currentFormDataB = data;

    // Validate required fields
    if (!data.reporterName || data.reporterName === 'N/A') {
        alert('⚠️ Reporter name is missing. Please check the form.');
        console.error('Missing reporter name');
        return;
    }

    if (!data.incidentType) {
        alert('⚠️ Please select an incident type');
        return;
    }

    if (!data.incidentDateTime) {
        alert('⚠️ Please enter the incident date and time');
        return;
    }

    // Save to database
    let incidentId;
    try {
        console.log('💾 Saving to database...');
        incidentId = await saveItIncident('B', data);
        data.incidentId = incidentId;
        console.log('✅ Saved successfully with ID:', incidentId);
    } catch (err) {
        console.error('❌ Save failed:', err);
        alert('Failed to save IT incident: ' + err.message);
        return;
    }

    // Generate report HTML (your existing code continues here...)
    const reportHTMLB = `
        <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Information Security Incident Report - Form B</title>
                        <style>
                            body { 
                                font-family: Arial, sans-serif; 
                                padding: 20px; 
                                font-size: 12px; 
                            }
                            .report-container { 
                                max-width: 1200px; 
                                margin: 0 auto; 
                            }
                            table { 
                                width: 100%; 
                                border-collapse: collapse; 
                                margin-bottom: 20px; 
                            }
                            table, th, td { 
                                border: 1px solid #000; 
                            }
                            th, td { 
                                padding: 8px; 
                                text-align: left; 
                                vertical-align: top; 
                            }
                            th { 
                                background: #f0f0f0; 
                                font-weight: 600; 
                                width: 40%; 
                            }
                            .header-section { 
                                background: #1d4ed8; 
                                color: white; 
                                padding: 15px; 
                                margin-bottom: 20px; 
                            }
                            .section-title { 
                                background: #e8f4f8; 
                                font-weight: bold; 
                                padding: 10px; 
                                margin-top: 15px; 
                            }
                            .review-btn { 
                                background: #3b82f6; 
                                color: white; 
                                padding: 12px 30px; 
                                border: none; 
                                border-radius: 5px; 
                                cursor: pointer; 
                                font-size: 14px;
                                margin: 20px 0;
                            }
                            .review-btn:hover { 
                                background: #2563eb; 
                            }
                            .editable { 
                                background: #fffbeb; 
                            }
                            textarea { 
                                width: 100%; 
                                min-height: 60px; 
                                padding: 5px; 
                            }
                            input[type="text"], 
                            input[type="date"], 
                            input[type="datetime-local"] { 
                                width: 30%; 
                                padding: 5px; 
                            }
                            input[type="checkbox"]:disabled {
                                opacity: 0.8;
                                cursor: default;
                            }
                            .checkbox-grid {
                                display: grid;
                                grid-template-columns: repeat(4, 1fr);
                                gap: 6px;
                                margin-top: 8px;
                            }
                            .radio-group {
                                margin: 5px 0;
                            }
                        </style>
                    </head>
                    <body>
                        <div class="report-container">
                            <div class="header-section">
                                <h2>Information Security Incident Report (Format B)</h2>
                                <p>Use this format when "Tampering/unauthorized access of public websites," or "Virus infection and other incidents" occur.<br>
                                Use Format A when "Theft/loss" or "Sending to wrong destination" occurs.</p>
                            </div>

                <!-- Top Section -->
                <table>
                    <tr>
                        <th>Reported on:</th>
                        <td id="edit-reportedDate">${data.reportedDate || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>To:</th>
                        <td>Manager of Cyber Security Center of Corporate Technology Planning Div.<br>
                        (email address: HDQ-CSEC-head@ml.toshiba.co.jp)</td>
                    </tr>
                    <tr>
                        <th>Scope of disclosure:</th>
                        <td>Cyber Security Center of Corporate Technology Planning Div., Legal Affairs Div., reporting division/department, and those permitted by the managers thereof</td>
                    </tr>
                </table>

                <!-- CSIRT Leader Section -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">CSIRT Leader of Toshiba or Key group company (Division in Charge)</th>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td id="edit-csirtName">${data.csirtName || 'Marumoto Shuichiro'}</td>
                    </tr>
                    <tr>
                        <th>Designation and Division</th>
                        <td id="edit-csirtDesignation">${data.csirtJobTitle || 'Director'}, ${data.csirtDivision || 'CO'}</td>
                    </tr>
                </table>

                <!-- Department Information -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">Case Details</th>
                    </tr>
                    <tr>
                        <th>Company name & department</th>
                        <td id="edit-company">${data.companyName || 'N/A'}, ${data.personInvolvedDept || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>Name, job title and phone of person making report</th>
                        <td id="edit-reporter">${data.reporterName || 'N/A'}, ${data.reporterJobTitle || 'N/A'} (Phone: ${data.reporterPhone || 'N/A'})</td>
                    </tr>
                    <tr>
                        <th>Job category, job title and name of the person involved in incident</th>
                        <td id="edit-personInvolved">
                            Name & Job Title: ${data.personInvolvedName || 'N/A'}, ${data.personInvolvedJobTitle || 'N/A'}<br>
                            Department: ${data.personInvolvedDept || 'N/A'}<br>
                            ${data.jobCategory ? `Job category: ${data.jobCategory}<br>` : ''}
                            ${data.outsourcee ? `Outsourcee: ${data.outsourcee}<br>` : ''}
                        </td>
                    </tr>
                </table>

                <!-- Incident Type -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">Incident Type</th>
                    </tr>
                    ${data.incidentType === 'publicWebsite' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Unauthorized access to publicly accessible websites, defacement, etc.
                        </th>
                        <td>
                            Affected URL: ${data.affectedUrl || 'N/A'}<br>
                            ${data.publicWebsiteTypes && data.publicWebsiteTypes.length > 0 ? 'Types: ' + data.publicWebsiteTypes.join(', ') : ''}
                            ${data.publicWebsiteOther ? '<br>Other: ' + data.publicWebsiteOther : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'virusInfection' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Virus infection, etc.
                        </th>
                        <td>
                            Virus name: ${data.virusName || 'N/A'}<br>
                            ${data.virusTypes && data.virusTypes.length > 0 ? 'Types: ' + data.virusTypes.join(', ') : ''}
                            ${data.virusOther ? '<br>Other: ' + data.virusOther : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'intranetUnauthorized' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Unauthorized access to/from Intranet information systems
                        </th>
                        <td>
                            Affected system: ${data.affectedSystem || 'N/A'}<br>
                            ${data.intranetTypes && data.intranetTypes.length > 0 ? 'Types: ' + data.intranetTypes.join(', ') : ''}
                            ${data.intranetOther ? '<br>Other: ' + data.intranetOther : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'dos' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            DoS/DDoS attack
                        </th>
                        <td>
                            Target: ${data.dosTarget || 'N/A'}<br>
                            ${data.dosTypes && data.dosTypes.length > 0 ? 'Types: ' + data.dosTypes.join(', ') : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'targetedAttack' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Targeted attack
                        </th>
                        <td>
                            Attack vector: ${data.attackVector || 'N/A'}<br>
                            ${data.targetedAttackTypes && data.targetedAttackTypes.length > 0 ? 'Types: ' + data.targetedAttackTypes.join(', ') : ''}
                        </td>
                    </tr>
                    ` : ''}
                    ${data.incidentType === 'otherIncident' ? `
                    <tr>
                        <th style="width: 40%;">
                            <input type="checkbox" checked disabled style="margin-right: 8px; pointer-events: none;">
                            Other
                        </th>
                        <td>${data.otherIncidentDesc || 'N/A'}</td>
                    </tr>
                    ` : ''}
                </table>

                <!-- Main Content Sections 1-12 -->
                <table>
                    <tr>
                        <th>1. Report status</th>
                        <td class="editable" id="edit-reportStatus">${data.reportStatus || 'First'}</td>
                    </tr>
                    <tr>
                        <th>2. Date and time of incident</th>
                        <td id="edit-incidentDateTime">${data.incidentDateTime || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>3. Date and time of incident discovered</th>
                        <td id="edit-discoveredDateTime">${data.discoveredDateTime || 'N/A'}</td>
                    </tr>
                    <tr>
                        <th>4. What made you notice incident</th>
                        <td id="edit-whatMadeNotice"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box;">${data.whatMadeNotice || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>5. Incident overview<br><small>* General overview of incident, including causes</small></th>
                        <td id="edit-incidentOverview">
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 100px;">${data.incidentOverview || ''}</textarea>
                            ${data.incidentType === 'publicWebsite' ? `
                            <br><small>＜Fill in the following section if the incident is "Unauthorized access to publicly accessible websites, defacement, etc."＞</small><br>
                            <strong>Number of devices affected:</strong> <input type="number" class="editable" disabled value="${data.publicDeviceCount || '0'}" style="width: 100px;"> devices
                            ` : ''}
                            ${data.incidentType === 'virusInfection' ? `
                            <br><small>＜Fill in the following section if the incident is "Virus infection, etc."＞</small><br>
                            <strong>Number of devices affected:</strong> <input type="number" class="editable" disabled value="${data.virusDeviceCount || '0'}" style="width: 100px;"> devices
                            ` : ''}
                            ${data.incidentType === 'intranetUnauthorized' ? `
                            <br><small>＜Fill in the following section if the incident is "Unauthorized access to/from Intranet information systems"＞</small><br>
                            <strong>Number of devices affected (Intranet):</strong> <input type="number" class="editable" disabled value="${data.intranetDeviceCount || '0'}" style="width: 100px;"> devices<br>
                            <strong>Number of devices affected (Mobile):</strong> <input type="number" class="editable" disabled value="${data.mobileDeviceCount || '0'}" style="width: 100px;"> devices
                            ` : ''}
                        </td>
                    </tr>
                    <tr>
                        <th>6. Information that was, or can possibly be, leaked<br><small>* If the incident includes loss of customers' information, write their company names.</small></th>
                        <td id="edit-infoLeaked">
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.infoLeaked || ''}</textarea><br><br>
                            <small>＜Fill in the following section if the incident includes loss of personal information＞</small><br>
                            <strong>Data items:</strong>
                            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-top: 8px;">
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.name ? 'checked' : ''}> Name</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.birthDate ? 'checked' : ''}> Birth date</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.gender ? 'checked' : ''}> Gender</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.address ? 'checked' : ''}> Address</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.phone ? 'checked' : ''}> Phone number</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.email ? 'checked' : ''}> Email address</label>
                                <label><input class="editable" type="checkbox" disabled ${data.dataItems?.other ? 'checked' : ''}> Other</label>
                            </div><br>
                            <strong>Records on:</strong> <input type="number" class="editable" disabled value="${data.recordsCount || '0'}" style="width: 100px;"> people<br>
                            <strong>(Breakdown:</strong><br>
                            &nbsp;&nbsp;Customers' info: <input type="number" class="editable" disabled value="${data.customersInfo || '0'}" style="width: 100px;"> people<br>
                            &nbsp;&nbsp;Employees' info: <input type="number" class="editable" disabled value="${data.employeesInfo || '0'}" style="width: 100px;"> people<br>
                            &nbsp;&nbsp;Other contacts: <input type="number" class="editable" disabled value="${data.otherContacts || '0'}" style="width: 100px;"> people<strong>)</strong><br><br>
                            <strong>Secondary damage in event of misuse:</strong><br>
                            <label><input type="radio" class="editable" disabled name="secondaryDamage" value="possible" ${data.secondaryDamage === 'possible' ? 'checked' : ''}> Possible</label>
                            <label><input type="radio" class="editable" disabled name="secondaryDamage" value="none" ${data.secondaryDamage === 'none' ? 'checked' : ''}> None</label><br>
                            <strong>Description:</strong><br>
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 60px;">${data.secondaryDamageDesc || ''}</textarea>
                        </td>
                    </tr>
                    <tr>
                        <th>7. Information security measures that were taken</th>
                        <td id="edit-securityMeasures"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.securityMeasures || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>8. Post-incident responses<br><small>* Actions taken to minimize potential damage</small></th>
                        <td id="edit-postIncidentActions"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 100px;">${data.postIncidentActions || ''}</textarea></td>
                    </tr>
                </table>

                <!-- Section 9: Timeline -->
                <table>
                    <tr>
                        <th colspan="2" class="section-title">9. Timeline<br><small>* Describe chronologically: Initial response, Stopgap measure, Instructions given by CSIRT Leader</small></th>
                    </tr>
                    <tr>
                        <th style="width: 30%;">Date/time</th>
                        <th>Situation, response, etc.</th>
                    </tr>
                    ${(data.timeline && data.timeline.length > 0) ? data.timeline.map(item => `
                    <tr>
                        <td><input class="editable" disabled type="datetime-local" value="${item.dateTime || ''}" style="width: 100%; box-sizing: border-box;" /></td>
                        <td><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 60px;">${item.situation || ''}</textarea></td>
                    </tr>
                    `).join('') : '<tr><td colspan="2">No timeline entries</td></tr>'}
                </table>
                 <button class="review-btn" id="report-actions" style="display: none; style="background: #09bb53; padding: 8px 10px; margin: 0px 0 20px 0;" onclick="addTimelineRow()">
                                        Add Timeline Row
                                </button>
                <!-- Sections 10-12 -->
                <table>
                    <tr>
                        <th>10. Assumed causes<br><small>* Provide root causes. For example, if person concerned neglected to follow rules, describe why he/she did.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                        <td id="edit-assumedCauses"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.assumedCauses || ''}</textarea></td>
                    </tr>
                    <tr>
                        <th>11. Preventive measures<br><small>* Describe specifically. Attach evidence records, if any, such as a notice of issue and documents provided.</small><br><small style="color: red;">Can be omitted for first report</small></th>
                        <td id="edit-preventiveMeasures">
                            <textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 80px;">${data.preventiveMeasures || ''}</textarea><br>
                            <strong>Name and job title of person responsible for implementation:</strong><br>
                            <input type="text" class="editable" disabled value="${data.responsiblePerson || ''}" style="width: 100%;"><br>
                            <strong>Date of (scheduled) completion:</strong><br>
                            <input type="date" class="editable" disabled value="${data.completionDate || ''}" style="width: 100%;">
                        </td>
                    </tr>
                    <tr>
                        <th>12. Remarks</th>
                        <td id="edit-remarks"><textarea class="editable" disabled style="width: 100%; box-sizing: border-box; min-height: 60px;">${data.remarks || ''}</textarea></td>
                    </tr>
                </table>

                <!-- Review/Edit Button -->
                <div style="text-align: center; margin: 30px 0;">
                    <button class="review-btn" id="editBtn" onclick="enableEditing()">Review & Edit Report</button>
                    <button class="review-btn" style="background: #10b981; display: none;" id="saveBtn" onclick="saveChanges()">💾 Save Changes</button>
                    <button class="review-btn" onclick="window.print()">Print Report</button>
                </div>
            </div>

            <script>
                const INCIDENT_ID = '${incidentId}' || 'UNKNOWN';
                const API_BASE = 'http://localhost:5000';

                function enableEditing() {
                    const editables = document.querySelectorAll('.editable');
                    editables.forEach(el => {
                        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
                            el.disabled = false;
                            el.readOnly = false;
                        } else {
                            el.contentEditable = true;
                        }
                        el.style.border = '2px solid #3b82f6';
                        el.style.background = '#ffffff';
                    });
                    document.getElementById('editBtn').style.display = 'none';
                    document.getElementById('saveBtn').style.display = 'inline-block';
                    alert('✏️ Editing enabled! Click inside highlighted fields to modify.');
                }
                function addTimelineRow() {
 
                        const table = document.getElementById('timeline-table');
                        const rows = table.querySelectorAll('.timeline-row');
                        if (rows.length === 1) {
                            const firstCell = rows[0].cells[0];
                            if (firstCell && firstCell.colSpan === 2 && firstCell.textContent.includes('No timeline entries')) {
                                rows[0].remove();
                            }
                        }
                       
                        const newRow = table.insertRow(-1); // Insert at the end
                        newRow.className = 'timeline-row';
                       
                        // Create date/time cell
                        const cell1 = newRow.insertCell(0);
                        const dateInput = document.createElement('input');
                        dateInput.type = 'datetime-local';
                        dateInput.className = 'editable';
                        dateInput.style.width = '100%';
                        dateInput.style.boxSizing = 'border-box';
                        dateInput.style.border = '2px solid #3b82f6';
                        cell1.appendChild(dateInput);
                       
                        // Create situation cell
                        const cell2 = newRow.insertCell(1);
                        const textarea = document.createElement('textarea');
                        textarea.className = 'editable';
                        textarea.style.width = '100%';
                        textarea.style.boxSizing = 'border-box';
                        textarea.style.border = '2px solid #3b82f6';
                        textarea.style.minHeight = '60px';
                        cell2.appendChild(textarea);
                    }
 
                async function saveChanges() {
                    if (!confirm('Save all changes to incident ' + INCIDENT_ID + '?')) return;

                    const saveBtn = document.getElementById('saveBtn');
                    saveBtn.disabled = true;
                    saveBtn.textContent = '⏳ Saving...';

                    try {
                        function getValue(id) {
                            const el = document.getElementById(id);
                            if (!el) return '';
                            return el.tagName === 'TEXTAREA' || el.tagName === 'INPUT'
                                ? (el.value || '').trim()
                                : (el.textContent || '').trim();
                        }
                        
                        function getTextAreaValue(id) {
                            const el = document.getElementById(id);
                            if (!el) return '';
                            const ta = el.querySelector('textarea');
                            if (ta) return (ta.value || '').trim();
                            return el.tagName === 'TEXTAREA' ? (el.value || '').trim() : (el.textContent || '').trim();
                        }

                        function getNumberValue(selector) {
                            const el = document.querySelector(selector);
                            return el ? (el.value || '0') : '0';
                        }

                        // Collect data items checkboxes
                        const dataItems = {
                            name: !!document.querySelector('input[type="checkbox"].editable[value="name"]')?.checked,
                            birthDate: !!document.querySelector('input[type="checkbox"].editable[value="birthDate"]')?.checked,
                            gender: !!document.querySelector('input[type="checkbox"].editable[value="gender"]')?.checked,
                            address: !!document.querySelector('input[type="checkbox"].editable[value="address"]')?.checked,
                            phone: !!document.querySelector('input[type="checkbox"].editable[value="phone"]')?.checked,
                            email: !!document.querySelector('input[type="checkbox"].editable[value="email"]')?.checked,
                            other: !!document.querySelector('input[type="checkbox"].editable[value="other"]')?.checked
                        };

                        const updatedData = {
                            reportedDate: getValue('edit-reportedDate'),
                            csirtName: getValue('edit-csirtName'),
                            csirtDesignation: getValue('edit-csirtDesignation'),
                            companyName: getValue('edit-company'),
                            reporterName: getValue('edit-reporter'),
                            personInvolved: getValue('edit-personInvolved'),
                            reportStatus: getValue('edit-reportStatus'),
                            incidentDateTime: getValue('edit-incidentDateTime'),
                            discoveredDateTime: getValue('edit-discoveredDateTime'),
                            whatMadeNotice: getTextAreaValue('edit-whatMadeNotice'),
                            incidentOverview: getTextAreaValue('edit-incidentOverview'),
                            infoLeaked: getTextAreaValue('edit-infoLeaked'),
                            dataItems: dataItems,
                            recordsCount: getNumberValue('input[type="number"].editable'),
                            securityMeasures: getTextAreaValue('edit-securityMeasures'),
                            postIncidentActions: getTextAreaValue('edit-postIncidentActions'),
                            assumedCauses: getTextAreaValue('edit-assumedCauses'),
                            preventiveMeasures: getTextAreaValue('edit-preventiveMeasures'),
                            remarks: getTextAreaValue('edit-remarks')
                        };

                        // Collect timeline rows
                        const timelineInputs = document.querySelectorAll('input[type="datetime-local"].editable');
                        if (timelineInputs.length > 0) {
                            updatedData.timeline = [];
                            timelineInputs.forEach(dateInput => {
                                const situationTA = dateInput.closest('tr')?.querySelector('textarea.editable');
                                if (dateInput && situationTA) {
                                    updatedData.timeline.push({
                                        dateTime: dateInput.value.trim(),
                                        situation: situationTA.value.trim()
                                    });
                                }
                            });
                        }

                        const response = await fetch(API_BASE + '/api/it-incidents/' + encodeURIComponent(INCIDENT_ID), {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ form_data: updatedData })
                        });

                        if (!response.ok) {
                            let errorMessage = 'Server error: ' + response.status + ' ' + response.statusText;
                            try {
                                const errorData = await response.json();
                                errorMessage = errorData.error || errorMessage;
                            } catch (e) {
                                if (response.status === 405) {
                                    errorMessage = 'Update endpoint not implemented on server. Please contact IT support.';
                                }
                            }
                            throw new Error(errorMessage);
                        }

                        const result = await response.json();

                        if (result.success) {
                            alert('✅ Changes saved successfully!');
                            document.querySelectorAll('.editable').forEach(el => {
                                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                                    el.disabled = true;
                                } else {
                                    el.contentEditable = false;
                                }
                                el.style.border = '';
                                el.style.background = '#fffbeb';
                            });
                            document.getElementById('saveBtn').style.display = 'none';
                            document.getElementById('editBtn').style.display = 'inline-block';
                        } else {
                            alert('❌ Failed to save: ' + (result.error || 'Unknown error'));
                        }
                    } catch (err) {
                        alert('❌ Error saving: ' + err.message);
                    } finally {
                        saveBtn.disabled = false;
                        saveBtn.textContent = '💾 Save Changes';
                    }
                }
            </script>
        </body>
        </html>
    `;

    window.reportWindow = window.open('', 'ITSecurityReportFormB', 'width=1200,height=900,resizable=yes,scrollbars=yes');
    window.reportWindow.document.write(reportHTMLB);
    window.reportWindow.document.close();

    console.log('✅ Form B report generated successfully');
}


// DEBUG FUNCTION - Test data collection without submitting
function testFormDataCollection() {
    console.clear();
    console.log('='.repeat(60));
    console.log('🧪 TESTING FORM DATA COLLECTION');
    console.log('='.repeat(60));

    // Test Form A
    const formatA = document.getElementById('formatAContent');
    if (formatA && formatA.style.display !== 'none') {
        console.log('\n📋 FORM A DATA:');
        const dataA = collectFormAData();
        console.table({
            'Reporter Name': dataA.reporterName,
            'Reporter Title': dataA.reporterJobTitle,
            'Person Involved': dataA.personInvolvedName,
            'Department': dataA.personInvolvedDept,
            'Company': dataA.companyName,
            'Incident Type': dataA.incidentType,
            'Incident DateTime': dataA.incidentDateTime,
            'Timeline Entries': dataA.timeline.length
        });
        console.log('Full Form A Data:', dataA);
    }

    // Test Form B
    const formatB = document.getElementById('formatBContent');
    if (formatB && formatB.style.display !== 'none') {
        console.log('\n📋 FORM B DATA:');
        const dataB = collectFormBData();
        console.table({
            'Reporter Name': dataB.reporterName,
            'Reporter Title': dataB.reporterJobTitle,
            'Person Involved': dataB.personInvolvedName,
            'Department': dataB.personInvolvedDept,
            'Company': dataB.companyName,
            'Incident Type': dataB.incidentType,
            'Incident DateTime': dataB.incidentDateTime,
            'Timeline Entries': dataB.timeline.length
        });
        console.log('Full Form B Data:', dataB);
    }

    console.log('\n' + '='.repeat(60));
    alert('✅ Data collection test complete. Check browser console (F12) for results.');
}

// Add keyboard shortcut: Ctrl+Shift+D to test
document.addEventListener('keydown', function (e) {
    if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        testFormDataCollection();
    }
});

function showIncidentsTab() {
    // Hide form sections
    const formatAContent = document.getElementById('formatAContent');
    const formatBContent = document.getElementById('formatBContent');
    const incidentsContent = document.getElementById('incidentsContent');

    if (formatAContent) formatAContent.style.display = 'none';
    if (formatBContent) formatBContent.style.display = 'none';
    if (incidentsContent) incidentsContent.style.display = 'block';

    // Update active tab styling (if you have tab buttons)
    const tabs = document.querySelectorAll('.helpdesk-tab, .tab-btn');
    tabs.forEach(tab => {
        if (tab.textContent.includes('Incidents') || tab.onclick?.toString().includes('showIncidents')) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });

    console.log('✅ Switched to Incidents tab');
}



// Add click handler for IT incident tabs
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('it-tab-btn')) {
        const tabName = e.target.getAttribute('data-tab');
        const container = e.target.closest('.helpdesk-container');

        // Update button styles
        const allButtons = container.querySelectorAll('.it-tab-btn');
        allButtons.forEach(btn => {
            btn.style.background = '#f9fafb';
            btn.style.color = '#666';
            btn.style.fontWeight = 'normal';
            btn.classList.remove('active');
        });

        // Set active button
        e.target.style.background = '#dbeafe';
        e.target.style.color = '#1d4ed8';
        e.target.style.fontWeight = '600';
        e.target.classList.add('active');

        // Show corresponding tab content
        const allContent = container.querySelectorAll('.tab-content');
        allContent.forEach(content => content.style.display = 'none');

        const targetContent = container.querySelector(`#tab-${tabName}`);
        if (targetContent) {
            targetContent.style.display = 'block';
        }
    }
});

// Data and Initialization
document.addEventListener('DOMContentLoaded', function () {

    const theftLossSection = document.getElementById('theftLossSection');
    const wrongDestSection = document.getElementById('wrongDestinationSection');

    if (theftLossSection) theftLossSection.style.display = 'none';
    if (wrongDestSection) wrongDestSection.style.display = 'none';

    // ===== Enter key for employee search (Form B) =====
    const empIdInput = document.getElementById('empIdInput');
    if (empIdInput) {
        empIdInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                searchEmployee();
            }
        });
    }

    const formB = document.getElementById('incidentForm');
    if (formB) {
        formB.addEventListener('submit', handleSubmit);
    }
});

// Incident Type Toggle
function toggleIncidentSections(type) {
    const theftLoss = document.getElementById('theftLossSection');
    const wrongDest = document.getElementById('wrongDestinationSection');
    const email = document.querySelector('input[name="wrongDestMethod"][value="Email"]');
    const fax = document.querySelector('input[name="wrongDestMethod"][value="Fax"]');
    const mail = document.querySelector('input[name="wrongDestMethod"][value="Mail"]');
    const cloud = document.querySelector('input[name="wrongDestMethod"][value="Cloud"]');
    const other = document.querySelector('input[name="wrongDestMethod"][value="Other"]');
    const pclaptop = document.querySelector('input[name="theftItem"][value="PC/Laptop"]');
    const usb = document.querySelector('input[name="theftItem"][value="USB Drive"]');
    const mobilephone = document.querySelector('input[name="theftItem"][value="Mobile Phone"]');
    const tablet = document.querySelector('input[name="theftItem"][value="Tablet"]');
    const documents = document.querySelector('input[name="theftItem"][value="Documents"]');
    const other2 = document.querySelector('input[name="theftItem"][value="Other"]');


    // Section 4 - Location and Circumstances
    const section4Card = document.getElementById('section4Card');

    // Section 7 content
    const section7TheftLossContent = document.getElementById('section7TheftLossContent');
    const section7WrongDestContent = document.getElementById('section7WrongDestContent');

    // Section 8 content
    const section8TheftLossContent = document.getElementById('section8TheftLossContent');
    const section8WrongDestContent = document.getElementById('section8WrongDestContent');

    if (type === 'theftLoss') {
        // Show Theft/Loss incident type section
        theftLoss.style.display = 'block';
        wrongDest.style.display = 'none';

        // Show Section 4
        if (section4Card) {
            section4Card.style.display = 'block';
        }

        // Section 7: Show Theft/Loss content, Hide Wrong Destination content
        if (section7TheftLossContent) {
            section7TheftLossContent.style.display = 'block';
        }
        if (section7WrongDestContent) {
            section7WrongDestContent.style.display = 'none';
        }

        // Section 8: Show Theft/Loss content, Hide Wrong Destination content
        if (section8TheftLossContent) {
            section8TheftLossContent.style.display = 'block';
        }
        if (section8WrongDestContent) {
            section8WrongDestContent.style.display = 'none';
        }

        other2.disabled = false;

        email.disabled = true;
        email.checked = false;
        fax.disabled = true;
        fax.checked = false;
        mail.disabled = true;
        mail.checked = false;
        cloud.disabled = true;
        cloud.checked = false;
        other.disabled = true;
        other.checked = false;

    } else if (type === 'wrongDestination') {

        // Show Wrong Destination incident type section
        theftLoss.style.display = 'none';
        wrongDest.style.display = 'block';

        // Hide Section 4
        if (section4Card) {
            section4Card.style.display = 'none';
        }

        // Section 7: Hide Theft/Loss content, Show Wrong Destination content
        if (section7TheftLossContent) {
            section7TheftLossContent.style.display = 'none';
        }
        if (section7WrongDestContent) {
            section7WrongDestContent.style.display = 'block';
        }

        // Section 8: Hide Theft/Loss content, Show Wrong Destination content
        if (section8TheftLossContent) {
            section8TheftLossContent.style.display = 'none';
        }
        if (section8WrongDestContent) {
            section8WrongDestContent.style.display = 'block';
        }

        email.disabled = false;
        fax.disabled = false;
        mail.disabled = false;
        cloud.disabled = false;
        other.disabled = false;

        pclaptop.disabled = true;
        pclaptop.checked = false;
        usb.disabled = true;
        usb.checked = false;
        mobilephone.disabled = true;
        mobilephone.checked = false;
        tablet.disabled = true;
        tablet.checked = false;
        documents.disabled = true;
        documents.checked = false;
        other2.disabled = true;
        other2.checked = false;
    }
}

// Employee Database
const employeeDatabase = {
    '1234': {
        ename: 'John Doe',
        empid: '1234',
        desig: 'Sr. Engineer',
        company: 'TTDI',
        dept: 'Corporate',
        divi: 'Information Technology',
        mobno: '+91-40-1234-5678',
        email: 'john.doe@toshiba-ttdi.com'
    },
    '2345': {
        ename: 'Jane Smith',
        empid: '2345',
        desig: 'Sr. Engineer',
        company: 'TTDI',
        dept: 'DTR',
        divi: 'Stores',
        mobno: '+91-40-2345-6789',
        email: 'jane.smith@toshiba-ttdi.com'
    },
    '3456': {
        ename: 'Raj Kumar',
        empid: '3456',
        desig: 'Jr. Engineer',
        company: 'TTDI',
        dept: 'Corporate',
        divi: 'Finance & Accounts',
        mobno: '+91-40-3456-7890',
        email: 'raj.kumar@toshiba-ttdi.com'
    },
    '4567': {
        ename: 'Sarah Johnson',
        empid: '4567',
        desig: 'Jr. Engineer',
        company: 'TTDI',
        dept: 'Corporate',
        divi: 'Human Resources',
        mobno: '+91-40-4567-8901',
        email: 'sarah.johnson@toshiba-ttdi.com'
    }
};

async function searchEmployee(buttonElement) {
    console.log("🔍 searchEmployee called from:", buttonElement);

    // 1. Identify context (The specific search card where button was clicked)
    const card = buttonElement.closest('.card') ||
        buttonElement.closest('form') ||
        buttonElement.closest('[id*="format"]');

    if (!card) {
        console.error("No card/form container found");
        return;
    }

    console.log("  Container:", card.id || card.className);

    // 2. Check if this specific button should show assets
    const shouldShowAssets = buttonElement.getAttribute('data-show-assets') === 'true';
    console.log("  Should show assets:", shouldShowAssets);

    // Find the input field within this container
    const input = card.querySelector('#empIdInput') ||
        card.querySelector('input[placeholder*="Enter ID"]');

    const detailsDiv = card.querySelector('#employeeDetails') ||
        card.querySelector('.employee-details');

    const errorDiv = card.querySelector('#errorMessage') ||
        card.querySelector('.error-msg');

    // Find asset container (may be outside the card)
    const assetContainer = document.getElementById('dynamicAssetContainer');

    if (!input) {
        console.error("Employee ID input not found");
        return;
    }

    const empId = input.value.trim();

    // Reset UI for the clicked card
    if (detailsDiv) detailsDiv.style.display = 'none';
    if (errorDiv) errorDiv.style.display = 'none';

    // ALWAYS clear assets if the container exists
    if (assetContainer) {
        assetContainer.innerHTML = '<p style="color: #666; font-style: italic; font-size: 0.85rem;">Please search for an employee to see available assets.</p>';
    }

    if (!empId) {
        if (errorDiv) {
            errorDiv.textContent = 'Please enter an Employee ID.';
            errorDiv.style.display = 'block';
        } else {
            alert('Please enter an Employee ID.');
        }
        return;
    }

    // Show loading state
    if (errorDiv) {
        errorDiv.textContent = 'Searching...';
        errorDiv.style.display = 'block';
        errorDiv.style.color = '#1d4ed8';
    }

    try {
        console.log('✓ Searching for employee:', empId);

        // Fetch employee from database API
        const employee = await fetchEmployeeFromDB(empId);

        if (errorDiv) errorDiv.style.display = 'none';

        if (!employee) {
            console.warn("❌ Employee not found");
            if (errorDiv) {
                errorDiv.textContent = 'Employee not found. Please check the employee ID.';
                errorDiv.style.color = '#dc2626';
                errorDiv.style.display = 'block';
            } else {
                alert('Employee not found.');
            }
            return;
        }

        console.log('✓ Employee found:', employee);

        // 3. Populate standard details in the current card
        const updateElement = (selector, value) => {
            const el = card.querySelector(selector);
            if (el) {
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    el.value = value || 'N/A';
                } else {
                    el.textContent = value || 'N/A';
                }
                return true;
            }
            return false;
        };

        // Update all employee fields
        updateElement('#empName', employee.ename);
        updateElement('#empJobTitle', employee.desig);
        updateElement('#empId', employee.empId);
        updateElement('#empComp', employee.company);
        updateElement('#empDept', employee.dept);
        updateElement('#empDiv', employee.divi);
        updateElement('#empPhone', employee.mobno);
        updateElement('#empEmail', employee.email);

        console.log('✅ Employee details populated');

       
        if (shouldShowAssets && assetContainer) {

            assetContainer.innerHTML = ''; 
            if (employee.assets && employee.assets.length > 0) {
                employee.assets.forEach(asset => {
                    const label = document.createElement('label');
                    label.className = 'checkbox-item';

                    // 1. Create the checkbox element
                    const checkbox = document.createElement('input');
                    checkbox.type = 'checkbox';
                    checkbox.name = 'theftItem';
                    checkbox.value = `${asset.assetname} (${asset.assetId})`;

                    // Add the event listener to trigger your function
                    checkbox.addEventListener('change', handleMobilePhoneSelection);

                    // 2. Check if this is a mobile phone
                    if (asset.assetname === 'Mobile') {
                        // Assign the ID your function is looking for
                        checkbox.id = 'mobilePhoneCheckbox';
                    }

                    // 3. Assemble the label
                    const textNode = document.createTextNode(` ${asset.assetname} `);
                    const small = document.createElement('small');
                    small.style.color = '#666';
                    small.textContent = `(${asset.assetId})`;

                    label.appendChild(checkbox);
                    label.appendChild(textNode);
                    label.appendChild(small);

                    assetContainer.appendChild(label);
                });
            } else {
                assetContainer.innerHTML = '<p style="font-size: 0.8rem; color: #666;">No registered assets found.</p>';
            }
        }

        // Show details section
        if (detailsDiv) {
            detailsDiv.style.display = 'block';
            console.log('  ✓ Details section shown');
        }

    } catch (error) {
        console.error('❌ Error:', error);
        if (errorDiv) {
            errorDiv.textContent = 'Error fetching employee data: ' + error.message;
            errorDiv.style.color = '#dc2626';
            errorDiv.style.display = 'block';
        } else {
            alert('Error: ' + error.message);
        }
    }
}

function handleMobilePhoneSelection() {
    // 1. Get all checkboxes in the asset container
    const allCheckedAssets = document.querySelectorAll('input[name="theftItem"]:checked');

    // 2. Identify our target
    const mobilePhoneCheckbox = document.getElementById('mobilePhoneCheckbox');

    // 3. Elements to manipulate
    const permissionObtained = document.getElementById('permissionObtained');
    const permissionNotObtained = document.getElementById('permissionNotObtained');
    const windowsPCEncryption = document.getElementById('windowsPCEncryption');
    const storageMediumEncryption = document.getElementById('storageMediumEncryption');
    const passwordCheckboxes = document.querySelectorAll('input[name="passwordType"]');

    const isOnlyMobileSelected = allCheckedAssets.length === 1 && mobilePhoneCheckbox.checked;

    if (isOnlyMobileSelected) {
        // --- YOUR EXISTING "IF CHECKED" LOGIC ---
        if (permissionObtained) {
            permissionObtained.checked = true;
            permissionObtained.disabled = false;
        }
        if (permissionNotObtained) {
            permissionNotObtained.disabled = true;
            permissionNotObtained.checked = false;
        }
        passwordCheckboxes.forEach(checkbox => {
            if (checkbox.value === 'unlockScreen') {
                checkbox.checked = true;
                checkbox.disabled = false;
            } else {
                checkbox.checked = false;
                checkbox.disabled = true;
            }
        });
        if (windowsPCEncryption) windowsPCEncryption.style.display = 'none';
        if (storageMediumEncryption) storageMediumEncryption.style.display = 'block';

    } else {
        if (permissionObtained) {
            permissionObtained.checked = false;
            permissionObtained.disabled = false;
        }
        if (permissionNotObtained) permissionNotObtained.disabled = false;

        passwordCheckboxes.forEach(checkbox => {
            checkbox.checked = false;
            checkbox.disabled = false;
        });

        if (windowsPCEncryption) windowsPCEncryption.style.display = 'block';
        if (storageMediumEncryption) storageMediumEncryption.style.display = 'block';
    }
}
// Handle Incident Type Change
function handleIncidentTypeChange(event) {
    const publicWebsiteCheckbox = document.querySelector('input[name="incidentType"][value="publicWebsite"]');
    const virusInfectionCheckbox = document.querySelector('input[name="incidentType"][value="virusInfection"]');
    const otherCheckbox = document.querySelector('input[name="incidentType"][value="other"]');
    const registeredradio = document.querySelector('input[name="websiteType"][value="registered"]');
    const unregisteredradio = document.querySelector('input[name="websiteType"][value="unregistered"]');
    const text = document.querySelector('input[name="box"][value=""]');
    const text1 = document.querySelector('input[name="box1"][value=""]');
    const intranetcheckbox = document.querySelector('input[name="deviceType"][value="intranet"]');
    const clientcheckbox = document.querySelector('input[name="intranetDevice"][value="clients"]');
    const servercheckbox = document.querySelector('input[name="intranetDevice"][value="servers"]');
    const intranetothercheckbox = document.querySelector('input[name="intranetDevice"][value="intranetOther"]');
    const text2 = document.querySelector('input[name="box2"][value=""]');
    const number = document.querySelector('input[name="count"][value=""]');
    const mobilecheckbox = document.querySelector('input[name="deviceType"][value="mobile"]');
    const pctabletcheckbox = document.querySelector('input[name="mobileDevice"][value="pcTablet"]');
    const smartphonecheckbox = document.querySelector('input[name="mobileDevice"][value="smartphone"]');
    const mobileothercheckbox = document.querySelector('input[name="mobileDevice"][value="mobileOther"]');
    const text3 = document.querySelector('input[name="box3"][value=""]');
    const number2 = document.querySelector('input[name="count2"][value=""]');

    const changedCheckbox = event.target;

    // If one checkbox is checked, disable the others: disabled-true: yes make them inactive and disabled-false: no don't make them inactive and no need for .checked option for checkboxes in case they are disabled.
    if (changedCheckbox === publicWebsiteCheckbox && publicWebsiteCheckbox.checked) {

        registeredradio.disabled = false;
        unregisteredradio.disabled = false;
        text.disabled = false;
        text1.disabled = false;

        intranetcheckbox.disabled = true;
        intranetcheckbox.checked = false;
        clientcheckbox.disabled = true;
        clientcheckbox.checked = false;
        servercheckbox.disabled = true;
        servercheckbox.checked = false;
        intranetothercheckbox.disabled = true;
        intranetothercheckbox.checked = false;
        text2.disabled = true;
        text2.value = "";
        number.disabled = true;
        number.value = 0;
        mobilecheckbox.disabled = true;
        mobilecheckbox.checked = false;
        pctabletcheckbox.disabled = true;
        pctabletcheckbox.checked = false;
        smartphonecheckbox.disabled = true;
        smartphonecheckbox.checked = false;
        mobileothercheckbox.disabled = true;
        mobileothercheckbox.checked = false;
        text3.disabled = true;
        text3.value = "";
        number2.disabled = true;
        number2.value = 0;


        // Show/hide section 7 and 8 content for Public Website
        toggleSection7Content('publicWebsite');
        toggleSection8Content('publicWebsite');

    } else if (changedCheckbox === virusInfectionCheckbox && virusInfectionCheckbox.checked) {

        virusInfectionCheckbox.disabled = false;
        otherCheckbox.disabled = false;
        intranetcheckbox.disabled = false;
        clientcheckbox.disabled = false;
        servercheckbox.disabled = false;
        intranetothercheckbox.disabled = false;
        text2.disabled = false;
        text2.value = "";
        number.disabled = false;
        number.value = 0;
        mobilecheckbox.disabled = false;
        pctabletcheckbox.disabled = false;
        smartphonecheckbox.disabled = false;
        mobileothercheckbox.disabled = false;
        text3.disabled = false;
        text3.value = "";
        number2.disabled = false;
        number2.value = 0;

        registeredradio.disabled = true;
        registeredradio.checked = false;
        unregisteredradio.checked = false;
        unregisteredradio.disabled = true;
        text.disabled = true;
        text.value = "";
        text1.disabled = true;
        text1.value = "";

        // Show/hide section 7 and 8 content for Virus Infection
        toggleSection7Content('virusInfection');
        toggleSection8Content('virusInfection');

    } else if (changedCheckbox === otherCheckbox && otherCheckbox.checked) {
        registeredradio.disabled = true;
        unregisteredradio.disabled = true;
        text.disabled = true;
        text.value = "";
        text1.disabled = true;
        text1.value = "";
        intranetcheckbox.disabled = true;
        clientcheckbox.disabled = true;
        servercheckbox.disabled = true;
        intranetothercheckbox.disabled = true;
        text2.disabled = true;
        text2.value = "";
        number.disabled = true;
        number.value = 0;
        mobilecheckbox.disabled = true;
        mobilecheckbox.checked = false;
        pctabletcheckbox.disabled = true;
        pctabletcheckbox.checked = false;
        smartphonecheckbox.disabled = true;
        smartphonecheckbox.checked = false;
        mobileothercheckbox.disabled = true;
        mobileothercheckbox.checked = false;
        text3.disabled = true;
        text3.value = "";
        number2.disabled = true;
        number2.value = 0;

        // Show only "Others" in sections 7 and 8
        toggleSection7Content('other');
        toggleSection8Content('other');

    } else {
        // If unchecked, enable all checkboxes
        publicWebsiteCheckbox.disabled = false;
        virusInfectionCheckbox.disabled = false;
        otherCheckbox.disabled = false;
        registeredradio.disabled = true;
        unregisteredradio.disabled = true;
        text.disabled = true;
        text1.disabled = true;
        intranetcheckbox.disabled = true;
        clientcheckbox.disabled = true;
        servercheckbox.disabled = true;
        intranetothercheckbox.disabled = true;
        text2.disabled = true;
        number.disabled = true;
        mobilecheckbox.disabled = true;
        pctabletcheckbox.disabled = true;
        smartphonecheckbox.disabled = true;
        mobileothercheckbox.disabled = true;
        text3.disabled = true;
        number2.disabled = true;

        // Hide all section 7 and 8 specific content
        toggleSection7Content('none');
        toggleSection8Content('none');
    }
}

// Toggle Section 7 Content Based on Incident Type (Your existing function)
function toggleSection7Content(type) {
    // Get section 7 content divs
    const publicWebsiteContent = document.getElementById('publicwebsitecontent7');
    const virusInfectionContent = document.getElementById('virusinfectioncontent7');
    const othersContent = document.getElementById('othercontent7');

    if (!publicWebsiteContent || !virusInfectionContent || !othersContent) return;

    if (type === 'publicWebsite') {
        // Show Public Website content and Others
        publicWebsiteContent.style.display = 'block';
        virusInfectionContent.style.display = 'none';
        othersContent.style.display = 'block';

    } else if (type === 'virusInfection') {
        // Show only Virus Infection content and Others
        publicWebsiteContent.style.display = 'none';
        virusInfectionContent.style.display = 'block';
        othersContent.style.display = 'block';

    } else if (type === 'other') {
        // Show only Others
        publicWebsiteContent.style.display = 'none';
        virusInfectionContent.style.display = 'none';
        othersContent.style.display = 'block';

    } else {
        // Hide all (when nothing is selected)
        publicWebsiteContent.style.display = 'none';
        virusInfectionContent.style.display = 'none';
        othersContent.style.display = 'none';
    }
}

// ========== SECTION 8 CONTROL FUNCTIONS ==========

function toggleSection8Content(type) {
    // Get all Section 8 subsections by ID
    const interimMeasures = document.getElementById('interimMeasuresSection');
    const investigationDamage = document.getElementById('investigationDamageSection');
    const investigationCauses = document.getElementById('investigationCausesSection');
    const othersGrid = document.getElementById('othersRecoveryGrid');
    const othersSection = document.getElementById('othersAdditionalMeasures');
    const reopeningSection = document.getElementById('reopeningWebsiteSection');
    const recoveryMethod = document.getElementById('recoveryMethodSection');

    // Check if elements exist
    if (!interimMeasures || !investigationDamage || !investigationCauses || !othersGrid) {
        console.error('Section 8 elements not found!');
        return;
    }

    if (type === 'publicWebsite') {
        // ===== PUBLIC WEBSITE =====
        // Show all main sections
        interimMeasures.style.display = 'block';
        investigationDamage.style.display = 'block';
        investigationCauses.style.display = 'block';
        othersGrid.style.display = 'grid'; // Keep grid layout for 2 columns

        // Show/hide specific content
        hideVirusContentInSection8();
        showPublicWebsiteContentInSection8();

        // Show: Others + Reopening, Hide: Recovery method
        if (othersSection) othersSection.style.display = 'block';
        if (reopeningSection) reopeningSection.style.display = 'block';
        if (recoveryMethod) recoveryMethod.style.display = 'none';

    } else if (type === 'virusInfection') {
        // ===== VIRUS INFECTION =====
        // Show all main sections
        interimMeasures.style.display = 'block';
        investigationDamage.style.display = 'block';
        investigationCauses.style.display = 'block';
        othersGrid.style.display = 'block'; // Single column (only left side)

        // Show/hide specific content
        hidePublicWebsiteContentInSection8();
        showVirusContentInSection8();

        // Show: Others + Recovery method, Hide: Reopening
        if (othersSection) othersSection.style.display = 'block';
        if (reopeningSection) reopeningSection.style.display = 'none';
        if (recoveryMethod) recoveryMethod.style.display = 'block';

    } else if (type === 'other') {
        // ===== OTHER =====
        // Hide all main sections except Others
        interimMeasures.style.display = 'none';
        investigationDamage.style.display = 'none';
        investigationCauses.style.display = 'none';
        othersGrid.style.display = 'block'; // Single column

        // Show: Only Others, Hide: Reopening + Recovery method
        if (othersSection) othersSection.style.display = 'block';
        if (reopeningSection) reopeningSection.style.display = 'none';
        if (recoveryMethod) recoveryMethod.style.display = 'none';

    } else {
        // ===== NONE SELECTED =====
        // Hide everything
        interimMeasures.style.display = 'none';
        investigationDamage.style.display = 'none';
        investigationCauses.style.display = 'none';
        othersGrid.style.display = 'none';
        if (recoveryMethod) recoveryMethod.style.display = 'none';
    }
}

// Hide virus-specific content in all sections
function hideVirusContentInSection8() {
    // Interim Measures
    const interimDiv = document.getElementById('interimMeasuresSection');
    if (interimDiv) {
        const paragraphs = interimDiv.querySelectorAll('p');
        const labels = interimDiv.querySelectorAll('label');

        paragraphs.forEach(p => {
            if (p.textContent.includes('For Virus Infection')) {
                p.style.display = 'none';
            }
            if (p.textContent.includes('For Public Website')) {
                p.style.display = 'block';
            }
        });

        labels.forEach(label => {
            if (label.textContent.includes('Isolate infected devices')) {
                label.style.display = 'none';
            }
        });
    }

    // Investigation of Damage
    const damageDiv = document.getElementById('investigationDamageSection');
    if (damageDiv) {
        const paragraphs = damageDiv.querySelectorAll('p');
        const labels = damageDiv.querySelectorAll('label');

        paragraphs.forEach(p => {
            if (p.textContent.includes('For Virus Infection')) {
                p.style.display = 'none';
            }
            if (p.textContent.includes('For Public Website')) {
                p.style.display = 'block';
            }
        });

        labels.forEach(label => {
            const text = label.textContent;
            if (text.includes('Check for information stored in devices') ||
                text.includes('Check the access log to the server that holds important')) {
                label.style.display = 'none';
            } else if (!text.includes('Other')) {
                label.style.display = 'flex';
            }
        });
    }

    // Investigation of Causes
    const causesDiv = document.getElementById('investigationCausesSection');
    if (causesDiv) {
        const paragraphs = causesDiv.querySelectorAll('p');
        const labels = causesDiv.querySelectorAll('label');

        paragraphs.forEach(p => {
            if (p.textContent.includes('For Virus Infection')) {
                p.style.display = 'none';
            }
        });

        labels.forEach(label => {
            const text = label.textContent;
            if (text.includes('Collect information and obtain analysis result') ||
                text.includes('Check characteristics of the virus') ||
                text.includes('Check the proxy log') ||
                text.includes('User interview (suspicious emails') ||
                text.includes('Log investigation of devices')) {
                label.style.display = 'none';
            } else {
                label.style.display = 'flex';
            }
        });
    }
}

// Show public website content in all sections
function showPublicWebsiteContentInSection8() {
    // Already handled in hideVirusContentInSection8
    // Public website content is shown by default
}

// Hide public website content, show virus content
function hidePublicWebsiteContentInSection8() {
    // Interim Measures
    const interimDiv = document.getElementById('interimMeasuresSection');
    if (interimDiv) {
        const paragraphs = interimDiv.querySelectorAll('p');
        const labels = interimDiv.querySelectorAll('label');
        const divs = interimDiv.querySelectorAll('div[style*="flex-direction: column"]');

        paragraphs.forEach(p => {
            if (p.textContent.includes('For Public Website')) {
                p.style.display = 'none';
            }
            if (p.textContent.includes('For Virus Infection')) {
                p.style.display = 'block';
            }
        });

        // Hide public website checkboxes container
        if (divs[0]) {
            divs[0].style.display = 'none';
        }

        // Show virus checkbox
        labels.forEach(label => {
            if (label.textContent.includes('Isolate infected devices')) {
                label.style.display = 'flex';
            }
        });
    }

    // Investigation of Damage
    const damageDiv = document.getElementById('investigationDamageSection');
    if (damageDiv) {
        const paragraphs = damageDiv.querySelectorAll('p');
        const labels = damageDiv.querySelectorAll('label');

        paragraphs.forEach(p => {
            if (p.textContent.includes('For Public Website')) {
                p.style.display = 'none';
            }
            if (p.textContent.includes('For Virus Infection')) {
                p.style.display = 'block';
            }
        });

        labels.forEach(label => {
            const text = label.textContent;
            if (text.includes('Check that the website has been infected') ||
                text.includes('Check for information stored in the server') ||
                text.includes('Check the access log to the server (for the possibility')) {
                label.style.display = 'none';
            } else if (text.includes('Check for information stored in devices') ||
                text.includes('Check the access log to the server that holds important')) {
                label.style.display = 'flex';
            }
        });
    }

    // Investigation of Causes
    const causesDiv = document.getElementById('investigationCausesSection');
    if (causesDiv) {
        const paragraphs = causesDiv.querySelectorAll('p');
        const labels = causesDiv.querySelectorAll('label');

        paragraphs.forEach(p => {
            if (p.textContent.includes('For Virus Infection')) {
                p.style.display = 'block';
            }
        });

        labels.forEach(label => {
            const text = label.textContent;
            // Hide public website checkboxes
            if (text.includes('Check for publicly disclosed vulnerability') ||
                text.includes('Check for vulnerability in website') ||
                text.includes('Check that access right to the website') ||
                text.includes('Check for unfamiliar files in the server') ||
                text.includes('Check for illegal codes on the contents') ||
                text.includes('Check for illegal descriptions in the directory') ||
                text.includes('Check the server log') ||
                text.includes('Check the IPS/WAF log')) {
                label.style.display = 'none';
            }
            // Show virus checkboxes
            else if (text.includes('Collect information and obtain analysis result') ||
                text.includes('Check characteristics of the virus') ||
                text.includes('Check the proxy log') ||
                text.includes('User interview (suspicious emails') ||
                text.includes('Log investigation of devices')) {
                label.style.display = 'flex';
            }
        });
    }
}

// Show virus-specific content
function showVirusContentInSection8() {
    // Already handled in hidePublicWebsiteContentInSection8
}


// Add Timeline Row function
function addTimelineRowA() {
    const tbody = document.getElementById('timelineRowsA');
    const newRow = tbody.rows[0].cloneNode(true);
    // Clear the input values
    newRow.querySelectorAll('input, textarea').forEach(input => input.value = '');
    tbody.appendChild(newRow);
}

function addTimelineRowB() {
    const tbody = document.getElementById('timelineRowsB');
    const newRow = tbody.rows[0].cloneNode(true);
    // Clear the input values
    newRow.querySelectorAll('input, textarea').forEach(input => input.value = '');
    tbody.appendChild(newRow);
}

// Submit Logic
function handleSubmit(e) {
    e.preventDefault();
    const successDiv = document.getElementById('successMessage');
    if (successDiv) {
        successDiv.style.display = 'block';
        successDiv.scrollIntoView({ behavior: 'smooth' });
        setTimeout(() => {
            successDiv.style.display = 'none';
        }, 5000);
    }
}


// Function to add timeline row dynamically
function addTimelineRow() {
    const tbody = document.getElementById('timelineRows');
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
                        <td style="padding: 0.5rem; border: 1px solid #ddd;">
                            <input type="datetime-local" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;">
                        </td>
                        <td style="padding: 0.5rem; border: 1px solid #ddd;">
                            <textarea rows="2" style="width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.3rem;"></textarea>
                        </td>
                    `;
    tbody.appendChild(newRow);
}

// Update the existing tab switching logic to handle IT tabs
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('tab-btn')) {
        const tabName = e.target.getAttribute('data-tab');
        const container = e.target.closest('.helpdesk-container') || e.target.closest('.content');

        // Remove active class from all tabs and content in this container
        const allTabs = container.querySelectorAll('.tab-btn');
        const allContent = container.querySelectorAll('.tab-content');

        allTabs.forEach(tab => tab.classList.remove('active'));
        allContent.forEach(content => content.style.display = 'none');

        // Add active class to clicked tab
        e.target.classList.add('active');

        // Show corresponding content
        const targetContent = container.querySelector(`#tab-${tabName}`);
        if (targetContent) {
            targetContent.style.display = 'block';
        }
    }
});

// Close sidebar when clicking on nav links (mobile)
document.addEventListener('click', (e) => {
    if (e.target.closest('.nav-link') || e.target.closest('.policy-group-header') || e.target.closest('.btn-chip')) {
        if (window.innerWidth <= 1040 && sidebar.classList.contains('active')) {
            toggleSidebar();
        }
    }
});

// Service Item Click Handlers
document.addEventListener('click', function (e) {
    const serviceItem = e.target.closest('.service-item');
    if (!serviceItem) return;

    const label = serviceItem.querySelector('.service-label').textContent.trim();

    // Map service labels to content keys
    const contentMap = {
        'Facility Requests': 'facilityRequests',
        'Service Requests': 'serviceRequests',
        'Leave': 'leaveRequests',
        'OT': 'otRequests'
    };

    const contentKey = contentMap[label];
    if (contentKey) {
        loadContent(contentKey);

        // Close mobile sidebar if open
        if (window.innerWidth <= 1040 && sidebar && sidebar.classList.contains('active')) {
            toggleSidebar();
        }
    }
});

// Action Button Handlers with Comment Support
function handleAction(action, requestId) {
    const commentInput = document.getElementById(`comment-${requestId}`);
    const comment = commentInput ? commentInput.value.trim() : '';

    let message = '';

    switch (action) {
        case 'grant':
            if (!comment) {
                alert('⚠️ Please enter a comment before granting the request');
                commentInput.focus();
                return;
            }
            message = `✓ Request ${requestId} has been GRANTED\nComment: "${comment}"`;
            break;

        case 'reject':
            if (!comment) {
                alert('⚠️ Please enter a comment before rejecting the request');
                commentInput.focus();
                return;
            }
            message = `✗ Request ${requestId} has been REJECTED\nComment: "${comment}"`;
            break;

        case 'addLevel':
            message = `↑ Request ${requestId} escalated to next level`;
            if (comment) {
                message += `\nComment: "${comment}"`;
            }
            break;
    }

    alert(message);

    // Log the action with comment
    console.log({
        action: action,
        requestId: requestId,
        comment: comment,
        timestamp: new Date().toISOString()
    });

    // Optional: Remove the row after successful action
    if (action === 'grant' || action === 'reject') {
        const row = commentInput.closest('tr');
        row.style.opacity = '0';
        row.style.transition = 'opacity 0.3s ease';
        setTimeout(() => row.remove(), 300);
    }
}





// Diagnostic script to identify which fields are missing
function diagnoseFormAData() {
    console.log('🔍 FORM A DIAGNOSTIC - Checking all fields...\n');

    const data = collectFormAData();

    const missing = [];
    const found = [];

    // Check each field
    Object.keys(data).forEach(key => {
        const value = data[key];

        // Check if empty/null/undefined
        if (value === '' || value === null || value === undefined || value === 'N/A' || value === '0') {
            missing.push(key);
            console.log(`❌ MISSING: ${key} = "${value}"`);
        } else if (typeof value === 'object' && !Array.isArray(value)) {
            // Check object fields
            const objEmpty = Object.values(value).every(v => !v);
            if (objEmpty) {
                missing.push(key);
                console.log(`❌ MISSING: ${key} (all false)`);
            } else {
                found.push(key);
            }
        } else if (Array.isArray(value) && value.length === 0) {
            missing.push(key);
            console.log(`❌ MISSING: ${key} (empty array)`);
        } else {
            found.push(key);
            console.log(`✅ FOUND: ${key} = "${value}"`);
        }
    });

    console.log('\n📊 SUMMARY:');
    console.log(`✅ Fields found: ${found.length}`);
    console.log(`❌ Fields missing: ${missing.length}`);
    console.log('\n❌ Missing fields:', missing.join(', '));

    return { data, missing, found };
}

// Run it


// Diagnostic script to identify which fields are missing in Form B
function diagnoseFormBData() {
    console.log('🔍 FORM B DIAGNOSTIC - Checking all fields...\n');

    const data = collectFormBData();

    const missing = [];
    const found = [];

    // Check each field
    Object.keys(data).forEach(key => {
        const value = data[key];

        // Check if empty/null/undefined
        if (value === '' || value === null || value === undefined || value === 'N/A' || value === '0') {
            missing.push(key);
            console.log(`❌ MISSING: ${key} = "${value}"`);
        } else if (typeof value === 'object' && !Array.isArray(value)) {
            // Check object fields
            const objEmpty = Object.values(value).every(v => !v);
            if (objEmpty) {
                missing.push(key);
                console.log(`❌ MISSING: ${key} (all false)`);
            } else {
                found.push(key);
            }
        } else if (Array.isArray(value) && value.length === 0) {
            missing.push(key);
            console.log(`❌ MISSING: ${key} (empty array)`);
        } else {
            found.push(key);
            console.log(`✅ FOUND: ${key} = "${value}"`);
        }
    });

    console.log('\n📊 SUMMARY:');
    console.log(`✅ Fields found: ${found.length}`);
    console.log(`❌ Fields missing: ${missing.length}`);
    console.log('\n❌ Missing fields:', missing.join(', '));

    return { data, missing, found };
}

// Run it

// COMPREHENSIVE FORM B DIAGNOSTIC
function diagnoseFormBStructure() {
    console.log('🔍 FORM B COMPREHENSIVE DIAGNOSTIC\n');
    console.log('='.repeat(80));

    const formatB = document.getElementById('formatBContent');
    if (!formatB) {
        console.error('❌ formatBContent not found');
        return;
    }

    console.log('✅ formatBContent found\n');

    // ===== 1. CHECK EMPLOYEE FIELDS =====
    console.log('📌 1. EMPLOYEE FIELDS:');
    const empFields = ['empNameB', 'empJobTitleB', 'empDeptB', 'empDivB', 'empCompB'];
    empFields.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            console.log(`  ✅ #${id}: "${el.textContent || el.value}" (tag: ${el.tagName})`);
        } else {
            console.log(`  ❌ #${id}: NOT FOUND`);
        }
    });
    console.log('');

    // ===== 2. CHECK RADIO BUTTONS =====
    console.log('📌 2. RADIO BUTTONS:');
    const radioNames = [
        'jobCategoryB',
        'incidentTypeB',
        'reportStatusB',
        'alcoholIntakeB',
        'secondaryDamageB',
        'managerPermissionB',
        'windowsEncryptionB',
        'storageEncryptionB',
        'lossPreventionStrapB',
        'deleteRequestB'
    ];

    radioNames.forEach(name => {
        const radios = formatB.querySelectorAll(`input[name="${name}"]`);
        const checked = formatB.querySelector(`input[name="${name}"]:checked`);
        console.log(`  ${name}: ${radios.length} options, checked="${checked ? checked.value : 'NONE'}"`);
    });
    console.log('');

    // ===== 3. CHECK CHECKBOXES =====
    console.log('📌 3. CHECKBOXES:');
    const checkboxNames = [
        'unauthorizedItem',
        'disclosureMethod',
        'dataItems',
        'passwordTypeB',
        'encryptionToolB'
    ];

    checkboxNames.forEach(name => {
        const checkboxes = formatB.querySelectorAll(`input[name="${name}"]`);
        const checked = formatB.querySelectorAll(`input[name="${name}"]:checked`);
        console.log(`  ${name}: ${checkboxes.length} total, ${checked.length} checked`);
        if (checked.length > 0) {
            checked.forEach(cb => console.log(`    ✓ ${cb.value}`));
        }
    });
    console.log('');

    // ===== 4. CHECK ALL SECTIONS =====
    console.log('📌 4. SECTIONS:');
    const sections = formatB.querySelectorAll('.section-card');
    console.log(`  Total sections: ${sections.length}\n`);

    sections.forEach((section, idx) => {
        const numSpan = section.querySelector('.section-num');
        const sectionNum = numSpan ? numSpan.textContent.trim() : '?';

        console.log(`  📍 Section ${sectionNum} (index ${idx}):`);

        // Count inputs
        const textInputs = section.querySelectorAll('input[type="text"]');
        const numberInputs = section.querySelectorAll('input[type="number"]');
        const dateInputs = section.querySelectorAll('input[type="date"]');
        const datetimeInputs = section.querySelectorAll('input[type="datetime-local"]');
        const textareas = section.querySelectorAll('textarea');
        const radios = section.querySelectorAll('input[type="radio"]');
        const checkboxes = section.querySelectorAll('input[type="checkbox"]');

        console.log(`     Text inputs: ${textInputs.length}`);
        if (textInputs.length > 0) {
            textInputs.forEach((input, i) => {
                console.log(`       [${i}] id="${input.id}" name="${input.name}" value="${input.value}" placeholder="${input.placeholder}"`);
            });
        }

        console.log(`     Number inputs: ${numberInputs.length}`);
        if (numberInputs.length > 0) {
            numberInputs.forEach((input, i) => {
                console.log(`       [${i}] id="${input.id}" name="${input.name}" value="${input.value}"`);
            });
        }

        console.log(`     Date/DateTime inputs: ${dateInputs.length + datetimeInputs.length}`);
        console.log(`     Textareas: ${textareas.length}`);
        if (textareas.length > 0) {
            textareas.forEach((ta, i) => {
                console.log(`       [${i}] id="${ta.id}" name="${ta.name}" value="${ta.value.substring(0, 50)}${ta.value.length > 50 ? '...' : ''}"`);
            });
        }

        console.log(`     Radios: ${radios.length}`);
        console.log(`     Checkboxes: ${checkboxes.length}`);
        console.log('');
    });

    // ===== 5. CHECK TEXT INPUTS BY ID =====
    console.log('📌 5. TEXT INPUTS (by common IDs):');
    const textInputIds = [
        'outsourceeB',
        'locationOccurredB',
        'passwordOtherB',
        'encryptionToolOtherB',
        'securityMeasuresOtherB',
        'passwordChangeTarget',
        'responsiblePersonB'
    ];

    textInputIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            console.log(`  ✅ #${id}: "${el.value}"`);
        } else {
            console.log(`  ❌ #${id}: NOT FOUND`);
        }
    });
    console.log('');

    // ===== 6. CHECK TEXTAREAS BY ID =====
    console.log('📌 6. TEXTAREAS (by common IDs):');
    const textareaIds = [
        'otherTextbox2',
        'otherTextbox3',
        'secondaryTextboxB',
        'otherActionsUnauthorizedB',
        'deleteRequestReasonB',
        'otherActionsDisclosureB',
        'assumedCausesB',
        'preventiveMeasuresB',
        'remarksB'
    ];

    textareaIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            console.log(`  ✅ #${id}: "${el.value.substring(0, 50)}${el.value.length > 50 ? '...' : ''}"`);
        } else {
            console.log(`  ❌ #${id}: NOT FOUND`);
        }
    });
    console.log('');

    // ===== 7. ALL INPUTS SUMMARY =====
    console.log('📌 7. COMPLETE INPUT SUMMARY:');
    const allInputs = formatB.querySelectorAll('input, textarea, select');
    console.log(`  Total form elements: ${allInputs.length}\n`);

    console.log('  Elements WITH filled values:');
    let filledCount = 0;
    allInputs.forEach(el => {
        const value = el.value || (el.type === 'checkbox' || el.type === 'radio' ? (el.checked ? el.value : '') : '');
        if (value) {
            filledCount++;
            console.log(`    ${el.tagName} [type="${el.type}"] id="${el.id}" name="${el.name}" value="${value}"`);
        }
    });
    console.log(`  Total filled: ${filledCount}\n`);

    console.log('='.repeat(80));
}























updateCurrentDateLabel();
setInterval(updateCurrentDateLabel, 1000);