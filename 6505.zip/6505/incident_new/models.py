from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


# Employee/Asset Model - Maps to 'incidents' table
class EmployeeAsset(db.Model):
    __tablename__ = 'incidents'
    __table_args__ = (
        # Composite primary key: empId + assetId together
        db.PrimaryKeyConstraint('empId', 'assetId'),
        {'extend_existing': True}
    )
    
    # Columns (no individual primary_key=True anymore)
    empId = db.Column('empId', db.String(50), nullable=False)
    ename = db.Column('ename', db.String(200))
    company = db.Column('company', db.String(200))
    email = db.Column('email', db.String(200))
    mobno = db.Column('mobno', db.String(50))
    dept = db.Column('dept', db.String(200))
    divi = db.Column('divi', db.String(200))
    desig = db.Column('desig', db.String(200))
    assetId = db.Column('assetId', db.String(50), nullable=False)
    assetname = db.Column('assetname', db.String(200))
    
    def to_dict(self):
        return {
            'empId': self.empId,
            'ename': self.ename,
            'company': self.company,
            'email': self.email,
            'mobno': self.mobno,
            'dept': self.dept,
            'divi': self.divi,
            'desig': self.desig,
            'assetId': self.assetId,
            'assetname': self.assetname
        }


# Facility Requests Model
class FacilityRequest(db.Model):
    __tablename__ = 'facility_requests'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    case_id = db.Column('case_id', db.String(50), unique=True, nullable=False)
    category = db.Column('category', db.String(100))
    description = db.Column('description', db.Text)
    comment = db.Column('comment', db.Text)
    status = db.Column('status', db.String(20), default='pending')
    created_at = db.Column('created_at', db.DateTime, default=datetime.utcnow)
    updated_at = db.Column('updated_at', db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'case_id': self.case_id,
            'category': self.category,
            'description': self.description,
            'comment': self.comment,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


# Service Requests Model
class ServiceRequest(db.Model):
    __tablename__ = 'service_requests'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    case_id = db.Column('case_id', db.String(50), unique=True, nullable=False)
    category = db.Column('category', db.String(100))
    description = db.Column('description', db.Text)
    comment = db.Column('comment', db.Text)
    status = db.Column('status', db.String(20), default='pending')
    created_at = db.Column('created_at', db.DateTime, default=datetime.utcnow)
    updated_at = db.Column('updated_at', db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'case_id': self.case_id,
            'category': self.category,
            'description': self.description,
            'comment': self.comment,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


# Leave Requests Model
class LeaveRequest(db.Model):
    __tablename__ = 'leave_requests'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    employee_id = db.Column('employee_id', db.String(50))
    employee_name = db.Column('employee_name', db.String(100))
    leave_type = db.Column('leave_type', db.String(50))
    start_date = db.Column('start_date', db.Date)
    end_date = db.Column('end_date', db.Date)
    days = db.Column('days', db.Integer)
    reason = db.Column('reason', db.Text)
    status = db.Column('status', db.String(20), default='pending')
    created_at = db.Column('created_at', db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'employee_id': self.employee_id,
            'employee_name': self.employee_name,
            'leave_type': self.leave_type,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'days': self.days,
            'reason': self.reason,
            'status': self.status
        }


# OT Requests Model
class OTRequest(db.Model):
    __tablename__ = 'ot_requests'
    __table_args__ = {'extend_existing': True}
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    employee_id = db.Column('employee_id', db.String(50))
    employee_name = db.Column('employee_name', db.String(100))
    date = db.Column('date', db.Date)
    hours = db.Column('hours', db.Float)
    reason = db.Column('reason', db.Text)
    status = db.Column('status', db.String(20), default='pending')
    created_at = db.Column('created_at', db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'employee_id': self.employee_id,
            'employee_name': self.employee_name,
            'date': self.date.isoformat() if self.date else None,
            'hours': self.hours,
            'reason': self.reason,
            'status': self.status
        }


# IT Incidents Model (Form A + Form B storage)
class ITIncident(db.Model):
    __tablename__ = 'it_incidents'
    __table_args__ = {'extend_existing': True}
    
    # id is NOT IDENTITY in your table, so we'll set it manually in code
    id = db.Column(db.Integer, primary_key=True)
    incident_id = db.Column(db.String(40), unique=True, nullable=False)
    form_type = db.Column(db.String(1), nullable=False)          # 'A' or 'B'
    report_date = db.Column(db.DateTime, nullable=False)
    incident_type = db.Column(db.String(100))
    department = db.Column(db.String(150))
    severity = db.Column(db.String(50))
    status = db.Column(db.String(50))
    report_status = db.Column(db.String(50))
    form_data = db.Column(db.Text, nullable=False)               # JSON as text
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_summary_dict(self):
        return {
            'incident_id': self.incident_id,
            'form_type': self.form_type,
            'report_date': self.report_date.date().isoformat() if self.report_date else None,
            'incident_type': self.incident_type,
            'department': self.department,
            'severity': self.severity,
            'status': self.status,
            'report_status': self.report_status
        }
