﻿from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from config import Config
from models import db, EmployeeAsset, FacilityRequest, ServiceRequest, LeaveRequest, OTRequest, ITIncident
from datetime import datetime
from sqlalchemy import func
import json
import traceback

app = Flask(__name__, static_folder='static')
app.config.from_object(Config)

# Initialize database
db.init_app(app)
CORS(app)

# NOTE: We do NOT create tables since they already exist
# with app.app_context():
#     db.create_all()  # SKIP THIS - tables already exist


# ============== SERVE FRONTEND FILES ==============

@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('static', 'Index_2.html')


@app.route('/<path:path>')
def serve_static(path):
    """Serve static files (CSS, JS, images)"""
    return send_from_directory('static', path)


# ============== HELPER FUNCTIONS FOR IT INCIDENTS ==============







# ============== EMPLOYEE/ASSET API ROUTES ==============

@app.route('/api/employees', methods=['GET'])
def get_all_employees():
    """Get all employees with their assets"""
    try:
        employees = EmployeeAsset.query.all()
        return jsonify({
            'success': True,
            'data': [emp.to_dict() for emp in employees],
            'count': len(employees)
        })
    except Exception as e:
        app.logger.error(f"Error fetching employees: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/employees/<emp_id>', methods=['GET'])
def get_employee(emp_id):
    try:
        app.logger.info(f"Fetching employee: {emp_id}")
        
        # Get ALL rows for this employee (multiple assets)
        employee_records = db.session.query(EmployeeAsset).filter_by(empId=emp_id).all()
        
        if not employee_records or len(employee_records) == 0:
            app.logger.warning(f"Employee {emp_id} not found")
            return jsonify({'error': 'Employee not found'}), 404
        
        app.logger.info(f"Found {len(employee_records)} records for employee {emp_id}")
        
        # Use first record for employee details
        first_record = employee_records[0]
        
        # Collect all unique assets
        assets = []
        seen_assets = set()
        
        for record in employee_records:
            if record.assetId and record.assetname:
                asset_key = f"{record.assetId}_{record.assetname}"
                if asset_key not in seen_assets:
                    assets.append({
                        'assetId': record.assetId,
                        'assetname': record.assetname
                    })
                    seen_assets.add(asset_key)
                    app.logger.info(f"  Asset: {record.assetname} ({record.assetId})")
        
        # Return employee data with assets array
        employee_data = {
            'empId': first_record.empId,
            'ename': first_record.ename,
            'company': first_record.company,
            'email': first_record.email,
            'mobno': first_record.mobno,
            'dept': first_record.dept,
            'divi': first_record.divi,
            'desig': first_record.desig,
            'assets': assets  # Array of assets
        }
        
        app.logger.info(f"Employee {emp_id} found: {first_record.ename} with {len(assets)} assets")
        return jsonify({'success': True, 'data': employee_data}), 200
        
    except Exception as e:
        app.logger.error(f"Error fetching employee {emp_id}: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/employees/search', methods=['POST'])
def search_employee():
    """Search employee by empId, name, email, or department"""
    try:
        data = request.get_json()
        search_term = data.get('search', '').strip()
        
        if not search_term:
            return jsonify({'success': False, 'error': 'Search term required'}), 400
        
        # Search in multiple fields
        employees = EmployeeAsset.query.filter(
            db.or_(
                EmployeeAsset.empId.ilike(f'%{search_term}%'),
                EmployeeAsset.ename.ilike(f'%{search_term}%'),
                EmployeeAsset.email.ilike(f'%{search_term}%'),
                EmployeeAsset.dept.ilike(f'%{search_term}%')
            )
        ).all()
        
        return jsonify({
            'success': True,
            'data': [emp.to_dict() for emp in employees],
            'count': len(employees)
        })
    except Exception as e:
        app.logger.error(f"Error searching employees: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============== FACILITY REQUESTS API ==============

@app.route('/api/facility-requests', methods=['GET'])
def get_facility_requests():
    """Get all pending facility requests"""
    try:
        status_filter = request.args.get('status', 'pending')
        requests_data = FacilityRequest.query.filter_by(status=status_filter).all()
        
        return jsonify({
            'success': True,
            'data': [req.to_dict() for req in requests_data],
            'count': len(requests_data)
        })
    except Exception as e:
        app.logger.error(f"Error fetching facility requests: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/facility-requests/<case_id>', methods=['PUT'])
def update_facility_request(case_id):
    """Update facility request status and comment"""
    try:
        data = request.get_json()
        req = FacilityRequest.query.filter_by(case_id=case_id).first()
        
        if not req:
            return jsonify({'success': False, 'error': 'Request not found'}), 404
        
        if 'status' in data:
            req.status = data['status']
        if 'comment' in data:
            req.comment = data['comment']
        
        req.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Request {case_id} updated successfully',
            'data': req.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error updating facility request: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============== SERVICE REQUESTS API ==============

@app.route('/api/service-requests', methods=['GET'])
def get_service_requests():
    """Get all pending service requests"""
    try:
        status_filter = request.args.get('status', 'pending')
        requests_data = ServiceRequest.query.filter_by(status=status_filter).all()
        
        return jsonify({
            'success': True,
            'data': [req.to_dict() for req in requests_data],
            'count': len(requests_data)
        })
    except Exception as e:
        app.logger.error(f"Error fetching service requests: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/service-requests/<case_id>', methods=['PUT'])
def update_service_request(case_id):
    """Update service request status and comment"""
    try:
        data = request.get_json()
        req = ServiceRequest.query.filter_by(case_id=case_id).first()
        
        if not req:
            return jsonify({'success': False, 'error': 'Request not found'}), 404
        
        if 'status' in data:
            req.status = data['status']
        if 'comment' in data:
            req.comment = data['comment']
        
        req.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Request {case_id} updated successfully',
            'data': req.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error updating service request: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============== LEAVE REQUESTS API ==============

@app.route('/api/leave-requests', methods=['GET'])
def get_leave_requests():
    """Get all pending leave requests"""
    try:
        status_filter = request.args.get('status', 'pending')
        requests_data = LeaveRequest.query.filter_by(status=status_filter).all()
        
        return jsonify({
            'success': True,
            'data': [req.to_dict() for req in requests_data],
            'count': len(requests_data)
        })
    except Exception as e:
        app.logger.error(f"Error fetching leave requests: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============== OT REQUESTS API ==============

@app.route('/api/ot-requests', methods=['GET'])
def get_ot_requests():
    """Get all pending OT requests"""
    try:
        status_filter = request.args.get('status', 'pending')
        requests_data = OTRequest.query.filter_by(status=status_filter).all()
        
        return jsonify({
            'success': True,
            'data': [req.to_dict() for req in requests_data],
            'count': len(requests_data)
        })
    except Exception as e:
        app.logger.error(f"Error fetching OT requests: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============== IT INCIDENTS API (Form A + Form B) ==============

@app.route('/api/it-incidents', methods=['POST'])
def create_it_incident():
    """
    Insert a new IT incident from Form A or Form B.
    Expects JSON:
    {
      "formtype": "A" or "B",
      "formdata": { ...full form data... }
    }
    """
    try:
        body = request.get_json() or {}
        form_type = body.get('formtype')  # Match frontend: formtype not form_type
        data = body.get('formdata') or {}  # Match frontend: formdata not form_data

        if form_type not in ('A', 'B'):
            return jsonify({'success': False, 'error': 'Invalid form_type'}), 400

        # Summary fields (common between Form A and B)
        report_status = data.get('reportStatus')
        incident_type = data.get('incidentType')
        department = (
            data.get('department')
            or data.get('personInvolvedDept')
            or data.get('companyName')
        )
        severity = data.get('severity') or 'Medium'
        status = data.get('status') or 'Under Investigation'

        # Report date
        reported_on = data.get('reportedDate') or data.get('reportedDateB')
        try:
            report_date = datetime.fromisoformat(reported_on)
        except Exception:
            report_date = datetime.utcnow()

        # Generate incident_id (ITA-2026-001, ITB-2026-002, etc.)
        year = datetime.utcnow().year
        prefix = 'ITA' if form_type == 'A' else 'ITB'
        
        # Get the next sequence number for this form type
        last_incident = (
            ITIncident.query
            .filter(ITIncident.incident_id.like(f'{prefix}-{year}-%'))
            .order_by(ITIncident.id.desc())
            .first()
        )
        
        if last_incident:
            # Extract number from ITA-2026-001 → 001
            parts = last_incident.incident_id.split('-')
            next_num = int(parts[-1]) + 1
        else:
            next_num = 1
        
        incident_id = f"{prefix}-{year}-{next_num:03d}"

        # Create incident WITHOUT manually setting id - let SQL Server auto-generate it
        incident = ITIncident(
            # DO NOT SET id here - it's auto-generated by IDENTITY
            incident_id=incident_id,
            form_type=form_type,
            report_date=report_date,
            incident_type=incident_type,
            department=department,
            severity=severity,
            status=status,
            report_status=report_status,
            form_data=json.dumps(data),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )

        db.session.add(incident)
        db.session.commit()

        # Return incidentid (not incident_id) to match frontend expectation
        return jsonify({'success': True, 'incidentid': incident_id}), 201
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error creating IT incident: {e}\n{traceback.format_exc()}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/it-incidents', methods=['GET'])
def list_it_incidents():
    """List all IT incidents for Logged IT table."""
    try:
        incidents = (
            ITIncident.query
            .order_by(ITIncident.report_date.desc(), ITIncident.incident_id.desc())
            .all()
        )
        data = [inc.to_summary_dict() for inc in incidents]
        return jsonify({'success': True, 'data': data, 'count': len(data)})
    except Exception as e:
        app.logger.error(f"Error listing IT incidents: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/it-incidents/<incident_id>', methods=['GET'])
def get_it_incident(incident_id):
    """Get one IT incident (full JSON) for View button."""
    try:
        incident = ITIncident.query.filter_by(incident_id=incident_id).first()
        if not incident:
            return jsonify({'success': False, 'error': 'Not found'}), 404

        # Parse form_data if it's a JSON string
        form_data = incident.form_data
        if isinstance(form_data, str):
            try:
                form_data = json.loads(form_data)
            except json.JSONDecodeError:
                pass
        
        return jsonify({
            'success': True,
            'form_type': incident.form_type,
            'data': form_data
        })
    except Exception as e:
        app.logger.error(f"Error fetching IT incident {incident_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/it-incidents/<incident_id>', methods=['PUT'])
def update_it_incident(incident_id):
    """Update an existing IT incident"""
    try:
        # Get JSON data from request
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Find the incident
        incident = ITIncident.query.filter_by(incident_id=incident_id).first()
        
        if not incident:
            return jsonify({
                'success': False,
                'error': f'Incident {incident_id} not found'
            }), 404
        
        # Update form_data if provided
        if 'form_data' in data:
            form_data = data['form_data']
            # Convert dict to JSON string for storage
            if isinstance(form_data, dict):
                incident.form_data = json.dumps(form_data)
            else:
                incident.form_data = form_data
        
        # Update other fields if provided
        updateable_fields = ['status', 'severity', 'report_status', 'department', 'incident_type']
        for field in updateable_fields:
            if field in data and hasattr(incident, field):
                setattr(incident, field, data[field])
        
        # Update timestamp
        incident.updated_at = datetime.utcnow()
        
        # Commit to database
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Incident {incident_id} updated successfully',
            'data': {
                'incident_id': incident.incident_id,
                'updated_at': incident.updated_at.isoformat()
            }
        }), 200
        
    except Exception as e:
        # Rollback on error
        db.session.rollback()
        app.logger.error(f"Error updating incident {incident_id}: {str(e)}")
        
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ============== DASHBOARD SUMMARY API ==============

@app.route('/api/dashboard/counts', methods=['GET'])
def get_dashboard_counts():
    """Get counts of all pending requests for dashboard"""
    try:
        counts = {
            'facility_requests': FacilityRequest.query.filter_by(status='pending').count(),
            'service_requests': ServiceRequest.query.filter_by(status='pending').count(),
            'leave_requests': LeaveRequest.query.filter_by(status='pending').count(),
            'ot_requests': OTRequest.query.filter_by(status='pending').count()
        }
        return jsonify({'success': True, 'data': counts})
    except Exception as e:
        app.logger.error(f"Error fetching dashboard counts: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============== HEALTH CHECK ==============

@app.route('/api/health', methods=['GET'])
def health_check():
    """Check if API is running"""
    return jsonify({
        'success': True,
        'message': 'API is running',
        'timestamp': datetime.utcnow().isoformat()
    })


# ============== ERROR HANDLERS ==============

@app.errorhandler(404)
def not_found(error):
    return jsonify({'success': False, 'error': 'Endpoint not found'}), 404


@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify({'success': False, 'error': 'Method not allowed'}), 405


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return jsonify({'success': False, 'error': 'Internal server error'}), 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)