#!/usr/bin/env python3
"""
Cosmic Corner Sales - Server
SQLite Database Backend with NOBITA Integration
"""

import json
import os
import sys
import base64
import time
import sqlite3
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote
import mimetypes

# ============================================================================
# CONFIGURATION
# ============================================================================

def get_port():
    """Read port from MainServer's config.json (NOBITA integration)"""
    config_path = Path(__file__).parent.parent / "config.json"
    if config_path.exists():
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                folder_name = Path(__file__).parent.name
                port = config.get("folders", {}).get(folder_name)
                if port:
                    return port
        except Exception as e:
            print(f"[ERROR] Failed to read port from config: {e}")
    return 8000  # Default port

# ============================================================================
# DATABASE SETUP
# ============================================================================

class Database:
    """SQLite Database Manager"""
    
    def __init__(self, db_path):
        self.db_path = db_path
        self.init_database()
    
    def get_connection(self):
        """Get a new database connection"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        """Initialize database tables"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Create entries table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                form_name TEXT NOT NULL,
                date TEXT,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                amount REAL NOT NULL,
                remarks TEXT,
                image_path TEXT,
                timestamp TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create index on form_name for faster queries
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_form_name 
            ON entries(form_name)
        ''')
        
        conn.commit()
        conn.close()
        
        print(f"[Database] Initialized at {self.db_path}")
    
    def add_entry(self, form_name, date, product_name, quantity, amount, remarks, image_path, timestamp):
        """Add a new entry"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO entries (form_name, date, product_name, quantity, amount, remarks, image_path, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (form_name, date, product_name, quantity, amount, remarks, image_path, timestamp))
        
        entry_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return entry_id
    
    def get_entries(self, form_name=None):
        """Get all entries or entries for a specific form"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        if form_name:
            cursor.execute('''
                SELECT * FROM entries 
                WHERE form_name = ? 
                ORDER BY date DESC, timestamp DESC
            ''', (form_name,))
        else:
            cursor.execute('''
                SELECT * FROM entries 
                ORDER BY date DESC, timestamp DESC
            ''')
        
        rows = cursor.fetchall()
        entries = [dict(row) for row in rows]
        conn.close()
        
        return entries
    
    def get_entry(self, entry_id):
        """Get a specific entry by ID"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM entries WHERE id = ?', (entry_id,))
        row = cursor.fetchone()
        conn.close()
        
        return dict(row) if row else None
    
    def update_entry(self, entry_id, date, product_name, quantity, amount, remarks):
        """Update an existing entry"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE entries 
            SET date = ?, product_name = ?, quantity = ?, amount = ?, remarks = ?
            WHERE id = ?
        ''', (date, product_name, quantity, amount, remarks, entry_id))
        
        conn.commit()
        conn.close()
    
    def delete_entry(self, entry_id):
        """Delete an entry and return its image path"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Get image path before deleting
        cursor.execute('SELECT image_path FROM entries WHERE id = ?', (entry_id,))
        row = cursor.fetchone()
        image_path = row['image_path'] if row else None
        
        # Delete entry
        cursor.execute('DELETE FROM entries WHERE id = ?', (entry_id,))
        conn.commit()
        conn.close()
        
        return image_path
    
    def get_forms(self):
        """Get list of all form names"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT DISTINCT form_name FROM entries ORDER BY form_name')
        rows = cursor.fetchall()
        forms = [row['form_name'] for row in rows]
        conn.close()
        
        return forms
    
    def get_form_stats(self, form_name):
        """Get statistics for a specific form"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT 
                COUNT(*) as count,
                SUM(quantity) as total_qty,
                SUM(amount) as total_amount
            FROM entries 
            WHERE form_name = ?
        ''', (form_name,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'count': row['count'] or 0,
                'totalQty': row['total_qty'] or 0,
                'total': row['total_amount'] or 0
            }
        return {'count': 0, 'totalQty': 0, 'total': 0}

# ============================================================================
# SETUP DIRECTORIES
# ============================================================================

def setup_directories():
    """Ensure required directories exist"""
    base_dir = Path(__file__).parent
    images_dir = base_dir / 'images'
    
    if not images_dir.exists():
        images_dir.mkdir(parents=True, exist_ok=True)
    
    db_path = base_dir / 'sales.db'
    
    return base_dir, images_dir, db_path

# ============================================================================
# REQUEST HANDLER
# ============================================================================

class CosmicCornerHandler(SimpleHTTPRequestHandler):
    """Custom HTTP handler for Cosmic Corner Sales"""
    
    db = None  # Will be set by server
    images_dir = None
    base_dir = None
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(self.base_dir), **kwargs)
    
    def log_message(self, format, *args):
        """Custom logging with folder name prefix"""
        folder_name = Path(__file__).parent.name
        print(f"[{folder_name}] {args[0]}")
    
    def send_json_response(self, data, status=200):
        """Send a JSON response"""
        try:
            response_data = json.dumps(data)
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(response_data)))
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(response_data.encode())
        except Exception as e:
            print(f"[ERROR] Failed to send response: {e}")
    
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def do_GET(self):
        """Handle GET requests"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        query = parse_qs(parsed_path.query)
        
        # Serve index.html for root path
        if path == '/':
            path = '/index.html'
        
        # API Routes
        if path == '/api/forms':
            # Get all form names
            forms = self.db.get_forms()
            self.send_json_response({'forms': forms})
        
        elif path.startswith('/api/forms/') and path.endswith('/stats'):
            # Get stats for a specific form
            form_name = unquote(path.split('/')[3])
            stats = self.db.get_form_stats(form_name)
            self.send_json_response(stats)
        
        elif path == '/api/entries':
            # Get entries (optionally filtered by form name)
            form_name = query.get('formName', [None])[0]
            if form_name:
                form_name = unquote(form_name)
            entries = self.db.get_entries(form_name)
            self.send_json_response({'entries': entries})
        
        elif path.startswith('/api/entries/'):
            # Get specific entry
            entry_id = int(path.split('/')[-1])
            entry = self.db.get_entry(entry_id)
            if entry:
                self.send_json_response(entry)
            else:
                self.send_json_response({'error': 'Entry not found'}, 404)
        
        elif path == '/api/backup':
            # Download database backup
            try:
                with open(self.db.db_path, 'rb') as f:
                    content = f.read()
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Disposition', f'attachment; filename="backup-{int(time.time())}.db"')
                self.send_header('Content-Length', len(content))
                self.end_headers()
                self.wfile.write(content)
            except Exception as e:
                print(f"[ERROR] Backup failed: {e}")
                self.send_json_response({'error': 'Backup failed'}, 500)
        
        else:
            # Serve static files
            self.path = path
            super().do_GET()
    
    def do_POST(self):
        """Handle POST requests"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        
        try:
            data = json.loads(body)
        except json.JSONDecodeError as e:
            print(f"[ERROR] JSON parse error: {e}")
            self.send_json_response({'error': 'Invalid JSON'}, 400)
            return
        
        if path == '/api/entries':
            # Add new entry
            try:
                form_name = data.get('formName', '').strip()
                date = data.get('date', '')
                product_name = data.get('productName', '').strip()
                qty = int(data.get('qty', 0))
                amount = float(data.get('amount', 0))
                remarks = data.get('remarks', '').strip()
                image_data = data.get('image')
                timestamp = data.get('timestamp', time.strftime("%Y-%m-%dT%H:%M:%S.000Z"))
                
                if not form_name or not product_name or qty <= 0 or amount < 0:
                    self.send_json_response({'error': 'Invalid data'}, 400)
                    return
                
                # Handle image if provided
                image_path = None
                if image_data and image_data.startswith('data:image'):
                    try:
                        header, encoded = image_data.split(",", 1)
                        file_ext = header.split(';')[0].split('/')[1]
                        image_bytes = base64.b64decode(encoded)
                        
                        filename = f"img_{int(time.time() * 1000)}.{file_ext}"
                        filepath = self.images_dir / filename
                        
                        with open(filepath, 'wb') as img_file:
                            img_file.write(image_bytes)
                        
                        image_path = f"images/{filename}"
                    except Exception as e:
                        print(f"[ERROR] Failed to save image: {e}")
                
                # Add entry to database
                entry_id = self.db.add_entry(
                    form_name, date, product_name, qty, amount, remarks, image_path, timestamp
                )
                
                self.send_json_response({
                    'success': True,
                    'id': entry_id,
                    'message': 'Entry saved successfully'
                })
            
            except Exception as e:
                print(f"[ERROR] Failed to save entry: {e}")
                self.send_json_response({'error': str(e)}, 500)
        
        else:
            self.send_json_response({'error': 'Not found'}, 404)
    
    def do_PUT(self):
        """Handle PUT requests"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            self.send_json_response({'error': 'Invalid JSON'}, 400)
            return
        
        if path.startswith('/api/entries/'):
            # Update entry
            try:
                entry_id = int(path.split('/')[-1])
                
                date = data.get('date', '')
                product_name = data.get('productName', '').strip()
                qty = int(data.get('qty', 0))
                amount = float(data.get('amount', 0))
                remarks = data.get('remarks', '').strip()
                
                if not product_name or qty <= 0 or amount < 0:
                    self.send_json_response({'error': 'Invalid data'}, 400)
                    return
                
                self.db.update_entry(entry_id, date, product_name, qty, amount, remarks)
                
                self.send_json_response({
                    'success': True,
                    'message': 'Entry updated successfully'
                })
            
            except Exception as e:
                print(f"[ERROR] Failed to update entry: {e}")
                self.send_json_response({'error': str(e)}, 500)
        
        else:
            self.send_json_response({'error': 'Not found'}, 404)
    
    def do_DELETE(self):
        """Handle DELETE requests"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        if path.startswith('/api/entries/'):
            # Delete entry
            try:
                entry_id = int(path.split('/')[-1])
                
                # Delete entry and get image path
                image_path = self.db.delete_entry(entry_id)
                
                # Delete image file if exists
                if image_path:
                    full_image_path = self.base_dir / image_path
                    if full_image_path.exists():
                        try:
                            os.remove(full_image_path)
                        except Exception as e:
                            print(f"[ERROR] Failed to delete image: {e}")
                
                self.send_json_response({
                    'success': True,
                    'message': 'Entry deleted successfully'
                })
            
            except Exception as e:
                print(f"[ERROR] Failed to delete entry: {e}")
                self.send_json_response({'error': str(e)}, 500)
        
        else:
            self.send_json_response({'error': 'Not found'}, 404)

# ============================================================================
# MAIN SERVER
# ============================================================================

def main():
    """Start the server"""
    port = get_port()
    base_dir, images_dir, db_path = setup_directories()
    
    # Initialize database
    db = Database(db_path)
    
    # Set class variables
    CosmicCornerHandler.db = db
    CosmicCornerHandler.images_dir = images_dir
    CosmicCornerHandler.base_dir = base_dir
    
    # Print startup info
    folder_name = Path(__file__).parent.name
    print(f"\n{'='*60}")
    print(f"   COSMIC CORNER SALES SERVER")
    print(f"{'='*60}")
    print(f"   Folder: {folder_name}")
    print(f"   Port:   {port}")
    print(f"   Local:  http://localhost:{port}")
    print(f"   DB:     {db_path}")
    print(f"   Images: {images_dir}")
    print(f"{'='*60}\n")
    
    try:
        server = HTTPServer(('0.0.0.0', port), CosmicCornerHandler)
        print(f"[{folder_name}] Server running on port {port}")
        server.serve_forever()
    except KeyboardInterrupt:
        print(f"\n[{folder_name}] Server stopped")
        sys.exit(0)
    except Exception as e:
        print(f"[ERROR] {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
