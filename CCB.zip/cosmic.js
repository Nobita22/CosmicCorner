// ============================================================================
// COSMIC CORNER - BACKGROUND ANIMATIONS
// Stars, Shooting Stars, and Cosmic Dust
// ============================================================================

(function() {
    'use strict';
    
    const container = document.getElementById('starsContainer');
    if (!container) {
        console.warn('Stars container not found');
        return;
    }
    
    // ========================================================================
    // HELPER FUNCTIONS
    // ========================================================================
    
    /**
     * Check if position is in content area (to avoid placing stars there)
     */
    function isInContentArea(x, y) {
        const screenWidth = window.innerWidth;
        const screenHeight = window.innerHeight;
        const contentWidth = 450; // max-w-md is ~448px
        const contentLeft = (screenWidth - contentWidth) / 2;
        const contentRight = contentLeft + contentWidth;
        const contentTop = 60; // header height
        const contentBottom = screenHeight - 50;
        
        const pixelX = (x / 100) * screenWidth;
        const pixelY = (y / 100) * screenHeight;
        
        return pixelX > contentLeft - 20 && pixelX < contentRight + 20 && 
               pixelY > contentTop && pixelY < contentBottom;
    }
    
    /**
     * Get random position avoiding content area
     */
    function getRandomPosition() {
        let x, y, attempts = 0;
        do {
            x = Math.random() * 100;
            y = Math.random() * 100;
            attempts++;
        } while (isInContentArea(x, y) && attempts < 50);
        return { x, y };
    }
    
    /**
     * Create a single star element
     */
    function createStar(type) {
        const star = document.createElement('div');
        star.className = `star ${type}`;
        
        const pos = getRandomPosition();
        star.style.left = pos.x + '%';
        star.style.top = pos.y + '%';
        star.style.setProperty('--delay', (Math.random() * 4) + 's');
        star.style.setProperty('--duration', (2 + Math.random() * 3) + 's');
        star.style.setProperty('--min-opacity', (0.1 + Math.random() * 0.2));
        star.style.setProperty('--max-opacity', (0.5 + Math.random() * 0.4));
        
        return star;
    }
    
    /**
     * Create a cosmic dust particle
     */
    function createCosmicDust() {
        const dust = document.createElement('div');
        dust.className = 'cosmic-dust';
        
        const pos = getRandomPosition();
        dust.style.left = pos.x + '%';
        dust.style.top = pos.y + '%';
        dust.style.animationDelay = (Math.random() * 20) + 's';
        dust.style.animationDuration = (15 + Math.random() * 10) + 's';
        
        return dust;
    }
    
    // ========================================================================
    // INITIALIZE STARS
    // ========================================================================
    
    function initializeStars() {
        const starTypes = ['tiny', 'tiny', 'tiny', 'small', 'small', 'medium', 'bright'];
        const fragment = document.createDocumentFragment();
        
        // Create 100 twinkling stars
        for (let i = 0; i < 100; i++) {
            const type = starTypes[Math.floor(Math.random() * starTypes.length)];
            const star = createStar(type);
            fragment.appendChild(star);
        }
        
        container.appendChild(fragment);
    }
    
    // ========================================================================
    // INITIALIZE COSMIC DUST
    // ========================================================================
    
    function initializeCosmicDust() {
        const fragment = document.createDocumentFragment();
        
        // Create 40 cosmic dust particles
        for (let i = 0; i < 40; i++) {
            const dust = createCosmicDust();
            fragment.appendChild(dust);
        }
        
        container.appendChild(fragment);
    }
    
    // ========================================================================
    // SHOOTING STARS
    // ========================================================================
    
    /**
     * Launch a shooting star
     */
    function launchShootingStar() {
        const shootingStar = document.createElement('div');
        shootingStar.className = 'shooting-star';
        
        // Random edge to start from
        // 0 = top edge, 1 = left edge, 2 = top-right area
        const edge = Math.floor(Math.random() * 3);
        let startX, startY, angle;
        
        if (edge === 0) {
            // From top edge
            startX = 10 + Math.random() * 80;
            startY = -5 + Math.random() * 15;
            angle = 25 + Math.random() * 40;
        } else if (edge === 1) {
            // From left edge
            startX = -5 + Math.random() * 15;
            startY = 10 + Math.random() * 40;
            angle = 20 + Math.random() * 30;
        } else {
            // From top-right going left-down
            startX = 60 + Math.random() * 35;
            startY = -5 + Math.random() * 20;
            angle = 30 + Math.random() * 25;
        }
        
        shootingStar.style.left = startX + '%';
        shootingStar.style.top = startY + '%';
        
        // Travel distance
        const travelX = 150 + Math.random() * 300;
        const travelY = travelX * Math.tan(angle * Math.PI / 180);
        
        // Duration
        const duration = 0.8 + Math.random() * 1.2;
        
        shootingStar.style.setProperty('--angle', angle + 'deg');
        shootingStar.style.setProperty('--travel-x', travelX + 'px');
        shootingStar.style.setProperty('--travel-y', travelY + 'px');
        shootingStar.style.setProperty('--shoot-duration', duration + 's');
        
        container.appendChild(shootingStar);
        
        // Trigger animation
        requestAnimationFrame(() => {
            shootingStar.classList.add('active');
        });
        
        // Remove after animation
        setTimeout(() => {
            shootingStar.remove();
        }, duration * 1000 + 100);
    }
    
    /**
     * Schedule next shooting star
     */
    function scheduleShootingStar() {
        const delay = 1500 + Math.random() * 4000; // 1.5-5.5 seconds
        setTimeout(() => {
            launchShootingStar();
            scheduleShootingStar();
        }, delay);
    }
    
    // ========================================================================
    // INITIALIZE ALL EFFECTS
    // ========================================================================
    
    function initializeCosmicEffects() {
        // Clear existing content
        container.innerHTML = '';
        
        // Create stars
        initializeStars();
        
        // Create cosmic dust
        initializeCosmicDust();
        
        // Launch initial shooting stars
        setTimeout(() => launchShootingStar(), 800);
        setTimeout(() => launchShootingStar(), 2000);
        setTimeout(() => launchShootingStar(), 3500);
        
        // Schedule continuous shooting stars
        scheduleShootingStar();
    }
    
    // ========================================================================
    // WINDOW RESIZE HANDLER
    // ========================================================================
    
    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            initializeCosmicEffects();
        }, 500);
    });
    
    // ========================================================================
    // START
    // ========================================================================
    
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeCosmicEffects);
    } else {
        initializeCosmicEffects();
    }
    
})();
