// ============================================================================
// COSMIC CORNER SALES - MAIN APPLICATION
// Complete JavaScript with SQLite Integration
// ============================================================================

let editingIndex = null;
let currentFormName = '';
let formNames = [];

// ============================================================================
// INITIALIZATION
// ============================================================================
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

function initializeApp() {
    loadSettings();
    setupEventListeners();
    loadFormNames();
    loadEntries();
}

// ============================================================================
// SETTINGS MANAGEMENT
// ============================================================================
function loadSettings() {
    const settings = JSON.parse(localStorage.getItem('cosmicSettings')) || {
        appName: 'Cosmic Corner Sales',
        theme: 'default'
    };
    
    // Apply App Name
    document.getElementById('headerTitle').textContent = settings.appName;
    document.getElementById('settingAppName').value = settings.appName;
    document.title = settings.appName;

    // Apply Theme
    const body = document.body;
    if (settings.theme === 'plain') {
        body.classList.add('plain-theme');
        const plainRadio = document.querySelector('input[name="theme"][value="plain"]');
        if (plainRadio) plainRadio.checked = true;
    } else {
        body.classList.remove('plain-theme');
        const cosmicRadio = document.querySelector('input[name="theme"][value="default"]');
        if (cosmicRadio) cosmicRadio.checked = true;
    }
}

function saveSettings() {
    const appName = document.getElementById('settingAppName').value || 'Cosmic Corner Sales';
    const theme = document.querySelector('input[name="theme"]:checked').value;
    
    const settings = { appName, theme };
    localStorage.setItem('cosmicSettings', JSON.stringify(settings));
    
    loadSettings();
    showNotification('Settings saved successfully!');
}

// ============================================================================
// EVENT LISTENERS SETUP
// ============================================================================
function setupEventListeners() {
    // Burger Menu
    document.getElementById('burgerBtn').addEventListener('click', toggleBurgerMenu);
    document.getElementById('allFormsBtn').addEventListener('click', () => {
        closeBurgerMenu();
        showPage('allForms');
    });
    document.getElementById('homeBtn').addEventListener('click', () => {
        closeBurgerMenu();
        showPage('main');
    });
    document.getElementById('settingsBtn').addEventListener('click', () => {
        closeBurgerMenu();
        showPage('settings');
    });
    document.getElementById('headerTitle').addEventListener('click', () => showPage('main'));
    
    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
        const burgerBtn = document.getElementById('burgerBtn');
        const burgerMenu = document.getElementById('burgerMenu');
        if (!burgerBtn.contains(e.target) && !burgerMenu.contains(e.target)) {
            closeBurgerMenu();
        }
    });
    
    // Form Name Dropdown
    const formNameInput = document.getElementById('formNameInput');
    const dropdown = document.getElementById('formNameDropdown');
    
    formNameInput.addEventListener('click', () => {
        toggleDropdown();
    });
    
    formNameInput.addEventListener('input', (e) => {
        filterDropdown(e.target.value);
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!dropdown.contains(e.target)) {
            closeDropdown();
        }
    });
    
    // Form Submit
    document.getElementById('productForm').addEventListener('submit', handleFormSubmit);
    
    // Remarks Toggle
    document.getElementById('remarksToggle').addEventListener('click', toggleRemarks);
    
    // Image Upload
    document.getElementById('imageInput').addEventListener('change', handleImageUpload);
    document.getElementById('removeImage').addEventListener('click', removeImage);
    document.getElementById('addImageInput').addEventListener('change', handleAddImageUpload);
    document.getElementById('removeAddImage').addEventListener('click', removeAddImage);
    
    // Settings
    document.getElementById('saveSettingsBtn').addEventListener('click', saveSettings);
    document.getElementById('backupBtn').addEventListener('click', downloadBackup);
    
    // Overview Details Toggle
    const detailsBtn = document.getElementById('detailsBtn');
    if (detailsBtn) {
        detailsBtn.addEventListener('click', toggleOverviewDetails);
    }
    
    // Form name input change
    formNameInput.addEventListener('input', () => {
        loadEntries();
    });
}

// ============================================================================
// BURGER MENU
// ============================================================================
function toggleBurgerMenu() {
    const menu = document.getElementById('burgerMenu');
    menu.classList.toggle('hidden');
}

function closeBurgerMenu() {
    document.getElementById('burgerMenu').classList.add('hidden');
}

// ============================================================================
// CUSTOM DROPDOWN
// ============================================================================
function toggleDropdown() {
    const dropdown = document.getElementById('formNameDropdown');
    const list = document.getElementById('formNameList');
    
    dropdown.classList.toggle('active');
    list.classList.toggle('hidden');
    
    if (!list.classList.contains('hidden')) {
        renderDropdownList(formNames);
    }
}

function closeDropdown() {
    const dropdown = document.getElementById('formNameDropdown');
    const list = document.getElementById('formNameList');
    
    dropdown.classList.remove('active');
    list.classList.add('hidden');
}

function filterDropdown(searchTerm) {
    const filtered = formNames.filter(name => 
        name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    renderDropdownList(filtered);
    
    const list = document.getElementById('formNameList');
    if (list.classList.contains('hidden')) {
        list.classList.remove('hidden');
        document.getElementById('formNameDropdown').classList.add('active');
    }
}

function renderDropdownList(items) {
    const list = document.getElementById('formNameList');
    
    if (items.length === 0) {
        list.innerHTML = '<div class="dropdown-empty">No forms found. Type to create new.</div>';
        return;
    }
    
    list.innerHTML = items.map(name => `
        <div class="dropdown-item" onclick="selectFormName('${name}')">${name}</div>
    `).join('');
}

function selectFormName(name) {
    document.getElementById('formNameInput').value = name;
    closeDropdown();
    loadEntries();
}

async function loadFormNames() {
    try {
        const response = await fetch('/api/forms');
        if (response.ok) {
            const data = await response.json();
            formNames = data.forms || [];
        }
    } catch (error) {
        console.error('Error loading form names:', error);
    }
}

// ============================================================================
// REMARKS TOGGLE
// ============================================================================
function toggleRemarks() {
    const toggle = document.getElementById('remarksToggle');
    const field = document.getElementById('remarksField');
    
    toggle.classList.toggle('active');
    field.classList.toggle('hidden');
}

// ============================================================================
// IMAGE HANDLING
// ============================================================================
async function handleImageUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    try {
        const dataUrl = await processImage(file);
        const preview = document.getElementById('imagePreview');
        const container = document.getElementById('imagePreviewContainer');
        
        preview.src = dataUrl;
        container.classList.remove('hidden');
    } catch (error) {
        console.error('Error processing image:', error);
        showNotification('Error processing image');
    }
}

async function handleAddImageUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    try {
        const dataUrl = await processImage(file);
        const preview = document.getElementById('addImagePreview');
        const container = document.getElementById('addImagePreviewContainer');
        
        preview.src = dataUrl;
        container.classList.remove('hidden');
    } catch (error) {
        console.error('Error processing image:', error);
        showNotification('Error processing image');
    }
}

function removeImage() {
    document.getElementById('imageInput').value = '';
    document.getElementById('imagePreview').src = '';
    document.getElementById('imagePreviewContainer').classList.add('hidden');
}

function removeAddImage() {
    document.getElementById('addImageInput').value = '';
    document.getElementById('addImagePreview').src = '';
    document.getElementById('addImagePreviewContainer').classList.add('hidden');
}

function processImage(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                
                // Resize to max 800px
                let width = img.width;
                let height = img.height;
                const maxSize = 800;
                
                if (width > height) {
                    if (width > maxSize) {
                        height *= maxSize / width;
                        width = maxSize;
                    }
                } else {
                    if (height > maxSize) {
                        width *= maxSize / height;
                        height = maxSize;
                    }
                }
                
                canvas.width = width;
                canvas.height = height;
                ctx.drawImage(img, 0, 0, width, height);
                
                resolve(canvas.toDataURL('image/jpeg', 0.7));
            };
            img.onerror = reject;
            img.src = e.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

// ============================================================================
// FORM SUBMISSION
// ============================================================================
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const formName = document.getElementById('formNameInput').value.trim();
    if (!formName) {
        showNotification('Please enter a form name');
        return;
    }
    
    const preview = document.getElementById('imagePreview');
    const hasImage = !document.getElementById('imagePreviewContainer').classList.contains('hidden') && preview.src;
    
    const data = {
        formName: formName,
        date: new Date().toISOString().split('T')[0],
        productName: document.getElementById('productName').value,
        qty: parseInt(document.getElementById('qty').value),
        amount: parseFloat(document.getElementById('amount').value),
        remarks: document.getElementById('remarks').value,
        image: hasImage ? preview.src : null,
        timestamp: new Date().toISOString()
    };
    
    try {
        const response = await fetch('/api/entries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            // Reset form
            document.getElementById('productName').value = '';
            document.getElementById('qty').value = '';
            document.getElementById('amount').value = '';
            document.getElementById('remarks').value = '';
            removeImage();
            
            // Hide remarks if shown
            const remarksField = document.getElementById('remarksField');
            if (!remarksField.classList.contains('hidden')) {
                toggleRemarks();
            }
            
            loadEntries();
            loadFormNames();
            showNotification('Entry saved successfully!');
        } else {
            showNotification('Error saving entry');
        }
    } catch (error) {
        console.error('Error saving entry:', error);
        showNotification('Error: Server not running');
    }
}

// ============================================================================
// LOAD ENTRIES
// ============================================================================
async function loadEntries() {
    const container = document.getElementById('entriesList');
    const formName = document.getElementById('formNameInput').value.trim();
    
    if (!formName) {
        container.innerHTML = '<p class="empty-message">Enter a form name to view entries</p>';
        document.getElementById('runningTotal').textContent = '₹0.00';
        return;
    }
    
    try {
        const response = await fetch(`/api/entries?formName=${encodeURIComponent(formName)}`);
        if (!response.ok) {
            throw new Error('Failed to fetch entries');
        }
        
        const data = await response.json();
        const items = data.entries || [];
        
        // Calculate total
        const total = items.reduce((sum, item) => sum + item.amount, 0);
        document.getElementById('runningTotal').textContent = `₹${total.toFixed(2)}`;
        
        if (items.length === 0) {
            container.innerHTML = '<p class="empty-message">No entries yet</p>';
            return;
        }
        
        container.innerHTML = items.map((item) => {
            const hasImage = item.image_path;
            const displayDate = item.date ? new Date(item.date).toLocaleDateString() : '';
            
            return `
                <div class="entry-item">
                    <div class="entry-content">
                        ${hasImage ? `<img src="${item.image_path}" class="entry-image" alt="Product">` : ''}
                        <div class="entry-info">
                            <div class="entry-name">
                                ${item.product_name}
                                ${displayDate ? `<span class="entry-date">(${displayDate})</span>` : ''}
                            </div>
                            <div class="entry-details">Qty: ${item.quantity} | ₹${item.amount.toFixed(2)}</div>
                            ${item.remarks ? `<div class="entry-remarks">${item.remarks}</div>` : ''}
                        </div>
                    </div>
                    <div class="entry-actions">
                        <button onclick="openEditModal(${item.id})" class="btn-action">Edit</button>
                        <button onclick="deleteEntry(${item.id})" class="btn-action">Del</button>
                    </div>
                </div>
            `;
        }).join('');
    } catch (error) {
        console.error('Error loading entries:', error);
        container.innerHTML = '<p class="empty-message">Start server to view entries</p>';
    }
}

// ============================================================================
// LOAD ALL FORMS
// ============================================================================
async function loadAllForms() {
    const container = document.getElementById('formsList');
    
    try {
        const response = await fetch('/api/forms');
        if (!response.ok) {
            throw new Error('Failed to fetch forms');
        }
        
        const data = await response.json();
        const forms = data.forms || [];
        
        if (forms.length === 0) {
            container.innerHTML = '<p class="empty-message">No forms yet</p>';
            return;
        }
        
        // Get stats for each form
        const formsWithStats = await Promise.all(forms.map(async (formName) => {
            const statsResponse = await fetch(`/api/forms/${encodeURIComponent(formName)}/stats`);
            const stats = await statsResponse.json();
            return { formName, ...stats };
        }));
        
        container.innerHTML = formsWithStats.map(form => `
            <div class="form-card">
                <div class="form-card-header" onclick="showFormOverview('${form.formName}')">
                    <div class="form-card-title">${form.formName}</div>
                    <div class="form-card-info">${form.count || 0} entries</div>
                    <div class="form-card-total">Total: ₹${(form.total || 0).toFixed(2)}</div>
                </div>
                <button onclick="event.stopPropagation(); openDownloadModal('${form.formName}')" class="form-card-download">
                    ⬇ Download
                </button>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading forms:', error);
        container.innerHTML = '<p class="empty-message">Start server to view forms</p>';
    }
}

// ============================================================================
// FORM OVERVIEW
// ============================================================================
async function showFormOverview(formName) {
    currentFormName = formName;
    document.getElementById('overviewTitle').textContent = formName;
    document.getElementById('overviewEntries').classList.add('hidden');
    
    try {
        const statsResponse = await fetch(`/api/forms/${encodeURIComponent(formName)}/stats`);
        const stats = await statsResponse.json();
        
        document.getElementById('overviewQty').textContent = stats.totalQty || 0;
        document.getElementById('overviewAmount').textContent = `₹${(stats.total || 0).toFixed(2)}`;
        
        const entriesResponse = await fetch(`/api/entries?formName=${encodeURIComponent(formName)}`);
        const entriesData = await entriesResponse.json();
        const items = entriesData.entries || [];
        
        const list = document.getElementById('overviewEntriesList');
        list.innerHTML = items.map((item) => {
            const hasImage = item.image_path;
            const displayDate = item.date ? new Date(item.date).toLocaleDateString() : '';
            
            return `
                <div class="entry-item">
                    <div class="entry-content">
                        ${hasImage ? `<img src="${item.image_path}" class="entry-image" alt="Product">` : ''}
                        <div class="entry-info">
                            <div class="entry-name">${item.product_name}</div>
                            <div class="entry-date">${displayDate}</div>
                            <div class="entry-details">Qty: ${item.quantity} | ₹${item.amount.toFixed(2)}</div>
                            ${item.remarks ? `<div class="entry-remarks">${item.remarks}</div>` : ''}
                        </div>
                    </div>
                    <div class="entry-actions">
                        <button onclick="openEditModal(${item.id})" class="btn-action">Edit</button>
                        <button onclick="deleteEntry(${item.id}, true)" class="btn-action">Del</button>
                    </div>
                </div>
            `;
        }).join('');
        
        showPage('overview');
    } catch (error) {
        console.error('Error loading form overview:', error);
        showNotification('Error loading form data');
    }
}

function toggleOverviewDetails() {
    const entries = document.getElementById('overviewEntries');
    entries.classList.toggle('hidden');
}

// ============================================================================
// EDIT ENTRY
// ============================================================================
async function openEditModal(id) {
    try {
        const response = await fetch(`/api/entries/${id}`);
        if (!response.ok) {
            throw new Error('Failed to fetch entry');
        }
        
        const item = await response.json();
        
        editingIndex = id;
        document.getElementById('editEntryDate').value = item.date || '';
        document.getElementById('editProductName').value = item.product_name;
        document.getElementById('editQty').value = item.quantity;
        document.getElementById('editAmount').value = item.amount;
        document.getElementById('editRemarks').value = item.remarks || '';
        document.getElementById('editModal').classList.remove('hidden');
    } catch (error) {
        console.error('Error loading entry:', error);
        showNotification('Error loading entry');
    }
}

function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
    editingIndex = null;
}

async function saveEdit() {
    if (editingIndex === null) return;
    
    const updatedItem = {
        date: document.getElementById('editEntryDate').value,
        productName: document.getElementById('editProductName').value,
        qty: parseInt(document.getElementById('editQty').value),
        amount: parseFloat(document.getElementById('editAmount').value),
        remarks: document.getElementById('editRemarks').value
    };
    
    try {
        const response = await fetch(`/api/entries/${editingIndex}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedItem)
        });
        
        if (response.ok) {
            closeEditModal();
            
            // Refresh the appropriate page
            if (!document.getElementById('overviewPage').classList.contains('hidden')) {
                showFormOverview(currentFormName);
            } else {
                loadEntries();
            }
            
            showNotification('Entry updated successfully!');
        } else {
            showNotification('Error updating entry');
        }
    } catch (error) {
        console.error('Error saving edit:', error);
        showNotification('Error saving changes');
    }
}

// ============================================================================
// DELETE ENTRY
// ============================================================================
async function deleteEntry(id, fromOverview = false) {
    if (!confirm('Delete this entry?')) return;
    
    try {
        const response = await fetch(`/api/entries/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            if (fromOverview) {
                showFormOverview(currentFormName);
            } else {
                loadEntries();
            }
            showNotification('Entry deleted successfully!');
        } else {
            showNotification('Error deleting entry');
        }
    } catch (error) {
        console.error('Error deleting entry:', error);
        showNotification('Error deleting entry');
    }
}

// ============================================================================
// ADD ENTRY MODAL (from Overview page)
// ============================================================================
function openAddEntryModal() {
    document.getElementById('addEntryFormName').textContent = currentFormName;
    
    // Reset fields
    document.getElementById('addProductName').value = '';
    document.getElementById('addQty').value = '';
    document.getElementById('addAmount').value = '';
    document.getElementById('addRemarks').value = '';
    removeAddImage();
    
    document.getElementById('addEntryModal').classList.remove('hidden');
}

function closeAddEntryModal() {
    document.getElementById('addEntryModal').classList.add('hidden');
}

async function saveNewEntry() {
    const productName = document.getElementById('addProductName').value.trim();
    const qty = parseInt(document.getElementById('addQty').value);
    const amount = parseFloat(document.getElementById('addAmount').value);
    const remarks = document.getElementById('addRemarks').value.trim();
    
    if (!productName || !qty || !amount) {
        showNotification('Please fill all required fields');
        return;
    }
    
    const preview = document.getElementById('addImagePreview');
    const hasImage = !document.getElementById('addImagePreviewContainer').classList.contains('hidden') && preview.src;
    
    const data = {
        formName: currentFormName,
        date: new Date().toISOString().split('T')[0],
        productName: productName,
        qty: qty,
        amount: amount,
        remarks: remarks,
        image: hasImage ? preview.src : null,
        timestamp: new Date().toISOString()
    };
    
    try {
        const response = await fetch('/api/entries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            closeAddEntryModal();
            showFormOverview(currentFormName);
            loadFormNames();
            showNotification('Entry added successfully!');
        } else {
            showNotification('Error adding entry');
        }
    } catch (error) {
        console.error('Error saving entry:', error);
        showNotification('Error adding entry');
    }
}

// ============================================================================
// DOWNLOAD MODAL
// ============================================================================
let downloadFormNameSelected = '';

function openDownloadModal(formName) {
    downloadFormNameSelected = formName;
    document.getElementById('downloadFormName').textContent = `Download "${formName}" as:`;
    document.getElementById('downloadModal').classList.remove('hidden');
}

function closeDownloadModal() {
    document.getElementById('downloadModal').classList.add('hidden');
    downloadFormNameSelected = '';
}

async function downloadAsPDF() {
    try {
        const response = await fetch(`/api/entries?formName=${encodeURIComponent(downloadFormNameSelected)}`);
        const data = await response.json();
        const items = data.entries || [];
        
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const pageWidth = doc.internal.pageSize.getWidth();
        
        // Positions
        const col1 = 15;  // S.No
        const col2 = 25;  // Date
        const col3 = 50;  // Product
        const col4 = 105; // Remarks
        const col5 = 145; // Qty
        const col6 = 165; // Amount
        const rightMargin = pageWidth - 15;
        
        // Title
        doc.setFontSize(20);
        doc.setFont('helvetica', 'bold');
        doc.text(downloadFormNameSelected, pageWidth / 2, 20, { align: 'center' });
        
        // Subtitle
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text('Cosmic Corner Sales', pageWidth / 2, 28, { align: 'center' });
        doc.text('Generated: ' + new Date().toLocaleDateString(), pageWidth / 2, 34, { align: 'center' });
        
        // Line
        doc.setLineWidth(0.5);
        doc.line(15, 40, rightMargin, 40);
        
        // Table Header
        let y = 50;
        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.text('S.No', col1, y);
        doc.text('Date', col2, y);
        doc.text('Product', col3, y);
        doc.text('Remarks', col4, y);
        doc.text('Qty', col5, y);
        doc.text('Amount', col6, y);
        
        // Line under header
        y += 8;
        doc.setLineWidth(0.3);
        doc.line(15, y, rightMargin, y);
        
        // Table Data
        y += 10;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        
        let totalQty = 0;
        let totalAmount = 0;
        
        items.forEach((item, index) => {
            if (y > 265) {
                doc.addPage();
                y = 20;
            }
            
            const displayDate = item.date ? new Date(item.date).toLocaleDateString() : '-';
            
            doc.text(String(index + 1), col1, y);
            doc.text(displayDate, col2, y);
            doc.text(item.product_name.substring(0, 25), col3, y);
            doc.text((item.remarks || '-').substring(0, 20), col4, y);
            doc.text(String(item.quantity), col5, y);
            doc.text(item.amount.toFixed(2), col6, y);
            
            totalQty += item.quantity;
            totalAmount += item.amount;
            y += 8;
        });
        
        // Total line
        y += 5;
        doc.setLineWidth(0.5);
        doc.line(15, y, rightMargin, y);
        
        // Totals
        y += 10;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text('TOTAL', col3, y);
        doc.text(String(totalQty), col5, y);
        doc.text('Rs. ' + totalAmount.toFixed(2), col6, y);
        
        // Save
        doc.save(`${downloadFormNameSelected}-${new Date().toISOString().split('T')[0]}.pdf`);
        closeDownloadModal();
        showNotification('PDF downloaded successfully!');
    } catch (error) {
        console.error('Error generating PDF:', error);
        showNotification('Error generating PDF');
    }
}

async function downloadAsExcel() {
    try {
        const response = await fetch(`/api/entries?formName=${encodeURIComponent(downloadFormNameSelected)}`);
        const data = await response.json();
        const items = data.entries || [];
        
        // Prepare data
        const excelData = [
            [downloadFormNameSelected],
            ['Cosmic Corner Sales'],
            [`Generated: ${new Date().toLocaleDateString()}`],
            [],
            ['S.No', 'Date', 'Product Name', 'Remarks', 'Quantity', 'Amount (₹)']
        ];
        
        let totalQty = 0;
        let totalAmount = 0;
        
        items.forEach((item, index) => {
            const displayDate = item.date ? new Date(item.date).toLocaleDateString() : '-';
            excelData.push([
                index + 1,
                displayDate,
                item.product_name,
                item.remarks || '',
                item.quantity,
                item.amount
            ]);
            totalQty += item.quantity;
            totalAmount += item.amount;
        });
        
        // Add totals
        excelData.push([]);
        excelData.push(['', '', 'TOTAL', '', totalQty, totalAmount]);
        
        // Create workbook
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet(excelData);
        
        // Set column widths
        ws['!cols'] = [
            { wch: 8 },
            { wch: 15 },
            { wch: 30 },
            { wch: 25 },
            { wch: 12 },
            { wch: 15 }
        ];
        
        XLSX.utils.book_append_sheet(wb, ws, 'Sales Data');
        XLSX.writeFile(wb, `${downloadFormNameSelected}-${new Date().toISOString().split('T')[0]}.xlsx`);
        
        closeDownloadModal();
        showNotification('Excel downloaded successfully!');
    } catch (error) {
        console.error('Error generating Excel:', error);
        showNotification('Error generating Excel');
    }
}

// ============================================================================
// BACKUP
// ============================================================================
async function downloadBackup() {
    try {
        const response = await fetch('/api/backup');
        if (!response.ok) {
            throw new Error('Failed to download backup');
        }
        
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `backup-${new Date().toISOString().split('T')[0]}.db`;
        a.click();
        URL.revokeObjectURL(url);
        
        showNotification('Backup downloaded successfully!');
    } catch (error) {
        console.error('Error downloading backup:', error);
        showNotification('Error downloading backup');
    }
}

// ============================================================================
// PAGE NAVIGATION
// ============================================================================
function showPage(page) {
    // Hide all pages
    document.getElementById('mainPage').classList.add('hidden');
    document.getElementById('allFormsPage').classList.add('hidden');
    document.getElementById('overviewPage').classList.add('hidden');
    document.getElementById('settingsPage').classList.add('hidden');
    
    // Show selected page
    if (page === 'main') {
        document.getElementById('mainPage').classList.remove('hidden');
        loadEntries();
    } else if (page === 'allForms') {
        document.getElementById('allFormsPage').classList.remove('hidden');
        loadAllForms();
    } else if (page === 'overview') {
        document.getElementById('overviewPage').classList.remove('hidden');
    } else if (page === 'settings') {
        document.getElementById('settingsPage').classList.remove('hidden');
    }
}

// ============================================================================
// NOTIFICATIONS
// ============================================================================
function showNotification(message) {
    // Simple alert for now
    // You can implement a custom toast notification here
    alert(message);
}
