# 🚀 Quick Start Guide

Get up and running in 30 seconds!

## Step 1: Start the Server

### Standalone Mode
```bash
python server.py
```

### NOBITA Mode (if using MainServer)
```bash
# MainServer auto-starts all servers
python MainServer.py
```

## Step 2: Open Browser

```
http://localhost:9999
```
(Or the port shown in terminal)

## Step 3: Create Your First Form

1. **Enter form name**: Type "Daily Sales" in the dropdown
2. **Add product**: Enter product details
3. **Save**: Click "Save Entry"

That's it! 🎉

## Common Tasks

### Add More Entries
- Same form: Just keep filling and saving
- New form: Change the form name in dropdown

### View All Forms
- Click ☰ (burger menu)
- Select "Forms"
- Click any form to see details

### Export Data
- Go to Forms page
- Click "Download" on any form
- Choose PDF or Excel

### Take Photo
- Click "Camera / Upload" when adding entry
- Select camera or choose file
- Image auto-compresses for storage

### Backup Everything
- Click ☰ → Settings
- Click "Download Database Backup"
- Save the .db file

## Tips

✅ Form names are case-sensitive  
✅ Use consistent naming (e.g., "Daily-2024-01")  
✅ Remarks are optional - click to expand  
✅ Images compress automatically  
✅ Works offline after first load  

## Need Help?

Check the full README.md for detailed documentation.

Happy tracking! 🌟
