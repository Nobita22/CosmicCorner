# 🔧 Troubleshooting Guide

Common issues and solutions for Cosmic Corner Sales.

---

## 🚨 Server Issues

### Server Won't Start

**Problem:** Server doesn't start or shows error

**Solutions:**

1. **Check Python installation**
   ```bash
   python3 --version
   # Should show Python 3.6 or higher
   ```

2. **Install Python (if missing)**
   ```bash
   # Termux (Android)
   pkg install python
   
   # Ubuntu/Debian
   sudo apt install python3
   
   # macOS (with Homebrew)
   brew install python3
   ```

3. **Check port availability**
   ```bash
   # Try different port
   python server.py 8080
   ```

4. **Kill existing server**
   ```bash
   # Find process
   ps aux | grep server.py
   
   # Kill it (replace PID)
   kill -9 PID
   ```

### Port Already in Use

**Problem:** Error: "Address already in use"

**Solutions:**

1. **Use different port**
   ```bash
   python server.py 9000
   ```

2. **Find and kill process using port**
   ```bash
   # On Linux/Mac
   lsof -i :8000
   kill -9 PID
   
   # On Windows
   netstat -ano | findstr :8000
   taskkill /PID PID /F
   ```

3. **Wait and retry**
   - Sometimes takes 30 seconds for port to release
   - Just wait and try again

### Can't Access from Browser

**Problem:** "Cannot connect to localhost:8000"

**Solutions:**

1. **Check if server is running**
   - Look for "Server running on port 8000" message
   - Server must be running in terminal

2. **Use correct URL**
   ```
   http://localhost:8000
   NOT https://localhost:8000
   ```

3. **Check firewall**
   - Temporarily disable firewall
   - Add exception for Python

4. **Try 127.0.0.1**
   ```
   http://127.0.0.1:8000
   ```

---

## 🌐 Network Access Issues

### Can't Access from Other Devices

**Problem:** Works on localhost but not from phone/tablet

**Solutions:**

1. **Find your IP address**
   ```bash
   # Linux/Mac
   ifconfig | grep inet
   hostname -I
   
   # Windows
   ipconfig
   
   # Termux
   ifconfig wlan0
   ```

2. **Use correct IP**
   ```
   http://192.168.1.XXX:8000
   NOT localhost:8000
   ```

3. **Check network**
   - Both devices must be on same WiFi network
   - Can't use cellular data

4. **Disable firewall temporarily**
   - Test if firewall is blocking
   - Add exception for Python

5. **Check router settings**
   - Some routers block device-to-device communication
   - Enable "AP Isolation" or "Client Isolation"

### Slow Network Performance

**Problem:** Slow loading from other devices

**Solutions:**

1. **Use better WiFi**
   - Move closer to router
   - Use 5GHz network if available

2. **Reduce image sizes**
   - Images are compressed automatically
   - But smaller originals help

3. **Check bandwidth**
   - Close other apps using network
   - Pause downloads

---

## 💾 Database Issues

### Database Not Created

**Problem:** No cosmic_sales.db file appears

**Solutions:**

1. **Check permissions**
   ```bash
   # Check if you can write to directory
   touch test.txt
   rm test.txt
   ```

2. **Run server as admin (if needed)**
   ```bash
   sudo python server.py
   ```

3. **Check disk space**
   ```bash
   df -h
   ```

### Database Locked Error

**Problem:** "Database is locked" error

**Solutions:**

1. **Close other instances**
   - Only one server should run at a time
   - Check for duplicate processes

2. **Close database tools**
   - Close SQLite browser if open
   - Close any DB management tools

3. **Restart server**
   ```bash
   # Ctrl+C to stop
   # Then restart
   python server.py
   ```

4. **Last resort: Delete lock file**
   ```bash
   rm cosmic_sales.db-journal
   ```

### Data Not Saving

**Problem:** Entries disappear after refresh

**Solutions:**

1. **Check browser console**
   - Press F12
   - Look for error messages
   - Check Network tab

2. **Verify server is running**
   - Check terminal for errors
   - Server should show POST requests

3. **Test API manually**
   ```bash
   curl http://localhost:8000/api/entries
   ```

4. **Check database file**
   ```bash
   ls -lh cosmic_sales.db
   # Should exist and have size > 0
   ```

---

## 🖼️ Image Issues

### Images Not Uploading

**Problem:** Can't select or upload images

**Solutions:**

1. **Check file size**
   - Very large images (>10MB) may fail
   - Resize before uploading

2. **Check file format**
   - Use JPG, PNG, or WebP
   - Avoid HEIC (iPhone) - convert first

3. **Check browser permissions**
   - Allow camera access
   - Allow file access

4. **Try different browser**
   - Chrome/Firefox work best
   - Safari may have issues

### Images Not Displaying

**Problem:** Image uploaded but won't display

**Solutions:**

1. **Check browser console**
   - F12 → Console
   - Look for errors

2. **Clear browser cache**
   ```
   Ctrl+F5 (force reload)
   ```

3. **Check image data**
   - Should be Base64 encoded
   - Should start with "data:image/"

### Camera Not Working

**Problem:** Camera button doesn't work

**Solutions:**

1. **Grant camera permission**
   - Browser will ask for permission
   - Check site settings

2. **Use HTTPS** (if on network)
   - Camera requires HTTPS on remote devices
   - Localhost works without HTTPS

3. **Use file upload instead**
   - Take photo with camera app
   - Upload using file picker

---

## 📱 Mobile Issues

### App Not Loading on Phone

**Problem:** Blank screen or won't load

**Solutions:**

1. **Check URL format**
   ```
   Correct: http://192.168.1.XXX:8000
   Wrong: https://192.168.1.XXX:8000
   Wrong: localhost:8000
   ```

2. **Check WiFi connection**
   - Both devices on same network
   - Disable cellular data

3. **Try different browser**
   - Chrome (recommended)
   - Firefox
   - Safari (iOS)

4. **Clear browser data**
   - Settings → Clear browsing data
   - Reload page

### Touch Not Working Properly

**Problem:** Buttons don't respond to touch

**Solutions:**

1. **Use compatible browser**
   - Chrome/Firefox work best
   - Update browser to latest version

2. **Check zoom level**
   - Reset zoom to 100%
   - Some browsers zoom interferes

3. **Disable browser extensions**
   - Ad blockers may interfere
   - Try incognito mode

---

## 📊 Export Issues

### PDF Export Fails

**Problem:** Can't generate PDF

**Solutions:**

1. **Check internet connection**
   - jsPDF library loads from CDN
   - Need internet first time

2. **Wait for page to fully load**
   - Give page 2-3 seconds after opening
   - Then try export

3. **Try smaller dataset**
   - Export in chunks if too large
   - 1000 entries at a time recommended

4. **Check browser console**
   - F12 → Console
   - Look for errors

### Excel Export Fails

**Problem:** Can't generate Excel file

**Solutions:**

1. **Check internet connection**
   - XLSX library loads from CDN
   - Need internet first time

2. **Check browser compatibility**
   - Chrome/Firefox work best
   - Update browser

3. **Try incognito mode**
   - Extension may be blocking

---

## ⚙️ Settings Issues

### Settings Not Saving

**Problem:** Changed settings revert after refresh

**Solutions:**

1. **Check server response**
   - Open browser console
   - Look for 200 OK response

2. **Check database**
   ```bash
   sqlite3 cosmic_sales.db "SELECT * FROM settings"
   ```

3. **Clear browser cache**
   - Settings stored in database, not browser
   - But cache may cause issues

### Theme Not Changing

**Problem:** Theme stays the same

**Solutions:**

1. **Hard refresh**
   ```
   Ctrl+Shift+R (or Cmd+Shift+R on Mac)
   ```

2. **Check CSS loading**
   - F12 → Network tab
   - style.css should load

3. **Clear cache**
   - Browser may cache old CSS

---

## 🔄 Performance Issues

### App Running Slow

**Problem:** Lag, freezing, or slow response

**Solutions:**

1. **Check database size**
   ```bash
   ls -lh cosmic_sales.db
   ```

2. **Optimize database**
   ```bash
   sqlite3 cosmic_sales.db "VACUUM"
   ```

3. **Reduce image sizes**
   - Images are compressed, but smaller is better
   - Delete old entries with large images

4. **Clear old data**
   - Export and archive old forms
   - Delete from database

5. **Restart server**
   ```bash
   # Ctrl+C to stop
   python server.py
   ```

### Browser Freezing

**Problem:** Browser becomes unresponsive

**Solutions:**

1. **Update browser**
   - Use latest version
   - Clear cache and cookies

2. **Close other tabs**
   - Free up memory
   - One tab for app

3. **Check RAM usage**
   - Close other applications
   - Restart browser

4. **Try different browser**
   - Chrome (recommended)
   - Firefox
   - Edge

---

## 🔍 Debugging

### Enable Debug Mode

**Check browser console:**

```javascript
// Open console (F12)
// Type:
localStorage.setItem('debug', 'true')
// Reload page
```

**Check server logs:**

```bash
# Server logs appear in terminal
# Look for error messages
# Check HTTP response codes
```

**Test API directly:**

```bash
# Get settings
curl http://localhost:8000/api/settings

# Get forms
curl http://localhost:8000/api/forms

# Get entries
curl http://localhost:8000/api/entries
```

---

## 📞 Getting Help

### Information to Provide

When asking for help, include:

1. **System info**
   - Operating system
   - Python version
   - Browser version

2. **Error messages**
   - From terminal
   - From browser console
   - Screenshots if possible

3. **Steps to reproduce**
   - What you did
   - What you expected
   - What actually happened

4. **Database info**
   - Database file size
   - Number of entries
   - Number of forms

### Quick Diagnostic

Run this test:

```bash
# 1. Check Python
python3 --version

# 2. Check database
ls -lh cosmic_sales.db

# 3. Test server
python server.py &
sleep 2
curl http://localhost:8000/api/settings
```

---

## 🆘 Emergency Recovery

### Complete Reset

**If nothing works:**

1. **Backup your data**
   ```bash
   cp cosmic_sales.db backup.db
   ```

2. **Stop all servers**
   ```bash
   killall python
   # or
   pkill -f server.py
   ```

3. **Delete database**
   ```bash
   rm cosmic_sales.db
   ```

4. **Restart server**
   ```bash
   python server.py
   # Fresh database will be created
   ```

5. **Restore data if needed**
   ```bash
   cp backup.db cosmic_sales.db
   ```

### Fresh Install

**Start completely fresh:**

1. **Download fresh copy**
2. **Delete old folder**
3. **Extract new files**
4. **Start server**
5. **Import backup if you have one**

---

## ✅ Prevention Tips

### Best Practices

1. **Regular backups**
   - Weekly database backups
   - Store in multiple locations

2. **Keep updated**
   - Update Python
   - Update browser
   - Update OS

3. **Monitor disk space**
   - Keep 1GB free minimum
   - Clean old data regularly

4. **Use good network**
   - Stable WiFi
   - Good signal strength
   - Minimal interference

5. **Close unused tabs**
   - Free up memory
   - Better performance

---

**Still having issues? Check README.md for more information!**
