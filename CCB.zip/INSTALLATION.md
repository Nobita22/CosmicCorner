# 📦 Installation Guide

Complete installation instructions for Cosmic Corner Sales SQLite Edition.

## System Requirements

- **Python**: 3.6 or higher
- **Browser**: Modern browser (Chrome, Firefox, Safari, Edge)
- **OS**: Windows, macOS, Linux, Android (Termux)
- **Storage**: ~10MB + data

## Installation Methods

### Method 1: Standalone Installation

#### Step 1: Download/Clone
```bash
# If you have git
git clone <repository-url>
cd CosmicCorner

# Or download and extract ZIP
```

#### Step 2: Verify Files
Ensure these files exist:
- ✅ `server.py`
- ✅ `index.html`
- ✅ `style.css`
- ✅ `app.js`
- ✅ `cosmic.js`
- ✅ `manifest.json`

#### Step 3: Run Server
```bash
# Make executable (Unix/Mac)
chmod +x server.py

# Run server
python server.py
```

#### Step 4: Access Application
Open browser:
```
http://localhost:9999
```

---

### Method 2: NOBITA Multi-Server Integration

#### Step 1: Place in NOBITA Directory
```bash
# Copy folder to NOBITA
cp -r CosmicCorner /path/to/NOBITA/

# Or move
mv CosmicCorner /path/to/NOBITA/
```

#### Step 2: NOBITA Auto-Detection
NOBITA will automatically:
- Detect the folder
- Assign a port
- Add to config.json
- Start the server

#### Step 3: Access from Dashboard
```
http://localhost:9000
```
Click on "CosmicCorner" in the dashboard.

#### Step 4: Custom Port (Optional)
Edit `NOBITA/config.json`:
```json
{
  "folders": {
    "CosmicCorner": 9050
  }
}
```

---

### Method 3: Termux (Android)

#### Step 1: Install Termux
Download from F-Droid (not Google Play)

#### Step 2: Install Python
```bash
pkg update
pkg install python
```

#### Step 3: Download Files
```bash
# Navigate to storage
cd ~/storage/downloads

# Or use termux-setup-storage
termux-setup-storage
```

#### Step 4: Run Server
```bash
cd CosmicCorner
python server.py
```

#### Step 5: Access on Phone
```
http://localhost:9999
```

Or from other devices on same network:
```
http://YOUR_PHONE_IP:9999
```

---

## Post-Installation Setup

### 1. Verify Installation
```bash
# Check server is running
curl http://localhost:9999

# Should return HTML content
```

### 2. Test Database
```bash
# Server creates database automatically
ls -la cosmic_sales.db

# Should show database file
```

### 3. Create Test Entry
1. Open browser to http://localhost:9999
2. Enter form name: "Test Form"
3. Add a test product
4. Click Save
5. Verify entry appears

### 4. Test Export
1. Go to Forms page
2. Click Download on test form
3. Select PDF or Excel
4. Verify file downloads

---

## Configuration

### Change Default Port
Edit `server.py`:
```python
def get_port():
    # ... existing code ...
    return 8080  # Change this line
```

### Change App Name
1. Open application
2. Go to Settings
3. Change "App Name"
4. Save Settings

### Change Theme
1. Open application
2. Go to Settings
3. Select theme (Cosmic or Plain)
4. Save Settings

---

## Directory Structure After Install

```
CosmicCorner/
├── server.py              # Python server
├── index.html             # Main page
├── style.css              # Styles
├── app.js                 # Application logic
├── cosmic.js              # Background effects
├── manifest.json          # PWA manifest
├── README.md              # Documentation
├── QUICKSTART.md          # Quick guide
├── CHANGELOG.md           # Version history
├── INSTALLATION.md        # This file
├── cosmic_sales.db        # Database (auto-created)
└── images/                # Image storage (auto-created)
    ├── img_1234567890.jpg
    └── img_1234567891.jpg
```

---

## Troubleshooting

### Server won't start
**Error**: "Address already in use"
```bash
# Find process using port
lsof -i :9999

# Kill process
kill -9 <PID>

# Or change port in server.py
```

**Error**: "Permission denied"
```bash
# Make executable
chmod +x server.py

# Or run with python directly
python server.py
```

### Can't access from browser
**Issue**: "Connection refused"
- Check server is running
- Check correct port
- Try 127.0.0.1 instead of localhost

**Issue**: Can't access from other devices
```bash
# Check server binds to 0.0.0.0 (not 127.0.0.1)
# In server.py, verify:
server = HTTPServer(('0.0.0.0', port), ...)
```

### Database errors
**Error**: "Database is locked"
```bash
# Close all connections
# Restart server
python server.py
```

**Error**: "Unable to open database file"
```bash
# Check permissions
ls -la cosmic_sales.db

# Fix permissions
chmod 644 cosmic_sales.db
```

### Images not loading
**Issue**: Broken image icons
```bash
# Check images folder exists
ls -la images/

# Create if missing
mkdir images
chmod 755 images
```

---

## Uninstallation

### Remove Application
```bash
# Stop server (Ctrl+C)

# Remove folder
rm -rf CosmicCorner
```

### Remove from NOBITA
1. Stop NOBITA MainServer
2. Delete folder from NOBITA directory
3. Remove from `config.json`
4. Restart NOBITA

### Backup Before Removal
```bash
# Backup database
cp cosmic_sales.db ~/backups/cosmic_sales_backup.db

# Or download via browser
# Settings → Download Database Backup
```

---

## Upgrade from v1 (JSON)

See CHANGELOG.md for migration guide.

---

## Getting Help

- 📖 Read README.md for features
- 🚀 Check QUICKSTART.md for basics
- 📝 See CHANGELOG.md for changes
- 🐛 Check Troubleshooting above

---

Enjoy your cosmic sales tracking! 🌟
