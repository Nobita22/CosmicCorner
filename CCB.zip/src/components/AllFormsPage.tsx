import { useState, useEffect } from 'react';
import { db } from '../services/database';

interface AllFormsPageProps {
  onNavigate: (page: string, formName?: string) => void;
}

interface FormStats {
  name: string;
  count: number;
  qty: number;
  amount: number;
}

export const AllFormsPage = ({ onNavigate }: AllFormsPageProps) => {
  const [forms, setForms] = useState<FormStats[]>([]);
  const [downloadFormName, setDownloadFormName] = useState<string | null>(null);

  useEffect(() => {
    loadForms();
  }, []);

  const loadForms = async () => {
    const formNames = await db.getFormNames();
    const formStats: FormStats[] = [];

    for (const name of formNames) {
      const stats = await db.getFormStats(name);
      formStats.push({
        name,
        ...stats
      });
    }

    setForms(formStats);
  };

  return (
    <div className="max-w-md mx-auto p-4">
      <h2 className="text-xl font-bold mb-4 border-b-2 border-black pb-2">All Forms</h2>
      
      <div className="space-y-3">
        {forms.length === 0 ? (
          <p className="text-gray-500 text-center py-4">No forms yet</p>
        ) : (
          forms.map((form) => (
            <div key={form.name} className="border-2 border-black p-4 hover:bg-gray-50 transition-all">
              <div
                onClick={() => onNavigate('overview', form.name)}
                className="cursor-pointer"
              >
                <h3 className="font-bold text-lg">{form.name}</h3>
                <p className="text-sm">{form.count} entries</p>
                <p className="text-xs mt-1">Total: ₹{form.amount.toFixed(2)}</p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setDownloadFormName(form.name);
                }}
                className="mt-3 w-full border-2 border-black py-2 text-sm font-medium hover:bg-black hover:text-white transition-all"
              >
                ⬇ Download
              </button>
            </div>
          ))
        )}
      </div>

      <button
        onClick={() => onNavigate('main')}
        className="mt-4 w-full border-2 border-black py-3 font-medium hover:bg-black hover:text-white transition-all"
      >
        ← Back
      </button>

      {/* Download Modal */}
      {downloadFormName && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white border-2 border-black p-4 w-full max-w-sm">
            <h3 className="font-bold text-lg mb-4 border-b border-black pb-2">Download Format</h3>
            <p className="text-sm mb-4 text-gray-600">
              Select format for "{downloadFormName}"
            </p>
            <div className="flex gap-2">
              <button
                onClick={async () => {
                  const { exportToPDF } = await import('../utils/exportUtils');
                  const entries = await db.getEntries(downloadFormName);
                  exportToPDF(entries, downloadFormName);
                  setDownloadFormName(null);
                }}
                className="flex-1 border-2 border-black py-3 font-medium hover:bg-black hover:text-white transition-all"
              >
                📄 PDF
              </button>
              <button
                onClick={async () => {
                  const { exportToExcel } = await import('../utils/exportUtils');
                  const entries = await db.getEntries(downloadFormName);
                  exportToExcel(entries, downloadFormName);
                  setDownloadFormName(null);
                }}
                className="flex-1 border-2 border-black py-3 font-medium hover:bg-black hover:text-white transition-all"
              >
                📊 Excel
              </button>
            </div>
            <button
              onClick={() => setDownloadFormName(null)}
              className="mt-3 w-full border-2 border-black py-2 font-medium hover:bg-gray-100"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
