import { useState, useEffect, useRef } from 'react';
import { db, SalesEntry } from '../services/database';
import { processImage } from '../utils/imageUtils';

interface MainPageProps {
  onNavigate?: (page: string) => void;
}

export const MainPage = ({}: MainPageProps) => {
  const [formName, setFormName] = useState('');
  const [formNames, setFormNames] = useState<string[]>([]);
  const [productName, setProductName] = useState('');
  const [qty, setQty] = useState('');
  const [amount, setAmount] = useState('');
  const [remarks, setRemarks] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [entries, setEntries] = useState<SalesEntry[]>([]);
  const [total, setTotal] = useState(0);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editData, setEditData] = useState<Partial<SalesEntry>>({});
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadFormNames();
    loadEntries();
  }, [formName]);

  const loadFormNames = async () => {
    const names = await db.getFormNames();
    setFormNames(names);
  };

  const loadEntries = async () => {
    if (!formName) {
      setEntries([]);
      setTotal(0);
      return;
    }

    const data = await db.getEntries(formName);
    setEntries(data);
    
    const sum = data.reduce((acc, entry) => acc + entry.amount, 0);
    setTotal(sum);
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const processed = await processImage(file);
        setImage(processed);
      } catch (error) {
        console.error('Error processing image:', error);
        alert('Failed to process image');
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formName || !productName || !qty || !amount) {
      alert('Please fill all required fields');
      return;
    }

    const entry: Omit<SalesEntry, 'id'> = {
      formName,
      date: new Date().toISOString().split('T')[0],
      productName,
      qty: parseInt(qty),
      amount: parseFloat(amount),
      remarks,
      image,
      timestamp: new Date().toISOString()
    };

    try {
      await db.addEntry(entry);
      
      // Reset form
      setProductName('');
      setQty('');
      setAmount('');
      setRemarks('');
      setImage(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      
      // Reload entries
      await loadEntries();
      await loadFormNames();
    } catch (error) {
      console.error('Error saving entry:', error);
      alert('Failed to save entry');
    }
  };

  const handleEdit = (entry: SalesEntry) => {
    setEditingId(entry.id!);
    setEditData({
      date: entry.date,
      productName: entry.productName,
      qty: entry.qty,
      amount: entry.amount,
      remarks: entry.remarks
    });
  };

  const handleSaveEdit = async () => {
    if (editingId === null) return;

    try {
      await db.updateEntry(editingId, {
        ...editData,
        timestamp: new Date().toISOString()
      });
      
      setEditingId(null);
      setEditData({});
      await loadEntries();
    } catch (error) {
      console.error('Error updating entry:', error);
      alert('Failed to update entry');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this entry?')) return;

    try {
      await db.deleteEntry(id);
      await loadEntries();
    } catch (error) {
      console.error('Error deleting entry:', error);
      alert('Failed to delete entry');
    }
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr : d.toLocaleDateString();
  };

  return (
    <div className="max-w-md mx-auto p-4">
      {/* Form Name */}
      <div className="border-2 border-black p-4 mb-4">
        <input
          type="text"
          value={formName}
          onChange={(e) => setFormName(e.target.value)}
          list="formNameList"
          className="w-full text-xl font-bold text-center border-b-2 border-black bg-transparent outline-none pb-2"
          placeholder="Form Name"
          onClick={(e) => e.currentTarget.select()}
        />
        <datalist id="formNameList">
          {formNames.map((name) => (
            <option key={name} value={name} />
          ))}
        </datalist>
      </div>

      {/* Total Display */}
      <div className="border-2 border-black p-4 mb-4 bg-black text-white">
        <div className="flex justify-between items-center">
          <span className="font-medium">Total Amount:</span>
          <span className="text-2xl font-bold">₹{total.toFixed(2)}</span>
        </div>
      </div>

      {/* Entry Form */}
      <form onSubmit={handleSubmit} className="border-2 border-black p-4 mb-4">
        <div className="mb-4">
          <label htmlFor="productName" className="block text-sm font-medium mb-1">
            Product Name
          </label>
          <input
            type="text"
            id="productName"
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
            required
            className="w-full px-3 py-2 border-2 border-black outline-none focus:bg-gray-100"
            placeholder="Enter product name"
          />
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="qty" className="block text-sm font-medium mb-1">
              Quantity
            </label>
            <input
              type="number"
              id="qty"
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              required
              min="1"
              className="w-full px-3 py-2 border-2 border-black outline-none focus:bg-gray-100"
              placeholder="Qty"
            />
          </div>
          <div>
            <label htmlFor="amount" className="block text-sm font-medium mb-1">
              Amount
            </label>
            <input
              type="number"
              id="amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
              step="0.01"
              min="0"
              className="w-full px-3 py-2 border-2 border-black outline-none focus:bg-gray-100"
              placeholder="Amount"
            />
          </div>
        </div>

        <div className="mb-4">
          <label htmlFor="remarks" className="block text-sm font-medium mb-1">
            Remarks
          </label>
          <input
            type="text"
            id="remarks"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            className="w-full px-3 py-2 border-2 border-black outline-none focus:bg-gray-100"
            placeholder="Optional remarks"
          />
        </div>

        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Image (Camera/Upload)</label>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleImageChange}
            className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border-2 file:border-black file:text-sm file:font-semibold file:bg-white file:text-black hover:file:bg-black hover:file:text-white transition-all"
          />
          {image && (
            <img
              src={image}
              alt="Preview"
              className="w-20 h-20 object-cover mt-2 border border-black"
            />
          )}
        </div>

        <button
          type="submit"
          className="w-full bg-black text-white font-bold py-3 hover:bg-gray-800 transition-all"
        >
          Save
        </button>
      </form>

      {/* Entries List */}
      <div className="border-2 border-black">
        <div className="border-b-2 border-black p-3 bg-gray-100">
          <span className="font-medium">Entries</span>
        </div>
        <div className="max-h-64 overflow-y-auto">
          {entries.length === 0 ? (
            <p className="text-gray-500 text-center py-4 text-sm">No entries yet</p>
          ) : (
            entries.map((entry) => (
              <div
                key={entry.id}
                className="p-3 border-b border-gray-200 flex justify-between items-center"
              >
                <div className="flex gap-3 items-center">
                  {entry.image && (
                    <img
                      src={entry.image}
                      alt={entry.productName}
                      className="w-10 h-10 object-cover border border-gray-300 rounded"
                    />
                  )}
                  <div>
                    <p className="font-medium">
                      {entry.productName}{' '}
                      {entry.date && (
                        <span className="text-xs text-gray-400 font-normal">
                          ({formatDate(entry.date)})
                        </span>
                      )}
                    </p>
                    <p className="text-sm text-gray-600">
                      Qty: {entry.qty} | ₹{entry.amount.toFixed(2)}
                    </p>
                    {entry.remarks && (
                      <p className="text-xs text-gray-500 italic">{entry.remarks}</p>
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => handleEdit(entry)}
                    className="px-2 py-1 border border-black text-xs hover:bg-black hover:text-white"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(entry.id!)}
                    className="px-2 py-1 border border-black text-xs hover:bg-black hover:text-white"
                  >
                    Del
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Edit Modal */}
      {editingId !== null && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white border-2 border-black p-4 w-full max-w-sm">
            <h3 className="font-bold text-lg mb-4 border-b border-black pb-2">Edit Entry</h3>
            <div className="mb-3">
              <label className="block text-sm font-medium mb-1">Date</label>
              <input
                type="date"
                value={editData.date || ''}
                onChange={(e) => setEditData({ ...editData, date: e.target.value })}
                className="w-full px-3 py-2 border-2 border-black outline-none"
              />
            </div>
            <div className="mb-3">
              <label className="block text-sm font-medium mb-1">Product Name</label>
              <input
                type="text"
                value={editData.productName || ''}
                onChange={(e) => setEditData({ ...editData, productName: e.target.value })}
                className="w-full px-3 py-2 border-2 border-black outline-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">Quantity</label>
                <input
                  type="number"
                  value={editData.qty || ''}
                  onChange={(e) => setEditData({ ...editData, qty: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border-2 border-black outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={editData.amount || ''}
                  onChange={(e) => setEditData({ ...editData, amount: parseFloat(e.target.value) })}
                  className="w-full px-3 py-2 border-2 border-black outline-none"
                />
              </div>
            </div>
            <div className="mb-3">
              <label className="block text-sm font-medium mb-1">Remarks</label>
              <input
                type="text"
                value={editData.remarks || ''}
                onChange={(e) => setEditData({ ...editData, remarks: e.target.value })}
                className="w-full px-3 py-2 border-2 border-black outline-none"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setEditingId(null);
                  setEditData({});
                }}
                className="flex-1 border-2 border-black py-2 font-medium hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEdit}
                className="flex-1 bg-black text-white py-2 font-medium hover:bg-gray-800"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
