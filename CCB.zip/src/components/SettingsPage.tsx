import { useState, useEffect } from 'react';
import { db, Settings } from '../services/database';

interface SettingsPageProps {
  onNavigate: (page: string) => void;
  onSettingsChange: () => void;
}

export const SettingsPage = ({ onNavigate, onSettingsChange }: SettingsPageProps) => {
  const [appName, setAppName] = useState('Cosmic Corner Sales');
  const [theme, setTheme] = useState<'default' | 'plain'>('default');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const settings = await db.getSettings();
    setAppName(settings.appName);
    setTheme(settings.theme);
  };

  const handleSave = async () => {
    const settings: Settings = { appName, theme };
    
    try {
      await db.saveSettings(settings);
      onSettingsChange();
      alert('Settings saved!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings');
    }
  };

  const handleBackup = async () => {
    try {
      const data = await db.exportData();
      const blob = new Blob([data], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `cosmic-backup-${new Date().toISOString().split('T')[0]}.txt`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error creating backup:', error);
      alert('Failed to create backup');
    }
  };

  const handleRestore = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt';
    
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      try {
        const text = await file.text();
        await db.importData(text);
        alert('Backup restored successfully! Reloading...');
        window.location.reload();
      } catch (error) {
        console.error('Error restoring backup:', error);
        alert('Failed to restore backup');
      }
    };

    input.click();
  };

  return (
    <div className="max-w-md mx-auto p-4">
      <h2 className="text-xl font-bold mb-4 border-b-2 border-black pb-2">Settings</h2>

      <div className="mb-6">
        <label className="block text-sm font-bold mb-2">App Name (Header)</label>
        <input
          type="text"
          value={appName}
          onChange={(e) => setAppName(e.target.value)}
          className="w-full px-3 py-2 border-2 border-black outline-none"
          placeholder="Cosmic Corner Sales"
        />
      </div>

      <div className="mb-6">
        <label className="block text-sm font-bold mb-2">Background Theme</label>
        <div className="flex gap-4">
          <label className="flex items-center cursor-pointer">
            <input
              type="radio"
              name="theme"
              value="default"
              checked={theme === 'default'}
              onChange={(e) => setTheme(e.target.value as 'default' | 'plain')}
              className="mr-2"
            />
            <span>Cosmic (Default)</span>
          </label>
          <label className="flex items-center cursor-pointer">
            <input
              type="radio"
              name="theme"
              value="plain"
              checked={theme === 'plain'}
              onChange={(e) => setTheme(e.target.value as 'default' | 'plain')}
              className="mr-2"
            />
            <span>Plain (White)</span>
          </label>
        </div>
      </div>

      <button
        onClick={handleSave}
        className="w-full bg-black text-white font-bold py-3 hover:bg-gray-800 transition-all mb-6"
      >
        Save Settings
      </button>

      <div className="border-t-2 border-black pt-6">
        <h3 className="font-bold mb-3">Data Management</h3>
        <button
          onClick={handleBackup}
          className="block w-full border-2 border-black py-3 font-medium hover:bg-black hover:text-white transition-all mb-3"
        >
          ⬇ Download Backup
        </button>
        <button
          onClick={handleRestore}
          className="block w-full border-2 border-black py-3 font-medium hover:bg-black hover:text-white transition-all"
        >
          ⬆ Restore Backup
        </button>
      </div>

      <button
        onClick={() => onNavigate('main')}
        className="mt-6 w-full border-2 border-black py-3 font-medium hover:bg-black hover:text-white transition-all"
      >
        ← Back
      </button>
    </div>
  );
};
