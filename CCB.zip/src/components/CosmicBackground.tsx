import { useEffect, useRef } from 'react';

interface CosmicBackgroundProps {
  enabled: boolean;
}

export const CosmicBackground = ({ enabled }: CosmicBackgroundProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!enabled || !containerRef.current) return;

    const container = containerRef.current;
    container.innerHTML = '';

    // Get random position avoiding content area
    const getRandomPosition = () => {
      const screenWidth = window.innerWidth;
      const screenHeight = window.innerHeight;
      const contentWidth = 450;
      const contentLeft = (screenWidth - contentWidth) / 2;
      const contentRight = contentLeft + contentWidth;
      const contentTop = 60;
      const contentBottom = screenHeight - 50;

      let x: number, y: number, attempts = 0;
      do {
        x = Math.random() * 100;
        y = Math.random() * 100;
        const pixelX = (x / 100) * screenWidth;
        const pixelY = (y / 100) * screenHeight;
        attempts++;

        if (
          !(pixelX > contentLeft - 20 && pixelX < contentRight + 20 &&
            pixelY > contentTop && pixelY < contentBottom)
        ) {
          break;
        }
      } while (attempts < 50);

      return { x, y };
    };

    // Create twinkling stars
    const starTypes = ['tiny', 'tiny', 'tiny', 'small', 'small', 'medium', 'bright'];

    for (let i = 0; i < 100; i++) {
      const star = document.createElement('div');
      const type = starTypes[Math.floor(Math.random() * starTypes.length)];
      star.className = `star ${type}`;

      const pos = getRandomPosition();
      star.style.left = pos.x + '%';
      star.style.top = pos.y + '%';
      star.style.setProperty('--delay', (Math.random() * 4) + 's');
      star.style.setProperty('--duration', (2 + Math.random() * 3) + 's');
      star.style.setProperty('--min-opacity', String(0.1 + Math.random() * 0.2));
      star.style.setProperty('--max-opacity', String(0.5 + Math.random() * 0.4));

      container.appendChild(star);
    }

    // Create cosmic dust
    for (let i = 0; i < 40; i++) {
      const dust = document.createElement('div');
      dust.className = 'cosmic-dust';
      const pos = getRandomPosition();
      dust.style.left = pos.x + '%';
      dust.style.top = pos.y + '%';
      dust.style.animationDelay = (Math.random() * 20) + 's';
      dust.style.animationDuration = (15 + Math.random() * 10) + 's';
      container.appendChild(dust);
    }

    // Shooting stars
    const launchShootingStar = () => {
      const shootingStar = document.createElement('div');
      shootingStar.className = 'shooting-star';

      const edge = Math.floor(Math.random() * 3);
      let startX: number, startY: number, angle: number;

      if (edge === 0) {
        startX = 10 + Math.random() * 80;
        startY = -5 + Math.random() * 15;
        angle = 25 + Math.random() * 40;
      } else if (edge === 1) {
        startX = -5 + Math.random() * 15;
        startY = 10 + Math.random() * 40;
        angle = 20 + Math.random() * 30;
      } else {
        startX = 60 + Math.random() * 35;
        startY = -5 + Math.random() * 20;
        angle = 30 + Math.random() * 25;
      }

      shootingStar.style.left = startX + '%';
      shootingStar.style.top = startY + '%';

      const travelX = 150 + Math.random() * 300;
      const travelY = travelX * Math.tan(angle * Math.PI / 180);
      const duration = 0.8 + Math.random() * 1.2;

      shootingStar.style.setProperty('--angle', angle + 'deg');
      shootingStar.style.setProperty('--travel-x', travelX + 'px');
      shootingStar.style.setProperty('--travel-y', travelY + 'px');
      shootingStar.style.setProperty('--shoot-duration', duration + 's');

      container.appendChild(shootingStar);

      requestAnimationFrame(() => {
        shootingStar.classList.add('active');
      });

      setTimeout(() => {
        shootingStar.remove();
      }, duration * 1000 + 100);
    };

    const scheduleShootingStar = () => {
      const delay = 1500 + Math.random() * 4000;
      setTimeout(() => {
        launchShootingStar();
        scheduleShootingStar();
      }, delay);
    };

    setTimeout(launchShootingStar, 800);
    setTimeout(launchShootingStar, 2000);
    setTimeout(launchShootingStar, 3500);
    scheduleShootingStar();

  }, [enabled]);

  if (!enabled) return null;

  return <div ref={containerRef} className="stars-container fixed inset-0 pointer-events-none overflow-hidden -z-10" />;
};
