import { useState, useEffect, useRef } from 'react';
import { db, SalesEntry } from '../services/database';
import { processImage } from '../utils/imageUtils';

interface OverviewPageProps {
  formName: string;
  onNavigate: (page: string) => void;
}

export const OverviewPage = ({ formName, onNavigate }: OverviewPageProps) => {
  const [entries, setEntries] = useState<SalesEntry[]>([]);
  const [totalQty, setTotalQty] = useState(0);
  const [totalAmount, setTotalAmount] = useState(0);
  const [showDetails, setShowDetails] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editData, setEditData] = useState<Partial<SalesEntry>>({});

  // Add entry form state
  const [productName, setProductName] = useState('');
  const [qty, setQty] = useState('');
  const [amount, setAmount] = useState('');
  const [remarks, setRemarks] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadData();
  }, [formName]);

  const loadData = async () => {
    const data = await db.getEntries(formName);
    setEntries(data);

    const stats = await db.getFormStats(formName);
    setTotalQty(stats.qty);
    setTotalAmount(stats.amount);
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const processed = await processImage(file);
        setImage(processed);
      } catch (error) {
        console.error('Error processing image:', error);
        alert('Failed to process image');
      }
    }
  };

  const handleAddEntry = async () => {
    if (!productName || !qty || !amount) {
      alert('Please fill all required fields');
      return;
    }

    const entry: Omit<SalesEntry, 'id'> = {
      formName,
      date: new Date().toISOString().split('T')[0],
      productName,
      qty: parseInt(qty),
      amount: parseFloat(amount),
      remarks,
      image,
      timestamp: new Date().toISOString()
    };

    try {
      await db.addEntry(entry);
      
      // Reset form
      setProductName('');
      setQty('');
      setAmount('');
      setRemarks('');
      setImage(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setShowAddModal(false);
      
      await loadData();
    } catch (error) {
      console.error('Error adding entry:', error);
      alert('Failed to add entry');
    }
  };

  const handleEdit = (entry: SalesEntry) => {
    setEditingId(entry.id!);
    setEditData({
      date: entry.date,
      productName: entry.productName,
      qty: entry.qty,
      amount: entry.amount,
      remarks: entry.remarks
    });
  };

  const handleSaveEdit = async () => {
    if (editingId === null) return;

    try {
      await db.updateEntry(editingId, {
        ...editData,
        timestamp: new Date().toISOString()
      });
      
      setEditingId(null);
      setEditData({});
      await loadData();
    } catch (error) {
      console.error('Error updating entry:', error);
      alert('Failed to update entry');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this entry?')) return;

    try {
      await db.deleteEntry(id);
      await loadData();
    } catch (error) {
      console.error('Error deleting entry:', error);
      alert('Failed to delete entry');
    }
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr : d.toLocaleDateString();
  };

  return (
    <div className="max-w-md mx-auto p-4">
      <h2 className="text-xl font-bold mb-4 border-b-2 border-black pb-2">{formName}</h2>

      <div className="border-2 border-black mb-4">
        <div className="p-4 border-b border-black flex justify-between">
          <span>Total Quantity:</span>
          <span className="font-bold">{totalQty}</span>
        </div>
        <div className="p-4 bg-black text-white flex justify-between">
          <span>Total Amount:</span>
          <span className="font-bold">₹{totalAmount.toFixed(2)}</span>
        </div>
      </div>

      <button
        onClick={() => setShowDetails(!showDetails)}
        className="w-full border-2 border-black py-3 font-medium hover:bg-black hover:text-white transition-all mb-4"
      >
        {showDetails ? 'Hide Details' : 'Details'}
      </button>

      <button
        onClick={() => setShowAddModal(true)}
        className="w-full border-2 border-black py-3 font-medium hover:bg-black hover:text-white transition-all mb-4"
      >
        + Add Entry
      </button>

      {showDetails && (
        <div className="border-2 border-black mb-4">
          <div className="border-b-2 border-black p-3 bg-gray-100">
            <span className="font-medium">All Entries</span>
          </div>
          <div className="max-h-64 overflow-y-auto">
            {entries.map((entry) => (
              <div key={entry.id} className="p-3 border-b border-gray-200">
                <div className="flex justify-between items-start">
                  <div className="flex gap-3">
                    {entry.image && (
                      <img
                        src={entry.image}
                        alt={entry.productName}
                        className="w-10 h-10 object-cover border border-gray-300 rounded"
                      />
                    )}
                    <div>
                      <span className="font-medium">{entry.productName}</span>
                      <p className="text-xs text-gray-500">{formatDate(entry.date)}</p>
                      <p className="text-sm text-gray-600">
                        Qty: {entry.qty} | ₹{entry.amount.toFixed(2)}
                      </p>
                      {entry.remarks && (
                        <p className="text-xs text-gray-500 italic">{entry.remarks}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleEdit(entry)}
                      className="px-2 py-1 border border-black text-xs hover:bg-black hover:text-white"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(entry.id!)}
                      className="px-2 py-1 border border-black text-xs hover:bg-black hover:text-white"
                    >
                      Del
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <button
        onClick={() => onNavigate('allForms')}
        className="w-full border-2 border-black py-3 font-medium hover:bg-black hover:text-white transition-all"
      >
        ← Back
      </button>

      {/* Add Entry Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white border-2 border-black p-4 w-full max-w-sm max-h-[90vh] overflow-y-auto">
            <h3 className="font-bold text-lg mb-4 border-b border-black pb-2 sticky top-0 bg-white">
              Add Entry to {formName}
            </h3>
            <div className="mb-3">
              <label className="block text-sm font-medium mb-1">Product Name</label>
              <input
                type="text"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                className="w-full px-3 py-2 border-2 border-black outline-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">Quantity</label>
                <input
                  type="number"
                  value={qty}
                  onChange={(e) => setQty(e.target.value)}
                  min="1"
                  className="w-full px-3 py-2 border-2 border-black outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Amount</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  step="0.01"
                  min="0"
                  className="w-full px-3 py-2 border-2 border-black outline-none"
                />
              </div>
            </div>
            <div className="mb-3">
              <label className="block text-sm font-medium mb-1">Remarks</label>
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                className="w-full px-3 py-2 border-2 border-black outline-none"
              />
            </div>
            <div className="mb-3">
              <label className="block text-sm font-medium mb-1">Image (Camera/Upload)</label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleImageChange}
                className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border-2 file:border-black file:text-sm file:font-semibold file:bg-white file:text-black hover:file:bg-black hover:file:text-white transition-all"
              />
              {image && (
                <img
                  src={image}
                  alt="Preview"
                  className="w-20 h-20 object-cover mt-2 border border-black"
                />
              )}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setProductName('');
                  setQty('');
                  setAmount('');
                  setRemarks('');
                  setImage(null);
                  if (fileInputRef.current) fileInputRef.current.value = '';
                }}
                className="flex-1 border-2 border-black py-2 font-medium hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                onClick={handleAddEntry}
                className="flex-1 bg-black text-white py-2 font-medium hover:bg-gray-800"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {editingId !== null && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white border-2 border-black p-4 w-full max-w-sm">
            <h3 className="font-bold text-lg mb-4 border-b border-black pb-2">Edit Entry</h3>
            <div className="mb-3">
              <label className="block text-sm font-medium mb-1">Date</label>
              <input
                type="date"
                value={editData.date || ''}
                onChange={(e) => setEditData({ ...editData, date: e.target.value })}
                className="w-full px-3 py-2 border-2 border-black outline-none"
              />
            </div>
            <div className="mb-3">
              <label className="block text-sm font-medium mb-1">Product Name</label>
              <input
                type="text"
                value={editData.productName || ''}
                onChange={(e) => setEditData({ ...editData, productName: e.target.value })}
                className="w-full px-3 py-2 border-2 border-black outline-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">Quantity</label>
                <input
                  type="number"
                  value={editData.qty || ''}
                  onChange={(e) => setEditData({ ...editData, qty: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border-2 border-black outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={editData.amount || ''}
                  onChange={(e) => setEditData({ ...editData, amount: parseFloat(e.target.value) })}
                  className="w-full px-3 py-2 border-2 border-black outline-none"
                />
              </div>
            </div>
            <div className="mb-3">
              <label className="block text-sm font-medium mb-1">Remarks</label>
              <input
                type="text"
                value={editData.remarks || ''}
                onChange={(e) => setEditData({ ...editData, remarks: e.target.value })}
                className="w-full px-3 py-2 border-2 border-black outline-none"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setEditingId(null);
                  setEditData({});
                }}
                className="flex-1 border-2 border-black py-2 font-medium hover:bg-gray-100"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEdit}
                className="flex-1 bg-black text-white py-2 font-medium hover:bg-gray-800"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
