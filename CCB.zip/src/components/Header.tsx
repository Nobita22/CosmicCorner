import { useState, useRef, useEffect } from 'react';

interface HeaderProps {
  title: string;
  onNavigate: (page: string) => void;
}

export const Header = ({ title, onNavigate }: HeaderProps) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="border-b border-black p-4 flex justify-between items-center bg-white relative">
      <button
        onClick={() => setMenuOpen(!menuOpen)}
        className="text-2xl font-bold hover:bg-black hover:text-white px-2 py-1 transition-all"
      >
        ☰
      </button>
      
      <span
        onClick={() => onNavigate('main')}
        className="text-sm font-bold cursor-pointer hover:underline"
      >
        {title}
      </span>
      
      <div className="w-8" />

      {menuOpen && (
        <div
          ref={menuRef}
          className="absolute top-14 left-4 bg-white border-2 border-black shadow-lg z-50"
        >
          <button
            onClick={() => {
              setMenuOpen(false);
              onNavigate('allForms');
            }}
            className="block w-full px-6 py-3 text-left font-medium hover:bg-black hover:text-white transition-all border-b border-black"
          >
            Forms
          </button>
          <button
            onClick={() => {
              setMenuOpen(false);
              onNavigate('main');
            }}
            className="block w-full px-6 py-3 text-left font-medium hover:bg-black hover:text-white transition-all border-b border-black"
          >
            Home
          </button>
          <button
            onClick={() => {
              setMenuOpen(false);
              onNavigate('settings');
            }}
            className="block w-full px-6 py-3 text-left font-medium hover:bg-black hover:text-white transition-all"
          >
            Settings
          </button>
        </div>
      )}
    </header>
  );
};
