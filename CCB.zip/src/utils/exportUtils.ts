import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import { SalesEntry } from '../services/database';

export const exportToPDF = (entries: SalesEntry[], formName: string) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Column positions
  const col1 = 15;  // S.No
  const col2 = 25;  // Date
  const col3 = 50;  // Product Name
  const col4 = 105; // Remarks
  const col5 = 145; // Qty
  const col6 = 165; // Amount
  const rightMargin = pageWidth - 15;
  
  // Title
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text(formName, pageWidth / 2, 20, { align: 'center' });
  
  // Subtitle
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Cosmic Corner Sales', pageWidth / 2, 28, { align: 'center' });
  doc.text('Generated: ' + new Date().toLocaleDateString(), pageWidth / 2, 34, { align: 'center' });
  
  // Line
  doc.setLineWidth(0.5);
  doc.line(15, 40, rightMargin, 40);
  
  // Table Header
  let y = 50;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('S.No', col1, y);
  doc.text('Date', col2, y);
  doc.text('Product', col3, y);
  doc.text('Remarks', col4, y);
  doc.text('Qty', col5, y);
  doc.text('Amount', col6, y);
  
  // Line under header
  y += 8;
  doc.setLineWidth(0.3);
  doc.line(15, y, rightMargin, y);
  
  // Table Data
  y += 10;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  
  let totalQty = 0;
  let totalAmount = 0;
  
  entries.forEach((item, index) => {
    if (y > 265) {
      doc.addPage();
      y = 20;
    }
    
    // Format date
    let displayDate = '-';
    if (item.date) {
      const d = new Date(item.date);
      if (!isNaN(d.getTime())) {
        displayDate = d.toLocaleDateString();
      }
    }

    doc.text(String(index + 1), col1, y);
    doc.text(displayDate, col2, y);
    doc.text(item.productName.substring(0, 25), col3, y);
    doc.text((item.remarks || '-').substring(0, 20), col4, y);
    doc.text(String(item.qty), col5, y);
    doc.text(item.amount.toFixed(2), col6, y);
    
    totalQty += item.qty;
    totalAmount += item.amount;
    y += 8;
  });
  
  // Total line
  y += 5;
  doc.setLineWidth(0.5);
  doc.line(15, y, rightMargin, y);
  
  // Totals
  y += 10;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('TOTAL', col3, y);
  doc.text(String(totalQty), col5, y);
  doc.text('Rs. ' + totalAmount.toFixed(2), col6, y);
  
  // Double line under total
  y += 4;
  doc.setLineWidth(0.3);
  doc.line(col5 - 5, y, rightMargin, y);
  y += 1;
  doc.line(col5 - 5, y, rightMargin, y);
  
  // Footer
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text('Cosmic Corner Sales', pageWidth / 2, 285, { align: 'center' });
  
  doc.save(`${formName}-${new Date().toISOString().split('T')[0]}.pdf`);
};

export const exportToExcel = (entries: SalesEntry[], formName: string) => {
  // Prepare data
  const excelData: any[][] = [
    [formName],
    ['Cosmic Corner Sales'],
    [`Generated: ${new Date().toLocaleDateString()}`],
    [],
    ['S.No', 'Date', 'Product Name', 'Remarks', 'Image Ref', 'Quantity', 'Amount (₹)']
  ];
  
  let totalQty = 0;
  let totalAmount = 0;
  
  entries.forEach((item, index) => {
    excelData.push([
      index + 1,
      item.date || '-',
      item.productName,
      item.remarks || '',
      item.image ? 'Has Image' : 'No',
      item.qty,
      item.amount
    ]);
    totalQty += item.qty;
    totalAmount += item.amount;
  });
  
  // Add totals
  excelData.push([]);
  excelData.push(['', '', 'TOTAL', '', '', totalQty, totalAmount]);
  
  // Create workbook
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(excelData);
  
  // Set column widths
  ws['!cols'] = [
    { wch: 8 },
    { wch: 15 },
    { wch: 30 },
    { wch: 25 },
    { wch: 10 },
    { wch: 12 },
    { wch: 15 }
  ];
  
  XLSX.utils.book_append_sheet(wb, ws, 'Sales Data');
  XLSX.writeFile(wb, `${formName}-${new Date().toISOString().split('T')[0]}.xlsx`);
};
