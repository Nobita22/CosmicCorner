/* eslint-disable @typescript-eslint/no-explicit-any */
import initSqlJs, { Database } from 'sql.js';

export interface SalesEntry {
  id?: number;
  formName: string;
  date: string;
  productName: string;
  qty: number;
  amount: number;
  remarks: string;
  image: string | null;
  timestamp: string;
}

export interface Settings {
  appName: string;
  theme: 'default' | 'plain';
}

class DatabaseService {
  private db: Database | null = null;
  private SQL: any = null;
  private dbKey = 'cosmic-corner-db';

  async init() {
    if (this.db) return;

    try {
      // Initialize SQL.js
      this.SQL = await initSqlJs({
        locateFile: (file) => `https://sql.js.org/dist/${file}`
      });

      // Try to load existing database from localStorage
      const savedDb = localStorage.getItem(this.dbKey);
      
      if (savedDb) {
        const uint8Array = new Uint8Array(JSON.parse(savedDb));
        this.db = new this.SQL.Database(uint8Array);
      } else {
        this.db = new this.SQL.Database();
        this.createTables();
      }
    } catch (error) {
      console.error('Database initialization error:', error);
      throw error;
    }
  }

  private createTables() {
    if (!this.db) return;

    // Create sales entries table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        formName TEXT NOT NULL,
        date TEXT NOT NULL,
        productName TEXT NOT NULL,
        qty INTEGER NOT NULL,
        amount REAL NOT NULL,
        remarks TEXT,
        image TEXT,
        timestamp TEXT NOT NULL
      )
    `);

    // Create settings table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    `);

    // Create indexes for better performance
    this.db.run(`CREATE INDEX IF NOT EXISTS idx_formName ON entries(formName)`);
    this.db.run(`CREATE INDEX IF NOT EXISTS idx_date ON entries(date)`);
    this.db.run(`CREATE INDEX IF NOT EXISTS idx_timestamp ON entries(timestamp)`);

    this.save();
  }

  private save() {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      const buffer = JSON.stringify(Array.from(data));
      localStorage.setItem(this.dbKey, buffer);
    } catch (error) {
      console.error('Error saving database:', error);
    }
  }

  // ============ ENTRIES METHODS ============

  async addEntry(entry: Omit<SalesEntry, 'id'>): Promise<number> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      this.db.run(
        `INSERT INTO entries (formName, date, productName, qty, amount, remarks, image, timestamp)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          entry.formName,
          entry.date,
          entry.productName,
          entry.qty,
          entry.amount,
          entry.remarks || '',
          entry.image || null,
          entry.timestamp
        ]
      );

      const result = this.db.exec('SELECT last_insert_rowid()');
      const id = result[0].values[0][0] as number;
      
      this.save();
      return id;
    } catch (error) {
      console.error('Error adding entry:', error);
      throw error;
    }
  }

  async getEntries(formName?: string): Promise<SalesEntry[]> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      let query = 'SELECT * FROM entries';
      let params: any[] = [];

      if (formName) {
        query += ' WHERE formName = ?';
        params = [formName];
      }

      query += ' ORDER BY timestamp DESC';

      const result = this.db.exec(query, params);
      
      if (result.length === 0) return [];

      const columns = result[0].columns;
      const values = result[0].values;

      return values.map((row) => {
        const entry: any = {};
        columns.forEach((col, idx) => {
          entry[col] = row[idx];
        });
        return entry as SalesEntry;
      });
    } catch (error) {
      console.error('Error getting entries:', error);
      return [];
    }
  }

  async getEntry(id: number): Promise<SalesEntry | null> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      const result = this.db.exec('SELECT * FROM entries WHERE id = ?', [id]);
      
      if (result.length === 0 || result[0].values.length === 0) return null;

      const columns = result[0].columns;
      const row = result[0].values[0];
      
      const entry: any = {};
      columns.forEach((col, idx) => {
        entry[col] = row[idx];
      });

      return entry as SalesEntry;
    } catch (error) {
      console.error('Error getting entry:', error);
      return null;
    }
  }

  async updateEntry(id: number, entry: Partial<SalesEntry>): Promise<void> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      const fields: string[] = [];
      const values: any[] = [];

      if (entry.formName !== undefined) { fields.push('formName = ?'); values.push(entry.formName); }
      if (entry.date !== undefined) { fields.push('date = ?'); values.push(entry.date); }
      if (entry.productName !== undefined) { fields.push('productName = ?'); values.push(entry.productName); }
      if (entry.qty !== undefined) { fields.push('qty = ?'); values.push(entry.qty); }
      if (entry.amount !== undefined) { fields.push('amount = ?'); values.push(entry.amount); }
      if (entry.remarks !== undefined) { fields.push('remarks = ?'); values.push(entry.remarks); }
      if (entry.image !== undefined) { fields.push('image = ?'); values.push(entry.image); }
      if (entry.timestamp !== undefined) { fields.push('timestamp = ?'); values.push(entry.timestamp); }

      if (fields.length === 0) return;

      values.push(id);
      
      this.db.run(
        `UPDATE entries SET ${fields.join(', ')} WHERE id = ?`,
        values
      );

      this.save();
    } catch (error) {
      console.error('Error updating entry:', error);
      throw error;
    }
  }

  async deleteEntry(id: number): Promise<void> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      this.db.run('DELETE FROM entries WHERE id = ?', [id]);
      this.save();
    } catch (error) {
      console.error('Error deleting entry:', error);
      throw error;
    }
  }

  async getFormNames(): Promise<string[]> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      const result = this.db.exec('SELECT DISTINCT formName FROM entries ORDER BY formName');
      
      if (result.length === 0) return [];

      return result[0].values.map((row) => row[0] as string);
    } catch (error) {
      console.error('Error getting form names:', error);
      return [];
    }
  }

  async getFormStats(formName: string): Promise<{ qty: number; amount: number; count: number }> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      const result = this.db.exec(
        `SELECT COUNT(*) as count, SUM(qty) as qty, SUM(amount) as amount 
         FROM entries WHERE formName = ?`,
        [formName]
      );

      if (result.length === 0 || result[0].values.length === 0) {
        return { qty: 0, amount: 0, count: 0 };
      }

      const [count, qty, amount] = result[0].values[0];
      
      return {
        count: (count as number) || 0,
        qty: (qty as number) || 0,
        amount: (amount as number) || 0
      };
    } catch (error) {
      console.error('Error getting form stats:', error);
      return { qty: 0, amount: 0, count: 0 };
    }
  }

  // ============ SETTINGS METHODS ============

  async getSettings(): Promise<Settings> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      const result = this.db.exec('SELECT key, value FROM settings');
      
      const settings: Settings = {
        appName: 'Cosmic Corner Sales',
        theme: 'default'
      };

      if (result.length > 0) {
        result[0].values.forEach(([key, value]) => {
          if (key === 'appName') settings.appName = value as string;
          if (key === 'theme') settings.theme = value as 'default' | 'plain';
        });
      }

      return settings;
    } catch (error) {
      console.error('Error getting settings:', error);
      return { appName: 'Cosmic Corner Sales', theme: 'default' };
    }
  }

  async saveSettings(settings: Settings): Promise<void> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      this.db.run(
        'INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)',
        ['appName', settings.appName]
      );
      this.db.run(
        'INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)',
        ['theme', settings.theme]
      );

      this.save();
    } catch (error) {
      console.error('Error saving settings:', error);
      throw error;
    }
  }

  // ============ BACKUP/RESTORE ============

  async exportData(): Promise<string> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('Database not initialized');

    try {
      const data = this.db.export();
      return btoa(String.fromCharCode(...data));
    } catch (error) {
      console.error('Error exporting data:', error);
      throw error;
    }
  }

  async importData(base64Data: string): Promise<void> {
    if (!this.SQL) await this.init();
    if (!this.SQL) throw new Error('SQL not initialized');

    try {
      const binaryString = atob(base64Data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      this.db = new this.SQL.Database(bytes);
      this.save();
    } catch (error) {
      console.error('Error importing data:', error);
      throw error;
    }
  }
}

export const db = new DatabaseService();
