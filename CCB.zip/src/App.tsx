import { useState, useEffect } from 'react';
import { db, Settings } from './services/database';
import { CosmicBackground } from './components/CosmicBackground';
import { Header } from './components/Header';
import { MainPage } from './components/MainPage';
import { AllFormsPage } from './components/AllFormsPage';
import { OverviewPage } from './components/OverviewPage';
import { SettingsPage } from './components/SettingsPage';

type Page = 'main' | 'allForms' | 'overview' | 'settings';

export function App() {
  const [currentPage, setCurrentPage] = useState<Page>('main');
  const [selectedFormName, setSelectedFormName] = useState('');
  const [settings, setSettings] = useState<Settings>({ appName: 'Cosmic Corner Sales', theme: 'default' });
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    initApp();
  }, []);

  const initApp = async () => {
    try {
      await db.init();
      const savedSettings = await db.getSettings();
      setSettings(savedSettings);
      
      // Register service worker
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js').catch((error) => {
          console.log('Service Worker registration failed:', error);
        });
      }
      
      setInitialized(true);
    } catch (error) {
      console.error('Failed to initialize app:', error);
      setInitialized(true);
    }
  };

  const handleNavigate = (page: string, formName?: string) => {
    setCurrentPage(page as Page);
    if (formName) {
      setSelectedFormName(formName);
    }
  };

  const handleSettingsChange = async () => {
    const newSettings = await db.getSettings();
    setSettings(newSettings);
  };

  if (!initialized) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-black border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="font-bold">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-white text-black ${settings.theme === 'plain' ? 'plain-theme' : ''}`}>
      <CosmicBackground enabled={settings.theme === 'default'} />
      
      <Header title={settings.appName} onNavigate={handleNavigate} />

      {currentPage === 'main' && <MainPage onNavigate={handleNavigate} />}
      {currentPage === 'allForms' && <AllFormsPage onNavigate={handleNavigate} />}
      {currentPage === 'overview' && <OverviewPage formName={selectedFormName} onNavigate={handleNavigate} />}
      {currentPage === 'settings' && <SettingsPage onNavigate={handleNavigate} onSettingsChange={handleSettingsChange} />}
    </div>
  );
}
