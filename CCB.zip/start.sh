#!/bin/bash

# Cosmic Corner Sales - Start Script

clear

echo "╔══════════════════════════════════════════════════════════╗"
echo "║                                                          ║"
echo "║          🌟  COSMIC CORNER SALES  🌟                     ║"
echo "║                                                          ║"
echo "║          Sales Management with SQLite Database          ║"
echo "║                                                          ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "Starting server..."
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed!"
    echo "Install it with: pkg install python"
    exit 1
fi

# Get port (default 8000)
PORT=${1:-8000}

# Check if database exists
if [ ! -f "cosmic_sales.db" ]; then
    echo "📦 Creating new database..."
fi

# Start server
python3 server.py $PORT
