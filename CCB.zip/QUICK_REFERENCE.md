# ⚡ Quick Reference - Cosmic Corner Sales

## 🚀 Start Server
```bash
python server.py
# Opens at: http://localhost:8000
```

## 📝 Basic Usage

### Add Entry
1. Type form name in dropdown
2. Enter product name
3. Enter quantity & amount
4. Click "Save Entry"

### Custom Dropdown
- **Click** → Show all forms
- **Type** → Filter/search
- **Select** → Choose form
- **New name** → Create new form

### Remarks (Optional)
1. Click "Remarks" button (underlined)
2. Field expands
3. Type remarks
4. Click again to hide

### Images (Optional)
1. Click "Camera / Upload"
2. Choose camera or file
3. Auto-compressed
4. Click × to remove

## 🎯 Navigation

### Menu (☰)
- **Forms** → See all forms
- **Home** → Back to main page
- **Settings** → App settings

### Forms Page
- Click form → View details
- Click "Download" → Export

### Settings Page
- Change app name
- Switch theme (Cosmic/Plain)
- Download database backup

## 📊 Export

### PDF
1. Forms → Download → PDF
2. Professional formatted report

### Excel
1. Forms → Download → Excel
2. Spreadsheet with all data

### Backup
1. Settings → Download Database Backup
2. Saves complete .db file

## ⌨️ Keyboard Shortcuts

| Field | Keyboard |
|-------|----------|
| Quantity | Numeric |
| Amount | Decimal |
| Product | Text |
| Remarks | Text |

## 🎨 Themes

### Cosmic (Default)
- ⭐ Twinkling stars
- 💫 Shooting stars
- ✨ Cosmic dust

### Plain
- ⚪ Clean white
- No animations
- Faster on old devices

## 🔧 Quick Fixes

### Can't see entries?
→ Enter form name first

### Dropdown empty?
→ Create first entry

### Total not updating?
→ Refresh page (F5)

### Images not saving?
→ Check browser console (F12)

### Server won't start?
→ Check port 8000 not in use

## 📱 Mobile Tips

### iOS
- Add to Home Screen
- Full screen mode

### Android
- Install App
- Standalone mode

### Camera
- Works in both modes
- Auto-compresses images

## 🗂️ Files

```
CosmicCorner/
├── index.html          # Main page
├── style.css           # Styles
├── app.js              # Logic
├── cosmic.js           # Animations
├── server.py           # Server
├── manifest.json       # PWA
├── sales.db            # Database
└── images/             # Photos
```

## 🎯 Best Practices

### Naming
✅ "Daily Sales Jan 2024"
✅ "Store A - Electronics"
❌ "sales" (too generic)

### Backups
- Daily → Cloud sync
- Weekly → Excel export
- Monthly → Database backup

### Performance
- Under 50K entries per form
- Regular database vacuum
- Archive old data

## 📊 Limits

| Item | Limit |
|------|-------|
| Max entries | 100,000+ |
| Query speed | < 1ms |
| Image size | < 100KB |
| Forms | Unlimited |

## 🆘 Emergency

### Lost data?
→ Check database backup

### Corrupted DB?
→ Restore from backup

### Server crash?
→ Restart: `python server.py`

### All else fails?
→ Check README.md

## 🔗 Quick Links

- **Full Docs**: README.md
- **Usage Guide**: COMPLETE_GUIDE.md
- **Summary**: SUMMARY.md

## ⚡ Speed Tips

1. Use keyboard navigation
2. Tab between fields
3. Enter to submit
4. Esc to close modals

## 🎊 That's It!

**You're ready to go!** 🚀

Just run: `python server.py`

Happy selling! 🌟
