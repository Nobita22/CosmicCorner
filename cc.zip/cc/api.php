<?php
// Cosmic Corner Book - Single-file PHP backend
// Endpoints (via action param):
//   GET  api.php?action=read
//   POST api.php?action=write
//   POST api.php?action=upload  (multipart/form-data, field name: file)
//
// Optional Apache rewrites can map:
//   POST /save   -> api.php?action=write
//   POST /upload -> api.php?action=upload

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(204);
  exit;
}

$ROOT = __DIR__;
$DATA_PATH = $ROOT . DIRECTORY_SEPARATOR . 'data.json';
$MEDIA_DIR = $ROOT . DIRECTORY_SEPARATOR . 'Media';
$REPORTS_DIR = $ROOT . DIRECTORY_SEPARATOR . 'Reports';

$DEFAULT_DATA = [
  'inventory' => [],
  'transactions' => [],
  'investments' => [],
  'maintenance' => [],
  'customers' => [],
  'settings' => [
    'currency' => 'INR',
    'businessName' => 'Cosmic Corner Book',
    'lastBackup' => null,
    'lowStockThreshold' => 10
  ]
];

function ensure_dirs($MEDIA_DIR, $REPORTS_DIR) {
  $dirs = [
    $MEDIA_DIR,
    $MEDIA_DIR . DIRECTORY_SEPARATOR . 'Products',
    $MEDIA_DIR . DIRECTORY_SEPARATOR . 'Receipts',
    $MEDIA_DIR . DIRECTORY_SEPARATOR . 'QR_Codes',
    $REPORTS_DIR,
  ];
  foreach ($dirs as $d) {
    if (!is_dir($d)) @mkdir($d, 0775, true);
  }
}

function read_db($DATA_PATH, $DEFAULT_DATA) {
  if (!file_exists($DATA_PATH)) {
    file_put_contents($DATA_PATH, json_encode($DEFAULT_DATA, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    return $DEFAULT_DATA;
  }

  $raw = @file_get_contents($DATA_PATH);
  $json = json_decode($raw, true);
  if (!is_array($json)) {
    // backup corrupt
    @copy($DATA_PATH, $DATA_PATH . '.corrupt.json');
    file_put_contents($DATA_PATH, json_encode($DEFAULT_DATA, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    return $DEFAULT_DATA;
  }

  // soft merge
  $json = array_merge($DEFAULT_DATA, $json);
  $json['settings'] = array_merge($DEFAULT_DATA['settings'], isset($json['settings']) && is_array($json['settings']) ? $json['settings'] : []);
  return $json;
}

function write_db($DATA_PATH, $DEFAULT_DATA, $payload) {
  $decoded = json_decode($payload, true);
  if (!is_array($decoded)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
    exit;
  }
  $decoded = array_merge($DEFAULT_DATA, $decoded);
  $decoded['settings'] = array_merge($DEFAULT_DATA['settings'], isset($decoded['settings']) && is_array($decoded['settings']) ? $decoded['settings'] : []);

  $tmp = $DATA_PATH . '.tmp';
  file_put_contents($tmp, json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
  rename($tmp, $DATA_PATH);
}

function uuidv4() {
  $data = random_bytes(16);
  $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
  $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
  return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

ensure_dirs($MEDIA_DIR, $REPORTS_DIR);

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action === 'read') {
  $db = read_db($DATA_PATH, $DEFAULT_DATA);
  echo json_encode($db, JSON_UNESCAPED_UNICODE);
  exit;
}

if ($action === 'write') {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'POST required']);
    exit;
  }
  $payload = file_get_contents('php://input');
  write_db($DATA_PATH, $DEFAULT_DATA, $payload);
  echo json_encode(['status' => 'success']);
  exit;
}

if ($action === 'upload') {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'POST required']);
    exit;
  }

  if (!isset($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Missing file field']);
    exit;
  }

  $file = $_FILES['file'];
  if (!is_uploaded_file($file['tmp_name'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid upload']);
    exit;
  }

  $orig = $file['name'] ?? 'upload.bin';
  $ext = '';
  $dot = strrpos($orig, '.');
  if ($dot !== false) $ext = strtolower(substr($orig, $dot));

  $name = uuidv4() . $ext;
  $dest = $MEDIA_DIR . DIRECTORY_SEPARATOR . 'Products' . DIRECTORY_SEPARATOR . $name;

  if (!move_uploaded_file($file['tmp_name'], $dest)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Failed to save file']);
    exit;
  }

  $rel = 'Media/Products/' . $name;
  echo json_encode(['status' => 'success', 'path' => $rel]);
  exit;
}

http_response_code(400);
echo json_encode(['status' => 'error', 'message' => 'Unknown action']);
