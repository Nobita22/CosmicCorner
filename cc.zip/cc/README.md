# Cosmic Corner Book (Self-hosted SPA)

This repo is a **single-page** ERP/CRM for a small 3D printing business.

## Folder Structure

- `index.html` – the full SPA (UI + Tailwind + JS logic)
- `data.json` – flat-file database
- `server.py` – Python (stdlib) backend server (recommended)
- `api.php` – PHP backend (LAMP)
- `.htaccess` – optional Apache rewrites for `/save` and `/upload`
- `Media/` – uploaded files
  - `Products/`
  - `Receipts/`
  - `QR_Codes/`
- `Reports/` – generated exports (reserved)

## Run with Python (recommended)

### Windows (localhost)

1. Install Python 3.10+.
2. Open PowerShell in the project folder.

```powershell
python server.py
```

Open:
- `http://localhost:8000`

**Change port** (example: 9000):

```powershell
$env:PORT="9000"; python server.py
```

> By default the server binds to `127.0.0.1` so it’s only accessible on the same device. If you want LAN access, set `HOST=0.0.0.0`.

### Linux / macOS

```bash
python3 server.py
```

Open:
- `http://localhost:8000`

### Android (Termux) (localhost)

```bash
pkg update
pkg install python
python server.py
```

Or use the included launcher:

```bash
chmod +x run_termux.sh
./run_termux.sh
```

Open (on the same phone):
- `http://localhost:8000`

**Change port** (example: 9000):

```bash
PORT=9000 python server.py
```

> On Android browsers, camera/QR scanning works on `http://localhost` / `http://127.0.0.1`. If you later switch to LAN IP access, you may need HTTPS.

> Note: If you want to open the app from **another phone/PC on the same Wi‑Fi**, you must use your device LAN IP and (for camera/QR scanning) HTTPS is usually required.

## Run with PHP

### Option A: PHP built-in server

```bash
php -S 0.0.0.0:8000
```

Open:
- `http://localhost:8000`

> The frontend already falls back to `api.php?action=write` / `api.php?action=upload` automatically, so it works even without Apache rewrites.

### Option B: Apache/LAMP

Upload all files to your web root and ensure `.htaccess` is enabled.

### Option B: Apache/LAMP

Upload all files to your web root and ensure `.htaccess` is enabled.

## HTTPS mode (only needed if you use LAN IP access)

If you are hosting on the **same device** and opening the app via:
- `http://localhost:PORT`

…then camera/QR scanning typically works without HTTPS.

HTTPS is only needed when you access the app from another device using a LAN IP (like `http://192.168.x.x:PORT`).

Most mobile browsers (especially iOS Safari) only allow camera access on:
- `https://...` OR
- `http://localhost` / `http://127.0.0.1`

So if you open the app from another device using your LAN IP like `http://192.168.x.x:8000`, QR scanning may fail.

### Enable HTTPS in `server.py`

1) Create a self-signed certificate (OpenSSL required):

**Linux/macOS/Termux**
```bash
openssl req -x509 -newkey rsa:2048 -keyout key.pem -out cert.pem -days 365 -nodes -subj "/CN=cosmic.local"
```

**Windows (if OpenSSL is installed)**
```powershell
openssl req -x509 -newkey rsa:2048 -keyout key.pem -out cert.pem -days 365 -nodes -subj "/CN=cosmic.local"
```

2) Start the server in HTTPS mode:

**Linux/macOS/Termux**
```bash
HTTPS=1 SSL_CERT=cert.pem SSL_KEY=key.pem python3 server.py
```

**Windows (PowerShell)**
```powershell
$env:HTTPS="1"; $env:SSL_CERT="cert.pem"; $env:SSL_KEY="key.pem"; python server.py
```

Then open:
- `https://<your-lan-ip>:8000`

> You will likely see a certificate warning (expected for self-signed). Accept it for local use.

## Data Safety

- If `data.json` is missing, the backend will create it.
- If `data.json` is corrupted, the backend will back it up and reset.

## Upload Paths

Uploads are stored in:

- `Media/Products/<uuid>.<ext>`

and returned to the frontend as a relative path.
