#!/usr/bin/env python3
"""Cosmic Corner Book - Standard Library Backend

Endpoints:
  GET  /data.json          -> returns JSON database
  POST /save               -> overwrites data.json with request JSON
  POST /upload             -> multipart/form-data (field name: file), saves into Media/Products/

Static files:
  / (index.html)
  /index.html
  /Media/...
  /Reports/...

CORS:
  Access-Control-Allow-Origin: *

Run:
  python3 server.py
  open http://localhost:8000
"""

from __future__ import annotations

import cgi
import json
import mimetypes
import os
from pathlib import Path
import posixpath
import shutil
import sys
import uuid
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import ssl

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data.json"
MEDIA_DIR = ROOT / "Media"
REPORTS_DIR = ROOT / "Reports"

REQUIRED_DIRS = [
    MEDIA_DIR,
    MEDIA_DIR / "Products",
    MEDIA_DIR / "Receipts",
    MEDIA_DIR / "QR_Codes",
    REPORTS_DIR,
]

DEFAULT_DATA = {
    "inventory": [],
    "transactions": [],
    "investments": [],
    "maintenance": [],
    "customers": [],
    "settings": {
        "currency": "INR",
        "businessName": "Cosmic Corner Book",
        "lastBackup": None,
        "lowStockThreshold": 10,
    },
}


def ensure_dirs() -> None:
    for d in REQUIRED_DIRS:
        d.mkdir(parents=True, exist_ok=True)


def read_db() -> dict:
    if not DATA_PATH.exists():
        write_db(DEFAULT_DATA)
        return DEFAULT_DATA
    try:
        with DATA_PATH.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        # If corrupted, keep a backup and re-init
        try:
            shutil.copyfile(DATA_PATH, DATA_PATH.with_suffix(".corrupt.json"))
        except Exception:
            pass
        write_db(DEFAULT_DATA)
        return DEFAULT_DATA


def write_db(data: dict) -> None:
    tmp = DATA_PATH.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DATA_PATH)


class Handler(SimpleHTTPRequestHandler):
    # Serve from project root
    def translate_path(self, path: str) -> str:
        # Based on SimpleHTTPRequestHandler.translate_path but pinned to ROOT
        path = path.split("?", 1)[0]
        path = path.split("#", 1)[0]
        path = posixpath.normpath(path)
        words = path.split("/")
        words = [w for w in words if w]
        p = ROOT
        for w in words:
            if os.path.dirname(w) or w in (os.curdir, os.pardir):
                continue
            p = p / w
        return str(p)

    def end_headers(self) -> None:
        # CORS
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        if self.path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def _send_json(self, code: int, payload: dict):
        data = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        ensure_dirs()

        if self.path.startswith("/save"):
            try:
                length = int(self.headers.get("Content-Length", "0"))
                raw = self.rfile.read(length)
                obj = json.loads(raw.decode("utf-8"))
                if not isinstance(obj, dict):
                    raise ValueError("Root must be object")
                # Soft-merge with defaults (so missing keys won't crash frontend)
                merged = {**DEFAULT_DATA, **obj}
                merged["settings"] = {**DEFAULT_DATA["settings"], **(obj.get("settings") or {})}
                write_db(merged)
                self._send_json(200, {"status": "success"})
            except Exception as e:
                self._send_json(400, {"status": "error", "message": str(e)})
            return

        if self.path.startswith("/upload"):
            ctype = self.headers.get("Content-Type", "")
            if "multipart/form-data" not in ctype:
                self._send_json(400, {"status": "error", "message": "Expected multipart/form-data"})
                return

            try:
                form = cgi.FieldStorage(
                    fp=self.rfile,
                    headers=self.headers,
                    environ={
                        "REQUEST_METHOD": "POST",
                        "CONTENT_TYPE": ctype,
                    },
                )
                if "file" not in form:
                    self._send_json(400, {"status": "error", "message": "Missing file field"})
                    return

                item = form["file"]
                if not getattr(item, "file", None):
                    self._send_json(400, {"status": "error", "message": "Invalid uploaded file"})
                    return

                filename = getattr(item, "filename", "") or "upload.bin"
                ext = os.path.splitext(filename)[1].lower()
                uid = str(uuid.uuid4())
                save_name = f"{uid}{ext}"
                out_path = MEDIA_DIR / "Products" / save_name

                with out_path.open("wb") as out:
                    shutil.copyfileobj(item.file, out)

                rel = str(out_path.relative_to(ROOT)).replace("\\", "/")
                self._send_json(200, {"status": "success", "path": rel})
            except Exception as e:
                self._send_json(500, {"status": "error", "message": str(e)})
            return

        self._send_json(404, {"status": "error", "message": "Unknown endpoint"})


def main():
    ensure_dirs()
    # Create db if missing
    read_db()

    # Default to true localhost for Windows/Termux usage:
    #   http://localhost:PORT
    # If you want LAN access (other devices), run with HOST=0.0.0.0
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    httpd = ThreadingHTTPServer((host, port), Handler)

    # Optional HTTPS for mobile camera access (iOS/Android typically require HTTPS on LAN IP)
    # Usage:
    #   set HTTPS=1
    #   set SSL_CERT=cert.pem
    #   set SSL_KEY=key.pem
    #   python server.py
    #
    # Termux example:
    #   HTTPS=1 SSL_CERT=cert.pem SSL_KEY=key.pem python server.py
    use_https = os.environ.get("HTTPS", "0") == "1"
    if use_https:
      cert = os.environ.get("SSL_CERT", "cert.pem")
      key = os.environ.get("SSL_KEY", "key.pem")
      try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(certfile=cert, keyfile=key)
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
        scheme = "https"
      except Exception as e:
        print(f"[WARN] HTTPS requested but failed to load cert/key: {e}")
        print("       Falling back to HTTP.")
        scheme = "http"
    else:
      scheme = "http"

    print(f"Cosmic Corner Book server running on {scheme}://{host}:{port}")
    # Friendly URLs
    if host in ("127.0.0.1", "localhost"):
        print(f"Open: {scheme}://localhost:{port}")
        print(f"Alt : {scheme}://127.0.0.1:{port}")
    else:
        print(f"Open: {scheme}://{host}:{port}")
        print(f"Tip : If you are running locally, you can still use {scheme}://localhost:{port}")
    print(f"Serving from: {ROOT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")


if __name__ == "__main__":
    main()
