#!/data/data/com.termux/files/usr/bin/bash

# Cosmic Corner Book - Termux quick launcher
# Usage:
#   ./run_termux.sh        (defaults to port 8000)
#   ./run_termux.sh 9000   (custom port)

PORT_ARG="$1"
if [ -z "$PORT_ARG" ]; then
  PORT_ARG="8000"
fi

export PORT="$PORT_ARG"

echo "Starting Cosmic Corner Book on http://localhost:$PORT"

# Prefer python3 if available
if command -v python3 >/dev/null 2>&1; then
  python3 server.py
else
  python server.py
fi
