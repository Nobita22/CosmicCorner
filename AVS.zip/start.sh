#!/bin/bash

# Configuration
APP_DIR=$(pwd)
SERVER_FILE="server.js"
FRONTEND_PORT=5173
BACKEND_PORT=3001

echo "--- ShortsAgent Auto-Run Script ---"

# 1. Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# 2. Check for yt-dlp
if ! command -v yt-dlp &> /dev/null
then
    echo "WARNING: yt-dlp not found! Please install it for video downloads."
    echo "Command: pip install yt-dlp"
fi

# 3. Check for ffmpeg
if ! command -v ffmpeg &> /dev/null
then
    echo "WARNING: ffmpeg not found! Please install it for thumbnail generation."
fi

# 4. Start Backend Server in background
echo "Starting backend server on port $BACKEND_PORT..."
node $SERVER_FILE &
BACKEND_PID=$!

# 5. Start Frontend
echo "Starting frontend..."
npm run dev &
FRONTEND_PID=$!

# Function to handle shutdown
cleanup() {
    echo "Shutting down servers..."
    kill $BACKEND_PID
    kill $FRONTEND_PID
    exit
}

trap cleanup SIGINT SIGTERM

echo "Agent is running 24/7."
echo "Access the dashboard at http://localhost:$FRONTEND_PORT"

# Keep script running
wait
