# ShortsAgent Automation Setup

This application is designed to run 24/7 on a mobile device (via Termux) or a home server.

## Features
- **Automation Agent**: Picks 5 random videos at midnight and schedules them for the day.
- **Intake Form**: Upload files or paste YouTube/Instagram links.
- **Downloader**: Integrated yt-dlp support for fetching high-quality shorts.
- **Reports**: Check daily quota, video runway (forecast), and agent health.
- **Safe Mode**: Automatically restarts and messages you on failures.

## Setup Instructions

1. **System Dependencies**:
   - Install **Node.js** (v16+)
   - Install **yt-dlp**: `pip install yt-dlp`
   - Install **ffmpeg**: `apt install ffmpeg`

2. **API Authentication**:
   - Obtain your YouTube Data API v3 credentials.
   - Save the JSON file as `storage/youtube_auth.json`.

3. **Running the Agent**:
   - Make the script executable: `chmod +x start.sh`
   - Start the system: `./start.sh`

4. **Directory Structure**:
   - `/storage/videos`: Raw video files.
   - `/storage/thumbnails`: Generated thumbnails.
   - `/storage/db.json`: Local database for schedules and metadata.

## Auto-Restart Logic
The included `start.sh` handles basic process management. For true 24/7 reliability on mobile, consider using a tool like `pm2` or a simple cron job that checks if the server is still alive.

## Thumbnail Creation
The agent automatically uses `ffmpeg` to capture a frame from every downloaded video. If it fails, it will look for `storage/default_thumbnail.jpg`.
