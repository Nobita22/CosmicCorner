import React, { useState, useEffect } from 'react';
import { 
  Library, 
  Search, 
  Trash2, 
  Play, 
  Calendar, 
  Clock,
  Video as VideoIcon,
  Image as ImageIcon
} from 'lucide-react';
import axios from 'axios';
import { Video } from '../types';

const LibraryPage: React.FC = () => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    fetchVideos();
  }, []);

  const fetchVideos = async () => {
    try {
      const res = await axios.get('http://localhost:3001/api/videos');
      setVideos(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredVideos = videos.filter(v => 
    v.name.toLowerCase().includes(filter.toLowerCase()) ||
    v.description.toLowerCase().includes(filter.toLowerCase())
  );

  if (loading) return <div>Loading library...</div>;

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Video Library</h1>
          <p className="text-gray-500">All downloaded and uploaded content</p>
        </div>
        
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Search videos..."
            className="w-full pl-9 pr-4 py-2 rounded-lg border border-gray-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredVideos.map((video) => (
          <div key={video.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden group">
            {/* Thumbnail */}
            <div className="aspect-video bg-gray-100 relative group-hover:cursor-pointer">
              {video.thumbnailPath ? (
                <img src={`http://localhost:3001/${video.thumbnailPath}`} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-gray-400">
                  <ImageIcon className="w-8 h-8 mb-2" />
                  <span className="text-xs">No Thumbnail</span>
                </div>
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center">
                  <Play className="w-6 h-6 text-white fill-white" />
                </div>
              </div>
              {video.isScheduled && (
                <div className="absolute top-2 right-2 bg-indigo-600 text-white text-[10px] px-2 py-1 rounded-full flex items-center font-bold">
                  <Clock className="w-3 h-3 mr-1" />
                  SCHEDULED
                </div>
              )}
            </div>

            {/* Info */}
            <div className="p-4">
              <h3 className="font-bold text-gray-900 mb-1 truncate">{video.name}</h3>
              <p className="text-xs text-gray-500 line-clamp-2 mb-4 h-8">{video.description}</p>
              
              <div className="flex items-center justify-between mt-4 pt-4 border-t">
                <div className="flex items-center space-x-2 text-[10px] text-gray-400 font-bold uppercase">
                  <VideoIcon className="w-3 h-3" />
                  <span>{video.source}</span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-gray-400 hover:text-red-600 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                  {!video.isScheduled && (
                    <button className="flex items-center space-x-1.5 bg-indigo-50 text-indigo-600 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-indigo-100">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Queue</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}

        {filteredVideos.length === 0 && (
          <div className="col-span-full py-20 text-center text-gray-500">
            <Library className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>No videos found in library.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default LibraryPage;
