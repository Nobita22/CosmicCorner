import React, { useState } from 'react';
import { Download, Youtube, Instagram, Loader2, Search, CheckCircle, ExternalLink } from 'lucide-react';
import axios from 'axios';

const Downloader: React.FC = () => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [status, setStatus] = useState<string | null>(null);

  const handleDownload = async (targetUrl: string) => {
    setLoading(true);
    setStatus('Starting download...');
    try {
      await axios.post('http://localhost:3001/api/download', {
        url: targetUrl,
        name: 'Auto Downloaded Video',
        description: 'Downloaded via ShortsAgent'
      });
      setStatus('Success! Check Video Library.');
      setTimeout(() => setStatus(null), 3000);
    } catch (err) {
      setStatus('Failed to download');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    
    // Simulate finding videos from a page
    setLoading(true);
    setTimeout(() => {
      setResults([
        { id: '1', title: 'Found Video 1', url: url, type: 'single' },
        { id: '2', title: 'Found Video 2 (Simulated)', url: url, type: 'suggested' }
      ]);
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Media Downloader</h1>
        <p className="text-gray-500">Download YouTube Shorts or Instagram Reels for free</p>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <form onSubmit={handleSearch} className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste YouTube Channel, Playlist or Instagram Profile URL"
              className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="bg-indigo-600 text-white px-8 py-3 rounded-lg font-bold hover:bg-indigo-700 transition-colors flex items-center space-x-2"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
            <span>Analyze</span>
          </button>
        </form>
      </div>

      {status && (
        <div className={`p-4 rounded-lg flex items-center space-x-2 ${status.includes('Success') ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
          {status.includes('Success') ? <CheckCircle className="w-5 h-5" /> : <Loader2 className="w-5 h-5 animate-spin" />}
          <span>{status}</span>
        </div>
      )}

      {results.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {results.map((res) => (
            <div key={res.id} className="bg-white p-4 rounded-xl border border-gray-100 flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-red-50 rounded-lg">
                  {url.includes('instagram') ? <Instagram className="text-pink-600" /> : <Youtube className="text-red-600" />}
                </div>
                <div>
                  <h4 className="font-bold text-gray-900">{res.title}</h4>
                  <p className="text-xs text-gray-500 truncate max-w-[200px]">{res.url}</p>
                </div>
              </div>
              <button
                onClick={() => handleDownload(res.url)}
                disabled={loading}
                className="flex items-center space-x-2 bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-800"
              >
                <Download className="w-4 h-4" />
                <span>Download</span>
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100">
        <h3 className="font-bold text-indigo-900 mb-2 flex items-center">
          <ExternalLink className="w-5 h-5 mr-2" />
          Pro Tip: Batch Downloads
        </h3>
        <p className="text-sm text-indigo-700">
          Enter a channel URL to see all recent shorts. You can transfer them to the library and they will be automatically picked up by the 24/7 agent for scheduling.
        </p>
      </div>
    </div>
  );
};

export default Downloader;
