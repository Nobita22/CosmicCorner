
import React from 'react';
import { 
  LayoutDashboard, 
  Upload, 
  Download, 
  Calendar, 
  Library, 
  Settings, 
  Zap,
  Activity
} from 'lucide-react';
import { cn } from '../utils/cn';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isAgentRunning: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, isAgentRunning }) => {
  const menuItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'upload', icon: Upload, label: 'Upload / Add Link' },
    { id: 'downloader', icon: Download, label: 'yt-dlp Downloader' },
    { id: 'library', icon: Library, label: 'Library' },
    { id: 'schedule', icon: Calendar, label: 'Schedule' },
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-slate-900 text-slate-100 p-6 flex flex-col border-r border-slate-800">
      <div className="flex items-center gap-3 mb-10 px-2">
        <Zap className="w-8 h-8 text-indigo-400 fill-indigo-400/20" />
        <h1 className="text-xl font-bold tracking-tight italic">AutoAgent</h1>
      </div>

      <nav className="flex-1 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-200 group",
              activeTab === item.id 
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                : "text-slate-400 hover:bg-slate-800 hover:text-slate-100"
            )}
          >
            <item.icon className={cn("w-5 h-5", activeTab === item.id ? "text-white" : "group-hover:text-indigo-400")} />
            <span className="font-medium text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="mt-auto pt-6 border-t border-slate-800">
        <div className="flex items-center gap-3 px-3 py-2 bg-slate-800/50 rounded-xl border border-slate-700/50">
          <div className={cn(
            "w-2 h-2 rounded-full",
            isAgentRunning ? "bg-green-400 animate-pulse" : "bg-red-400"
          )} />
          <div className="flex flex-col">
            <span className="text-[10px] uppercase font-bold text-slate-500">System Status</span>
            <span className="text-xs font-semibold">{isAgentRunning ? '24/7 Running' : 'Offline'}</span>
          </div>
          <Activity className="w-4 h-4 ml-auto text-slate-500" />
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
