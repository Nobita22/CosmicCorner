import React from 'react';
import { FileJson, Info, RefreshCw, Bell, Shield } from 'lucide-react';

const Settings: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings & Configuration</h1>
        <p className="text-gray-500">Manage your YouTube API and agent behavior</p>
      </div>

      {/* YouTube API Setup */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6 border-b bg-indigo-50/50">
          <div className="flex items-center space-x-3">
            <FileJson className="w-6 h-6 text-indigo-600" />
            <h3 className="font-bold text-gray-900">YouTube API Authentication</h3>
          </div>
        </div>
        <div className="p-6 space-y-6">
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg flex items-start space-x-3">
            <Info className="w-5 h-5 text-yellow-600 mt-0.5" />
            <div className="text-sm text-yellow-800">
              <p className="font-bold mb-1">Important Setup:</p>
              <p>Place your <code>youtube_auth.json</code> file in the <code>/storage</code> folder of the server directory. This file is required for the agent to upload videos automatically.</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900">Auth Status</p>
              <p className="text-sm text-gray-500">Checking for youtube_auth.json...</p>
            </div>
            <button className="flex items-center space-x-2 px-4 py-2 border rounded-lg text-sm font-medium hover:bg-gray-50">
              <RefreshCw className="w-4 h-4" />
              <span>Verify File</span>
            </button>
          </div>
        </div>
      </div>

      {/* Scheduling Rules */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3 mb-6">
            <Bell className="w-6 h-6 text-indigo-600" />
            <h3 className="font-bold text-gray-900">Notification & Reports</h3>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Daily midnight summary</span>
              <div className="w-10 h-5 bg-indigo-600 rounded-full relative">
                <div className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Low stock alerts (&lt; 5 videos)</span>
              <div className="w-10 h-5 bg-indigo-600 rounded-full relative">
                <div className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Upload failure notifications</span>
              <div className="w-10 h-5 bg-indigo-600 rounded-full relative">
                <div className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full" />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3 mb-6">
            <Shield className="w-6 h-6 text-indigo-600" />
            <h3 className="font-bold text-gray-900">Safeguards</h3>
          </div>
          <div className="space-y-4 text-sm text-gray-600">
            <p>• Max 100 uploads per day to stay within quota.</p>
            <p>• Randomized scheduling between 8 AM and 10 PM.</p>
            <p>• Auto-restart logic every 6 hours during idle time.</p>
            <p>• Automatic thumbnail fallback to default if generation fails.</p>
          </div>
        </div>
      </div>

      {/* Explanation Section */}
      <div className="bg-gray-900 text-white p-8 rounded-2xl">
        <h2 className="text-xl font-bold mb-6">How the 24/7 Agent Works</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-sm">
          <div>
            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center font-bold mb-4">1</div>
            <h4 className="font-bold mb-2">Collection</h4>
            <p className="text-gray-400">Add videos via the Intake Form or Downloader. They are stored locally in the <code>/storage/videos</code> folder.</p>
          </div>
          <div>
            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center font-bold mb-4">2</div>
            <h4 className="font-bold mb-2">The Midnight Run</h4>
            <p className="text-gray-400">Every day at 00:00, a cron job wakes up, selects 5 random videos that haven't been scheduled, and assigns them random times for the day.</p>
          </div>
          <div>
            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center font-bold mb-4">3</div>
            <h4 className="font-bold mb-2">Automation</h4>
            <p className="text-gray-400">A separate process monitors the schedule. When the clock hits a scheduled time, it uses your API key to post the Short to YouTube.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
