import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Clock, 
  Video as VideoIcon, 
  AlertCircle,
  TrendingUp,
  ShieldCheck
} from 'lucide-react';
import axios from 'axios';
import { Video } from '../types';

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState({
    quotaUsed: 0,
    quotaLimit: 100,
    totalVideos: 0,
    estimatedDaysLeft: 0
  });
  const [recentVideos, setRecentVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [statsRes, videosRes] = await Promise.all([
          axios.get('http://localhost:3001/api/stats'),
          axios.get('http://localhost:3001/api/videos')
        ]);
        setStats(statsRes.data);
        setRecentVideos(videosRes.data.slice(-5).reverse());
      } catch (err) {
        console.error('Failed to fetch dashboard data', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <div>Loading dashboard...</div>;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Agent Status</h1>
        <p className="text-gray-500">24/7 Automation monitoring and reports</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-indigo-50 rounded-lg">
              <BarChart3 className="w-6 h-6 text-indigo-600" />
            </div>
            <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">Optimal</span>
          </div>
          <h3 className="text-sm font-medium text-gray-500">Daily Quota</h3>
          <div className="mt-2 flex items-baseline">
            <p className="text-2xl font-bold text-gray-900">{stats.quotaUsed}</p>
            <p className="ml-1 text-sm text-gray-500">/ {stats.quotaLimit}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-blue-50 rounded-lg">
              <VideoIcon className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <h3 className="text-sm font-medium text-gray-500">Total Videos</h3>
          <p className="text-2xl font-bold text-gray-900 mt-2">{stats.totalVideos}</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-orange-50 rounded-lg">
              <TrendingUp className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <h3 className="text-sm font-medium text-gray-500">Estimated Runway</h3>
          <p className="text-2xl font-bold text-gray-900 mt-2">{stats.estimatedDaysLeft} Days</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-green-50 rounded-lg">
              <ShieldCheck className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-sm font-medium text-gray-500">Agent Health</h3>
          <p className="text-2xl font-bold text-gray-900 mt-2">Active</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Forecast/Schedule Preview */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b">
            <h3 className="font-bold text-gray-900">Recent Activity</h3>
          </div>
          <div className="divide-y">
            {recentVideos.map(video => (
              <div key={video.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gray-100 rounded flex items-center justify-center overflow-hidden">
                    {video.thumbnailPath ? (
                      <img src={`http://localhost:3001/${video.thumbnailPath}`} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <VideoIcon className="w-6 h-6 text-gray-400" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-900">{video.name}</h4>
                    <p className="text-xs text-gray-500 line-clamp-1">{video.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    video.status === 'ready' ? 'bg-green-50 text-green-700' :
                    video.status === 'downloading' ? 'bg-blue-50 text-blue-700' :
                    'bg-gray-50 text-gray-700'
                  }`}>
                    {video.status}
                  </span>
                  <p className="text-[10px] text-gray-400 mt-1">
                    {new Date(video.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Safeguards & Warnings */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center">
              <AlertCircle className="w-5 h-5 text-orange-500 mr-2" />
              Safeguards
            </h3>
            <ul className="space-y-4">
              <li className="text-sm flex items-start space-x-3">
                <div className="w-2 h-2 mt-1.5 rounded-full bg-green-500 flex-shrink-0" />
                <span className="text-gray-600">Daily quota monitoring enabled.</span>
              </li>
              <li className="text-sm flex items-start space-x-3">
                <div className="w-2 h-2 mt-1.5 rounded-full bg-green-500 flex-shrink-0" />
                <span className="text-gray-600">Automatic restart on failure active.</span>
              </li>
              <li className="text-sm flex items-start space-x-3">
                <div className="w-2 h-2 mt-1.5 rounded-full bg-orange-500 flex-shrink-0" />
                <span className="text-gray-600 font-medium">Low video warning:</span>
                <span className="text-gray-500">Triggers when runway &lt; 3 days.</span>
              </li>
            </ul>
          </div>

          <div className="bg-indigo-600 p-6 rounded-xl shadow-sm text-white">
            <div className="flex items-center mb-4">
              <Clock className="w-5 h-5 mr-2" />
              <h3 className="font-bold">Agent Schedule</h3>
            </div>
            <p className="text-sm text-indigo-100 mb-4">
              Agent randomly selects 5 videos every midnight and schedules them for the upcoming 24 hours.
            </p>
            <div className="text-xs bg-indigo-700/50 p-3 rounded-lg">
              Next run: Tonight at 00:00
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
