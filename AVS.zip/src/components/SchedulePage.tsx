import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Edit2, Check, X, Image as ImageIcon } from 'lucide-react';
import axios from 'axios';
import { Video } from '../types';
import { format } from 'date-fns';

const SchedulePage: React.FC = () => {
  const [scheduledVideos, setScheduledVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Video>>({});

  useEffect(() => {
    fetchScheduled();
  }, []);

  const fetchScheduled = async () => {
    try {
      const res = await axios.get('http://localhost:3001/api/videos');
      const scheduled = res.data
        .filter((v: Video) => v.isScheduled)
        .sort((a: Video, b: Video) => new Date(a.scheduledTime!).getTime() - new Date(b.scheduledTime!).getTime());
      setScheduledVideos(scheduled);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (video: Video) => {
    setEditingId(video.id);
    setEditForm(video);
  };

  const handleSave = async () => {
    if (!editingId) return;
    try {
      await axios.post('http://localhost:3001/api/schedule/update', {
        id: editingId,
        updates: editForm
      });
      setEditingId(null);
      fetchScheduled();
    } catch (err) {
      alert('Failed to save changes');
    }
  };

  if (loading) return <div>Loading schedules...</div>;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Today's Schedule</h1>
        <p className="text-gray-500">View and edit the 5 videos scheduled for today</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {scheduledVideos.length === 0 ? (
          <div className="bg-white p-12 text-center rounded-xl border-2 border-dashed border-gray-200">
            <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 font-medium">No videos scheduled for today yet.</p>
            <p className="text-sm text-gray-400">The agent will pick 5 videos at midnight.</p>
          </div>
        ) : (
          scheduledVideos.map((video) => (
            <div key={video.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex flex-col md:flex-row gap-6">
                {/* Video Preview */}
                <div className="w-full md:w-64 aspect-video bg-gray-100 rounded-lg overflow-hidden relative group">
                  {video.thumbnailPath ? (
                    <img 
                      src={`http://localhost:3001/${video.thumbnailPath}`} 
                      alt="" 
                      className="w-full h-full object-cover" 
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-gray-400">
                      <ImageIcon className="w-8 h-8 mb-2" />
                      <span className="text-xs">Using Default Thumbnail</span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button className="text-white text-xs bg-white/20 px-3 py-1.5 rounded-full backdrop-blur-sm hover:bg-white/30">
                      Change Thumbnail
                    </button>
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 space-y-4">
                  {editingId === video.id ? (
                    <div className="space-y-3">
                      <input
                        type="text"
                        value={editForm.name}
                        onChange={e => setEditForm({...editForm, name: e.target.value})}
                        className="w-full px-3 py-1.5 border rounded"
                      />
                      <textarea
                        value={editForm.description}
                        onChange={e => setEditForm({...editForm, description: e.target.value})}
                        className="w-full px-3 py-1.5 border rounded text-sm"
                        rows={3}
                      />
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-gray-400" />
                        <input
                          type="datetime-local"
                          value={editForm.scheduledTime ? format(new Date(editForm.scheduledTime), "yyyy-MM-dd'T'HH:mm") : ''}
                          onChange={e => setEditForm({...editForm, scheduledTime: new Date(e.target.value).toISOString()})}
                          className="px-2 py-1 border rounded text-sm"
                        />
                      </div>
                    </div>
                  ) : (
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 mb-1">{video.name}</h3>
                      <p className="text-sm text-gray-500 line-clamp-2 mb-3">{video.description}</p>
                      <div className="flex items-center text-indigo-600 font-medium text-sm">
                        <Clock className="w-4 h-4 mr-1.5" />
                        Scheduled for: {format(new Date(video.scheduledTime!), 'hh:mm a')}
                      </div>
                    </div>
                  )}

                  <div className="pt-4 border-t flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400">Status:</span>
                      <span className="text-[10px] uppercase font-bold tracking-wider text-indigo-600">Scheduled</span>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {editingId === video.id ? (
                        <>
                          <button 
                            onClick={() => setEditingId(null)}
                            className="p-2 text-gray-400 hover:text-gray-600"
                          >
                            <X className="w-5 h-5" />
                          </button>
                          <button 
                            onClick={handleSave}
                            className="flex items-center space-x-1.5 bg-green-600 text-white px-4 py-1.5 rounded-lg text-sm font-medium"
                          >
                            <Check className="w-4 h-4" />
                            <span>Save Changes</span>
                          </button>
                        </>
                      ) : (
                        <button 
                          onClick={() => startEdit(video)}
                          className="flex items-center space-x-1.5 bg-gray-100 text-gray-600 px-4 py-1.5 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                          <span>Edit Details</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default SchedulePage;
