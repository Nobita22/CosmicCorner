export interface Video {
  id: string;
  name: string;
  description: string;
  source: 'upload' | 'youtube' | 'instagram';
  originalUrl?: string;
  filePath: string;
  thumbnailPath?: string;
  createdAt: string;
  scheduledTime?: string;
  isScheduled: boolean;
  status: 'pending' | 'downloading' | 'ready' | 'uploaded' | 'failed';
}

export interface Schedule {
  date: string;
  videos: Video[];
  isSent: boolean;
}

export interface DailyStats {
  quotaUsed: number;
  quotaLimit: number;
  totalVideos: number;
  estimatedDaysLeft: number;
}
