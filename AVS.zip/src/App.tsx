import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Upload, 
  Calendar, 
  DownloadCloud, 
  Library, 
  Settings as SettingsIcon,
  Menu,
  X
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import UploadForm from './components/UploadForm';
import SchedulePage from './components/SchedulePage';
import Downloader from './components/Downloader';
import LibraryPage from './components/Library';
import Settings from './components/Settings';

const App: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 flex">
        {/* Sidebar */}
        <aside className={`
          fixed inset-y-0 left-0 z-50 w-64 bg-white border-r transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          <div className="h-full flex flex-col">
            <div className="p-6 border-b flex items-center justify-between">
              <span className="text-xl font-bold text-indigo-600">ShortsAgent</span>
              <button className="lg:hidden" onClick={() => setIsSidebarOpen(false)}>
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <nav className="flex-1 p-4 space-y-2">
              <Link to="/" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-indigo-50 text-gray-700 hover:text-indigo-600" onClick={() => setIsSidebarOpen(false)}>
                <LayoutDashboard className="w-5 h-5" />
                <span>Dashboard</span>
              </Link>
              <Link to="/upload" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-indigo-50 text-gray-700 hover:text-indigo-600" onClick={() => setIsSidebarOpen(false)}>
                <Upload className="w-5 h-5" />
                <span>Intake Form</span>
              </Link>
              <Link to="/schedule" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-indigo-50 text-gray-700 hover:text-indigo-600" onClick={() => setIsSidebarOpen(false)}>
                <Calendar className="w-5 h-5" />
                <span>Schedules</span>
              </Link>
              <Link to="/downloader" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-indigo-50 text-gray-700 hover:text-indigo-600" onClick={() => setIsSidebarOpen(false)}>
                <DownloadCloud className="w-5 h-5" />
                <span>Downloader</span>
              </Link>
              <Link to="/library" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-indigo-50 text-gray-700 hover:text-indigo-600" onClick={() => setIsSidebarOpen(false)}>
                <Library className="w-5 h-5" />
                <span>Video Library</span>
              </Link>
            </nav>

            <div className="p-4 border-t">
              <Link to="/settings" className="flex items-center space-x-3 p-3 rounded-lg hover:bg-indigo-50 text-gray-700 hover:text-indigo-600" onClick={() => setIsSidebarOpen(false)}>
                <SettingsIcon className="w-5 h-5" />
                <span>Settings</span>
              </Link>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <header className="bg-white border-b p-4 lg:hidden flex items-center">
            <button onClick={() => setIsSidebarOpen(true)}>
              <Menu className="w-6 h-6 text-gray-600" />
            </button>
            <span className="ml-4 font-bold text-gray-800">ShortsAgent</span>
          </header>

          <div className="p-4 lg:p-8">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/upload" element={<UploadForm />} />
              <Route path="/schedule" element={<SchedulePage />} />
              <Route path="/downloader" element={<Downloader />} />
              <Route path="/library" element={<LibraryPage />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </div>
        </main>
      </div>
    </Router>
  );
};

export default App;
