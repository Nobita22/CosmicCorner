const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cron = require('node-cron');
const { exec } = require('child_process');
const ffmpeg = require('fluent-ffmpeg');

const app = express();
const PORT = 3001;

// Configuration
const STORAGE_DIR = path.join(__dirname, 'storage');
const VIDEO_DIR = path.join(STORAGE_DIR, 'videos');
const THUMBNAIL_DIR = path.join(STORAGE_DIR, 'thumbnails');
const DB_FILE = path.join(STORAGE_DIR, 'db.json');
const DEFAULT_THUMBNAIL = path.join(STORAGE_DIR, 'default_thumbnail.jpg');

// Ensure directories exist
[STORAGE_DIR, VIDEO_DIR, THUMBNAIL_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// Middleware
app.use(cors());
app.use(express.json());
app.use('/storage', express.static(STORAGE_DIR));

// Simple DB helper
const readDB = () => {
  if (!fs.existsSync(DB_FILE)) return { videos: [], schedules: [] };
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
};

const writeDB = (data) => {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
};

// Storage setup for uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, VIDEO_DIR),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({ storage });

// API Endpoints
app.get('/api/videos', (req, res) => {
  res.json(readDB().videos);
});

app.post('/api/upload', upload.single('video'), (req, res) => {
  const { name, description } = req.body;
  const db = readDB();
  const video = {
    id: Date.now().toString(),
    name: name || req.file.originalname,
    description: description || '',
    source: 'upload',
    filePath: `storage/videos/${req.file.filename}`,
    createdAt: new Date().toISOString(),
    status: 'ready',
    isScheduled: false
  };
  db.videos.push(video);
  writeDB(db);
  res.json(video);
});

app.post('/api/download', async (req, res) => {
  const { url, name, description } = req.body;
  const id = Date.now().toString();
  const filename = `${id}.mp4`;
  const filePath = path.join(VIDEO_DIR, filename);

  const db = readDB();
  const video = {
    id,
    name: name || 'Downloading...',
    description: description || '',
    source: url.includes('instagram.com') ? 'instagram' : 'youtube',
    originalUrl: url,
    filePath: `storage/videos/${filename}`,
    createdAt: new Date().toISOString(),
    status: 'downloading',
    isScheduled: false
  };
  db.videos.push(video);
  writeDB(db);

  // Trigger yt-dlp in background
  const cmd = `yt-dlp -f "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best" -o "${filePath}" "${url}"`;
  exec(cmd, (error) => {
    const dbUpdate = readDB();
    const vIndex = dbUpdate.videos.findIndex(v => v.id === id);
    if (error) {
      dbUpdate.videos[vIndex].status = 'failed';
    } else {
      dbUpdate.videos[vIndex].status = 'ready';
      dbUpdate.videos[vIndex].name = name || 'Downloaded Video';
      // Auto-generate thumbnail
      const thumbFilename = `${id}.jpg`;
      ffmpeg(filePath)
        .screenshots({
          count: 1,
          folder: THUMBNAIL_DIR,
          filename: thumbFilename,
          size: '320x240'
        })
        .on('end', () => {
          dbUpdate.videos[vIndex].thumbnailPath = `storage/thumbnails/${thumbFilename}`;
          writeDB(dbUpdate);
        });
    }
    writeDB(dbUpdate);
  });

  res.json({ message: 'Download started', video });
});

app.post('/api/schedule/update', (req, res) => {
  const { id, updates } = req.body;
  const db = readDB();
  const vIndex = db.videos.findIndex(v => v.id === id);
  if (vIndex !== -1) {
    db.videos[vIndex] = { ...db.videos[vIndex], ...updates };
    writeDB(db);
    res.json(db.videos[vIndex]);
  } else {
    res.status(404).send('Video not found');
  }
});

app.post('/api/videos/generate-thumbnail', (req, res) => {
  const { id } = req.body;
  const db = readDB();
  const video = db.videos.find(v => v.id === id);
  if (!video) return res.status(404).send('Video not found');

  const thumbFilename = `${id}-${Date.now()}.jpg`;
  const absoluteVideoPath = path.join(__dirname, video.filePath);

  ffmpeg(absoluteVideoPath)
    .screenshots({
      count: 1,
      folder: THUMBNAIL_DIR,
      filename: thumbFilename,
      size: '320x240'
    })
    .on('end', () => {
      video.thumbnailPath = `storage/thumbnails/${thumbFilename}`;
      writeDB(db);
      res.json({ thumbnailPath: video.thumbnailPath });
    })
    .on('error', (err) => {
      res.status(500).send(err.message);
    });
});

app.get('/api/stats', (req, res) => {
  const db = readDB();
  const total = db.videos.filter(v => v.status === 'ready').length;
  const scheduledCount = db.videos.filter(v => v.isScheduled).length;
  res.json({
    quotaUsed: scheduledCount % 100, // Example
    quotaLimit: 100,
    totalVideos: total,
    estimatedDaysLeft: Math.floor(total / 5)
  });
});

// Scheduling Logic - Runs daily at midnight
cron.schedule('0 0 * * *', () => {
  console.log('Running daily schedule...');
  const db = readDB();
  const available = db.videos.filter(v => v.status === 'ready' && !v.isScheduled);
  
  if (available.length < 5) {
    console.warn('NOT ENOUGH VIDEOS TO SCHEDULE 5!');
    // Alert mechanism could be integrated here (e.g. Email/Telegram)
  }

  const selected = available.sort(() => 0.5 - Math.random()).slice(0, 5);
  const now = new Date();
  
  selected.forEach((v, idx) => {
    const vIndex = db.videos.findIndex(vid => vid.id === v.id);
    // Random hour between 8 AM and 10 PM
    const hour = 8 + Math.floor(Math.random() * 14);
    const scheduledTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour, Math.floor(Math.random() * 60));
    
    db.videos[vIndex].isScheduled = true;
    db.videos[vIndex].scheduledTime = scheduledTime.toISOString();
    if (!db.videos[vIndex].thumbnailPath && fs.existsSync(DEFAULT_THUMBNAIL)) {
      db.videos[vIndex].thumbnailPath = 'storage/default_thumbnail.jpg';
    } else if (!db.videos[vIndex].thumbnailPath) {
      // No thumbnail available
      db.videos[vIndex].thumbnailPath = '';
    }
  });

  writeDB(db);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
