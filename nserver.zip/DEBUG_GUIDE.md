# NOBITA - Debug Guide

## If You Still See Errors

### Error: "POST /api/servers net::ERR_EMPTY_RESPONSE"

**Root Cause:** JSON response headers missing or malformed

**Solution:**

1. **Check MainServer.py is running:**
   ```bash
   python MainServer.py
   ```
   
   Should show:
   ```
   ==================================================
   NOBITA - Multi-Server Hosting System
   ==================================================
   
   [STARTED] SampleApp on port 9001
   
   --------------------------------------------------
   Dashboard: http://localhost:9000
   ```

2. **Check console for error messages:**
   Look for `[ERROR]` prefix in console output

3. **Clear browser cache:**
   - Chrome: Ctrl+Shift+Delete
   - Firefox: Ctrl+Shift+Delete
   - Safari: Cmd+Shift+Delete

4. **Hard refresh browser:**
   - Chrome: Ctrl+F5 or Ctrl+Shift+R
   - Firefox: Ctrl+Shift+R
   - Safari: Cmd+Shift+R

5. **Restart MainServer:**
   - Press Ctrl+C in terminal
   - Wait 2 seconds
   - Run `python MainServer.py` again

---

### Error: "Pattern attribute value... Invalid regular expression"

**Root Cause:** HTML5 regex validation error

**Solution:**

This error is **already fixed** in the updated code. The pattern validation has been moved from HTML to server-side Python.

If you still see it:
1. Clear browser cache
2. Hard refresh page
3. Check browser console for source of error

---

### Sub-servers not running or stopping immediately

**Root Cause:** Process management issues

**Solution:**

1. **Check if ports are available:**
   
   **Windows:**
   ```bash
   netstat -ano | findstr :9001
   ```
   
   **Mac/Linux:**
   ```bash
   lsof -i :9001
   ```

2. **Kill existing processes:**
   
   **Windows:**
   ```bash
   taskkill /F /IM python.exe
   ```
   
   **Mac/Linux:**
   ```bash
   pkill -f python
   ```

3. **Restart MainServer:**
   ```bash
   python MainServer.py
   ```

---

## Debugging Checklist

### Before Creating Server:
- [ ] MainServer.py is running
- [ ] Console shows "Dashboard: http://localhost:9000"
- [ ] Browser loads dashboard without 404
- [ ] B/W gradient background shows
- [ ] SampleApp card visible

### When Creating Server:
- [ ] Console shows no errors
- [ ] Check browser console (F12)
- [ ] Look for network errors (F12 Network tab)
- [ ] See [DEBUG] messages in console

### After Creating Server:
- [ ] New server card appears
- [ ] Status shows "Running"
- [ ] Port shows a number (e.g., 9002)
- [ ] Can click card to open server
- [ ] Can start/stop server
- [ ] Can edit server
- [ ] Can delete server

---

## Browser Console Debugging

Press **F12** to open developer tools:

1. **Console Tab:** Look for error messages
2. **Network Tab:** Check API requests
   - Should see: POST /api/servers (200 status)
   - Should see: GET /api/servers (200 status)
3. **Application Tab:** Check local storage

**Look for:**
```
[DEBUG] Create server request: name=TestApp, port=null
[DEBUG] Server created: TestApp on port 9002
```

---

## Common Issues & Quick Fixes

### Issue: Dashboard loads but no servers show
**Fix:**
```bash
# Delete config.json and restart
rm config.json
python MainServer.py
```

### Issue: "Address already in use"
**Fix:**
```bash
# Windows
netstat -ano | findstr :9000
taskkill /PID [PID] /F

# Mac/Linux
lsof -i :9000
kill -9 [PID]
```

### Issue: Creating server fails silently
**Fix:**
1. Check console for [ERROR] messages
2. Try folder name with no spaces: `TestApp` not `Test App`
3. Try port number: `TestApp` not `Test.App`

### Issue: Sub-server won't start
**Fix:**
1. Navigate to folder: `cd TestApp`
2. Try running manually: `python server.py`
3. Check error messages
4. Verify `server.py` exists

---

## Step-by-Step Debug Process

### If something isn't working:

**Step 1: Restart Everything**
```bash
# Press Ctrl+C to stop MainServer
# Clear old processes
# Windows
taskkill /F /IM python.exe

# Mac/Linux
pkill -f python

# Restart
python MainServer.py
```

**Step 2: Clear Browser Cache**
- Press Ctrl+Shift+Delete (or Cmd+Shift+Delete on Mac)
- Clear "All time"
- Refresh page

**Step 3: Check Console Logs**
- Look at MainServer terminal for errors
- Open browser F12 and check Console tab
- Look for [ERROR] or [DEBUG] messages

**Step 4: Test Simple Operation**
- Try just opening dashboard
- Try searching for servers
- Try refreshing page
- Try opening a server in new tab

**Step 5: Verify File Structure**
```bash
# Should see:
NOBITA/
├── MainServer.py      ← Running?
├── index.html         ← Served?
├── config.json        ← Created?
├── SampleApp/         ← Has server.py?
│   └── server.py
```

**Step 6: Manual Server Test**
```bash
# Go to SampleApp folder
cd SampleApp

# Try running server manually
python server.py

# In another terminal, try accessing it
curl http://localhost:9001
```

If it works manually but not from dashboard:
- MainServer.py might have process management issue
- Restart and try again

---

## Expected Console Output

### When MainServer starts:
```
==================================================
NOBITA - Multi-Server Hosting System
==================================================

[STARTED] SampleApp on port 9001 (PID: 12345)

--------------------------------------------------
Dashboard: http://localhost:9000
--------------------------------------------------

[Dashboard] GET /api/servers 200
[Dashboard] GET /api/config 200
```

### When creating server:
```
[DEBUG] Create server request: name=TestApp, port=null
[DEBUG] Server created: TestApp on port 9002
[STARTED] TestApp on port 9002 (PID: 12346)
[Dashboard] POST /api/servers 200
```

### When starting/stopping server:
```
[STARTED] TestApp on port 9002 (PID: 12347)
[Dashboard] POST /api/servers/TestApp/start 200

[STOPPED] TestApp
[Dashboard] POST /api/servers/TestApp/stop 200
```

---

## Network Debugging

### Using curl to test API:

```bash
# Test dashboard
curl http://localhost:9000/

# Test API - get all servers
curl http://localhost:9000/api/servers

# Test API - create server
curl -X POST http://localhost:9000/api/servers \
  -H "Content-Type: application/json" \
  -d '{"name":"TestApp","port":null,"description":"Test"}'

# Test API - start server
curl -X POST http://localhost:9000/api/servers/TestApp/start

# Test API - stop server
curl -X POST http://localhost:9000/api/servers/TestApp/stop
```

---

## Port Troubleshooting

### Check which ports are in use:

**Windows:**
```bash
netstat -ano
netstat -ano | findstr :9000
netstat -ano | findstr :9001
```

**Mac/Linux:**
```bash
lsof -i
lsof -i :9000
lsof -i :9001
```

### Kill process on specific port:

**Windows:**
```bash
taskkill /PID [PID] /F
```

**Mac/Linux:**
```bash
kill -9 [PID]
```

---

## Python Version Check

Make sure you have Python 3.6+:

```bash
python --version
# Should show: Python 3.6.0 or higher
```

If not installed:
- Download from https://www.python.org/downloads/
- Install Python 3.9 or later

---

## Clean Start

If everything is messed up:

1. **Stop MainServer:**
   ```bash
   # Press Ctrl+C in MainServer terminal
   ```

2. **Kill all Python processes:**
   ```bash
   # Windows
   taskkill /F /IM python.exe
   
   # Mac/Linux
   pkill -f python
   ```

3. **Delete config.json:**
   ```bash
   rm config.json
   ```

4. **Delete all custom folders:**
   ```bash
   # Keep only SampleApp, delete any test folders
   ```

5. **Restart:**
   ```bash
   python MainServer.py
   ```

---

## Final Verification

After fixing issues, verify:

1. ✅ Dashboard loads at http://localhost:9000
2. ✅ B/W gradient background shows
3. ✅ SampleApp card visible
4. ✅ "Running" status shows in green
5. ✅ Port shows "9001"
6. ✅ All buttons visible and clickable
7. ✅ Can create new server
8. ✅ Can edit server
9. ✅ Can delete server
10. ✅ Can start/stop server
11. ✅ Search works
12. ✅ Filter works
13. ✅ No errors in browser console
14. ✅ No errors in MainServer console

If all green: ✅ **System is working perfectly!**

---

## Support

If you're still having issues:

1. Check this entire guide
2. Review the error messages carefully
3. Try the clean start procedure
4. Check all prerequisites (Python 3.6+, ports available)
5. Verify all files are in correct locations

**Everything should work with the latest fixes!**

