#!/usr/bin/env python3
"""
Cosmic Corner Server
Custom server for NOBITA with form data and image upload functionality
"""

import json
import os
import sys
import base64
import time
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, unquote

# ============================================================================
# STEP 1: READ PORT FROM MAINSERVER'S CONFIG.JSON
# ============================================================================
def get_port():
    """Read port from MainServer's config.json"""
    config_path = Path(__file__).parent.parent / "config.json"
    if config_path.exists():
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                folder_name = Path(__file__).parent.name
                port = config.get("folders", {}).get(folder_name)
                if port:
                    return port
        except Exception as e:
            print(f"[ERROR] Failed to read port from config: {e}")
    return 9999

# ============================================================================
# STEP 2: SETUP DIRECTORIES AND FILES
# ============================================================================
def setup_directories():
    """Ensure directories and files exist"""
    data_file = Path(__file__).parent / 'data.json'
    images_dir = Path(__file__).parent / 'images'
    
    # Create images directory if it doesn't exist
    if not images_dir.exists():
        images_dir.mkdir(parents=True, exist_ok=True)
    
    # Create data.json if it doesn't exist
    if not data_file.exists():
        with open(data_file, 'w') as f:
            json.dump([], f, indent=4)
    
    return data_file, images_dir

# ============================================================================
# STEP 3: CUSTOM REQUEST HANDLER
# ============================================================================
class CosmicCornerHandler(SimpleHTTPRequestHandler):
    """Custom handler for Cosmic Corner with form data and image uploads"""
    
    def __init__(self, *args, **kwargs):
        # Serve files from current folder (CosmicCorner/)
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)
    
    def log_message(self, format, *args):
        """Custom logging with folder name prefix"""
        print(f"[CosmicCorner] {args[0]}")
    
    # ========================================================================
    # GET REQUESTS
    # ========================================================================
    def do_GET(self):
        """Handle GET requests"""
        parsed_path = urlparse(self.path).path
        
        # Serve index.html for root path
        if parsed_path == '/':
            self.path = '/index.html'
            parsed_path = '/index.html'
        
        # GET /data - Return all form entries as JSON
        if parsed_path == '/data':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
            self.end_headers()
            try:
                data_file = Path(__file__).parent / 'data.json'
                with open(data_file, 'r') as f:
                    self.wfile.write(f.read().encode())
            except Exception as e:
                print(f"[ERROR] Failed to read data: {e}")
                self.wfile.write(b'[]')
        
        # GET /data/{index} - Return specific entry
        elif parsed_path.startswith('/data/'):
            try:
                index = int(parsed_path.split('/')[-1])
                data_file = Path(__file__).parent / 'data.json'
                
                with open(data_file, 'r') as f:
                    entries = json.load(f)
                
                if 0 <= index < len(entries):
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    self.wfile.write(json.dumps(entries[index]).encode())
                else:
                    self.send_response(404)
                    self.end_headers()
            except Exception as e:
                print(f"[ERROR] Failed to get entry: {e}")
                self.send_response(500)
                self.end_headers()
        
        # Default: Serve static files
        else:
            self.path = parsed_path
            super().do_GET()
    
    # ========================================================================
    # POST REQUESTS
    # ========================================================================
    def do_POST(self):
        """Handle POST requests for save, edit, delete"""
        parsed_path = urlparse(self.path).path
        
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length)
        
        try:
            body = json.loads(post_data.decode('utf-8'))
            data_file = Path(__file__).parent / 'data.json'
            images_dir = Path(__file__).parent / 'images'
            
            # Load existing data
            with open(data_file, 'r') as f:
                try:
                    db = json.load(f)
                except json.JSONDecodeError:
                    db = []
            
            # ================================================================
            # POST /save - Add new entry
            # ================================================================
            if parsed_path == '/save':
                # Handle image if provided
                if 'image' in body and body['image'] and body['image'].startswith('data:image'):
                    try:
                        # Extract base64 data
                        header, encoded = body['image'].split(",", 1)
                        file_ext = header.split(';')[0].split('/')[1]
                        image_data = base64.b64decode(encoded)
                        
                        # Create filename with timestamp
                        filename = f"img_{int(time.time() * 1000)}.{file_ext}"
                        filepath = images_dir / filename
                        
                        # Save image file
                        with open(filepath, 'wb') as img_f:
                            img_f.write(image_data)
                        
                        # Update body with relative path
                        body['image'] = f"images/{filename}"
                    except Exception as e:
                        print(f"[ERROR] Failed to save image: {e}")
                        body['image'] = None
                
                # Add timestamp if not present
                if 'timestamp' not in body:
                    body['timestamp'] = time.strftime("%Y-%m-%dT%H:%M:%S.000Z")
                
                # Add new entry
                db.append(body)
                
                response_msg = {"status": "ok", "message": "Entry saved successfully", "index": len(db) - 1}
            
            # ================================================================
            # POST /edit - Edit existing entry
            # ================================================================
            elif parsed_path == '/edit':
                idx = body.get('index')
                if idx is not None and 0 <= idx < len(db):
                    # Handle new image if provided
                    if 'image' in body and body['image'] and body['image'].startswith('data:image'):
                        try:
                            # Delete old image if exists
                            old_entry = db[idx]
                            if old_entry.get('image') and os.path.exists(old_entry['image']):
                                try:
                                    os.remove(old_entry['image'])
                                except:
                                    pass
                            
                            # Save new image
                            header, encoded = body['image'].split(",", 1)
                            file_ext = header.split(';')[0].split('/')[1]
                            image_data = base64.b64decode(encoded)
                            filename = f"img_{int(time.time() * 1000)}.{file_ext}"
                            filepath = images_dir / filename
                            
                            with open(filepath, 'wb') as img_f:
                                img_f.write(image_data)
                            
                            body['image'] = f"images/{filename}"
                        except Exception as e:
                            print(f"[ERROR] Failed to update image: {e}")
                            body['image'] = db[idx].get('image')
                    
                    # Update timestamp
                    body['timestamp'] = time.strftime("%Y-%m-%dT%H:%M:%S.000Z")
                    
                    # Merge updates
                    for k, v in body.items():
                        if k != 'index':
                            db[idx][k] = v
                    
                    response_msg = {"status": "ok", "message": "Entry updated successfully"}
                else:
                    response_msg = {"status": "error", "message": "Invalid index"}
            
            # ================================================================
            # POST /delete - Delete entry
            # ================================================================
            elif parsed_path == '/delete':
                idx = body.get('index')
                if idx is not None and 0 <= idx < len(db):
                    # Delete associated image file if exists
                    entry = db[idx]
                    if entry.get('image') and os.path.exists(entry['image']):
                        try:
                            os.remove(entry['image'])
                        except:
                            pass
                    
                    db.pop(idx)
                    response_msg = {"status": "ok", "message": "Entry deleted successfully"}
                else:
                    response_msg = {"status": "error", "message": "Invalid index"}
            
            else:
                response_msg = {"status": "error", "message": "Unknown endpoint"}
            
            # Save updated data back to file
            with open(data_file, 'w') as f:
                json.dump(db, f, indent=4)
            
            # Send success response
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(response_msg).encode())
            
        except Exception as e:
            print(f"[ERROR] {e}")
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "error", "message": str(e)}).encode())
    
    # ========================================================================
    # OPTIONS REQUEST (CORS)
    # ========================================================================
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

# ============================================================================
# STEP 4: MAIN SERVER FUNCTION
# ============================================================================
def main():
    """Start the Cosmic Corner server"""
    port = get_port()
    data_file, images_dir = setup_directories()
    
    print(f"\n{'='*60}")
    print(f"   COSMIC CORNER SERVER")
    print(f"{'='*60}")
    print(f"   Port: {port}")
    print(f"   Local:  http://localhost:{port}")
    print(f"   Data:   {data_file}")
    print(f"   Images: {images_dir}")
    print(f"{'='*60}\n")
    
    try:
        server = HTTPServer(('0.0.0.0', port), CosmicCornerHandler)
        print(f"[CosmicCorner] Server running on port {port}")
        server.serve_forever()
    except KeyboardInterrupt:
        print(f"\n[CosmicCorner] Server stopped")
        sys.exit(0)
    except Exception as e:
        print(f"[ERROR] {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
