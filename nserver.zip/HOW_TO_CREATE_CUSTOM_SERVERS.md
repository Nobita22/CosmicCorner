# 🎓 Complete Guide: How to Create Custom Servers for NOBITA

## Table of Contents

1. [Understanding the Architecture](#understanding-the-architecture)
2. [Server Components](#server-components)
3. [Step-by-Step Tutorial](#step-by-step-tutorial)
4. [Cosmic Corner Example](#cosmic-corner-example)
5. [Advanced Patterns](#advanced-patterns)
6. [Testing & Debugging](#testing--debugging)

---

## Understanding the Architecture

### The MainServer System

```
NOBITA Folder (Root)
│
├── MainServer.py (Port 9000)
│   ├─ Scans subfolders
│   ├─ Assigns ports
│   ├─ Launches servers
│   ├─ Hosts dashboard
│   └─ Manages all servers
│
├── config.json
│   ├─ Folder ↔ Port mappings
│   ├─ Last assigned port
│   └─ Metadata (descriptions)
│
├── Dashboard (index.html)
│   ├─ Shows all servers
│   ├─ Create/Edit/Delete
│   └─ Start/Stop servers
│
└── Sub-Servers (Your Apps)
    ├── SampleApp/ (Port 9001)
    ├── CosmicCorner/ (Port 9002)
    └── YourCustomApp/ (Port 9003+)
```

### Key Insight: Port Independence

```
MainServer.py (Port 9000)
    ↓
    Reads config.json
    ↓
    Assigns: SampleApp → 9001
             CosmicCorner → 9002
             YourApp → 9003
    ↓
    Launches each server.py
    ↓
    Each server.py reads its port from config.json
    ↓
    All running independently on different ports
```

**Important:** Each server.py MUST read its port from config.json, not hardcode it!

---

## Server Components

### Minimal Server Structure

```
YourCustomApp/
├── server.py           ← HTTP server logic
├── index.html          ← Web frontend
├── data.json           ← Data storage (optional)
├── icon.png            ← Dashboard icon (optional)
└── media/              ← Assets folder (optional)
```

### What Each File Does

#### **server.py** (Required)

- Reads port from config.json
- Listens for HTTP requests
- Serves static files
- Handles custom APIs
- Persists data

#### **index.html** (Required)

- User interface
- Forms for data entry
- Display of data
- Fetch API calls to server.py

#### **data.json** (Optional)

- Persistent data storage
- User-generated content
- Configuration
- Can be JSON or any format

#### **icon.png** (Optional)

- Displayed on dashboard
- 256x256 or larger
- PNG, JPG, GIF, or SVG

#### **media/** (Optional)

- CSS files
- JavaScript files
- Images and assets
- Any static files

---

## Step-by-Step Tutorial

### Step 1: Create Your Folder

```bash
# In NOBITA directory
mkdir MyAwesomeApp
cd MyAwesomeApp
```

This creates:
```
NOBITA/
└── MyAwesomeApp/
```

### Step 2: Create server.py

The most important file! Here's the pattern:

```python
#!/usr/bin/env python3
"""
MyAwesomeApp Server
Integrated with NOBITA
"""

import json
import sys
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

# ============================================================================
# STEP 1: READ PORT FROM CONFIG (CRITICAL!)
# ============================================================================

def get_port():
    """
    Read port from MainServer's config.json
    
    Why? Because MainServer assigns ports dynamically
    Your server must know which port to listen on
    """
    config_path = Path(__file__).parent.parent / "config.json"
    
    if config_path.exists():
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                # Get this folder's name
                folder_name = Path(__file__).parent.name
                # Look up the port assigned to this folder
                port = config.get("folders", {}).get(folder_name)
                if port:
                    return port
        except Exception as e:
            print(f"[ERROR] Failed to read config: {e}")
    
    # Fallback if config doesn't exist
    return 9999


# ============================================================================
# STEP 2: CREATE CUSTOM REQUEST HANDLER
# ============================================================================

class MyAwesomeAppHandler(SimpleHTTPRequestHandler):
    """
    Custom handler for your server
    Extends SimpleHTTPRequestHandler to serve static files + custom APIs
    """
    
    def __init__(self, *args, **kwargs):
        """
        Initialize handler
        directory=str(Path(__file__).parent) makes it serve files from
        current folder (MyAwesomeApp/) not NOBITA root
        """
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)
    
    def log_message(self, format, *args):
        """
        Custom logging - add folder name prefix
        Makes it easy to see which server is logging
        """
        folder_name = Path(__file__).parent.name
        print(f"[{folder_name}] {args[0]}")
    
    # ========================================================================
    # GET REQUESTS
    # ========================================================================
    
    def do_GET(self):
        """
        Handle GET requests
        
        Flow:
        1. Check if custom endpoint
        2. If custom: Handle it and return JSON
        3. If not: Serve static file
        """
        parsed_path = urlparse(self.path).path
        
        # Serve index.html for root path
        if parsed_path == '/':
            self.path = '/index.html'
            parsed_path = '/index.html'
        
        # Custom API endpoint example
        if parsed_path == '/api/hello':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b'{"message": "Hello from MyAwesomeApp!"}')
        
        # Custom API endpoint example 2
        elif parsed_path == '/api/data':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                data_file = Path(__file__).parent / 'data.json'
                with open(data_file, 'r') as f:
                    self.wfile.write(f.read().encode())
            except:
                self.wfile.write(b'{"error": "No data file"}')
        
        # Default: serve static files
        else:
            self.path = parsed_path
            super().do_GET()
    
    # ========================================================================
    # POST REQUESTS (Optional)
    # ========================================================================
    
    def do_POST(self):
        """
        Handle POST requests (optional)
        For form submissions, API calls, etc.
        """
        parsed_path = urlparse(self.path).path
        
        # Get request body
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length)
        
        try:
            body = json.loads(post_data.decode('utf-8'))
        except:
            body = {}
        
        # Example: /save endpoint
        if parsed_path == '/save':
            # Save data to file
            data_file = Path(__file__).parent / 'data.json'
            try:
                with open(data_file, 'w') as f:
                    json.dump(body, f, indent=2)
                
                response = {"status": "ok"}
            except Exception as e:
                response = {"error": str(e)}
        
        else:
            response = {"error": "Unknown endpoint"}
        
        # Send response
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(response).encode())
    
    # ========================================================================
    # OPTIONS REQUESTS (CORS Support)
    # ========================================================================
    
    def do_OPTIONS(self):
        """
        Handle CORS preflight requests
        Required for cross-origin AJAX requests
        """
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()


# ============================================================================
# STEP 3: MAIN FUNCTION
# ============================================================================

def main():
    """
    Start the server
    
    Flow:
    1. Get port from config
    2. Create HTTP server
    3. Start listening
    4. Run forever
    """
    port = get_port()
    folder_name = Path(__file__).parent.name
    
    print(f"\n{'='*60}")
    print(f"   {folder_name.upper()}")
    print(f"{'='*60}")
    print(f"   Port: {port}")
    print(f"   URL:  http://localhost:{port}")
    print(f"   Home: {Path(__file__).parent}")
    print(f"{'='*60}\n")
    
    try:
        server = HTTPServer(('0.0.0.0', port), MyAwesomeAppHandler)
        print(f"[{folder_name}] Server running on port {port}")
        server.serve_forever()
    except KeyboardInterrupt:
        print(f"\n[{folder_name}] Server stopped")
        sys.exit(0)
    except Exception as e:
        print(f"[ERROR] {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
```

**Key Takeaways:**
- ✅ `get_port()` reads from config.json (no hardcoding!)
- ✅ Class extends `SimpleHTTPRequestHandler`
- ✅ `directory=str(Path(__file__).parent)` serves current folder
- ✅ `do_GET()`, `do_POST()`, `do_OPTIONS()` handle requests
- ✅ Custom endpoints before `super().do_GET()`
- ✅ CORS headers on all JSON responses

### Step 3: Create index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyAwesomeApp</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-gradient-to-br from-blue-500 to-purple-600 text-white min-h-screen flex items-center justify-center">
    <div class="text-center max-w-md">
        <h1 class="text-5xl font-bold mb-4">MyAwesomeApp</h1>
        <p class="text-xl mb-8">Welcome to your custom application!</p>
        
        <div class="space-y-4">
            <button onclick="testAPI()" class="w-full bg-white text-blue-600 font-bold py-3 px-6 rounded-lg hover:bg-gray-100">
                Test API
            </button>
            <button onclick="loadData()" class="w-full bg-white bg-opacity-20 text-white font-bold py-3 px-6 rounded-lg hover:bg-opacity-30">
                Load Data
            </button>
            <a href="http://localhost:9000" class="block bg-yellow-500 text-black font-bold py-3 px-6 rounded-lg hover:bg-yellow-600">
                Back to Dashboard
            </a>
        </div>
        
        <div id="result" class="mt-8 text-left"></div>
    </div>

    <script>
        async function testAPI() {
            try {
                const response = await fetch('/api/hello');
                const data = await response.json();
                document.getElementById('result').innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
            } catch (error) {
                document.getElementById('result').innerHTML = `<pre style="color: red;">${error}</pre>`;
            }
        }

        async function loadData() {
            try {
                const response = await fetch('/api/data');
                const data = await response.json();
                document.getElementById('result').innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
            } catch (error) {
                document.getElementById('result').innerHTML = `<pre style="color: red;">${error}</pre>`;
            }
        }
    </script>
</body>
</html>
```

### Step 4: Create data.json

```json
{
    "appName": "MyAwesomeApp",
    "version": "1.0.0",
    "data": [],
    "created": "2024-01-21"
}
```

### Step 5: Update config.json

Add your app to NOBITA's config:

```json
{
  "folders": {
    "SampleApp": 9001,
    "CosmicCorner": 9002,
    "MyAwesomeApp": 9003
  },
  "last_port": 9003,
  "metadata": {
    "MyAwesomeApp": {
      "description": "My custom application"
    }
  }
}
```

### Step 6: Restart MainServer

```bash
python MainServer.py
```

Your app will:
- ✅ Be auto-detected
- ✅ Get assigned port 9003
- ✅ Be launched automatically
- ✅ Appear on dashboard
- ✅ Be accessible at http://localhost:9003

---

## Cosmic Corner Example

Cosmic Corner (your sales app) demonstrates:

### **Form Data Collection**
```python
# POST /save receives:
{
    "formName": "Daily Sales",
    "productName": "Laptop",
    "qty": 2,
    "amount": 50000,
    "remarks": "Premium models",
    "image": "data:image/jpeg;base64,/9j/4AAQSk..."
}
```

### **Image Handling**
```python
# Convert base64 to file
header, encoded = body['image'].split(",", 1)
image_data = base64.b64decode(encoded)

# Save to file
with open(f"images/img_{timestamp}.jpeg", 'wb') as f:
    f.write(image_data)

# Store path in JSON
body['image'] = f"images/img_{timestamp}.jpeg"
```

### **Data Persistence**
```python
# Load existing data
with open('data.json', 'r') as f:
    db = json.load(f)

# Add new entry
db.append(body)

# Save back
with open('data.json', 'w') as f:
    json.dump(db, f, indent=4)
```

### **Frontend Integration**
```javascript
// Convert image to base64
const reader = new FileReader();
reader.onload = function(e) {
    document.getElementById('imageInput').dataset.base64 = e.target.result;
};

// Send to server
const response = await fetch('/save', {
    method: 'POST',
    body: JSON.stringify({ image: imageBase64, ... })
});
```

---

## Advanced Patterns

### Pattern 1: Database Integration

```python
import sqlite3

def get_db():
    conn = sqlite3.connect('app.db')
    conn.row_factory = sqlite3.Row
    return conn

def save_entry(entry):
    db = get_db()
    db.execute('INSERT INTO entries (name, value) VALUES (?, ?)',
               (entry['name'], entry['value']))
    db.commit()
    db.close()
```

### Pattern 2: File Upload

```python
def save_file(self):
    content_length = int(self.headers['Content-Length'])
    file_data = self.rfile.read(content_length)
    
    filename = f"uploads/file_{int(time.time())}"
    with open(filename, 'wb') as f:
        f.write(file_data)
    
    return filename
```

### Pattern 3: Authentication

```python
def check_auth(self):
    auth_header = self.headers.get('Authorization', '')
    token = auth_header.replace('Bearer ', '')
    
    if not self.verify_token(token):
        self.send_response(401)
        self.end_headers()
        return False
    return True
```

---

## Testing & Debugging

### Test with curl

```bash
# Test GET endpoint
curl http://localhost:9003/api/hello

# Test POST endpoint
curl -X POST http://localhost:9003/save \
  -H "Content-Type: application/json" \
  -d '{"name": "test", "value": 100}'

# View data.json
curl http://localhost:9003/api/data
```

### Debug with Browser

```javascript
// Open browser console (F12)

// Test API
fetch('/api/hello').then(r => r.json()).then(d => console.log(d))

// Check response headers
fetch('/api/data').then(r => {
    console.log(r.headers);
    return r.json();
})

// Monitor network requests (F12 → Network tab)
```

### Check Server Logs

Look for `[MyAwesomeApp]` messages in MainServer console:

```
[MyAwesomeApp] GET /index.html 200
[MyAwesomeApp] POST /save 200
[MyAwesomeApp] GET /api/data 200
```

---

## Checklist for New Servers

- [ ] Create folder in NOBITA root
- [ ] Create `server.py` with:
  - [ ] `get_port()` function
  - [ ] Custom handler class
  - [ ] `do_GET()` method
  - [ ] `do_POST()` method (if needed)
  - [ ] `do_OPTIONS()` method (CORS)
  - [ ] `main()` function
- [ ] Create `index.html`
- [ ] Create `data.json`
- [ ] Create `icon.png` (optional)
- [ ] Update `config.json`
- [ ] Restart MainServer.py
- [ ] Verify on dashboard
- [ ] Test all endpoints

---

## Summary

You now know how to:

✅ Create custom servers for NOBITA
✅ Handle GET, POST, OPTIONS requests
✅ Store and retrieve data
✅ Upload and handle images
✅ Integrate with the dashboard
✅ Scale your system
✅ Build production-ready apps

**Start building! 🚀**

