# NOBITA Quick Reference Guide

## Start Server
```bash
python MainServer.py
```
Then: **http://localhost:9000**

---

## Dashboard Features

| Feature | How |
|---------|-----|
| **View Servers** | Dashboard shows all servers as cards |
| **Create Server** | Click "New Server" button |
| **Start Server** | Click ▶️ (play) button |
| **Stop Server** | Click ⏹️ (stop) button |
| **Edit Server** | Click ✏️ (edit) button |
| **Delete Server** | Click 🗑️ (delete) button |
| **See Details** | Click ℹ️ (info) button |
| **Open Server** | Click on server card or "Open" button |

---

## Creating a New Server (Easiest Way)

1. Click **"New Server"** button
2. Enter **folder name**: `MyApp` (no spaces!)
3. Leave **port blank** (auto-assign) or enter port number
4. Enter **description** (optional)
5. Click **"Create Server"**

**Done!** Folder created, files auto-generated, server launched.

---

## Creating server.py Manually

```python
#!/usr/bin/env python3
import os, sys, json
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

def get_port():
    config = Path(__file__).parent.parent / "config.json"
    with open(config) as f:
        return json.load(f)["folders"].get("MyApp", 9002)

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)

if __name__ == "__main__":
    HTTPServer(('0.0.0.0', get_port()), Handler).serve_forever()
```

---

## Folder Structure Template

```
MyApp/
├── server.py          ✓ Required (HTTP server)
├── index.html         ✓ Required (frontend)
├── data.json          ✓ Recommended (metadata)
├── icon.png           Optional (dashboard icon)
└── media/             Optional (assets)
    ├── style.css
    ├── script.js
    └── images/
```

---

## Valid Folder Names

```
✓ MyApp
✓ my_app
✓ my-app
✓ MyApp123
✓ test_app_v2

✗ My App       (spaces)
✗ my-app!      (special chars)
✗ .hidden      (starts with dot)
✗ __pycache__  (double underscore)
```

---

## MainServer.py Key Points

### Startup Flow
```
Run MainServer.py
    ↓
Scan NOBITA folder
    ↓
Load config.json
    ↓
Sync new/deleted folders
    ↓
Assign ports (9001, 9002...)
    ↓
Launch each server.py
    ↓
Host dashboard on 9000
```

### Port Assignment
- **Dashboard**: 9000 (fixed)
- **Sub-servers**: 9001, 9002, 9003... (auto)
- **Next new folder**: next available port

### Configuration File
```json
{
  "folders": {
    "SampleApp": 9001,
    "MyApp": 9002
  },
  "last_port": 9002
}
```

---

## API Endpoints

```
GET  /api/servers              List all servers
POST /api/servers              Create server
GET  /api/servers/{name}       Get server info
PUT  /api/servers/{name}       Edit server
DELETE /api/servers/{name}     Delete server
POST /api/servers/{name}/start Start server
POST /api/servers/{name}/stop  Stop server
```

---

## Testing APIs with curl

```bash
# List all servers
curl http://localhost:9000/api/servers

# Get specific server
curl http://localhost:9000/api/servers/SampleApp

# Create server (via dashboard easier!)
curl -X POST http://localhost:9000/api/servers \
  -H "Content-Type: application/json" \
  -d '{"name":"TestApp","port":null,"description":"Test"}'

# Start server
curl -X POST http://localhost:9000/api/servers/TestApp/start

# Stop server
curl -X POST http://localhost:9000/api/servers/TestApp/stop
```

---

## Keyboard Shortcuts

```
Ctrl+N    New server
Ctrl+R    Refresh
Esc       Close modal
```

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Dashboard won't load | Restart MainServer.py |
| Sub-servers not starting | Check console, verify syntax |
| Port already in use | Kill process on that port |
| Can't create server | Use valid name (no spaces) |
| Changes not appearing | Clear browser cache, refresh |

---

## Common Server.py Additions

### Add Custom API
```python
def do_GET(self):
    if self.path == '/api/data':
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"key":"value"}')
    else:
        super().do_GET()
```

### Add CORS Headers
```python
self.send_header('Access-Control-Allow-Origin', '*')
```

### Add Logging
```python
def log_message(self, format, *args):
    print(f"[MyApp] {args[0]}")
```

---

## File: config.json

```json
{
  "folders": {
    "SampleApp": 9001,
    "MyApp": 9002
  },
  "last_port": 9002,
  "metadata": {
    "SampleApp": {
      "description": "Sample application"
    }
  }
}
```

---

## One-Liner Commands

```bash
# Start and open dashboard
python MainServer.py & start http://localhost:9000

# Check if port is free (Windows)
netstat -ano | findstr :9000

# Check if port is free (Mac/Linux)
lsof -i :9000

# Kill process on port (Windows)
taskkill /PID 12345 /F

# Kill process on port (Mac/Linux)
kill -9 12345
```

---

## System Architecture

```
┌─────────────────────────────────────┐
│     MainServer.py (Port 9000)       │
│  - Hosts Dashboard                  │
│  - Manages all servers              │
│  - Handles REST API                 │
└────────────┬────────────────────────┘
             │
    ┌────────┼────────┐
    │        │        │
    ▼        ▼        ▼
┌────────┐ ┌──────┐ ┌──────┐
│9001    │ │9002  │ │9003  │
│Sample  │ │MyApp │ │Test  │
│App     │ │      │ │App   │
└────────┘ └──────┘ └──────┘
(subprocess)(subprocess)(subprocess)
```

---

## FAQ

**Q: Can I run this on Windows?**
A: Yes! Fully compatible with Windows/Mac/Linux

**Q: Do I need to install packages?**
A: No! Uses only Python built-in modules

**Q: How many servers can I run?**
A: Typically 50-100, limited by RAM (each ~50-100MB)

**Q: Can I change the dashboard port?**
A: Yes! Edit `MAIN_PORT = 9000` in MainServer.py

**Q: How do I stop a server?**
A: Click ⏹️ button on dashboard, or restart MainServer.py

**Q: What if a server crashes?**
A: Others keep running. Restart MainServer.py to restart all

**Q: How do I backup my servers?**
A: Copy entire NOBITA folder. Simple as that!

---

## Performance

```
RAM per server:  ~50-100MB
Typical limit:   50-100 servers
Available ports: ~64,000 (1024-65535)
Connection limit: Unlimited per server
```

---

## Best Practices

1. ✅ Always read port from config.json
2. ✅ Use folder name in logs: `[MyApp]`
3. ✅ Create index.html
4. ✅ Add icon.png for professional look
5. ✅ Add data.json with metadata
6. ✅ Test APIs with curl first
7. ✅ Handle shutdown gracefully

---

## Files Included

| File | Purpose |
|------|---------|
| `MainServer.py` | Main orchestrator (800+ lines) |
| `index.html` | Dashboard UI (700+ lines) |
| `config.json` | Port mappings & metadata |
| `SampleApp/server.py` | Example server |
| `SampleApp/index.html` | Example frontend |
| `SETUP_GUIDE.md` | Complete documentation |
| `QUICK_REFERENCE.md` | This file |

---

## Next Steps

1. **Run**: `python MainServer.py`
2. **Visit**: `http://localhost:9000`
3. **Create**: Click "New Server"
4. **Test**: Create a few servers
5. **Learn**: Read SETUP_GUIDE.md
6. **Build**: Create your own servers

---

**Happy hosting! 🚀**
