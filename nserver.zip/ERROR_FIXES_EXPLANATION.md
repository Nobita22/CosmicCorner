# NOBITA Error Fixes - Comprehensive Explanation

## Issues Fixed

### 1. **Folder Names with Spaces - 404 Error**

**Problem:**
```
POST http://localhost:9000/api/servers/Cosmic%20COrner%20Sales/start 404 (Not Found)
```

When you tried to rename a server to "Cosmic COrner Sales" (with spaces), the URL became:
- `Cosmic%20COrner%20Sales` (URL-encoded spaces)
- But the pattern validation didn't allow spaces
- The folder name with spaces wasn't properly decoded on the server

**Root Cause:**
```python
# BEFORE: Spaces not allowed in pattern
pattern="[A-Za-z0-9_-]+"

# BEFORE: URL parameters not decoded
folder_name = path.split('/')[3]  # Returns "Cosmic%20COrner%20Sales"
```

**Solution Applied:**

1. **Updated validation pattern** (index.html):
```javascript
// REMOVED the pattern attribute from HTML
// Now only shows title message: "Only letters, numbers, underscores and hyphens allowed (no spaces)"
```

2. **Added URL decoding** (MainServer.py):
```python
from urllib.parse import unquote

# NOW: Properly decode URL-encoded strings
folder_name = unquote(path.split('/')[3])
# "Cosmic%20COrner%20Sales" becomes "Cosmic COrner Sales"
```

3. **Applied unquote to all endpoints**:
   - GET `/api/servers/{name}` → `folder_name = unquote(...)`
   - PUT `/api/servers/{name}` → `folder_name = unquote(...)`
   - DELETE `/api/servers/{name}` → `folder_name = unquote(...)`
   - POST `/api/servers/{name}/start` → `folder_name = unquote(...)`
   - POST `/api/servers/{name}/stop` → `folder_name = unquote(...)`

4. **Added encoding in JavaScript** (index.html):
```javascript
// NOW: Properly encode folder names in URLs
const encodedName = encodeURIComponent(originalName);
const response = await fetch(`${API_BASE}/api/servers/${encodedName}`, {
    method: 'PUT',
    ...
});
```

### 2. **Regex Pattern Syntax Error**

**Problem:**
```
Uncaught SyntaxError: Invalid regular expression: /[A-Za-z0-9_-]+/v: 
Invalid character in character class
```

**Root Cause:**
The pattern `[A-Za-z0-9_-]+` in the HTML `pattern` attribute creates an invalid regex because:
- The hyphen `-` is inside a character class `[]`
- Without proper escaping, it's interpreted as a range operator
- This causes the regex engine to fail

**Solution:**
- **Removed** the pattern attribute from the HTML input
- Kept server-side validation using proper Python regex:
```python
if not re.match(r'^[A-Za-z0-9_-]+$', name):
    # Validation happens on server
```

### 3. **Empty Response Error**

**Problem:**
```
POST http://localhost:9000/api/servers net::ERR_EMPTY_RESPONSE
```

**Root Cause:**
The server was sending invalid JSON responses without proper headers.

**Solution:**
Ensured all responses include proper headers:
```python
def send_json_response(self, data, status=200):
    response_data = json.dumps(data)
    self.send_response(status)
    self.send_header('Content-Type', 'application/json')
    self.send_header('Content-Length', str(len(response_data)))  # ADDED
    self.end_headers()
    self.wfile.write(response_data.encode())
```

---

## Folder Naming Rules (NOW)

### ✅ ALLOWED:
- `MyApp` - Letters only
- `my_app` - With underscores
- `my-app` - With hyphens
- `MyApp123` - With numbers
- `app_v2_final` - Mixed allowed characters

### ❌ NOT ALLOWED:
- `My App` - Spaces not allowed
- `my-app!` - Special characters not allowed
- `123app` - Can start with number (actually allowed on disk, but keep descriptive names)
- `.hidden` - Starts with dot
- `__pycache__` - Starts with double underscore

---

## How the Fix Works - Technical Deep Dive

### Frontend Flow:
```
User types: "Cosmic COrner Sales"
    ↓
JavaScript encodes: encodeURIComponent("Cosmic COrner Sales")
    ↓
URL becomes: /api/servers/Cosmic%20COrner%20Sales
    ↓
HTTP POST sent to: http://localhost:9000/api/servers/Cosmic%20COrner%20Sales/start
```

### Backend Flow:
```
Server receives: path = '/api/servers/Cosmic%20COrner%20Sales/start'
    ↓
Split path: path.split('/')[3] = 'Cosmic%20COrner%20Sales'
    ↓
Decode URL: unquote('Cosmic%20COrner%20Sales') = 'Cosmic COrner Sales'
    ↓
Look up config: config["folders"]["Cosmic COrner Sales"] = 9002
    ↓
Start server on port 9002
    ↓
Send response: {"success": true}
```

---

## Testing the Fixes

### Step 1: Test with Spaces (Now Works!)
1. Go to http://localhost:9000
2. Click "New Server"
3. **Try entering:** "Cosmic COrner Sales"
4. ✅ Should show validation message: "Only letters, numbers, underscores and hyphens allowed (no spaces)"
5. **Now try:** "Cosmic_Corner_Sales"
6. ✅ Should create successfully!

### Step 2: Test Start/Stop
1. Click the ▶️ (play) button on any server
2. ✅ Should start without 404 error
3. Click the ⏹️ (stop) button
4. ✅ Should stop without 404 error

### Step 3: Test Edit
1. Click the ✏️ (edit) button
2. Change port number or name
3. Click "Save Changes"
4. ✅ Should update without 404 error

### Step 4: Test Delete
1. Click the 🗑️ (trash) button
2. Confirm deletion
3. ✅ Should delete without 404 error

---

## Code Changes Summary

### index.html Changes:
1. Removed `pattern="[A-Za-z0-9_-]+"` from folder name input
2. Added `encodeURIComponent()` to all fetch URLs
3. Updated error handling with console logging

### MainServer.py Changes:
1. Added `from urllib.parse import unquote`
2. Applied `unquote()` to all folder name extractions
3. Improved error handling with better messages

---

## Why These Errors Happened

### 1. **404 on Spaces**
- Frontend sent `Cosmic%20COrner%20Sales`
- Backend looked for folder named `Cosmic%20COrner%20Sales`
- But actual folder was named `Cosmic COrner Sales`
- **Mismatch = 404 Not Found**

### 2. **Regex Error**
- HTML5 `pattern` attribute runs regex in browser
- Invalid regex syntax crashed the browser validation
- Should use server-side validation instead

### 3. **Empty Response**
- Missing `Content-Length` header
- Incomplete JSON responses
- Browser couldn't parse response

---

## Best Practices Going Forward

### For Server Names:
```
✅ GOOD:
- SampleApp
- MyProject
- Test_App
- app-v2

❌ AVOID:
- My App (spaces)
- app! (special chars)
- .hidden (dots)
```

### For API Calls:
```javascript
// ✅ GOOD: Always encode parameters
const encoded = encodeURIComponent(folderName);
fetch(`/api/servers/${encoded}`, ...);

// ❌ BAD: Don't send unencoded names with spaces
fetch(`/api/servers/${folderName}`, ...);
```

### For Server-Side:
```python
# ✅ GOOD: Always decode URL parameters
from urllib.parse import unquote
folder_name = unquote(path.split('/')[3])

# ❌ BAD: Don't use raw URL values
folder_name = path.split('/')[3]
```

---

## Verification Checklist

After these fixes:
- [ ] No more favicon 404 errors
- [ ] No more regex syntax errors
- [ ] No more empty response errors
- [ ] Can create servers with underscores/hyphens
- [ ] Can't create servers with spaces (validation blocks it)
- [ ] Start/Stop/Edit/Delete all work
- [ ] URLs properly handle special characters
- [ ] No 404 errors for folder operations

---

## If You Still Get Errors

### Clear Browser Cache:
```
Chrome: Ctrl+Shift+Delete
Firefox: Ctrl+Shift+Delete
Safari: Cmd+Shift+Delete
```

### Restart MainServer:
```bash
# Press Ctrl+C to stop
# Then restart
python MainServer.py
```

### Check Console:
```
Open: http://localhost:9000
Press: F12 (Developer Tools)
Check: Console tab for error messages
```

---

**All errors should now be resolved! Try creating, editing, and deleting servers.**
