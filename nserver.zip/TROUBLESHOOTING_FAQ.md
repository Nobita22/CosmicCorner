# NOBITA - Troubleshooting & FAQ

## Quick Troubleshooting Checklist

Before diving into detailed solutions, try these quick fixes:

- [ ] **Restart MainServer.py**: `python MainServer.py`
- [ ] **Clear browser cache**: Ctrl+Shift+Delete (Chrome) or Cmd+Shift+Delete (Mac)
- [ ] **Check port availability**: 
  - Windows: `netstat -ano | findstr :9000`
  - Mac/Linux: `lsof -i :9000`
- [ ] **Check console logs**: Look at MainServer.py terminal output
- [ ] **Verify folder exists**: Check NOBITA directory for the folder
- [ ] **Check config.json**: Verify folder is listed with correct port

---

## Common Issues & Solutions

### Issue 1: "Address already in use" Error

**Error Message:**
```
OSError: [Errno 48] Address already in use
or
Address already in use (port 9000)
```

**Why it happens:**
- Another process is already using the port
- MainServer crashed but port still occupied
- Another application using same port

**How to fix:**

**Windows:**
```bash
# Find process on port 9000
netstat -ano | findstr :9000

# Output example:
# TCP    0.0.0.0:9000    0.0.0.0:0    LISTENING    12345

# Kill process (replace 12345 with PID)
taskkill /PID 12345 /F

# Then restart
python MainServer.py
```

**Mac/Linux:**
```bash
# Find process on port 9000
lsof -i :9000

# Output example:
# COMMAND   PID    USER    FD   TYPE             DEVICE SIZE/OFF NODE NAME
# python  12345    user   3u  IPv4 0x123456789     0t0  TCP *:9000 (LISTEN)

# Kill process (replace 12345 with PID)
kill -9 12345

# Then restart
python MainServer.py
```

**Alternative - Use different port:**

Edit MainServer.py:
```python
MAIN_PORT = 9001  # Change from 9000 to 9001
```

Then restart and access: `http://localhost:9001`

---

### Issue 2: Dashboard Won't Load

**Problem:** Browser shows "Cannot connect to localhost:9000"

**Checklist:**

1. **Is MainServer.py running?**
   ```bash
   # Check if running
   # Windows: Ctrl+C in terminal stops it - do you see "SHUTDOWN" message?
   # If no, MainServer isn't running
   
   # Fix: Start it
   python MainServer.py
   ```

2. **Is port 9000 available?**
   ```bash
   # Windows
   netstat -ano | findstr :9000
   # Should be EMPTY if available
   
   # Mac/Linux
   lsof -i :9000
   # Should show nothing if available
   ```

3. **Is Python in PATH?**
   ```bash
   python --version
   # Should show version like: Python 3.9.0
   ```

4. **Is MainServer.py in correct location?**
   ```bash
   # Should be in NOBITA folder, same level as config.json
   ls -la MainServer.py
   # Or in Windows: dir MainServer.py
   ```

5. **Firewall blocking?**
   - Windows: Check Windows Defender Firewall
   - Mac: Check System Preferences > Security & Privacy
   - Temporarily disable to test

---

### Issue 3: Server Appears but Shows "Stopped"

**Problem:** Server card shows running status (green dot) but app won't load

**Possible Causes:**

**A. Port is wrong:**
```json
// In config.json
"MyApp": 9050  // But server might be listening on 9002
```

**Fix:**
- Edit config.json manually
- Verify port matches what server.py expects
- Restart MainServer.py

**B. server.py has errors:**

1. Check manually:
```bash
cd MyApp
python server.py
# If error, you'll see it immediately
```

2. Look for Python syntax errors:
```python
# ✗ Wrong
def get_port()  # Missing colon

# ✓ Correct
def get_port():
```

3. Missing imports:
```python
# ✗ Fails if flask not installed
from flask import Flask

# ✓ Use built-in modules only
from http.server import HTTPServer
```

**C. Process crashed silently:**

1. Check if still running:
```bash
# Windows
tasklist | findstr python
# Look for multiple python.exe processes

# Mac/Linux
ps aux | grep python
# Look for multiple python processes
```

2. Restart MainServer.py:
```bash
python MainServer.py
```

**D. Server exits immediately:**

Check the MainServer.py console output for:
```
[ERROR] Failed to start MyApp: ...
[SKIP] MyApp - No server.py found
```

---

### Issue 4: Can't Create New Server

**Error:** "Failed to create server" notification

**Possible causes:**

**A. Invalid folder name:**
```python
# ✗ Not allowed
"My App"      # Space
"my-app!"     # Special character
"123App"      # Can start with number

# ✓ Allowed
"MyApp"       # Letters only
"my_app"      # Underscore OK
"my-app"      # Hyphen OK
"my_app_v1"   # Numbers OK (not at start)
```

**Fix:** Use only letters, numbers, underscores, hyphens

**B. Folder already exists:**

Check NOBITA directory:
```bash
ls  # or dir on Windows
```

If folder exists with that name, delete it or use different name.

**C. Disk permission error:**

MainServer can't create files. Fix permissions:
```bash
# Mac/Linux
chmod 755 .
chmod 755 ..

# Windows: Run as Administrator
python MainServer.py
```

**D. Port already in use:**

If you specify a port manually:
```bash
# Check if port is free
netstat -ano | findstr :9050

# If found, use different port
```

---

### Issue 5: Server Starts but Can't Access

**Problem:** Server shows "Running" but http://localhost:9001 times out

**Check 1: Is process actually running?**
```bash
# Windows
netstat -ano | findstr :9001

# Mac/Linux
lsof -i :9001

# Should show LISTENING on that port
```

If NOT listening:
- Process crashed
- Used wrong port
- Firewall blocked it

**Check 2: Index.html exists?**
```bash
ls MyApp/index.html
# or dir MyApp/index.html on Windows

# Should exist and have content
```

**Check 3: server.py works standalone?**
```bash
cd MyApp
python server.py

# Should print:
# [MyApp] Running on http://localhost:9002
# (or whatever port)

# Then test in browser or another terminal:
# curl http://localhost:9002
```

**Check 4: Firewall issue?**
- Temporarily disable firewall
- Test if accessible
- If works, add Python to firewall whitelist

---

### Issue 6: Server Won't Stop

**Problem:** Can't stop server from dashboard or it keeps restarting

**Solution 1: Via Dashboard**
1. Click Stop button (red square icon)
2. Wait 5 seconds for graceful shutdown
3. If still running after 5 seconds, it force-kills

**Solution 2: Manual Kill**

Windows:
```bash
# Find python process
tasklist | findstr python

# Kill by PID
taskkill /PID 12345 /F

# Or kill all Python
taskkill /F /IM python.exe
```

Mac/Linux:
```bash
# Find python process
ps aux | grep python

# Kill by PID
kill -9 12345

# Or kill all Python
pkill -f python
```

**Solution 3: Restart MainServer**
```bash
# Press Ctrl+C in MainServer terminal
# It will stop all sub-servers
# Then restart
python MainServer.py
```

---

### Issue 7: Changes to server.py Not Taking Effect

**Problem:** Modified server.py but changes don't appear

**Solution:**
```bash
# The issue: Old server process still running with old code

# Step 1: Stop server via dashboard
# (Click stop button)

# Step 2: Verify it stopped
netstat -ano | findstr :9002  # Should show nothing

# Step 3: Restart via dashboard
# (Click start button)

# OR - Restart MainServer
Ctrl+C in MainServer terminal
python MainServer.py
```

**Alternative: Auto-reload for development**
Install watchdog:
```bash
pip install watchdog
```

Create `watch.py`:
```python
import subprocess
import sys
import time

process = None

def start_server():
    global process
    print("Starting MainServer...")
    process = subprocess.Popen([sys.executable, "MainServer.py"])

start_server()

try:
    while True:
        time.sleep(1)
        if process.poll() is not None:  # Process died
            print("Server stopped, restarting...")
            start_server()
except KeyboardInterrupt:
    print("Shutting down...")
    process.terminate()
```

Run with:
```bash
python watch.py
```

---

### Issue 8: Port Number Keeps Resetting

**Problem:** Changed port in config.json but it reverts on restart

**Cause:** MainServer overwrites config if conflicts detected

**Solution:**

Edit config.json carefully:
```json
{
  "folders": {
    "MyApp": 9050
  },
  "last_port": 9050,  // ← Must match highest port!
  "metadata": {
    "MyApp": {
      "description": "..."
    }
  }
}
```

**Important:** `last_port` must be the highest port number, or MainServer might overwrite your port!

If it keeps reverting:
1. Open config.json in text editor
2. Verify ports are unique
3. Verify last_port is highest
4. Save file
5. Restart MainServer.py

---

### Issue 9: Multiple Python Processes Running

**Problem:** `ps aux | grep python` shows 20+ Python processes

**This is normal!** One for MainServer + one for each server.

Example:
```
MainServer.py      (Port 9000)
MyApp/server.py    (Port 9001)
App2/server.py     (Port 9002)
App3/server.py     (Port 9003)
...
```

That's 5 Python processes for 4 servers (1 main + 3 apps).

**Only worry if:**
- Way more than expected
- Same server listed multiple times
- MainServer not in list

**To clean up:**
```bash
# Kill all and restart
pkill -f python
python MainServer.py
```

---

### Issue 10: JSON Decode Error

**Error:** `json.JSONDecodeError: Expecting value`

**Causes:**

**A. config.json is corrupted:**
```json
// ✗ Wrong - missing comma
{
  "folders": {}
  "last_port": 9001
}

// ✓ Correct
{
  "folders": {},
  "last_port": 9001
}
```

**Fix:**
1. Open config.json in text editor
2. Validate JSON at jsonlint.com
3. Fix syntax errors
4. Save and restart

**B. server.py has bad JSON output:**
```python
# ✗ Wrong - not valid JSON
self.wfile.write(b'{message: hello}')

# ✓ Correct - valid JSON
self.wfile.write(json.dumps({"message": "hello"}).encode())
```

---

## Frequently Asked Questions

### Q1: Can I run NOBITA without Python?

**A:** No, you need Python 3.6+. But it's built-in on most systems.

Download from: https://www.python.org/downloads/

Verify installation:
```bash
python --version
# Should show: Python 3.x.x
```

---

### Q2: Can I change the dashboard port?

**A:** Yes! Edit MainServer.py:

```python
MAIN_PORT = 9000  # Change to any unused port, e.g., 8000
```

Then:
```bash
python MainServer.py
# Access at: http://localhost:8000
```

---

### Q3: Can I run servers on specific ports?

**A:** Yes, two ways:

**Way 1: Via Dashboard**
- Click "New Server"
- Enter port number manually (don't leave blank)
- Creates server on that port

**Way 2: Manually edit config.json**
```json
{
  "folders": {
    "MyApp": 8080,    // Specific port
    "App2": 8081
  },
  "last_port": 8081
}
```

---

### Q4: How many servers can I run?

**A:** Limited by:
- **System RAM**: Each Python process uses ~50MB
- **Available ports**: 65535 - 1024 = ~64,000 ports
- **CPU cores**: Threads share CPU

**Practical limit:** 50-100 servers on modern hardware.

---

### Q5: Can I use databases with NOBITA?

**A:** Yes! Add to your server:

```python
import sqlite3

def get_db():
    conn = sqlite3.connect('data.db')
    return conn
```

Or external databases:
```python
import psycopg2  # PostgreSQL
import mysql.connector  # MySQL
```

---

### Q6: Can I host NOBITA on the internet?

**A:** Yes, but requires:
1. Static IP or domain
2. Port forwarding in router
3. Security (HTTPS, authentication)
4. Firewall rules

**Not recommended for beginners** - use proper hosting instead.

---

### Q7: How do I backup my servers?

**A:** Easy! Backup the NOBITA folder:

```bash
# Windows
xcopy NOBITA NOBITA_backup /I /S /E

# Mac/Linux
cp -r NOBITA NOBITA_backup
```

This includes:
- All server files
- config.json
- MainServer.py

---

### Q8: Can multiple people use NOBITA?

**A:** Not built-in. Options:

1. **Local Network** - Access via IP instead of localhost
   - Find IP: `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
   - Access from other computer: `http://192.168.1.100:9000`

2. **With authentication** - Add username/password to dashboard

3. **Multiple instances** - Each person runs their own MainServer

---

### Q9: How do I update NOBITA?

**A:** Download latest files:

1. Backup current NOBITA folder
2. Download new MainServer.py
3. Download new index.html
4. Keep your server folders (they're separate)
5. Restart

Your servers stay intact!

---

### Q10: What if I break config.json?

**A:** Restore from backup or recreate:

```json
{
  "folders": {},
  "last_port": 9000,
  "metadata": {}
}
```

Then:
1. Restart MainServer.py
2. It will auto-detect your folders
3. Assign ports automatically

---

### Q11: Can I rename a server?

**A:** Yes! Via dashboard:

1. Click Edit (pencil icon)
2. Change folder name
3. Click "Save Changes"
4. Folder renamed automatically

---

### Q12: How do I move NOBITA to another computer?

**A:** Simple:

1. Copy entire NOBITA folder to new computer
2. Install Python 3.6+
3. Run `python MainServer.py`
4. Everything works!

---

### Q13: Why is my server slow?

**Possible causes:**

1. **Too many servers running**
   - Stop unused servers
   - Frees up RAM and CPU

2. **Network latency**
   - Check internet connection
   - Close bandwidth-heavy apps

3. **Inefficient code**
   - Optimize server.py
   - Add caching
   - Use databases efficiently

4. **Disk I/O**
   - Check disk usage: `df -h` (Mac/Linux) or `diskinfo` (Windows)
   - Free up space if low

---

### Q14: Can I password-protect NOBITA?

**A:** Not built-in. Options:

1. **Nginx reverse proxy** - Add auth layer
2. **Custom authentication** - Modify MainServer.py
3. **Network isolation** - Local network only

---

### Q15: What logs are available?

**A:** Logs appear in MainServer.py terminal:

```
[Dashboard] GET /api/servers 200
[SampleApp] GET /index.html 200
[MyApp] POST /api/submit 200
[MyApp] Server stopped
```

Each line shows:
- Server name in brackets
- HTTP method
- Path
- Status code

**To save logs to file:**

Redirect output:
```bash
python MainServer.py > nobita.log 2>&1
```

Or modify MainServer.py to write logs.

---

## Getting Help

If you still have issues:

1. **Check the logs** - Look at MainServer.py terminal output
2. **Read DETAILED_GUIDE.md** - In-depth explanations
3. **Try QUICK_START.md** - Step-by-step guide
4. **Review ARCHITECTURE.md** - Visual diagrams
5. **Copy code from CUSTOM_SERVER_TEMPLATE.py** - Working example

---

## Reporting Issues

If you find a bug:

1. **Describe the problem** - What were you doing?
2. **Expected vs actual** - What should happen vs what happened?
3. **Steps to reproduce** - Can you repeat it?
4. **Error messages** - Copy full error text
5. **System info** - Windows/Mac/Linux, Python version

---

**Happy hosting! 🚀**
