# NOBITA Architecture - Detailed Visual Guide

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         NOBITA System                           │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Port 9000: Dashboard (MainServer.py)                     │  │
│  │ Hosts: index.html                                         │  │
│  │ Handles: REST API, Server Management                      │  │
│  └──────────────────────────────────────────────────────────┘  │
│                              ▲                                   │
│                  ┌───────────┼───────────┐                       │
│                  │           │           │                       │
│         ┌────────▼──┐ ┌──────▼──┐ ┌──────▼──┐                    │
│         │ Port 9001 │ │Port 9002 │ │Port 9003 │ ...              │
│         │ SampleApp │ │  MyApp   │ │ TestApp  │                  │
│         │ server.py │ │server.py │ │server.py │                  │
│         └───────────┘ └──────────┘ └──────────┘                  │
│             (Thread)      (Thread)      (Thread)                  │
└─────────────────────────────────────────────────────────────────┘
```

## Startup Sequence

```
┌─────────────────────────────────────────────────────────────┐
│ Step 1: User runs: python MainServer.py                     │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 2: Load config.json                                    │
│ ├─ Read existing folder-to-port mappings                   │
│ ├─ Example: {"SampleApp": 9001, "MyApp": 9002}             │
│ └─ Get last_port: 9002                                     │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 3: Scan NOBITA folder for subfolders                   │
│ ├─ Find: [SampleApp, MyApp, TestApp]                        │
│ ├─ Exclude: .git, __pycache__, hidden folders               │
│ └─ Only directories (no files)                              │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 4: Synchronize folders with config                     │
│ ├─ New folders? → Assign next port (9003, 9004...)          │
│ ├─ Deleted folders? → Remove from config                    │
│ └─ Update config.json                                       │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 5: Launch server for each folder in separate thread    │
│ ├─ SampleApp/server.py → Listen on 9001                     │
│ ├─ MyApp/server.py → Listen on 9002                         │
│ ├─ TestApp/server.py → Listen on 9003                       │
│ └─ Each runs in separate process                            │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 6: Start MainServer HTTP server                         │
│ ├─ Port: 9000                                                │
│ ├─ Handler: DashboardHandler                                 │
│ └─ Serve: index.html + API endpoints                        │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│ System Ready!                                               │
│ Dashboard: http://localhost:9000                            │
│ SampleApp: http://localhost:9001                            │
│ MyApp: http://localhost:9002                                │
│ etc.                                                         │
└─────────────────────────────────────────────────────────────┘
```

## Request Flow Diagram

### Scenario 1: Dashboard Loads Server List

```
┌─────────────────────────────────────────────────────────────┐
│ User opens: http://localhost:9000                           │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────┐
        │ Browser (index.html)         │
        │ Loads & runs JavaScript      │
        └───────────┬──────────────────┘
                    │
                    │ fetch('/api/servers')
                    │
                    ▼
        ┌──────────────────────────────┐
        │ MainServer.py                │
        │ DashboardHandler.do_GET()    │
        └───────────┬──────────────────┘
                    │
                    │ Check path == '/api/servers'
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Load config.json             │
        │ Get all folder-port pairs    │
        └───────────┬──────────────────┘
                    │
                    │ For each folder:
                    │ ├─ Get status (running/stopped)
                    │ ├─ Get icon path
                    │ └─ Get metadata
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Return JSON response:        │
        │ {                            │
        │   "servers": [               │
        │     {                        │
        │       "name": "SampleApp",   │
        │       "port": 9001,          │
        │       "status": "running",   │
        │       "icon": "/SampleApp/icon.png"
        │     },                       │
        │     ...                      │
        │   ]                          │
        │ }                            │
        └───────────┬──────────────────┘
                    │
                    │ HTTP 200 + JSON
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Browser receives JSON        │
        │ Renders server cards         │
        │ Display on dashboard         │
        └──────────────────────────────┘
```

### Scenario 2: Create New Server

```
┌─────────────────────────────────────────────────────────────┐
│ User clicks: "New Server" button                            │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────┐
        │ Modal dialog opens           │
        │ Input: Folder name, port     │
        └───────────┬──────────────────┘
                    │
                    │ User clicks: "Create"
                    │
                    ▼
        ┌──────────────────────────────┐
        │ fetch POST /api/servers      │
        │ Body: {                      │
        │   "name": "MyApp",           │
        │   "port": null,  (auto)      │
        │   "description": "..."       │
        │ }                            │
        └───────────┬──────────────────┘
                    │
                    ▼
        ┌──────────────────────────────┐
        │ MainServer.py                │
        │ DashboardHandler.do_POST()   │
        └───────────┬──────────────────┘
                    │
                    │ Parse JSON body
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Validate folder name         │
        │ Check not already exists     │
        └───────────┬──────────────────┘
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Create folder structure:     │
        │ 1. mkdir MyApp/              │
        │ 2. Create server.py          │
        │ 3. Create index.html         │
        │ 4. Create data.json          │
        │ 5. mkdir media/              │
        └───────────┬──────────────────┘
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Assign port:                 │
        │ ├─ Get next port (9003)      │
        │ ├─ Update config.json        │
        │ └─ Save to disk              │
        └───────────┬──────────────────┘
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Start server process:        │
        │ subprocess.Popen(            │
        │   python MyApp/server.py     │
        │ )                            │
        └───────────┬──────────────────┘
                    │
                    │ Return success response
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Browser receives response    │
        │ Show notification: "Created!"│
        │ Refresh server list          │
        │ Display new server card      │
        └──────────────────────────────┘
```

### Scenario 3: User Visits Server

```
┌─────────────────────────────────────────────────────────────┐
│ User clicks server card (SampleApp)                         │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────┐
        │ Browser navigates to:        │
        │ http://localhost:9001        │
        └───────────┬──────────────────┘
                    │
                    │ HTTP GET /
                    │
                    ▼
        ┌──────────────────────────────┐
        │ SampleApp/server.py          │
        │ CustomHandler.do_GET()       │
        │ path = "/"                   │
        └───────────┬──────────────────┘
                    │
                    │ Not an API endpoint
                    │ Call super().do_GET()
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Serve static file:           │
        │ SampleApp/index.html         │
        └───────────┬──────────────────┘
                    │
                    │ Return HTML content
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Browser renders HTML         │
        │ Shows server page            │
        │ User sees app running!       │
        └──────────────────────────────┘
```

## Port Assignment Algorithm

```
┌─────────────────────────────────────────────────────────────┐
│ get_next_port(config) Function                              │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────┐
        │ Step 1: Collect used ports   │
        │ Config: {                    │
        │   "folders": {               │
        │     "App1": 9001,            │
        │     "App2": 9002,            │
        │     "App3": 9005             │
        │   }                          │
        │ }                            │
        │                              │
        │ used_ports = {9001, 9002, 9005}
        └───────────┬──────────────────┘
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Step 2: Get starting point   │
        │ last_port = 9005             │
        │ port = 9005 + 1 = 9006       │
        └───────────┬──────────────────┘
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Step 3: Loop until available │
        │                              │
        │ port = 9006                  │
        │ 9006 not in {9001,9002,9005}?│
        │ YES! ✓ Return 9006           │
        │                              │
        │ (If 9006 was used, try 9007) │
        └──────────────────────────────┘

        Example with gaps:
        used_ports = {9001, 9003, 9005}
        last_port = 9005
        port = 9006
        9006 not in used_ports? YES → Return 9006
        
        (It doesn't fill gaps, always increments)
```

## File Structure Created for New Server

```
When user creates "MyApp" via dashboard:

NOBITA/
│
├── config.json (UPDATED)
│   ├─ "MyApp": 9002 (added)
│   └─ "last_port": 9002 (updated)
│
└── MyApp/ (NEW)
    ├── server.py (AUTO-GENERATED)
    │   ├─ Reads port from config.json
    │   ├─ Serves static files
    │   ├─ Logs with [MyApp] prefix
    │   └─ Handles graceful shutdown
    │
    ├── index.html (AUTO-GENERATED)
    │   ├─ Template frontend
    │   ├─ Shows app name and port
    │   ├─ Link to data API
    │   └─ Back button to dashboard
    │
    ├── data.json (AUTO-GENERATED)
    │   ├─ name: "MyApp"
    │   ├─ port: 9002
    │   ├─ created: timestamp
    │   ├─ description: user input
    │   └─ version: "1.0.0"
    │
    ├── icon.png (OPTIONAL)
    │   └─ Displays on dashboard
    │
    └── media/ (AUTO-CREATED)
        ├─ css/
        ├─ js/
        ├─ images/
        └─ ...
```

## Configuration Persistence

```
┌─────────────────────────────────────────────────────────────┐
│ config.json - JSON File Format                              │
└──────────────────────┬──────────────────────────────────────┘
                       │
        ┌──────────────┴──────────────┐
        │                             │
        ▼                             ▼
    ┌─────────────────┐       ┌──────────────────┐
    │ "folders"       │       │ "last_port"      │
    ├─────────────────┤       ├──────────────────┤
    │ Map of:         │       │ Integer          │
    │ name → port     │       │ Highest port     │
    │                 │       │ assigned         │
    │ {               │       │                  │
    │   "App1": 9001, │       │ Used by:         │
    │   "App2": 9002  │       │ ├─ Port increment│
    │ }               │       │ └─ Start port    │
    └─────────────────┘       └──────────────────┘
                              
        ┌──────────────────────────────┐
        │ "metadata"                   │
        ├──────────────────────────────┤
        │ Map of:                      │
        │ name → {description, ...}    │
        │                              │
        │ {                            │
        │   "App1": {                  │
        │     "description": "..."     │
        │   }                          │
        │ }                            │
        └──────────────────────────────┘

Synced to disk on every change:
├─ New server created → save()
├─ Server renamed → save()
├─ Server deleted → save()
└─ Port changed → save()
```

## Subprocess Management

```
┌─────────────────────────────────────────────────────────────┐
│ MainServer.py (Port 9000)                                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  server_processes = {                                      │
│    "SampleApp": {                                           │
│      "process": <Popen object>,                             │
│      "port": 9001,                                          │
│      "pid": 12345                                           │
│    },                                                       │
│    "MyApp": {                                               │
│      "process": <Popen object>,                             │
│      "port": 9002,                                          │
│      "pid": 12346                                           │
│    }                                                        │
│  }                                                          │
│                                                             │
│  subprocess.Popen(                                          │
│    [python, server.py],                                     │
│    start_new_session=True      ← Independent group         │
│  )                                                          │
│                                                             │
│  Each process:                                              │
│  ├─ Running independently                                   │
│  ├─ Can be stopped separately                               │
│  ├─ Listens on its own port                                 │
│  ├─ Has its own stdout/stderr                               │
│  └─ Survives MainServer restart (new_session)              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
   │                        │                        │
   ▼                        ▼                        ▼
┌───────────┐        ┌───────────┐        ┌───────────┐
│SampleApp  │        │   MyApp   │        │ TestApp   │
│ :9001     │        │   :9002   │        │  :9003    │
│ (PID)     │        │  (PID)    │        │  (PID)    │
└───────────┘        └───────────┘        └───────────┘
```

## API Endpoint Routing

```
┌─────────────────────────────────────────────────────────────┐
│ HTTP Request → DashboardHandler                             │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────────────┐
        │ Parse path                           │
        └──────┬─────────────────────────────────┘
               │
               ├─── GET /
               │    ├─ Serve index.html
               │    └─ Display dashboard
               │
               ├─── GET /api/servers
               │    ├─ Load config.json
               │    ├─ Check status for each
               │    └─ Return JSON list
               │
               ├─── POST /api/servers
               │    ├─ Validate name
               │    ├─ Assign port
               │    ├─ Create folder structure
               │    ├─ Update config.json
               │    ├─ Start server
               │    └─ Return success
               │
               ├─── PUT /api/servers/{name}
               │    ├─ Stop if running
               │    ├─ Rename or change port
               │    ├─ Update config.json
               │    ├─ Start if was running
               │    └─ Return success
               │
               ├─── DELETE /api/servers/{name}
               │    ├─ Stop server
               │    ├─ Delete folder
               │    ├─ Remove from config.json
               │    └─ Return success
               │
               ├─── POST /api/servers/{name}/start
               │    ├─ Check if stopped
               │    ├─ Start process
               │    └─ Return success
               │
               ├─── POST /api/servers/{name}/stop
               │    ├─ Check if running
               │    ├─ Stop process gracefully
               │    └─ Return success
               │
               └─── [Other paths]
                    └─ Try to serve as static file
```

## Error Handling Flow

```
┌──────────────────────────────────────────────────────────┐
│ Exception during operation                              │
└────────────────┬─────────────────────────────────────────┘
                 │
                 ▼
     ┌───────────────────────────┐
     │ try-except block captures │
     │ error details             │
     └────────────┬──────────────┘
                  │
                  ├─── File not found
                  │    └─ Return 404
                  │
                  ├─── Port in use
                  │    └─ Return 400 + error msg
                  │
                  ├─── JSON parse error
                  │    └─ Return 400
                  │
                  ├─── Process won't start
                  │    └─ Return 500
                  │
                  └─── Unknown error
                       └─ Return 500 + error msg
                       
Dashboard receives error response:
├─ Read error message
├─ Show notification to user
└─ User can retry or debug
```

## Multi-threaded Request Handling

```
┌─────────────────────────────────────────────────────────────┐
│ ThreadedHTTPServer                                          │
└──────────────────────┬──────────────────────────────────────┘
                       │
        ┌──────────────┴──────────────────────────┐
        │                                         │
        ▼ Request 1                    ▼ Request 2
    ┌────────────┐                ┌────────────┐
    │ Thread A   │                │ Thread B   │
    │ GET /...   │                │ POST /...  │
    └────────────┘                └────────────┘
        │                              │
        │ Can handle                   │ Can handle
        │ simultaneously                simultaneously
        │                              │
        ▼                              ▼
    ┌────────────┐                ┌────────────┐
    │ Response A │                │ Response B │
    │ Ready now  │                │ Ready now  │
    └────────────┘                └────────────┘

No blocking, both requests served in parallel!
```

## Shutdown Sequence

```
┌─────────────────────────────────────────────────────────────┐
│ User presses Ctrl+C or system shutdown signal               │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────┐
        │ cleanup() function called    │
        └───────────┬──────────────────┘
                    │
                    ▼
        ┌──────────────────────────────┐
        │ For each running server:     │
        │ 1. Send SIGTERM signal       │
        │ 2. Wait 5 seconds graceful   │
        │ 3. Force kill if needed      │
        │ 4. Remove from tracking      │
        └───────────┬──────────────────┘
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Stop MainServer HTTP server  │
        └───────────┬──────────────────┘
                    │
                    ▼
        ┌──────────────────────────────┐
        │ Exit cleanly (code 0)        │
        │ All processes terminated     │
        │ Config saved to disk         │
        └──────────────────────────────┘
```

## Data Flow: Creating a Server

```
User Input
    │
    ├─ Folder name: "MyApp"
    ├─ Port: null (auto)
    └─ Description: "My awesome app"
    │
    ▼
┌────────────────────────────────┐
│ JavaScript validates input     │
│ ├─ Name is required            │
│ └─ Name matches pattern        │
└────────┬───────────────────────┘
         │
         │ POST /api/servers
         │ {name, port, description}
         │
         ▼
┌────────────────────────────────┐
│ MainServer backend             │
│ ├─ Parse JSON                  │
│ ├─ Validate name               │
│ ├─ Check not exists            │
│ └─ Assign port                 │
└────────┬───────────────────────┘
         │
         ▼
┌────────────────────────────────┐
│ Create folder structure        │
│ ├─ mkdir MyApp/                │
│ ├─ write server.py             │
│ ├─ write index.html            │
│ ├─ write data.json             │
│ ├─ mkdir media/                │
│ └─ set permissions             │
└────────┬───────────────────────┘
         │
         ▼
┌────────────────────────────────┐
│ Update config.json             │
│ ├─ Add MyApp: 9002             │
│ ├─ Update last_port: 9002      │
│ ├─ Add metadata                │
│ └─ Write to disk               │
└────────┬───────────────────────┘
         │
         ▼
┌────────────────────────────────┐
│ Start server process           │
│ ├─ subprocess.Popen()          │
│ ├─ python MyApp/server.py      │
│ └─ Listen on 9002              │
└────────┬───────────────────────┘
         │
         │ Return JSON: {success, name, port}
         │
         ▼
┌────────────────────────────────┐
│ Browser receives success       │
│ ├─ Show notification           │
│ ├─ Refresh server list         │
│ ├─ Fetch /api/servers          │
│ └─ Display new card            │
└──────────────────────────────────┘
```

---

**This architecture ensures:**
1. ✅ Scalability - Add servers without limits
2. ✅ Independence - Each server runs in isolation
3. ✅ Reliability - Graceful error handling
4. ✅ Persistence - Config survives restarts
5. ✅ Usability - Simple dashboard interface
6. ✅ Extensibility - Easy to add custom endpoints
