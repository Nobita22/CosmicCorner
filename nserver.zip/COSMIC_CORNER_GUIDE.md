# 🌟 Cosmic Corner - Custom Server Setup Guide

## Overview

**Cosmic Corner** is a Sales & Inventory Management System integrated into NOBITA. It demonstrates how to create a custom server with:
- Form data collection
- Image uploads with base64 encoding
- JSON file storage
- CRUD operations (Create, Read, Update, Delete)
- Real-time statistics

---

## 📁 Folder Structure

```
CosmicCorner/
├── server.py           ← HTTP server with custom API
├── index.html          ← Frontend with form and data display
├── data.json           ← Persistent data storage
└── images/             ← Uploaded images folder (auto-created)
```

---

## 🚀 How It Works

### 1. **Server Architecture (server.py)**

The `CosmicCorner/server.py` extends the basic server template with:

#### **Port Configuration**
```python
def get_port():
    # Reads port from MainServer's config.json
    config_path = Path(__file__).parent.parent / "config.json"
    # Returns auto-assigned port (e.g., 9002)
```

**Why?** MainServer.py assigns ports, so your server must read from config.

#### **Directory Setup**
```python
def setup_directories():
    # Creates images/ folder if missing
    # Creates data.json if missing
    # Returns paths for use in handlers
```

#### **Request Handler Classes**

**GET Requests:**
```
GET /                    → Serve index.html
GET /data                → Return all entries as JSON
GET /data/{index}        → Return specific entry
```

**POST Requests:**
```
POST /save               → Add new entry with image
POST /edit               → Update existing entry
POST /delete             → Remove entry
POST /{other}            → Return error 404
```

**Handle Image Upload:**
```python
# Extract base64 image
header, encoded = body['image'].split(",", 1)

# Decode to binary
image_data = base64.b64decode(encoded)

# Save to images/ folder
with open(filepath, 'wb') as img_f:
    img_f.write(image_data)

# Store path in JSON
body['image'] = f"images/{filename}"
```

---

### 2. **Frontend Logic (index.html)**

The form collects:
- **formName** - Name of the form/document
- **productName** - What product/item
- **qty** - Quantity
- **amount** - Price per unit
- **remarks** - Additional notes
- **image** - Product photo
- **timestamp** - Auto-added on save

#### **Form Submission Flow**

```javascript
// 1. User fills form and clicks "Save Entry"
document.getElementById('entryForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    // 2. Convert image to base64
    const formData = {
        formName: "...",
        productName: "...",
        image: document.getElementById('imageInput').dataset.base64,
        timestamp: new Date().toISOString()
    };

    // 3. Send to server
    const response = await fetch(`/save`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
    });

    // 4. Refresh display
    await refreshData();
});
```

#### **Image Handling**

```javascript
// Convert file to base64
document.getElementById('imageInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = function(event) {
        // Store base64 data
        document.getElementById('imageInput').dataset.base64 = event.target.result;
        // Show preview
        document.getElementById('imagePreview').innerHTML = `
            <img src="${event.target.result}" class="image-preview">
        `;
    };
    reader.readAsDataURL(file);
});
```

#### **Display Entries**

```javascript
async function refreshData() {
    // 1. Fetch all entries
    const response = await fetch('/data');
    const entries = await response.json();

    // 2. Loop through and display
    entries.forEach((entry, index) => {
        // Create card with data
        // Add Edit/Delete buttons
    });

    // 3. Update stats
    updateStats(entries);
}
```

---

## 📊 Data Structure (data.json)

```json
[
    {
        "formName": "Daily Sales - 21 Jan",
        "productName": "Laptop",
        "qty": 2,
        "amount": 50000,
        "remarks": "Premium business laptops",
        "image": "images/img_1768973725266.jpeg",
        "timestamp": "2024-01-21T10:30:00.000Z"
    },
    {
        "formName": "Weekly Report",
        "productName": "Monitor",
        "qty": 5,
        "amount": 15000,
        "remarks": "4K Display monitors",
        "image": null,
        "timestamp": "2024-01-21T11:45:00.000Z"
    }
]
```

---

## 🔄 API Endpoints

### **GET /data**
Returns all entries as JSON array

**Request:**
```javascript
fetch('/data').then(r => r.json())
```

**Response:**
```json
[
    { "formName": "...", "productName": "...", ... },
    { "formName": "...", "productName": "...", ... }
]
```

### **POST /save**
Add new entry

**Request:**
```javascript
fetch('/save', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        formName: "Daily Sales",
        productName: "Laptop",
        qty: 2,
        amount: 50000,
        remarks: "Notes...",
        image: "data:image/jpeg;base64,/9j/4AAQSk..." // base64 string
    })
})
```

**Response:**
```json
{
    "status": "ok",
    "message": "Entry saved successfully",
    "index": 0
}
```

### **POST /edit**
Update existing entry

**Request:**
```javascript
fetch('/edit', {
    method: 'POST',
    body: JSON.stringify({
        index: 0,
        productName: "Updated Product",
        qty: 5,
        // ... other fields
    })
})
```

### **POST /delete**
Delete entry by index

**Request:**
```javascript
fetch('/delete', {
    method: 'POST',
    body: JSON.stringify({ index: 0 })
})
```

---

## 🎯 How to Create Your Own Custom Server

### **Step 1: Create Folder**
```bash
mkdir MyCustomApp
cd MyCustomApp
```

### **Step 2: Create server.py**

Use this template:

```python
#!/usr/bin/env python3
"""
MyCustomApp Server
Integrated with NOBITA
"""

import json
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse

# Get port from MainServer's config.json
def get_port():
    config_path = Path(__file__).parent.parent / "config.json"
    if config_path.exists():
        with open(config_path, 'r') as f:
            config = json.load(f)
            folder_name = Path(__file__).parent.name
            port = config.get("folders", {}).get(folder_name)
            if port:
                return port
    return 9999

class CustomHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # Serve files from current folder
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)
    
    def log_message(self, format, *args):
        # Add folder name to logs
        folder = Path(__file__).parent.name
        print(f"[{folder}] {args[0]}")
    
    def do_GET(self):
        # Add your custom GET endpoints here
        # Example:
        if self.path == '/api/hello':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(b'{"message": "Hello from MyCustomApp!"}')
        else:
            # Default: serve static files
            super().do_GET()
    
    def do_POST(self):
        # Add your custom POST endpoints here
        pass
    
    def do_OPTIONS(self):
        # CORS support
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

def main():
    port = get_port()
    folder_name = Path(__file__).parent.name
    
    print(f"\n[{folder_name}] Server running on port {port}")
    
    try:
        server = HTTPServer(('0.0.0.0', port), CustomHandler)
        server.serve_forever()
    except KeyboardInterrupt:
        print(f"\n[{folder_name}] Server stopped")

if __name__ == "__main__":
    main()
```

### **Step 3: Create index.html**

Basic template:

```html
<!DOCTYPE html>
<html>
<head>
    <title>MyCustomApp</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-gradient-to-br from-blue-500 to-purple-600 text-white min-h-screen flex items-center justify-center">
    <div class="text-center">
        <h1 class="text-4xl font-bold mb-4">MyCustomApp</h1>
        <p class="text-xl mb-8">Welcome to your custom application!</p>
        <a href="http://localhost:9000" class="bg-white text-blue-600 px-6 py-2 rounded-lg font-bold hover:bg-gray-100">
            Back to Dashboard
        </a>
    </div>
</body>
</html>
```

### **Step 4: Create data.json**

```json
{
    "appName": "MyCustomApp",
    "version": "1.0.0",
    "data": []
}
```

### **Step 5: Update config.json**

Add your app to NOBITA's config.json:

```json
{
  "folders": {
    "SampleApp": 9001,
    "CosmicCorner": 9002,
    "MyCustomApp": 9003
  },
  "last_port": 9003,
  "metadata": {
    "MyCustomApp": {
      "description": "My custom application"
    }
  }
}
```

### **Step 6: Restart MainServer**

```bash
python MainServer.py
```

Your new app will automatically:
- ✅ Be detected by MainServer
- ✅ Be assigned a port (9003)
- ✅ Be launched automatically
- ✅ Appear on the dashboard
- ✅ Be accessible at http://localhost:9003

---

## 🎨 Key Design Patterns

### **Always Read Port Dynamically**
```python
# ✅ Good
port = get_port()  # Reads from config.json

# ❌ Bad
port = 9002  # Hardcoded!
```

### **Use Folder Name in Logs**
```python
# ✅ Good
folder = Path(__file__).parent.name
print(f"[{folder}] Message")

# ❌ Bad
print("Message")
```

### **Handle CORS**
```python
def do_OPTIONS(self):
    self.send_response(200)
    self.send_header('Access-Control-Allow-Origin', '*')
    self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    self.end_headers()
```

### **Proper Error Handling**
```python
try:
    # Your code here
    pass
except Exception as e:
    print(f"[ERROR] {e}")
    self.send_response(500)
    self.send_header('Content-Type', 'application/json')
    self.end_headers()
    self.wfile.write(json.dumps({"error": str(e)}).encode())
```

---

## 🧪 Testing Your Server

### **1. Start MainServer**
```bash
python MainServer.py
```

### **2. Open Dashboard**
```
http://localhost:9000
```

### **3. Access Your Server**
```
http://localhost:9002  # CosmicCorner
http://localhost:9003  # Your custom app
```

### **4. Test API Endpoints**

Using curl:
```bash
# Get all data
curl http://localhost:9002/data

# Add new entry
curl -X POST http://localhost:9002/save \
  -H "Content-Type: application/json" \
  -d '{"formName":"Test","productName":"Item","qty":1,"amount":100}'

# Edit entry
curl -X POST http://localhost:9002/edit \
  -H "Content-Type: application/json" \
  -d '{"index":0,"qty":5}'

# Delete entry
curl -X POST http://localhost:9002/delete \
  -H "Content-Type: application/json" \
  -d '{"index":0}'
```

---

## 📋 Checklist for Custom Servers

- [ ] Create folder in NOBITA root
- [ ] Create server.py with port reading
- [ ] Create index.html
- [ ] Create data.json
- [ ] Add to config.json
- [ ] Restart MainServer
- [ ] Check dashboard for your app
- [ ] Test API endpoints
- [ ] Test file uploads (if needed)
- [ ] Test CRUD operations

---

## 🎉 You Now Have:

✅ **Cosmic Corner** - Complete sales management system
✅ **Template** - For creating custom servers
✅ **Integration** - Fully integrated with NOBITA
✅ **Examples** - Multiple endpoints and operations
✅ **Documentation** - Complete guides

---

## 🚀 Next Steps

1. **Access Cosmic Corner:**
   ```
   http://localhost:9002
   ```

2. **Create new entries** with forms and images

3. **View statistics** (total entries, amounts, quantities)

4. **Export data** as JSON

5. **Create your own server** using the template provided

---

**Happy coding! 🌟**

