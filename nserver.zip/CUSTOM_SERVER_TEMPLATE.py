#!/usr/bin/env python3
"""
NOBITA Custom Server Template
Use this as a template when creating your own server.py files
"""

import json
import sys
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import time

# ============================================================================
# STEP 1: PORT CONFIGURATION
# ============================================================================
# This function reads the port from MainServer's config.json
# This ensures your server knows which port to listen on

def get_port():
    """
    Read port assignment from MainServer's config.json
    
    How it works:
    1. Look for config.json in parent directory (NOBITA root)
    2. Parse the JSON
    3. Find this folder's name in the "folders" mapping
    4. Return the assigned port
    5. If not found, use default port 9999
    """
    config_path = Path(__file__).parent.parent / "config.json"
    
    if config_path.exists():
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                # Get folder name from current directory
                folder_name = Path(__file__).parent.name
                # Look up port in config
                port = config.get("folders", {}).get(folder_name)
                if port:
                    return port
        except Exception as e:
            print(f"[ERROR] Failed to read port from config: {e}")
    
    # Fallback default port
    return 9999

# ============================================================================
# STEP 2: CUSTOM REQUEST HANDLER
# ============================================================================
# Extend SimpleHTTPRequestHandler to add custom functionality

class CustomHandler(SimpleHTTPRequestHandler):
    """
    HTTP Request Handler with custom logic
    
    Features:
    - Serves static files from current directory
    - Handles custom API endpoints
    - Adds logging with folder name prefix
    """
    
    def __init__(self, *args, **kwargs):
        """
        Initialize the handler
        
        Important:
        - directory=str(Path(__file__).parent) makes it serve files from
          the current folder (e.g., MyApp/ not NOBITA/)
        """
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)
    
    def log_message(self, format, *args):
        """
        Custom logging with folder name prefix
        
        Example output:
        [MyApp] GET /index.html 200
        [MyApp] GET /api/data 200
        """
        folder_name = Path(__file__).parent.name
        print(f"[{folder_name}] {args[0]}")
    
    # ========================================================================
    # GET REQUESTS
    # ========================================================================
    
    def do_GET(self):
        """
        Handle GET requests
        
        Flow:
        1. Parse the URL path
        2. Check if it's a custom API endpoint
        3. If custom: Handle it and return JSON
        4. If not: Serve static file (index.html, css, js, etc.)
        """
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # ====== CUSTOM API: /api/data ======
        if path == '/api/data':
            """
            Return application metadata
            Can be used by frontend to display app info
            """
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            # Check if data.json exists in this folder
            data_path = Path(__file__).parent / "data.json"
            if data_path.exists():
                with open(data_path, 'r') as f:
                    self.wfile.write(f.read().encode())
            else:
                response = {
                    "message": "Application is running",
                    "timestamp": time.time()
                }
                self.wfile.write(json.dumps(response).encode())
        
        # ====== CUSTOM API: /api/status ======
        elif path == '/api/status':
            """
            Return application status
            Example: Used for health checks
            """
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            status = {
                "status": "healthy",
                "uptime": "2 hours 30 minutes",
                "version": "1.0.0",
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.wfile.write(json.dumps(status).encode())
        
        # ====== CUSTOM API: /api/hello ======
        elif path == '/api/hello':
            """
            Simple greeting API
            """
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            response = {
                "message": f"Hello from {Path(__file__).parent.name}!",
                "folder": Path(__file__).parent.name,
                "port": get_port()
            }
            self.wfile.write(json.dumps(response).encode())
        
        # ====== DEFAULT: Serve static files ======
        else:
            """
            For any other path, try to serve static files
            Examples:
            - /index.html -> MyApp/index.html
            - /css/style.css -> MyApp/css/style.css
            - /js/app.js -> MyApp/js/app.js
            """
            super().do_GET()
    
    # ========================================================================
    # POST REQUESTS
    # ========================================================================
    
    def do_POST(self):
        """
        Handle POST requests (e.g., from forms or AJAX)
        """
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # Read request body
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)
        
        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            data = {}
        
        # ====== CUSTOM API: /api/submit ======
        if path == '/api/submit':
            """
            Accept data from frontend
            Example: Save form submission
            """
            print(f"Received data: {data}")
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            response = {
                "success": True,
                "message": "Data received successfully",
                "received": data
            }
            self.wfile.write(json.dumps(response).encode())
        
        # ====== CUSTOM API: /api/process ======
        elif path == '/api/process':
            """
            Process data and return result
            """
            name = data.get('name', 'User')
            age = data.get('age', 0)
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            response = {
                "success": True,
                "message": f"Hello {name}! You are {age} years old.",
                "processed": True
            }
            self.wfile.write(json.dumps(response).encode())
        
        # ====== DEFAULT: 404 ======
        else:
            self.send_response(404)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            response = {"error": "Endpoint not found"}
            self.wfile.write(json.dumps(response).encode())
    
    # ========================================================================
    # OPTIONS REQUESTS (CORS Support)
    # ========================================================================
    
    def do_OPTIONS(self):
        """
        Handle CORS preflight requests
        Required for cross-origin AJAX requests
        """
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()


# ============================================================================
# STEP 3: MAIN SERVER FUNCTION
# ============================================================================

def main():
    """
    Start the HTTP server
    
    Flow:
    1. Get port from config
    2. Create HTTP server instance
    3. Bind to all network interfaces (0.0.0.0)
    4. Start serving requests
    5. Log the startup message
    """
    
    port = get_port()
    folder_name = Path(__file__).parent.name
    
    # Create server
    server = HTTPServer(('0.0.0.0', port), CustomHandler)
    
    print(f"[{folder_name}] Server running on http://localhost:{port}")
    print(f"[{folder_name}] Press Ctrl+C to stop\n")
    
    try:
        # Serve forever until interrupted
        server.serve_forever()
    
    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        print(f"\n[{folder_name}] Shutting down...")
        server.shutdown()
        print(f"[{folder_name}] Server stopped")
        sys.exit(0)
    
    except Exception as e:
        print(f"[ERROR] Server error: {e}")
        sys.exit(1)


# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    main()


# ============================================================================
# USAGE EXAMPLES
# ============================================================================

"""
1. TESTING APIs FROM COMMAND LINE:

# Get data
curl http://localhost:9001/api/data

# Get status
curl http://localhost:9001/api/status

# Get greeting
curl http://localhost:9001/api/hello

# Submit data (POST)
curl -X POST http://localhost:9001/api/submit \
  -H "Content-Type: application/json" \
  -d '{"name": "Alice", "age": 25}'

# Process data (POST)
curl -X POST http://localhost:9001/api/process \
  -H "Content-Type: application/json" \
  -d '{"name": "Bob", "age": 30}'


2. TESTING WITH JAVASCRIPT (AJAX):

// Get data
fetch('http://localhost:9001/api/data')
  .then(r => r.json())
  .then(d => console.log(d))

// Submit data
fetch('http://localhost:9001/api/submit', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({name: 'Charlie', age: 35})
})
  .then(r => r.json())
  .then(d => console.log(d))


3. HOW TO CUSTOMIZE:

a) Change API endpoints:
   - Rename /api/data to /api/myendpoint
   - Add new elif path == '/api/newname': blocks

b) Add database:
   - Import sqlite3 or pymongo
   - Query database in API handlers
   - Return JSON response

c) Add file upload:
   - Parse multipart form data
   - Save uploaded files to media/ folder
   - Return JSON confirmation

d) Add authentication:
   - Check headers for API key
   - Verify user token
   - Return 401 if unauthorized

e) Add logging:
   - Create logs/ folder
   - Write requests to log file
   - Rotate logs daily

f) Add real-time updates:
   - Implement WebSocket support
   - Send events to connected clients
   - Requires additional libraries


4. FOLDER STRUCTURE AFTER CUSTOMIZATION:

MyApp/
├── server.py           (this file)
├── index.html          (frontend)
├── data.json           (metadata)
├── icon.png            (dashboard icon)
├── media/              (assets)
│   ├── logo.png
│   ├── style.css
│   └── script.js
├── logs/               (optional: request logs)
│   └── requests.log
└── database/           (optional: data storage)
    └── app.db


5. PORT MAPPING EXAMPLE:

config.json:
{
  "folders": {
    "SampleApp": 9001,
    "MyApp": 9002,
    "TestApp": 9003
  }
}

Each server reads:
- SampleApp/server.py gets port 9001
- MyApp/server.py gets port 9002
- TestApp/server.py gets port 9003

No hardcoding needed!
"""
