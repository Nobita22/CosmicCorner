# NOBITA Setup & Complete Guide

## Quick Start (30 seconds)

```bash
python MainServer.py
```

Then open: **http://localhost:9000**

---

## What is NOBITA?

NOBITA is a **multi-server hosting system** that lets you:
- Run multiple Python applications simultaneously
- Manage them all from a beautiful web dashboard
- Automatically discover and launch new servers
- Control servers (start/stop/edit/delete) from the UI

---

## System Architecture

```
MainServer.py (Port 9000)
    ↓
    ├─ Dashboard at http://localhost:9000
    ├─ REST API for management
    └─ Launches sub-servers:
        ├─ SampleApp on Port 9001
        ├─ MyApp on Port 9002
        ├─ TestApp on Port 9003
        └─ ... (auto-assigned ports)
```

---

## How MainServer.py Works

### 1. **Startup Process**
```python
initialize_servers()
    ↓
    ├─ scan_folders() → Finds all subfolders
    ├─ load_config() → Reads config.json
    ├─ sync_folders() → Updates folder mappings
    └─ start_server() → Launches each folder's server.py
```

### 2. **Port Assignment**
- **Main Dashboard**: Port 9000 (fixed)
- **Sub-servers**: 9001, 9002, 9003... (auto-assigned)
- New folder = Next available port

### 3. **Configuration Persistence**
Stores in `config.json`:
```json
{
  "folders": {
    "SampleApp": 9001,
    "MyApp": 9002
  },
  "last_port": 9002,
  "metadata": {
    "SampleApp": {"description": "Sample app"}
  }
}
```

### 4. **REST API Endpoints**
| Method | Endpoint | Action |
|--------|----------|--------|
| GET | `/api/servers` | List all servers |
| POST | `/api/servers` | Create new server |
| PUT | `/api/servers/{name}` | Edit server |
| DELETE | `/api/servers/{name}` | Delete server |
| POST | `/api/servers/{name}/start` | Start server |
| POST | `/api/servers/{name}/stop` | Stop server |

---

## Creating a server.py for New Folders

### Method 1: Auto-Generation (Easiest)
1. Click "New Server" in dashboard
2. Enter folder name: `MyApp`
3. Click "Create"
4. Files auto-generated!

### Method 2: Manual Creation

#### Step 1: Create Folder
```bash
mkdir MyApp
cd MyApp
```

#### Step 2: Create server.py
```python
#!/usr/bin/env python3
import os
import sys
import json
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

# Read port from MainServer's config.json
def get_port():
    config_path = Path(__file__).parent.parent / "config.json"
    if config_path.exists():
        with open(config_path, 'r') as f:
            config = json.load(f)
            return config.get("folders", {}).get("MyApp", 9002)
    return 9002

class CustomHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)
    
    def log_message(self, format, *args):
        print(f"[MyApp] {args[0]}")
    
    def do_GET(self):
        if self.path == '/api/data':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            data_path = Path(__file__).parent / "data.json"
            if data_path.exists():
                with open(data_path, 'r') as f:
                    self.wfile.write(f.read().encode())
            else:
                self.wfile.write(b'{"message": "No data"}')
        else:
            super().do_GET()

if __name__ == "__main__":
    port = get_port()
    server = HTTPServer(('0.0.0.0', port), CustomHandler)
    print(f"[MyApp] Running on port {port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
```

#### Step 3: Create index.html
```html
<!DOCTYPE html>
<html>
<head>
    <title>MyApp</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-gray-900 text-white flex items-center justify-center min-h-screen">
    <div class="text-center">
        <h1 class="text-4xl font-bold mb-4">MyApp</h1>
        <p class="text-gray-400 mb-6">Welcome to MyApp!</p>
        <a href="http://localhost:9000" class="px-6 py-2 bg-indigo-600 rounded-lg">
            Back to Dashboard
        </a>
    </div>
</body>
</html>
```

#### Step 4: Create data.json
```json
{
  "name": "MyApp",
  "version": "1.0.0",
  "description": "My custom application"
}
```

#### Step 5: Restart MainServer
```bash
python MainServer.py
```

✅ Done! System auto-detects MyApp and launches it

---

## Detailed MainServer.py Explanation

### Key Functions

#### `load_config()`
- Reads `config.json`
- Returns folder-to-port mappings
- If file missing, returns empty config

#### `save_config(config)`
- Writes config to `config.json`
- Called after any change
- Thread-safe using locks

#### `get_next_port(config)`
- Finds next available port
- Starts from `last_port + 1`
- Skips ports already in use

#### `scan_folders()`
- Lists all subfolders
- Excludes hidden folders (`.` prefix)
- Excludes Python cache (`__pycache__`)

#### `create_folder_structure(folder_name, port, description)`
- Creates folder and media/ subdirectory
- Generates server.py with auto-read port
- Creates index.html template
- Creates data.json metadata
- All files auto-generated

#### `start_server(folder_name, port)`
- Launches server.py as subprocess
- Uses `CREATE_NEW_PROCESS_GROUP` on Windows
- Uses `start_new_session=True` on Unix/Mac
- Tracks process in `server_processes` dict

#### `stop_server(folder_name)`
- Kills subprocess gracefully
- Uses `taskkill` on Windows
- Uses `os.killpg()` on Unix/Mac
- Removes from tracking

#### `get_server_status(folder_name)`
- Checks if process still running
- Returns "running" or "stopped"
- Cleans up terminated processes

#### `sync_folders()`
- Compares disk folders with config
- Adds new folders to config
- Removes deleted folders from config
- Assigns ports automatically

#### `initialize_servers()`
- Called at startup
- Syncs folders with config
- Launches all servers
- Prints startup info

### REST API Handler (DashboardHandler)

#### `do_GET()`
- `/api/servers` → List all servers with status
- `/api/config` → Return config.json
- `/api/servers/{name}` → Get specific server info
- Other paths → Serve static files

#### `do_POST()`
- `/api/servers` → Create new server
- `/api/servers/{name}/start` → Start server
- `/api/servers/{name}/stop` → Stop server
- `/api/refresh` → Re-scan folders

#### `do_PUT()`
- `/api/servers/{name}` → Edit server name/port
- Renames folder if name changes
- Updates port if specified
- Restarts if was running

#### `do_DELETE()`
- `/api/servers/{name}` → Delete server
- Stops if running
- Deletes folder and all files
- Updates config

---

## File Structure

```
NOBITA/
├── MainServer.py                 (Main orchestrator)
├── index.html                    (Dashboard UI)
├── config.json                   (Port mappings)
│
├── SampleApp/                    (Example server)
│   ├── server.py                (Auto-reads port from config)
│   ├── index.html               (Server frontend)
│   ├── data.json                (Server data)
│   ├── icon.png                 (Optional dashboard icon)
│   └── media/                   (Assets folder)
│
└── MyApp/                        (Your custom server)
    ├── server.py
    ├── index.html
    ├── data.json
    └── media/
```

---

## Common Tasks

### Create a Server
1. Click "New Server"
2. Enter name (letters, numbers, _, - only)
3. Leave port blank (auto-assign) or enter specific port
4. Click "Create"

### Start/Stop Server
1. Find server on dashboard
2. Click ▶️ to start or ⏹️ to stop
3. Status updates in real-time

### Edit Server
1. Click ✏️ edit button on server card
2. Change name or port
3. Click "Save Changes"

### Delete Server
1. Click 🗑️ delete button
2. Confirm deletion
3. Folder and all files removed

### Add Server Icon
1. Create image file (PNG/JPG/GIF/SVG)
2. Save as `icon.png` in folder
3. Restart MainServer
4. Icon appears on dashboard

---

## Troubleshooting

### Sub-servers not running
- Check console for error messages
- Verify server.py syntax (no spaces in auto-generated code)
- Check if port is available: `netstat -ano | findstr :PORT`
- Restart MainServer.py

### 404 errors when editing servers
- Fixed in latest version
- Folder names cannot have spaces
- Use only: A-Z, 0-9, underscore, hyphen

### Dashboard won't load
- Ensure MainServer.py is running
- Check if port 9000 is available
- Try: `http://localhost:9000`
- Check firewall settings

### Port conflicts
- Each server needs unique port
- Leave port blank for auto-assignment
- Or manually specify unused port (9050+)

---

## Advanced: Creating Custom APIs

Edit your server.py `do_GET()` method:

```python
def do_GET(self):
    if self.path == '/api/hello':
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(b'{"message": "Hello World"}')
    else:
        super().do_GET()
```

Test with:
```bash
curl http://localhost:9002/api/hello
# Output: {"message": "Hello World"}
```

---

## Best Practices

1. **Always read port from config.json**
   - Don't hardcode ports
   - Use `get_port()` function

2. **Use folder name in logs**
   ```python
   print(f"[MyApp] Message here")
   ```

3. **Handle shutdown gracefully**
   ```python
   try:
       server.serve_forever()
   except KeyboardInterrupt:
       server.shutdown()
   ```

4. **Include index.html**
   - So users see something when they visit

5. **Add icon.png**
   - Makes dashboard look professional

---

## Performance Tips

- Each server uses ~50-100MB RAM
- Can typically run 50-100 servers
- Port range: 1024-65535
- Stop unused servers to free resources

---

## System Requirements

- Python 3.6+
- No external dependencies (uses built-in modules only)
- Windows/Mac/Linux compatible

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+N | New server |
| Ctrl+R | Refresh |
| Esc | Close modal |

---

**That's it! You now have a complete multi-server hosting system!**
